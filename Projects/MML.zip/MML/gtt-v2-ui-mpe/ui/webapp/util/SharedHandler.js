sap.ui.define([
	"sap/ui/core/Fragment"
], function(Fragment) {
	"use strict";

	return {
		getDialog: function() {
			return sap.ui.getCore().byId("dialog");
		},

		onDialogCloseButtonPressed: function() {
			var dialog = this.getDialog();
			dialog.close();
		},

		getPopover: function() {
			return sap.ui.getCore().byId("popover");
		},

		onMessageLogsPropPressed: function(viewName, event, controller) {
			var link, dialog;

			link = event.getSource();

			dialog = this.getDialog();
			if (dialog) {
				dialog.destroy();
			}

			Fragment.load({
				name: "com.sap.gtt.v2.mpe.view." + viewName,
				controller: controller
			}).then(function(dialog) {
				link.addDependent(dialog);
				dialog.open();
			}.bind(link));
		},

		onTrackingIdsPressed: function(event, controller) {
			var link, popover;

			link = event.getSource();
			popover = this.getPopover();

			if (popover !== undefined) {
				popover.destroy();
			}

			Fragment.load({
				name: "com.sap.gtt.v2.mpe.view.TrackingIdList",
				controller: controller
			}).then(function(popover) {
				var binding, len, maxHeight = "18rem";
				link.addDependent(popover);
				binding = link.getBindingContext();
				len = binding.getProperty(binding.getPath() + "/trackingIds").length;
				if (len > 5) {
					popover.setContentHeight(maxHeight);
				}
				popover.openBy(link);
			}.bind(link));
		},
	};
});
