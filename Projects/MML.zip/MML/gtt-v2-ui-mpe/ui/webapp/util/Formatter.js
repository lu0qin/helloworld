sap.ui.define(["sap/ui/core/library"
], function(coreLibrary) {
	"use strict";

	return {
		statusIcon: function(strStatus) {
			var icon = "";
			switch (strStatus) {
			case "SUCCESS":
				icon = "sap-icon://status-positive";
				break;
			case "WARNING":
				icon = "sap-icon://message-warning";
				break;
			case "PENDING":
				icon = "sap-icon://pending";
				break;
			case "ERROR":
				icon = "sap-icon://status-negative";
				break;
			case "NOT_RELEVANT":
				icon = "sap-icon://negative";
				break;
			}
			return icon;
		},

		statusState: function(strStatus) {
			var state = "";
			switch (strStatus) {
			case "SUCCESS":
				state = "Success";
				break;
			case "WARNING":
				state = "Warning";
				break;
			case "PENDING":
				state = "Warning";
				break;
			case "ERROR":
				state = "Error";
				break;
			default:
				state = "None";
			}
			return state;
		},

		trackingIds: function(trackingIds) {
			var model, len;

			if (!Array.isArray(trackingIds)) {
				return "";
			}

			model = this.getOwnerComponent().getModel("messageLog");
			len = trackingIds.length;
			if (len === 1) {
				return model.getProperty("/" + trackingIds[0] + "/trackingId");
			} else if (len > 1) {
				return len + " items";
			} else {
				return "";
			}
		},

		isTrackingIdsClickable: function(aProp) {
			var len, isClickable;

			if (!Array.isArray(aProp)) {
				return false;
			}

			len = aProp.length;
			if (len > 1) {
				isClickable = true;
			} else  {
				isClickable = false;
			}

			return isClickable;
		},

		isMessageLogsPropClickable: function(aProp) {
			var len, isClickable;

			if (!Array.isArray(aProp)) {
				return false;
			}

			len = aProp.length;
			if (len > 0) {
				isClickable = true;
			} else  {
				isClickable = false;
			}

			return isClickable;
		},

		key2Text: function(className, key, context) {
			var _this, model, text;

			if (key === null || key === "") {
				text = "";
			} else {
				_this = !context ? this : context;
				model = _this.getOwnerComponent().getModel("i18n");
				text = model.getProperty(className + "." + key);
			}

			return text;
		},

		applyRouterFormat: function(routerName) {
			var splitter = -1;
			var reg1 = /([A-Z])/g;
			for (var i in routerName) {
				if (reg1.test(routerName[i])) {
					splitter = routerName[i];
					break;
				}
			}

			var arrayOfStrings = routerName.split(splitter);
			return arrayOfStrings[0].toUpperCase().concat("_", splitter, arrayOfStrings[1].toUpperCase());
		},

		getMessageType: function(strStatus) {
			var MessageType = coreLibrary.MessageType;
			var type = "";
			if (!strStatus) {
				return MessageType.None;
			}

			switch (strStatus.toUpperCase()) {
			case "SUCCESS":
				type = MessageType.Success;
				break;
			case "WARNING":
				type = MessageType.Warning;
				break;
			case "PENDING":
				type = MessageType.Warning;
				break;
			case "ERROR":
				type = MessageType.Error;
				break;
			case "NOT_RELEVANT":
				type = MessageType.None;
				break;
			}
			return type;
		},

		statusIconCorrelate: function(strStatus) {
			var icon = "";
			switch (strStatus) {
			case "SUCCESS":
				icon = "sap-icon://status-positive";
				break;
			case "WARNING":
				icon = "sap-icon://message-warning";
				break;
			case "PENDING":
				icon = "sap-icon://pending";
				break;
			case "ERROR":
				icon = "sap-icon://status-negative";
				break;
			case "NOT_RELEVANT":
				icon = "sap-icon://negative";
				break;
			default:
				icon = "sap-icon://status-inactive";
			}
			return icon;
		},

		statusIconColor: function(strStatus, phaseCount) {
			var iconColor = "";
			if (!strStatus || phaseCount === 0) {
				return "Neutral";
			}

			switch (strStatus.toUpperCase()) {
			case "SUCCESS":
				iconColor = "Positive";
				break;
			case "WARNING":
				iconColor = "Critical";
				break;
			case "PENDING":
				iconColor = "Critical";
				break;
			case "ERROR":
				iconColor = "Negative";
				break;
			case "NOT_RELEVANT":
				iconColor = "Neutral";
				break;
			}
			return iconColor;
		},

		eventPageTitle: function(className, eventType) {
			var model = this.getOwnerComponent().getModel("i18n");
			var eventPageTitle = eventType;
			if (className && eventType) {
				eventPageTitle = model.getProperty(className + "." + eventType);
			}
			return eventPageTitle;
		}
	};
});
