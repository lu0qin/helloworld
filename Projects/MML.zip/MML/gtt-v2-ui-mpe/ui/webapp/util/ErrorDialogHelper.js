sap.ui.define([
	"sap/m/MessageBox"
], function(MessageBox) {
	"use strict";

	var oErrorDialogHelper = {
		isMessageOpen: false,
		_oComponent: {}
	};

	oErrorDialogHelper.init = function(options) {
		oErrorDialogHelper._oComponent = options.component;
	};

	oErrorDialogHelper.checkHttpStatus = function(httpStatusCode, httpStatusText, isIgnoreResourceNotFound) {
		var result = {
				isMissingAuthorization: false,
				isError: false
			},
			statusCode = "" + httpStatusCode, // Type cast
			statusText = "" + httpStatusText; // Type cast
		if (!statusCode.match(/^2(.*)/) && statusCode !== "0") {
			if (statusCode === "401" || statusCode === "403") {
				result.isMissingAuthorization = true;
			} else if ((isIgnoreResourceNotFound === false) && statusCode === "404" && (statusText.indexOf("Resource not found") !== -1)) {
				result.isError = true;
			} else {
				result.isError = true;
			}
		}
		return result;
	};

	oErrorDialogHelper.displayErrorMessageBox = function(isMissingAuthorization, isError, errorMessage, detailMessage) {
		if (oErrorDialogHelper.isMessageOpen) {
			return;
		}
		if (isMissingAuthorization) {
			MessageBox.show(errorMessage, {
				title: oErrorDialogHelper._oComponent.getModel("i18n").getResourceBundle().getText("eventDetail.missingAuthorization"),
				onClose: function() {
					oErrorDialogHelper.isMessageOpen = false;
				}.bind(this)
			});
			oErrorDialogHelper.isMessageOpen = true;
		} else if (isError) {
			MessageBox.error(errorMessage, {
				details: detailMessage,
				onClose: function() {
					oErrorDialogHelper.isMessageOpen = false;
				}.bind(this)
			});
			oErrorDialogHelper.isMessageOpen = true;
		}
	};

	oErrorDialogHelper.checkIsRiskyEvent = function(httpStatusCode, errorCode) {
		var statusCode = httpStatusCode + "";
		if (statusCode === "400" && errorCode.indexOf("com.sap.gtt.v2.exception.TrackedProcessCheckException.NewTpIsOld") !== -1) {
			return true;
		}
		return false;
	};

	oErrorDialogHelper.showError = function(event) {
		var sError = "", httpStatusCode, httpStatusText, detailMessage = "", checkResult = {};
		if (event && event.getParameters()) {
			var response = event.getParameters().response;
			if (response && response.responseText) {
				httpStatusCode = response.statusCode;
				httpStatusText = response.statusText;
				checkResult = oErrorDialogHelper.checkHttpStatus(httpStatusCode, httpStatusText, false);
				sError = checkResult.isMissingAuthorization ? response.responseText : (JSON.parse(response.responseText).error.message.value);
			} else {
				sError = response;
			}

			oErrorDialogHelper.displayErrorMessageBox(checkResult.isMissingAuthorization, checkResult.isError, sError, detailMessage);
		}
	};

	oErrorDialogHelper.showErrorForRest = function(event) {
		var sErrorMsg = {}, httpStatusCode, httpStatusText, checkResult = {};
		if (event && event.getParameters()) {
			var parameters = event.getParameters();
			if (parameters && parameters.responseText) {
				var responseText = parameters.responseText;
				httpStatusCode = parameters.statusCode;
				httpStatusText = parameters.statusText;
				checkResult = oErrorDialogHelper.checkHttpStatus(httpStatusCode, httpStatusText, false);

				if (checkResult.isMissingAuthorization) {
					sErrorMsg.message = responseText;
				} else {
					sErrorMsg = oErrorDialogHelper.handleError(responseText);
				}
			}
			oErrorDialogHelper.displayErrorMessageBox(checkResult.isMissingAuthorization, checkResult.isError, sErrorMsg.message, sErrorMsg.detail);
		}
	};

	oErrorDialogHelper.showErrorForCoreEngine = function(response) {
		var sErrorMsg = {}, detailMessage = "", httpStatusCode, httpStatusText;
		if (response && response.response.data) {
			sErrorMsg = response.response.data;

			httpStatusCode = response.status;
			httpStatusText = response.statusText;

			/*if risky event, exit error handling. and let customer choose exit or continue*/
			if (sErrorMsg.error.code) {
				var isRiskyEvent = oErrorDialogHelper.checkIsRiskyEvent(response.response.status, sErrorMsg.error.code);
				if (isRiskyEvent) {
					return isRiskyEvent;
				}
			}

			var checkResult = oErrorDialogHelper.checkHttpStatus(httpStatusCode, httpStatusText, false);
			jQuery.each(sErrorMsg.error.details, function(index, detail) {
				detailMessage += detail.message;
			});
			oErrorDialogHelper.displayErrorMessageBox(checkResult.isMissingAuthorization,
				checkResult.isError,
				sErrorMsg.error.message,
				detailMessage);
		}
		return false;
	};

	oErrorDialogHelper.handleError = function(errorRoot) {
		var sError = "", sErrorDetail = "", detailMessage = "", errorMsg = {};
		if (JSON.parse(errorRoot).error) {
			sError = (JSON.parse(errorRoot).error.message);
			sErrorDetail = (JSON.parse(errorRoot).error.details);
			jQuery.each(sErrorDetail, function(index, detail) {
				detailMessage += detail.message;
			});
			errorMsg = {
				message: sError,
				detail: detailMessage
			};
		}
		return errorMsg;
	};

	return oErrorDialogHelper;
});
