sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/actions/Press",
	"sap/ui/test/matchers/AggregationLengthEquals",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/actions/EnterText",
	"sap/ui/test/matchers/Ancestor",
	"sap/ui/test/matchers/BindingPath"
], function(Opa5, Press, AggregationLengthEquals, PropertyStrictEquals, Ancestor, EnterText) {
	"use strict";

	var processFlowViewName = "ProcessFlow";
	var messageLogListViewName = "MessageLogList";
	var messageLogDetailViewName = "MessageLogDetail";
	var payloadViewName = "Payload";
	var sRequestTable = "tbMessageLog";

	Opa5.extendConfig({
		viewNamespace: "com.sap.gtt.v2.mpe.view.",
		autoWait: true,
		timeout: 120,
		pollingInterval: 500
	 });

	Opa5.createPageObjects({
		onTheMessageLogListPage: {
			actions: {
				// iTypeReceivedAt: function(date) {
				// 	return this.waitFor({
				// 		viewName: messageLogListViewName,
				// 		id: "selectOptionReceivedAt",
				// 		actions: function(oSelectOption){
				// 			oSelectOption.setOperator("EQ");
				// 			oSelectOption.setLow((new Date()).toString());

				// 		},
				// 		success: function(oSelectOptionReceivedAt) {
				// 			Opa5.assert.strictEqual(oSelectOptionReceivedAt.getToken[0].getText(), date);
				// 		}
				// 	});
				// },
				// iSelectSourceType: function(aKey) {
				// 	return this.waitFor({
				// 		viewName: messageLogListViewName,
				// 		id: "mcbSource",
				// 		actions: function(oInput) {
				// 			oInput.setSelectedKeys(aKey);
				// 		},
				// 		success: function(oInput) {
				// 			Opa5.assert.deepEqual(oInput.getSelectedKeys(), aKey);
				// 		}
				// 	})
				// },
				// iClickOnSearchButton: function() {
				// 	return this.waitFor({
				// 		viewName: messageLogListViewName,
				// 		controlType: "sap.m.Button",
				// 		matchers: new PropertyStrictEquals({
				// 			name: "text",
				// 			value: "Go"
				// 		}),
				// 		actions: new Press()
				// 	});
				// },

				iPressLinkForAnItem: function(iItemNumber, tableId, text) {
					return this.waitFor({
						id: tableId,
						viewName: messageLogListViewName,
						success: function(oTable) {
							var aItem = oTable.getItems(); // Table -> items
							var oItem = aItem[iItemNumber];
							return this.waitFor({
								controlType: "sap.m.ObjectAttribute",
								viewName: messageLogListViewName,
								matchers: [new Ancestor(oItem), new PropertyStrictEquals({
									name: "text",
									value: text
								})],
								actions: new Press(),
								errorMessage: "The link popover for item " +
                                    iItemNumber + " cannot be found."
							});
						},
						errorMessage: "Table cannot be found."
					});
				},
				iTypeReceiptTimeFrom: function(date) {
					return this.waitFor({
						viewName: messageLogListViewName,
						id: "dtReceiptTimeFrom",
						actions: function(oDateTimePicker) {
							oDateTimePicker.setDateValue(date);
						},
						success: function(oDateTimePicker) {
							Opa5.assert.strictEqual(oDateTimePicker.getDateValue(), date);
						}
					});
				},
				iTypeReceiptTimeTo: function(date) {
					return this.waitFor({
						viewName: messageLogListViewName,
						id: "dtReceiptTimeTo",
						actions: function(oDateTimePicker){
							oDateTimePicker.setDateValue(date);
						},
						success: function(oDateTimePicker) {
							Opa5.assert.strictEqual(oDateTimePicker.getDateValue(), date);
						}
					});
				},
				iSelectSourceType: function(aKey) {
					return this.waitFor({
						viewName: messageLogListViewName,
						id: "mcbSource",
						actions: function(oInput) {
							oInput.setSelectedKeys(aKey);
						},
						success: function(oInput) {
							Opa5.assert.deepEqual(oInput.getSelectedKeys(), aKey);
						}
					})
				},
				iClickOnSearchButton: function() {
					return this.waitFor({
						viewName: messageLogListViewName,
						controlType: "sap.m.Button",
						matchers: new PropertyStrictEquals({
							name: "text",
							value: "Go"
						}),
						actions: new Press()
					});
				},
				iClickOnTheMessageLogListItem: function() {
					return this.waitFor({
						viewName: messageLogListViewName,
						controlType: "sap.m.ColumnListItem",
						actions: new Press()
					});
				},
				iClickOnTheSortingButton: function() {
					return this.waitFor({
						viewName: messageLogListViewName,
						controlType: "sap.m.Button",
						matchers: {
							propertyStrictEquals: {
								name: "icon",
								value: "sap-icon://sort"
							}
						},
						actions: new Press()
					});
				},
				iClickOnTheOKButonOfDialog: function() {
					return this.waitFor({
						searchOpenDialogs: true,
						viewName: messageLogListViewName,
						controlType: "sap.m.Button",
						matchers: {
							propertyStrictEquals: {
								name: "text",
								value: "OK"
							}
						},
						success: function() {
							Opa5.assert.ok(true);
						},
						actions: new Press()
					});
				},
				iClickOnTheCloseButonOfDialog: function() {
					return this.waitFor({
						searchOpenDialogs: true,
						viewName: messageLogListViewName,
						controlType: "sap.m.Button",
						matchers: {
							propertyStrictEquals: {
								name: "text",
								value: "Close"
							}
						},
						success: function() {
							Opa5.assert.ok(true);
						},
						actions: new Press()
					});
				},
				iClickOnTheColumnSettingButton: function() {
					return this.waitFor({
						viewName: messageLogListViewName,
						controlType: "sap.m.Button",
						matchers: {
							propertyStrictEquals: {
								name: "icon",
								value: "sap-icon://action-settings"
							}
						},
						actions: new Press()
					});
				},
				iClickOnTheRetentionButton: function() {
					return this.waitFor({
						viewName: messageLogListViewName,
						id: "retention",
						actions: new Press()
					});
				},
				iClickOnTheValueHelpButton: function() {
					return this.waitFor({
						viewName: messageLogListViewName,
						id: "miTrackingID",
						actions: new Press()
					});
				},
				iClickOnTheVmButton: function() {
					return this.waitFor({
						viewName: messageLogListViewName,
						id: "pageVariant",
						actions: new Press()
					});
				},
				iClickOnTheVmStandardItem: function() {
					return this.waitFor({
						viewName: messageLogListViewName,
						id: "pageVariant-trigger-item-standard",
						actions: new Press()
					});
				},
				iClickOnTheVmSaveAsButton: function() {
					return this.waitFor({
						viewName: messageLogListViewName,
						id: "pageVariant-saveas",
						actions: new Press()
					});
				},
				iClickOnTheVmSaveButton: function() {
					return this.waitFor({
						viewName: messageLogListViewName,
						id: "pageVariant-variantsave",
						actions: new Press()
					});
				},
				iTypeVariantName: function() {
					var variantName = "New";
					return this.waitFor({
						searchOpenDialogs: true,
						viewName: messageLogListViewName,
						controlType: "sap.m.Input",
						matchers: {
							propertyStrictEquals: {
								name: "value",
								value: "Standard"
							}
						},
						actions: function(oInput) {
							oInput.setValue(variantName);
							oInput.fireChangeEvent();
							oInput.fireChange();
						},
						success: function(oInputs) {
							Opa5.assert.strictEqual(oInputs[0].getValue(), variantName);
						}
					});
				},
				iTypeRententionPeriod: function() {
					// var variantName = "3";
					return this.waitFor({
						searchOpenDialogs: true,
						// controlType: "sap.m.Input",
						id: "retentionPeriod",
						viewName: messageLogListViewName,
						actions:  function(oInput) {
							oInput.setValue("0");
							oInput.fireChangeEvent();
							oInput.fireChange();
						}

						//new EnterText({ text: "User", clearTextFirst: true , pressEnterKey: true, bKeepFocus:false})//,

					});
				},
				iClickOnTheVmManageButton: function() {
					return this.waitFor({
						viewName: messageLogListViewName,
						id: "pageVariant-manage",
						actions: new Press()
					});
				},
			},

			assertions: {
				// iShouldSeeTheEventTypeDialog: function() {
				// 	return this.waitFor({
				// 	viewName: messageLogListViewName,
				// 	id: "dialog",
				// 	matchers: new AggregationLengthEquals({
				// 		name: "items",
				// 		length: 1
				// 	}),
				// 	success: function() {
				// 		Opa5.assert.ok(true);
				// 	}
				//   });
				// },
				iShouldSeeTitleOnThePopoverDialog: function(sTitle) {
					return this.waitFor({
						viewName: messageLogListViewName,
						controlType: "sap.m.Dialog",
						matchers: {
							propertyStrictEquals: {
								name: "title",
								value: sTitle
							}
						},
						success: function() {
							Opa5.assert.ok(true);
						}
					});
				},
				iShouldSeeThePopover: function() {
					return this.waitFor({
						viewName: messageLogListViewName,
						id: "popover",
						success: function(oPopover) {
							if (oPopover){
								Opa5.assert.ok(true,"Popover found");
							}
						}
					});
				},
				iShouldSeeTheFilterBar: function() {
					return this.waitFor({
						viewName: messageLogListViewName,
						id: "messageLogFilterBar",
						success: function() {
							Opa5.assert.ok(true);
						}
					});
				},
				iShouldSeeTheMessageLogListWith2Entries: function() {
					return this.waitFor({
						viewName: messageLogListViewName,
						id: "messageLogTable",
						matchers: new AggregationLengthEquals({
							name: "items",
							length: 2
						}),
						success: function() {
							Opa5.assert.ok(true);
						}
					});
				},
				iShouldSeeTheMessageLogListWith0Entries: function() {
					return this.waitFor({
						viewName: messageLogListViewName,
						id: "tbMessageLog",
						matchers: new AggregationLengthEquals({
							name: "items",
							length: 0
						}),
						success: function() {
							Opa5.assert.ok(true);
						}
					});
				},
				iShouldSeeErrorStateOnRententionPeriod: function() {
					// var variantName = "3";
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Input",
						id: "retentionPeriod",
						viewName: messageLogListViewName,
						success: function(oInput) {
							Opa5.assert.strictEqual(oInput.getValueState(), "Error",
								"The input value state was set as error");
						},
						errorMessage: "The error for input was not set"
					});
				},
				iShouldSeeTheRetentionDialog: function() {
					return this.waitFor({
						searchOpenDialogs: true,
						viewName: messageLogListViewName,
						controlType: "sap.m.Input",
						matchers: {
							propertyStrictEquals: {
								name: "value",
								value: "30"
							}
						}
					});
				},
				iShouldSeeTheVmList: function(len) {
					return this.waitFor({
						viewName: messageLogListViewName,
						id: "pageVariant-list",
						matchers: new AggregationLengthEquals({
							name: "items",
							length: len
						}),
						success: function() {
							Opa5.assert.ok(true);
						}
					});
				}
			}
		},

		onTheMessageLogDetailPage: {
			actions: {
				iClickOnTheProcessFlowNode: function() {
					return this.waitFor({
						viewName: processFlowViewName,
						controlType: "sap.suite.ui.commons.ProcessFlowNode",
						actions: new Press()
					});
				},
				iClickOnTheValidationErrorLabel: function() {
					return this.waitFor({
						viewName: processFlowViewName,
						controlType: "sap.suite.ui.commons.ProcessFlowConnectionLabel",
						actions: new Press()
					});
				},
				iClickOnZoomInButton: function() {
					return this.waitFor({
						viewName: processFlowViewName,
						id: "zoomInButton",
						success: function(oButton) {
							Opa5.assert.ok(oButton);
						},
						actions: new Press()
					});
				},
				iClickOnZoomOutButton: function() {
					return this.waitFor({
						viewName: processFlowViewName,
						id: "zoomOutButton",
						success: function(oButton) {
							Opa5.assert.ok(oButton);
						},
						actions: new Press()
					});
				},
				iClickOnTheTrackingIdsLabel: function() {
					return this.waitFor({
						viewName: messageLogDetailViewName,
						id: "lbTrackingIds",
						success: function(oLabel) {
							Opa5.assert.ok(oLabel);
						},
						actions: new Press()
					});
				},
				iClickOnPayloadTab: function() {
					return this.waitFor({
						viewName: messageLogDetailViewName,
						id: "messageLogDetailPage",
						actions: function(oPage) {
							var section = oPage.getSections()[1];
							oPage.setSelectedSection(section);
							oPage.fireNavigate({
								section: section
							});
						}
					});
				  }
			},

			assertions: {
				itShouldNavToTheMessageLogDetailPage: function() {
					return this.waitFor({
						success: function() {
							var index = sap.ui.test.Opa5.getWindow().location.hash.search("/message-log/");
							Opa5.assert.notEqual(index, -1);
						}
					});
				},
				iShouldSeeThePageHeader: function() {
					return this.waitFor({
						viewName: messageLogDetailViewName,
						controlType: "sap.uxap.ObjectPageHeader",
						matchers: {
							properties: [
								{
									objectTitle: "07f38de0-afa8-11ea-bf88-2bd17f3185d6"
								}
							]
						},
						success: function(oControls) {
							Opa5.assert.strictEqual(oControls.length, 1);
						}
					});
				},
				iShouldSeeTheProcessFlow: function() {
					return this.waitFor({
						viewName: processFlowViewName,
						controlType: "sap.suite.ui.commons.ProcessFlowNode",
						success: function(oNodes) {
							Opa5.assert.strictEqual(oNodes.length, 3);
						}
					});
				},
				iShouldSeeValidationErrorLabel: function() {
					return this.waitFor({
						viewName: processFlowViewName,
						controlType: "sap.suite.ui.commons.ProcessFlowConnectionLabel",
						success: function(oLabel) {
							Opa5.assert.ok(oLabel);
						}
					});
				},
				iShouldSeeValidationErrorDialog: function() {
					return this.waitFor({
						viewName: processFlowViewName,
						controlType: "sap.m.MessageView",
						success: function(oMessageView) {
							Opa5.assert.ok(oMessageView);
						}
					});
				}
			}
		},

		onThePayloadPage: {
			actions: {
				iClickOnCopyButton: function() {
					return this.waitFor({
						viewName: payloadViewName,
						controlType: "sap.m.Button",
						matchers: {
							properties: [
								{
									icon: "sap-icon://copy"
								}
							]
						},
						success: function(oControls) {
							Opa5.assert.strictEqual(oControls.length, 1);
						},
						actions: new Press()
					});
				  }
			},
			assertions: {
				iShouldSeeThePayload: function() {
					return this.waitFor({
						viewName: payloadViewName,
						controlType: "sap.m.Text",
						matchers: {
							properties: [
								{
									text: "abcdef"
								}
							]
						},
						success: function(oControls) {
							Opa5.assert.strictEqual(oControls.length, 1);
						},
						timeout: 40
					});
				}
			}
		}
	});
});
