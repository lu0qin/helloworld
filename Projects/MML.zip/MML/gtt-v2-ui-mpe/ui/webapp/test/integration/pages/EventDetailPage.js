sap.ui.define([
	"sap/ui/test/Opa5",
	"sap/ui/test/matchers/AggregationFilled",
	"sap/ui/test/matchers/BindingPath",
	"sap/ui/test/matchers/PropertyStrictEquals",
	"sap/ui/test/matchers/Properties",
	"sap/ui/test/actions/Press"
], function(Opa5, AggregationFilled, BindingPath, PropertyStrictEquals, Properties, Press, Common) {
	"use strict";


	var sViewName = "EventDetail";
	Opa5.extendConfig({
		viewNamespace: "com.sap.gtt.v2.mpe.view.",
		autoWait: true
	 });
	Opa5.createPageObjects({
		onTheEventDetailPage: {
			// baseClass: Common,

			actions: {
				
				iPressOnTheBackButton : function () {
					return this.waitFor({
						viewName: sViewName,
						success: function () {
						  Opa5.getWindow().history.back();
						},
				  });
				},
				
				iPressOnViewLogsButton: function() {
					return this.waitFor({
						viewName: sViewName,
						controlType: "sap.m.Button",
						matchers: new PropertyStrictEquals({
							name: "text",
							value: "View Logs"
						}),
						actions: new Press(),
						errorMessage: "Does not have a View Logs Button"
					});
				},

				iClickOnPayloadFromEventPage: function() {
					return this.waitFor({
						controlType: "sap.m.IconTabFilter",
						viewName: sViewName,
						matchers: new Properties({
							key: new RegExp("event-payload")
						}),
						actions: new Press(),
						errorMessage: "The tab payload from event detail was not clicked"
					});
				},
				
				iClickOnProcessHistoryFromEventPage: function() {
					return this.waitFor({
						controlType: "sap.m.IconTabFilter",
						viewName: sViewName,
						matchers: new Properties({
							key: "processHistory"
						}),
						actions: new Press(),
						success: function() {
							Opa5.assert.ok(true, "The tab payload from event detail is clicked");
						},
						errorMessage: "The tab payload from event detail was not clicked"
					});
				},

				iClickOnProceedBtn: function() {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Button",
						viewName: sViewName,
						matchers: new Properties({
							text: "Confirm"
						}),
						actions: new Press(),
						success: function() {
							Opa5.assert.ok(true, "The confrim button is clicked");
						},
						errorMessage: "The confirm buttonl is not clicked"
					});
				},

				iClickOnNoBtn: function() {
					return this.waitFor({
						searchOpenDialogs: true,
						controlType: "sap.m.Button",
						viewName: sViewName,
						matchers: new Properties({
							text: "Cancel"
						}),
						actions: new Press(),
						success: function() {
							Opa5.assert.ok(true, "The Cancel button is clicked");
						},
						errorMessage: "The Cancel buttonl is not clicked"
					});
				},
				
				iClickOnRetriggerBtnFromEventPage: function() {
					return this.waitFor({
						controlType: "sap.m.Button",
						viewName: sViewName,
						id: "retriggerId",
						matchers: new Properties({
							text: "Retrigger"
						}),
						actions: new Press(),
						success: function() {
							Opa5.assert.ok(true, "The retrigger button is clicked");
						},
						errorMessage: "The retrigger buttonl is not clicked"
					});
				}
			},
			//assertion
			assertions: {
				iShouldSeeTitleOnEventPage: function(sTitle) {
					return this.waitFor({
						id: "pageTitleId",
						viewName: sViewName,
						matchers: new PropertyStrictEquals({
							name: "text",
							value: sTitle
						}),
						success: function() {
							Opa5.assert.ok(true, "The title is" + sTitle + " as expected");
						},
						errorMessage: "The title is " + sTitle
					});
				},

				iShouldSeeTitleOnEventPageLog: function(sTitle) {
					return this.waitFor({
						id: "logTitle",
						viewName: sViewName,
						matchers: new PropertyStrictEquals({
							name: "text",
							value: sTitle
						}),
						success: function() {
							Opa5.assert.ok(true, "The title is" + sTitle + " as expected");
						},
						errorMessage: "The title is " + sTitle
					});
				},

				iShouldSeeTitleCountOnProcessHistory: function(sTitle) {
					return this.waitFor({
						id: "iconTabBar",
						viewName: sViewName,
						matchers: new PropertyStrictEquals({
							name: "text",
							value: sTitle
						}),
						success: function() {
							Opa5.assert.ok(true, "The title is" + sTitle + " as expected");
						},
						errorMessage: "The title is " + sTitle
					});
				},

				iShouldSeeFieldOnEventPage: function(sId, sValue) {
					return this.waitFor({
						id: sId,
						viewName: sViewName,
						matchers: new PropertyStrictEquals({
							name: "text",
							value: sValue
						}),
						success: function() {
							Opa5.assert.ok(true, "The page contains " + sValue + " field as expected");
						},
						errorMessage: "The title doesn't have field " + sValue
					});
				},

				iShouldSeeTimelineAndCheckInforOnEventPage: function(sId, sValue) {
					return this.waitFor({
						id: "idTimeline",
						viewName: sViewName,
						controlType: "sap.suite.ui.commons.Timeline",
						matchers: new PropertyStrictEquals({
							name: sId,
							value: sValue
						}),
						success: function() {
							Opa5.assert.ok(true, "The timeline control shows " + sId + " and its value is " + sValue);
						},
						errorMessage: "The timeline control doesn't show the " + sId + " as expected " + sValue
					});
				},

				iShouldSeeTimelineItemMessage: function() {
					return this.waitFor({
						viewName: sViewName,
						controlType: "sap.m.ObjectStatus",
						matchers: new PropertyStrictEquals({
							name: "text",
							value: "This phase was successful"
						}),
						success: function() {
							Opa5.assert.ok(true, "The timeline control shows message text successfully");
						},
						errorMessage: "The timeline control doesn't show the message as expected "
					});
				},

				iShouldSeeTimelineItemMessageAsError: function() {
					return this.waitFor({
						viewName: sViewName,
						controlType: "sap.m.ObjectStatus",
						matchers: new PropertyStrictEquals({
							name: "text",
							value: "Swagger Validation Failed"
						}),
						success: function() {
							Opa5.assert.ok(true, "The timeline control shows message text successfully");
						},
						errorMessage: "The timeline control doesn't show the message as expected "
					});
				},

				iShouldSeeTimelineProcessingPhase: function() {
					return this.waitFor({
						viewName: sViewName,
						controlType: "sap.m.ObjectStatus",
						matchers: new PropertyStrictEquals({
							name: "text",
							value: "Event to Action External"
						}),
						success: function() {
							Opa5.assert.ok(true, "The timeline control shows message text successfully");
						},
						errorMessage: "The timeline control doesn't show the message as expected "
					});
				},

				iShouldSeeTrackingPhaseFromProcessingPhase: function() {
					return this.waitFor({
						id: new RegExp("idVPProgressBar"),
						viewName: sViewName,
						matchers: new Properties({
							selectedKey: new RegExp("tracking")
						}),
						success: function() {
							Opa5.assert.ok(true, "The selected key tracking shows up successfully");
						},
						errorMessage: "The selected key tracking doesn't show up as expected "
					});
				},
				
				iShouldSeeBusyWhenStatusPending: function() {
					return this.waitFor({
						id: "eventDetailView",
						viewName: sViewName,
						matchers: function (oPage) {
							return oPage.getBusy();
						},
						autoWait: false,
						success: function (oPage) {
							Opa5.assert.ok(oPage.getBusy(), "The event detail view is busy");
						},
						errorMessage: "The event detail view is not busy"
					});					
				},

				iShouldSeePayloadOnEventPage: function() {
					return this.waitFor({
						viewName: sViewName,
						controlType: "sap.m.Text",
						matchers: new Properties({
							text: new RegExp("QM7CLNT910")
						}),
						success: function(oContrl) {
							Opa5.assert.ok(true, "The payload text shows up successfully");
						},
						errorMessage: "The payload text doesn't show up as expected "
					});
				}
			}
		}
	});
});
