sap.ui.define([
	"sap/ui/test/opaQunit",
	"./pages/MessageLog.pageObject",
	"sap/ushell/services/Container"
], function(opaTest) {
	"use strict";

	var namespace = "com.sap.gtt.v2.mpe";

	sap.ushell.bootstrap("local");

	QUnit.module("Message Logs: Filter | Search | Settings");

	opaTest("Query by default('Received At')", function(Given, When, Then) {
		Given.iStartMyUIComponent({
			componentConfig: {
				name: namespace
			}
		});

		// When.onTheMessageLogListPage.iTypeReceivedAt(new Date());
		// When.onTheMessageLogListPage.iSelectSourceType(["ERP"]);
		// When.onTheMessageLogListPage.iClickOnSearchButton();
		Then.onTheMessageLogListPage.iShouldSeeTheMessageLogListWith2Entries();

		Then.iTeardownMyApp();
	});

	// opaSkip("Sorting & Setting", function(Given, When, Then) {
	// 	Given.iStartMyUIComponent({
	// 		componentConfig: {
	// 			name: namespace
	// 		}
	// 	});

	// 	When.onTheMessageLogListPage.iTypeReceiptTimeFrom(new Date(null));
	// 	When.onTheMessageLogListPage.iTypeReceiptTimeTo(new Date());
	// 	When.onTheMessageLogListPage.iClickOnSearchButton();
	// 	Then.onTheMessageLogListPage.iShouldSeeTheMessageLogListWith2Entries();

	// 	When.onTheMessageLogListPage.iClickOnTheSortingButton();
	// 	When.onTheMessageLogListPage.iClickOnTheOKButonOfDialog();
	// 	Then.onTheMessageLogListPage.iShouldSeeTheMessageLogListWith2Entries();

	// 	When.onTheMessageLogListPage.iClickOnTheColumnSettingButton();
	// 	When.onTheMessageLogListPage.iClickOnTheOKButonOfDialog();
	// 	Then.onTheMessageLogListPage.iShouldSeeTheMessageLogListWith2Entries();

	// 	Then.iTeardownMyApp();
	// });

	opaTest("Retention Dialog", function(Given, When, Then) {
		Given.iStartMyUIComponent({
			componentConfig: {
				name: namespace
			}
		});

		When.onTheMessageLogListPage.iClickOnTheRetentionButton();
		Then.onTheMessageLogListPage.iShouldSeeTheRetentionDialog();
		When.onTheMessageLogListPage.iClickOnTheCloseButonOfDialog();

		Then.iTeardownMyApp();
	});

	opaTest("Retention Dialog Input", function(Given, When, Then) {
		Given.iStartMyUIComponent({
			componentConfig: {
				name: namespace
			}
		});

		When.onTheMessageLogListPage.iClickOnTheRetentionButton();
		Then.onTheMessageLogListPage.iShouldSeeTheRetentionDialog();
		// When.onTheMessageLWogListPage.iTypeRententionPeriod();
		When.onTheMessageLogListPage.iClickOnTheOKButonOfDialog();

		Then.iTeardownMyApp();
	});

	opaTest("Retention Dialog Invalid Input", function(Given, When, Then) {
		Given.iStartMyUIComponent({
			componentConfig: {
				name: namespace
			}
		});

		When.onTheMessageLogListPage.iClickOnTheRetentionButton();
		Then.onTheMessageLogListPage.iShouldSeeTheRetentionDialog();
		When.onTheMessageLogListPage.iTypeRententionPeriod();
		// Then.onTheMessageLogListPage.iShouldSeeErrorStateOnRententionPeriod();
		When.onTheMessageLogListPage.iClickOnTheOKButonOfDialog();
		When.onTheMessageLogListPage.iClickOnTheCloseButonOfDialog();

		Then.iTeardownMyApp();
	});

	// opaSkip("Value Help", function(Given, When, Then) {
	// 	Given.iStartMyUIComponent({
	// 		componentConfig: {
	// 			name: namespace
	// 		}
	// 	});

	// 	When.onTheMessageLogListPage.iClickOnTheValueHelpButton();
	// 	When.onTheMessageLogListPage.iClickOnTheOKButonOfDialog();

	// 	Then.iTeardownMyApp();
	// });

	opaTest("Select the Standard from variant list", function(Given, When, Then) {
		Given.iStartMyUIComponent({
			componentConfig: {
				name: namespace
			}
		});

		When.onTheMessageLogListPage.iClickOnTheVmButton();
		Then.onTheMessageLogListPage.iShouldSeeTheVmList(1);

		When.onTheMessageLogListPage.iClickOnTheVmStandardItem();
		Then.onTheMessageLogListPage.iShouldSeeTheFilterBar();

		Then.iTeardownMyApp();
	});

	// opaTest("Save a new variant", function(Given, When, Then) {
	// 	Given.iStartMyUIComponent({
	// 		componentConfig: {
	// 			name: namespace
	// 		}
	// 	});

	// 	When.onTheMessageLogListPage.iClickOnTheVmButton();
	// 	Then.onTheMessageLogListPage.iShouldSeeTheVmList(1);

	// 	When.onTheMessageLogListPage.iClickOnTheVmSaveAsButton();
	// 	When.onTheMessageLogListPage.iTypeVariantName();
	// 	When.onTheMessageLogListPage.iClickOnTheVmSaveButton();

	// 	Then.iTeardownMyApp();
	// });

	opaTest("Manage a new variant", function(Given, When, Then) {
		Given.iStartMyUIComponent({
			componentConfig: {
				name: namespace
			}
		});

		When.onTheMessageLogListPage.iClickOnTheVmButton();
		Then.onTheMessageLogListPage.iShouldSeeTheVmList(1);

		When.onTheMessageLogListPage.iClickOnTheVmManageButton();
		When.onTheMessageLogListPage.iClickOnTheOKButonOfDialog();

		Then.iTeardownMyApp();
	});



	QUnit.module("Message Log");

	opaTest("Message Log: Page Header & tab on the Payload", function(Given, When, Then) {
		Given.iStartMyUIComponent({
			componentConfig: {
				name: namespace
			},
			hash: "/message-log/07f38de0-afa8-11ea-bf88-2bd17f3185d6"
		});

		Then.onTheMessageLogDetailPage.iShouldSeeThePageHeader();
		Then.onTheMessageLogDetailPage.iShouldSeeTheProcessFlow();

		When.onTheMessageLogDetailPage.iClickOnPayloadTab();
		Then.onThePayloadPage.iShouldSeeThePayload();
		When.onThePayloadPage.iClickOnCopyButton();

		Then.iTeardownMyApp();
	});

	opaTest("Process Flow chart", function(Given, When, Then) {
		Given.iStartMyUIComponent({
			componentConfig: {
				name: namespace
			},
			hash: "/message-log/07f38de0-afa8-11ea-bf88-2bd17f3185d6"
		});

		Then.onTheMessageLogDetailPage.iShouldSeeTheProcessFlow();
		When.onTheMessageLogDetailPage.iClickOnZoomOutButton();
		When.onTheMessageLogDetailPage.iClickOnZoomInButton();

		When.onTheMessageLogDetailPage.iClickOnTheProcessFlowNode();

		Then.iTeardownMyApp();
	});

	opaTest("Message Log: Check Validation Error of Process Flow", function(Given, When, Then) {
		Given.iStartMyUIComponent({
			componentConfig: {
				name: namespace
			},
			hash: "/message-log/07f38de0-afa8-11ea-bf88-2bd17f3185d6"
		});

		Then.onTheMessageLogDetailPage.iShouldSeeValidationErrorLabel();

		When.onTheMessageLogDetailPage.iClickOnTheValidationErrorLabel();
		Then.onTheMessageLogDetailPage.iShouldSeeValidationErrorDialog();

		Then.iTeardownMyApp();
	});

	// opaTest("Message Log | TrackingIds Popover", function(Given, When, Then) {
	// 	Given.iStartMyUIComponent({
	// 		componentConfig: {
	// 			name: namespace
	// 		},
	// 		hash: "/message-log/e2a4688c-bd20-11ea-ae0f-e95d6d541137"
	// 	});

	// 	When.onTheMessageLogDetailPage.iClickOnTheTrackingIdsLabel();

	// 	Then.iTeardownMyApp();
	// });

	opaTest("Navigate", function(Given, When, Then) {
		Given.iStartMyUIComponent({
			componentConfig: {
				name: namespace
			}
		});

		// When.onTheMessageLogListPage.iTypeReceiptTimeFrom(new Date(null));
		// When.onTheMessageLogListPage.iTypeReceiptTimeTo(new Date());
		// When.onTheMessageLogListPage.iClickOnSearchButton();
		// Then.onTheMessageLogListPage.iShouldSeeTheMessageLogListWith2Entries();

		When.onTheMessageLogListPage.iClickOnTheMessageLogListItem();
		Then.onTheMessageLogDetailPage.itShouldNavToTheMessageLogDetailPage();

		Then.iTeardownMyApp();
	});

});
