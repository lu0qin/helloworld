sap.ui.define([
	"sap/ui/test/opaQunit",
	"./pages/EventDetailPage",
	"./pages/Browser"
], function(opaTest) {
	"use strict";

	QUnit.module("EventDetail");

	opaTest("click event payload tab on icon tab bar", function(Given, When, Then) {
		// Arrangements
		Given.iStartMyUIComponent({
			componentConfig: {
				name: "com.sap.gtt.v2.mpe",
				async: true
			},
			hash: "/event/644da64a-480d-4343-971a-4a05826b14f6",
			timeout: 60,
			autoWait: true
		});

		//Action
		When.onTheEventDetailPage.iClickOnPayloadFromEventPage();
		// Assertions
		Then.onTheEventDetailPage.iShouldSeePayloadOnEventPage();
		//action
		When.onTheEventDetailPage.iClickOnProcessHistoryFromEventPage();
		// Assertions
		Then.onTheEventDetailPage.iShouldSeeTimelineItemMessageAsError();

		// Cleanup
		// Then.iTeardownMyUIComponent();
		Then.iTeardownMyApp();
	});

	opaTest("Should see the event detail page and check header detail", function(Given, When, Then) {
		// Arrangements
		Given.iStartMyUIComponent({
			componentConfig: {
				name: "com.sap.gtt.v2.mpe",
				async: true
			},
			hash: "/event/644da64a-480d-4343-971a-4a05826b14f6",
			timeout: 60,
			autoWait: true
		});

		// Assertions
		Then.onTheEventDetailPage.iShouldSeeTitleOnEventPage("644da64a-480d-4343-971a-4a05826b14f6");
		Then.onTheEventDetailPage.iShouldSeeFieldOnEventPage("trackingId","0000001610");
		Then.onTheEventDetailPage.iShouldSeeFieldOnEventPage("modelId","com.gttsampleso01.gtt.app.shipment");
		Then.onTheEventDetailPage.iShouldSeeFieldOnEventPage("eventType","shipment.shipmentEvent");
		// Then.onTheEventDetailPage.iShouldSeeFieldOnEventPage("lastProcessingPhase","Event to Action");
		Then.onTheEventDetailPage.iShouldSeeFieldOnEventPage("altKey","xri://sap.com/id:LBN#10013165:QM7CLNT910:SHP_NO:0000001610");
		Then.onTheEventDetailPage.iShouldSeeFieldOnEventPage("locationAltKey","xri://sap.com/id:LBN#10013165:QM7CLNT910:SHP_NO:0000001610");
		Then.onTheEventDetailPage.iShouldSeeFieldOnEventPage("logStatus","Error");

		// Cleanup
		// Then.iTeardownMyUIComponent();
		Then.iTeardownMyApp();
	});

	opaTest("Should see the timeline conrol on event detail page", function(Given, When, Then) {
		// Arrangements
		Given.iStartMyUIComponent({
			componentConfig: {
				name: "com.sap.gtt.v2.mpe",
				async: true
			},
			hash: "/event/644da64a-480d-4343-971a-4a05826b14f6",
			timeout: 60,
			autoWait: true
		});

		// Assertions
		Then.onTheEventDetailPage.iShouldSeeTimelineItemMessageAsError();

		// Cleanup
		// Then.iTeardownMyUIComponent();
		Then.iTeardownMyApp();
	});

	opaTest("Should see the event detail on event detail page", function(Given, When, Then) {
		// Arrangements
		Given.iStartMyUIComponent({
			componentConfig: {
				name: "com.sap.gtt.v2.mpe",
				async: true
			},
			hash: "/event/644da64a-480d-4343-971a-4a05826b14f6",
			timeout: 60,
			autoWait: true
		});

		// Assertions
		When.onTheEventDetailPage.iPressOnViewLogsButton();
		// Assertions
		Then.onTheEventDetailPage.iShouldSeeTitleOnEventPageLog("Logs (1)");

		// Cleanup
		Then.iTeardownMyApp();
	});

	opaTest("Should see the timeline control page on event correlation page", function(Given, When, Then) {
		// Arrangements
		Given.iStartMyUIComponent({
			componentConfig: {
				name: "com.sap.gtt.v2.mpe",
				async: true
			},
			hash: "/event-correlation/b9df6e7a-9ad6-4897-8c4f-dc3e9f7cc5b3",
			timeout: 60,
			autoWait: true
		});

		// Assertions
		Then.onTheEventDetailPage.iShouldSeeTimelineItemMessageAsError();

		// Cleanup
		Then.iTeardownMyApp();
	});

	opaTest("Should see the process history increase after click retrigger and proceed button", function(Given, When, Then) {
		// Arrangements
		Given.iStartMyUIComponent({
			componentConfig: {
				name: "com.sap.gtt.v2.mpe",
				async: true
			},
			hash: "/event/644da64a-480d-4343-971a-4a05826b14f6",
			timeout: 60,
			autoWait: true
		});

		//Action
		When.onTheEventDetailPage.iClickOnRetriggerBtnFromEventPage();
		When.onTheEventDetailPage.iClickOnProceedBtn();
		Then.onTheEventDetailPage.iShouldSeeTimelineItemMessageAsError();

		// Cleanup
		Then.iTeardownMyApp();

	});

	opaTest("Should see the process history increase after click retrigger button and cancel", function(Given, When, Then) {
		// Arrangements
		Given.iStartMyUIComponent({
			componentConfig: {
				name: "com.sap.gtt.v2.mpe",
				async: true
			},
			hash: "/event/644da64a-480d-4343-971a-4a05826b14f6",
			timeout: 60,
			autoWait: true
		});

		//Action
		When.onTheEventDetailPage.iClickOnRetriggerBtnFromEventPage();
		When.onTheEventDetailPage.iClickOnNoBtn();
		// Assertions
		Then.onTheEventDetailPage.iShouldSeeTimelineItemMessageAsError();

		// Cleanup
		Then.iTeardownMyApp();
	});
	
	opaTest("Should see the busy when pending on event correlation page", function(Given, When, Then) {
		// Arrangements
		Given.iStartMyUIComponent({
			componentConfig: {
				name: "com.sap.gtt.v2.mpe",
				async: true
			},
			hash: "/event-correlation/b9df6e7a-9ad6-4897-8c4f-dc3e9f7cc5b6",
			timeout: 60,
			autoWait: true
		});

		// Assertions
		Then.onTheEventDetailPage.iShouldSeeBusyWhenStatusPending();
		
		// Actions
		When.onTheBrowser.iChangeTheHashToTheThirdProduct();

		// Cleanup
		Then.iTeardownMyApp();
	});
});
