sap.ui.define([
	"com/sap/gtt/v2/mpe/test/mockService/mockserver",
	"com/sap/gtt/v2/mpe/test/integration/MessageLog.journey",
	"com/sap/gtt/v2/mpe/test/integration/EventDetailJouney"
], function(mockserver) {
	"use strict";

	mockserver.init();
});
