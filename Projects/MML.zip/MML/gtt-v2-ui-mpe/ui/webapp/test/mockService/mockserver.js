sap.ui.define([
	"sap/ui/core/util/MockServer",
	"sap/ui/model/json/JSONModel",
	"sap/base/Log"
], function(MockServer, JSONModel, Log) {
	"use strict"; //NOSONAR

	// var oMockServerInterface = {
	return {
		/**
		 * Initializes the mock server.
		 * You can configure the delay with the URL parameter "serverDelay".
		 * The local mock data in this folder is returned instead of the real data for testing.
		 * @public
		 */

		init: function(oOptionsParameter) {
			var oOptions = oOptionsParameter || {};
			oOptions.componentName = "com.sap.gtt.v2.mpe";
			return new Promise(
				function(fnResolve, fnReject) {
					var sManifestUrl = "../manifest.json";
					if (oOptions.componentName) {
						sManifestUrl = sap.ui.require.toUrl(
							oOptions.componentName.replace(/\./g, "/").concat("/manifest.json")
						);
					}

					var oManifestModel = new JSONModel(sManifestUrl);

					oManifestModel.attachRequestCompleted(function() {
						var componentName = oManifestModel.getProperty("/sap.app/id");

						oOptions.componentName = componentName;
						oOptions.appPath = componentName
							.replace(/\./g, "/")
							.concat("/");

						 // token service
						 this._initTokenMockServer(
							"csrfService",
							oOptions,
							oManifestModel
						  );

						this._initODataMockServer(
							"messageLogService",
							oOptions,
							oManifestModel
						);

						this._initJsonMockServer(
							oOptions,
							oManifestModel
						);

						Log.info("Running the app with mock data");
						fnResolve();
					}, this);

					oManifestModel.attachRequestFailed(function() {
						var sError = "Failed to load application manifest";

						Log.error(sError);
						fnReject(new Error(sError));
					  });
				}.bind(this)
			);
		},

		_initTokenMockServer: function(dataSourceName, oOptions, oManifestModel) {
			// token service
			var oMockServer = new MockServer({
					  rootUri: "/",
					  requests: [
					{
						  method: "HEAD",
						  path: /token.json(?:\?.+)?/, // "token.json?_=1234567"
						  response: function(oXhr) {
							oXhr.respond(200, {
							  "X-CSRF-Token": "csrf_token_" + Date.now(),
							});
							return true;
						  },
					},
					  ],
			});

			oMockServer.start();

			return oMockServer;
		},

		_initJsonMockServer: function( oOptions, oManifestModel) {
			var sAppPath = oOptions.appPath;

			var processFlowRequest = {
				method: "GET",
				path: new RegExp("processFlow(.*)"),
				response: function(oXhr) {
					var sLocalUri = sap.ui.require.toUrl(sAppPath + "test/mockService/mockdata/processFlow.json");
					oXhr.respondFile(200, {}, sLocalUri);
					return true;
				}
			};

			var validationErrorRequest = {
				method: "GET",
				path: new RegExp("MessageDetail(.*)"),
				response: function(oXhr) {
					var sLocalUri = sap.ui.require.toUrl(sAppPath + "test/mockService/mockdata/MessageDetail.filter=isValidationError.json");
					oXhr.respondFile(200, {}, sLocalUri);
					return true;
				}
			};

			var payloadRequest = {
				method: "GET",
				path: new RegExp("getProcessFlowPayLoad(.*)"),
				response: function(oXhr) {
					var sLocalUri = sap.ui.require.toUrl(sAppPath + "test/mockService/mockdata/Payload.json");
					oXhr.respondFile(200, {}, sLocalUri);
					return true;
				}
			};

			// add a mockserver for REST
			var eventPayloadsRequest = {
				method: "GET",
				path: new RegExp("eventPayloads(.*)"),
				response: function(oXhr) {
					var sLocalUri = sap.ui.require.toUrl(sAppPath + "test/mockService/mockdata/EventPayloads.json");
					oXhr.respondFile(200, {}, sLocalUri);
					return true;
				}
			};

			// add a mockserver for REST
			var retriggerRequest = {
				method: "POST",
				path: new RegExp("retrigger(.*)"),
				response: function(oXhr) {
					if (oXhr && oXhr.url.indexOf("force=false") > -1) {
						var sLocalUri = sap.ui.require.toUrl(sAppPath + "test/mockService/mockdata/RetriggerError.json");
						oXhr.respondFile(400, {"status":400,"statusText":"Bad Request"}, sLocalUri);
						return true;
					}
					var sLocalUri = sap.ui.require.toUrl(sAppPath + "test/mockService/mockdata/EventPayloads.json");
					oXhr.respondFile(200, {}, sLocalUri);
					return true;
				}
			};

			// add a mockserver for REST
			var retentionSettingGetRequest = {
				method: "GET",
				path: new RegExp("retentionSetting(.*)"),
				response: function(oXhr) {
					var sLocalUri = sap.ui.require.toUrl(sAppPath + "test/mockService/mockdata/retentionSetting.json");
					oXhr.respondFile(200, {}, sLocalUri);
					return true;
				}
			};

			// add a mockserver for REST
			var retentionSettingPostRequest = {
				method: "POST",
				path: new RegExp("retentionSetting(.*)"),
				response: function(oXhr) {
					var sLocalUri = sap.ui.require.toUrl(sAppPath + "test/mockService/mockdata/retentionSetting.json");
					oXhr.respondFile(200, {}, sLocalUri);
					return true;
				}
			};

			var oMockServer = new MockServer({
				rootUri:jQuery.sap.getModulePath(sAppPath) + "/data/sap/logistics/gtt/mpe/rest/v1/",
				requests: [
					eventPayloadsRequest,
					processFlowRequest,
					validationErrorRequest,
					payloadRequest,
					retriggerRequest,
					retentionSettingGetRequest,
					retentionSettingPostRequest
				]
			});

			oMockServer.start();
		},

		_initODataMockServer: function(dataSourceName, oOptions, oManifestModel) {
			var sAppPath = oOptions.appPath;
			var sMetadataUrl = sap.ui.require.toUrl(sAppPath + "test/mockService/metadata.xml");
			var sJsonFilesUrl = sap.ui.require.toUrl(sAppPath + "test/mockService/mockdata");
			var	oMockServer = new MockServer({
				rootUri: (jQuery.sap.getModulePath(sAppPath) + "/data/sap/logistics/gtt/mpe/odata/v1/com.sap.gtt.app.mpe.MessageLogs/").replace("/base/", "")
			});

			// configure mock server with a delay of 1s
			MockServer.config({
				autoRespond: true,
				autoRespondAfter: 1000
			});

			oMockServer.simulate(sMetadataUrl, {
				sMockdataBaseUrl: sJsonFilesUrl,
				bGenerateMissingMockData: true
			});

			var aRequests = oMockServer.getRequests();
			aRequests.push({
				method: "GET",
				path: new RegExp("ProcessHistory(.*)"),
				response: function(oXhr) {
					if (oXhr && oXhr.url.indexOf("43ab601c-281f-4516-bf69-d352dfe83633") > -1) {
						var sLocalUri1 = jQuery.sap.getModulePath(sAppPath + "test/mockService/mockdata/VPProcessHistory.json".replace(".json", ""), ".json");
						var VPProcessHistoryFile = jQuery.sap.sjax({
							url: sLocalUri1,
							dataType: "json"
						}).data;
						oXhr.respondJSON(200, {}, VPProcessHistoryFile);
						return true;	
					}
					var sLocalUri = jQuery.sap.getModulePath(sAppPath + "test/mockService/mockdata/ProcessHistory.json".replace(".json", ""), ".json");
					var ProcessHistoryFile = jQuery.sap.sjax({
						url: sLocalUri,
						dataType: "json"
					}).data;
					oXhr.respondJSON(200, {}, ProcessHistoryFile);
					return true;
				}
			});

			aRequests.push({
				method: "GET",
				path: new RegExp("MessageDetail(.*)"),
				response: function(oXhr) {
					var sLocalUri, MessageDetailFile;

					if (oXhr && oXhr.url.indexOf("EVENT_CORRELATION") > -1) {
						sLocalUri = jQuery.sap.getModulePath(sAppPath + "test/mockService/mockdata/EventCorrelation.json".replace(".json", ""), ".json");
					} else if (oXhr && oXhr.url.indexOf("PROCESS_EVENT") > -1) {	
						if (oXhr && oXhr.url.indexOf("2f299791-4bfc-4b6f-a737-81a0c3eb2988") > -1) {
							sLocalUri = jQuery.sap.getModulePath(sAppPath + "test/mockService/mockdata/VPProcessEvent.json".replace(".json", ""), ".json");
						}  else {
							sLocalUri = jQuery.sap.getModulePath(sAppPath + "test/mockService/mockdata/ProcessEvent.json".replace(".json", ""), ".json");
						}				
						
					} else {
						sLocalUri = jQuery.sap.getModulePath(sAppPath + "test/mockService/mockdata/MessageDetail.json".replace(".json", ""), ".json");
					}
					MessageDetailFile = jQuery.sap.sjax({
						url: sLocalUri,
						dataType: "json"
					}).data;
					oXhr.respondJSON(200, {}, MessageDetailFile);
					return true;
				}
			});

			aRequests.push({
				method: "GET",
				path: new RegExp("EventHistory(.*)"),
				response: function(oXhr) {
					var sLocalUri;
					if (oXhr && oXhr.url.indexOf("644da64a-480d-4343-971a-4a05826b14f6") > -1) {
						sLocalUri = jQuery.sap.getModulePath(sAppPath + "test/mockService/mockdata/EventHistory.json".replace(".json", ""), ".json");
					} else if (oXhr && oXhr.url.indexOf("b9df6e7a-9ad6-4897-8c4f-dc3e9f7cc5b3") > -1) {
						sLocalUri = jQuery.sap.getModulePath(sAppPath + "test/mockService/mockdata/EventHistory.json".replace(".json", ""), ".json");
					}  else if (oXhr && oXhr.url.indexOf("b9df6e7a-9ad6-4897-8c4f-dc3e9f7cc5b6") > -1) {
						sLocalUri = jQuery.sap.getModulePath(sAppPath + "test/mockService/mockdata/EventHistoryPending.json".replace(".json", ""), ".json");
					}
					var EventHistoryFile = jQuery.sap.sjax({
						url: sLocalUri,
						dataType: "json"
					}).data;
					oXhr.respondJSON(200, {}, EventHistoryFile);
					return true;
				}
			});

			oMockServer.setRequests(aRequests);
			oMockServer.start();
		}

	};
});