sap.ui.define([
	"sap/ui/core/util/MockServer"
], function(MockServer) {
	"use strict";

	return {

		init: function() {
			var oMockServer = new MockServer({
				rootUri: "/data/sap/logistics/gtt/mpe/odata/v1/com.sap.gtt.app.mpe.MessageLogs/"
			});

			MockServer.config({
				autoRespond: true,
				autoRespondAfter: 500
			});

			var sPath = sap.ui.require.toUrl("com/sap/gtt/v2/mpe/test/mockService");
			oMockServer.simulate(sPath + "/metadata.xml", {
				sMockdataBaseUrl: sPath + "/mockdata",
				bGenerateMissingMockData: true
			});

			oMockServer.start();
		}
	};

});
