sap.ui.define(function() {
	"use strict";

	return {
		defaults: {
			coverage: {
				only: ["com/sap/gtt/v2/mpe"],
			},
			loader: {
				paths: {
					"com/sap/gtt/v2/mpe": "/base/webapp"
				}
			}
		},

		tests: {
			"unitTest": {
				module: "./unit/unitTestSuite.qunit",
				title: "SAP MML Unit Test"
			},
			"opaTest": {
				module: "./integration/AllJourneys",
				title: "SAP MML OPA Test"
			}
		}
	};
});
