sap.ui.define([
	"./util/Formatter.qunit",
	"./util/ErrorDialogHelper.qunit"
], function() {
	"use strict";
});