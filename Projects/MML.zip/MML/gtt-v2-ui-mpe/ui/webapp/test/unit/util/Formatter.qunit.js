sap.ui.define([
	"com/sap/gtt/v2/mpe/util/Formatter"
], function(Formatter) {
	"use strict";

	QUnit.module("Formater: Status Icon");

	QUnit.test("Should format status SUCCESS to sap-icon://status-positive", function(assert) {
		assert.strictEqual(Formatter.statusIcon("SUCCESS"), "sap-icon://status-positive");
	});

	QUnit.test("Should format status WARNING to sap-icon://message-warning", function(assert) {
		assert.strictEqual(Formatter.statusIcon("WARNING"), "sap-icon://message-warning");
	});

	QUnit.test("Should format status NOT_RELEVANT to sap-icon://negative", function(assert) {
		assert.strictEqual(Formatter.statusIcon("NOT_RELEVANT"), "sap-icon://negative");
	});

	QUnit.test("Should format status ERROR to sap-icon://status-negative", function(assert) {
		assert.strictEqual(Formatter.statusIcon("ERROR"), "sap-icon://status-negative");
	});

	QUnit.test("Default format", function(assert) {
		assert.strictEqual(Formatter.statusIcon(""), "");
	});


	QUnit.module("Formater: Status State");

	QUnit.test("Should format status SUCCESS to 'Success'", function(assert) {
		assert.strictEqual(Formatter.statusState("SUCCESS"), "Success");
	});

	QUnit.test("Should format status WARNING to 'Warning'", function(assert) {
		assert.strictEqual(Formatter.statusState("WARNING"), "Warning");
	});

	QUnit.test("Should format status ERROR to 'Error'", function(assert) {
		assert.strictEqual(Formatter.statusState("ERROR"), "Error");
	});

	// QUnit.test("Should format status NOT_RELEVANT to 'Not Relevent'", function(assert) {
	// 	assert.strictEqual(Formatter.statusState("NOT_RELEVANT"), "Not Relevent");
	// });

	QUnit.test("Default format", function(assert) {
		assert.strictEqual(Formatter.statusState(""), "None");
	});

	QUnit.module("Formater: get Message Type");

	QUnit.test("Should format Message Type to standard", function(assert) {
		assert.strictEqual(Formatter.getMessageType("SUCCESS"), sap.ui.core.MessageType.Success);
	});

	QUnit.test("Should format status WARNING to 'Warning'", function(assert) {
		assert.strictEqual(Formatter.getMessageType("WARNING"), sap.ui.core.MessageType.Warning);
	});

	QUnit.test("Should format status ERROR to 'Error'", function(assert) {
		assert.strictEqual(Formatter.getMessageType("ERROR"), sap.ui.core.MessageType.Error);
	});

	QUnit.test("Message type is PENDING", function(assert) {
		assert.strictEqual(Formatter.getMessageType("PENDING"), sap.ui.core.MessageType.Warning);
	});

	QUnit.test("Message type is null", function(assert) {
		assert.strictEqual(Formatter.getMessageType(), sap.ui.core.MessageType.None);
	});

	QUnit.test("Default format", function(assert) {
		assert.strictEqual(Formatter.getMessageType(""), "None");
	});

	QUnit.module("Formater: status Icon for event Correlation");

	QUnit.test("Should format status SUCCESS to sap-icon://status-positive", function(assert) {
		assert.strictEqual(Formatter.statusIconCorrelate("SUCCESS"), "sap-icon://status-positive");
	});

	QUnit.test("Should format status WARNING to sap-icon://message-warning", function(assert) {
		assert.strictEqual(Formatter.statusIconCorrelate("WARNING"), "sap-icon://message-warning");
	});

	QUnit.test("Should format status ERROR to sap-icon://status-negative", function(assert) {
		assert.strictEqual(Formatter.statusIconCorrelate("ERROR"), "sap-icon://status-negative");
	});

	QUnit.test("Should format status PENDING to sap-icon://pending", function(assert) {
		assert.strictEqual(Formatter.statusIconCorrelate("PENDING"), "sap-icon://pending");
	});

	QUnit.test("Default format sap-icon://status-inactive", function(assert) {
		assert.strictEqual(Formatter.statusIconCorrelate(""), "sap-icon://status-inactive");
	});


	QUnit.module("Formater: status Icon's color");

	QUnit.test("Should format status SUCCESS and count = 1 to Positive", function(assert) {
		assert.strictEqual(Formatter.statusIconColor("SUCCESS", 1), "Positive");
	});

	QUnit.test("Should format status WARNING and count = 1 to Critical", function(assert) {
		assert.strictEqual(Formatter.statusIconColor("WARNING", 1), "Critical");
	});

	QUnit.test("Should format status ERROR and count = 1 to Negative", function(assert) {
		assert.strictEqual(Formatter.statusIconColor("ERROR", 1), "Negative");
	});

	QUnit.test("Should format status ERROR and count = 0 to Neutral ", function(assert) {
		assert.strictEqual(Formatter.statusIconColor("ERROR", 0), "Neutral");
	});

	QUnit.test("Should format status undefined and count = 1 to Neutral ", function(assert) {
		assert.strictEqual(Formatter.statusIconColor("PENDING", 1), "Critical");
	});

	QUnit.test("Should format status undefined and count = 1 to Neutral ", function(assert) {
		assert.strictEqual(Formatter.statusIconColor(undefined, 1), "Neutral");
	});

	QUnit.test("Default format Neutral", function(assert) {
		assert.strictEqual(Formatter.statusIconColor("abc", 2), "");
	});
});
