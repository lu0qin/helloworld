sap.ui.define([
	"sap/ui/core/UIComponent",
	"com/sap/gtt/v2/mpe/util/ErrorDialogHelper",
	"sap/m/MessageBox"
], function (UIComponent, ErrorDialogHelper, MessageBox) {
	"use strict";

	var sandbox = sinon.createSandbox();

	function stub(object, method, func) {
		if (!(method in object)) {
			object[method] = function () { };
		}

		var stubbed = sandbox.stub(object, method);

		if (typeof func === "function") {
			return stubbed.callsFake(func);
		}

		return stubbed;
	}

	QUnit.module("com.sap.gtt.v2.mpe.util.ErrorDialogHelper", {
		beforeEach: function () {

		},
		afterEach: function () {
			sandbox.restore();
		}
	});


	QUnit.test("checkHttpStatus - missing authorization", function (assert) {
		// Act
		var result = ErrorDialogHelper.checkHttpStatus(401, "Unauthorized", false);

		// Assert
		assert.ok(result.isMissingAuthorization === true, "The missing authorization check is correct");
	});

	QUnit.test("checkHttpStatus - 404 resource not found", function (assert) {
		// Act
		var result = ErrorDialogHelper.checkHttpStatus(404, "Resource not found", false);

		// Assert
		assert.ok(result.isError === true, "Resource not found is checked");
	});

	
	QUnit.test("checkHttpStatus - 500  system internal error", function (assert) {
		// Act
		var result = ErrorDialogHelper.checkHttpStatus(500, "system internal error", false);

		// Assert
		assert.ok(result.isError === true, "System internal error is checked");
	});

	QUnit.test("displayErrorMessageBox - the message box is open", function (assert) {
		// Arrange
		var component = {};		
		var options = {
			component: component
		};

		// Act
		ErrorDialogHelper.init(options);

		// Arrange
		ErrorDialogHelper.isMessageOpen === true;

		// Act
		var val = ErrorDialogHelper.displayErrorMessageBox(false, false, "", "");

		// Assert
		assert.ok(val === undefined, "The error message box has already opened.");
	});

	// QUnit.test("displayErrorMessageBox - Missing authorization", function (assert) {
	// 	var component = {};
	// 	var options = {
	// 		component: component
	// 	};
	// 	var fakeResourceModel = {};
	// 	var fakeBundle = {};
	// 	stub(fakeBundle, "getText").withArgs("eventDetail.missingAuthorization").returns("Authorization");
	// 	var fakePromise = Promise.resolve(fakeBundle);

	// 	stub(fakeResourceModel, "getResourceBundle").returns(fakePromise);
	// 	stub(component, "getModel")
	// 		.withArgs("i18n").returns(fakeResourceModel);

	//   		// // Arrange
	// 	// var resourceModel = new sap.ui.model.resource.ResourceModel({
	// 	//   bundleName: "com.sap.gtt.v2.cpe.i18n.i18n"
	// 	// });
	// 	// var fakeComponent = {};
	// 	// stub(fakeComponent, "getModel").withArgs("i18n").returns(resourceModel);


	// 	// Act
	// 	ErrorDialogHelper.init(options);

	// 	// Arrange
	// 	stub(MessageBox, "show");

	// 	// Act
	// 	ErrorDialogHelper.displayErrorMessageBox(true, false, "", "");
	// 	MessageBox.show.firstCall.args[1].onClose();

	// 	// Assert
	// 	assert.ok(ErrorDialogHelper.isMessageOpen === false, "Message box is opened by missing authorization error.");
	// });

	QUnit.test("displayErrorMessageBox - Other errors", function (assert) {
		// Arrange
		var component = {};
		var options = {
			component: component
		};
		var fakeResourceModel = {};
		var fakeBundle = {};
		stub(fakeBundle, "getText").withArgs("eventDetail.missingAuthorization").returns("Authorization");
		var fakePromise = Promise.resolve(fakeBundle);

		stub(fakeResourceModel, "getResourceBundle").returns(fakePromise);
		stub(component, "getModel")
			.withArgs("i18n").returns(fakeResourceModel);

		// Act
		ErrorDialogHelper.init(options);

		// Arrange
		ErrorDialogHelper.isMessageOpen = false;
		stub(MessageBox, "show");

		// Act
		ErrorDialogHelper.displayErrorMessageBox(false, true, "", "");
		MessageBox.show.firstCall.args[1].onClose();

		// Assert
		assert.ok(ErrorDialogHelper.isMessageOpen === false, "Message box is opened by other error.");
	});

	QUnit.test("showError - Missing Authorization", function (assert) {
		var component = {};
		var options = {
			component: component
		};

		// Arrange
		var fakeEvent = {};
		var parameters = {
			response: {
				responseText: "Unauthorized",
				statusCode: "401",
				statusText: "Unauthorized"
			}
		};
		stub(fakeEvent, "getParameters").returns(parameters);
		stub(ErrorDialogHelper, "checkHttpStatus").returns({
			isMissingAuthorization: true,
			isError: false
		});
		stub(ErrorDialogHelper, "displayErrorMessageBox").returns();


		// Act
		ErrorDialogHelper.init(options);

		// Act
		ErrorDialogHelper.showError(fakeEvent);

		// Assert
		assert.ok(ErrorDialogHelper.displayErrorMessageBox.calledOnce, "The error message box was called.");
	});

	QUnit.test("showError - 504 error", function (assert) {
		var component = {};
		var options = {
			component: component
		};

		// Arrange
		var fakeEvent = {};
		var parameters = {
			response: {
				statusText: "Bad Request",
				statusCode: "504",
				responseText: "{\"error\":{\"code\":\"com.sap.gtt.v2.exception.MetadataException.NotFound\",\"message\":\"com.sap.gtt.app is not found.\",\"details\":[]}}"
			}
		};
		stub(fakeEvent, "getParameters").returns(parameters);
		stub(ErrorDialogHelper, "checkHttpStatus").returns({
			isMissingAuthorization: true,
			isError: true
		});
		stub(ErrorDialogHelper, "displayErrorMessageBox").returns();


		// Act
		ErrorDialogHelper.init(options);

		// Act
		ErrorDialogHelper.showError(fakeEvent);

		// Assert
		assert.ok(ErrorDialogHelper.displayErrorMessageBox.calledOnce, "The error message box was called.");
	});

	QUnit.test("showError", function (assert) {
		// Arrange
		var component = {};
		var options = {
			component: component
		};
		
		var fakeEvent = {};
		var parameters = {
			response: {
				statusText: "Bad Request",
				statusCode: "500",
				responseText: "{\"error\":{\"code\":\"com.sap.gtt.v2.exception.MetadataException.NotFound\",\"message\":\"com.sap.gtt.app is not found.\",\"details\":[]}}"
			}
		};
		stub(fakeEvent, "getParameters").returns(parameters);
		stub(ErrorDialogHelper, "checkHttpStatus").returns({
			isMissingAuthorization: true,
			isError: true
		});
		stub(ErrorDialogHelper, "displayErrorMessageBox").returns();

		// Act
		ErrorDialogHelper.init(options);
		ErrorDialogHelper.showError(fakeEvent);

		// Assert
		assert.ok(ErrorDialogHelper.displayErrorMessageBox.calledOnce, "The error message box was called.");
	});


	QUnit.test("showErrorForRest - 504 error", function (assert) {
		// Arrange
		var component = {};
		var options = {
			component: component
		};
		
		var fakeEvent = {};
		var parameters = {
			statusText: "Bad Request",
			statusCode: "504",
			responseText: "{\"error\":{\"code\":\"com.sap.gtt.v2.exception.MetadataException.NotFound\",\"message\":\"com.sap.gtt.app is not found.\",\"details\":[]}}"
		};
		stub(fakeEvent, "getParameters").returns(parameters);
		stub(ErrorDialogHelper, "checkHttpStatus").returns({
			isMissingAuthorization: false,
			isError: true
		});
		stub(ErrorDialogHelper, "displayErrorMessageBox").returns();


		// Act
		ErrorDialogHelper.init(options);

		// Act
		ErrorDialogHelper.showErrorForRest(fakeEvent);

		// Assert
		assert.ok(ErrorDialogHelper.displayErrorMessageBox.calledOnce, "The error message box was called.");
	});

	
	QUnit.test("showErrorForRest - Authorization", function (assert) {
		// Arrange
		var component = {};
		var options = {
			component: component
		};
		
		var fakeEvent = {};
		var parameters = {
			statusText: "Bad Request",
			statusCode: "403",
			responseText: "{\"error\":{\"code\":\"com.sap.gtt.v2.exception.MetadataException.NotFound\",\"message\":\"com.sap.gtt.app is not found.\",\"details\":[]}}"
		};
		stub(fakeEvent, "getParameters").returns(parameters);
		stub(ErrorDialogHelper, "checkHttpStatus").returns({
			isMissingAuthorization: true,
			isError: true
		});
		stub(ErrorDialogHelper, "displayErrorMessageBox").returns();


		// Act
		ErrorDialogHelper.init(options);

		// Act
		ErrorDialogHelper.showErrorForRest(fakeEvent);

		// Assert
		assert.ok(ErrorDialogHelper.displayErrorMessageBox.calledOnce, "The error message box was called.");
	});

	QUnit.test("showErrorForRest", function (assert) {
		// Arrange
		var component = {};
		var options = {
			component: component
		};
		
		var fakeEvent = {};
		var parameters = {
			statusText: "Bad Request",
			statusCode: "500",
			responseText: "{\"error\":{\"code\":\"com.sap.gtt.v2.exception.MetadataException.NotFound\",\"message\":\"com.sap.gtt.app is not found.\",\"details\":[]}}"
		};
		stub(fakeEvent, "getParameters").returns(parameters);
		stub(ErrorDialogHelper, "checkHttpStatus").returns({
			isMissingAuthorization: true,
			isError: true
		});
		stub(ErrorDialogHelper, "displayErrorMessageBox").returns();

		// Act
		ErrorDialogHelper.init(options);

		// Act
		ErrorDialogHelper.showErrorForRest(fakeEvent);

		// Assert
		assert.ok(ErrorDialogHelper.displayErrorMessageBox.calledOnce, "The error message box was called.");
	});

	QUnit.test("showErrorForCoreEngine", function (assert) {
		// Arrange
		var component = {};
		var options = {
			component: component
		};
		
		var fakeEvent = { response:{
							status: 500,
							statusText: "Internal Server Error",
							data: {
								error:{								
									message: "System internal error. Please contact your IT administrator.",
									details: []
								}
							}
							}
						};

		stub(ErrorDialogHelper, "checkHttpStatus").returns({
			isMissingAuthorization: false,
			isError: true
		});
		stub(ErrorDialogHelper, "displayErrorMessageBox").returns();

		// Act
		ErrorDialogHelper.init(options);	
		ErrorDialogHelper.showErrorForCoreEngine(fakeEvent);

		// Assert
		assert.ok(ErrorDialogHelper.displayErrorMessageBox.calledOnce, "The error message box was called.");
	});
	
});
