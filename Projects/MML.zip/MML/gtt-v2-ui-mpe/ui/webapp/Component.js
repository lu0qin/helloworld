sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/resource/ResourceModel",
	"sap/m/MessageBox",
	"com/sap/gtt/v2/mpe/util/ErrorDialogHelper",
	"sap/ui/Device"
], function(UIComponent, JSONModel, ResourceModel, MessageBox, ErrorDialogHelper, Device) {
	"use strict";

	JSONModel.prototype.clearAllProperties = function() {
		var data, path;
		data = this.getProperty("/");
		for (var prop in data) {
			path = "/" + prop;
			this.setProperty(path, null);
		}
	};

	JSONModel.prototype.regisetrRequestFailed = function() {
		this.attachRequestFailed(function(event) {
			ErrorDialogHelper.showErrorForRest(event);
		});
	};

	return UIComponent.extend("com.sap.gtt.v2.mpe.Component", {
		metadata: {
			manifest: "json"
		},

		init: function() {
			UIComponent.prototype.init.apply(this, arguments);

			// set i18n model
			var i18nModel = new ResourceModel({
				bundleName: "com.sap.gtt.v2.mpe.i18n.i18n"
			});
			this.setModel(i18nModel, "i18n");

			// set device model
			var deviceModel = new JSONModel(Device);
			deviceModel.setDefaultBindingMode("OneWay");
			this.setModel(deviceModel, "device");

			var gModel = new JSONModel({
				sourceI18nClassName: "messageLog.source",
				statusI18nClassName: "messageLog.status",
				processFlowI18nClassName: "processFlow",
				validationI18nClassName: "validation",
				eventDetailI18nClassName: "eventDetail",
				keyCodeI18nClassName: "keyCode"
			});
			this.setModel(gModel, "g");

			var messageLogModel = this.getModel("messageLog");

			// initialize
			ErrorDialogHelper.init({
				component: this
			  });

			messageLogModel.attachMetadataFailed(function(event) {
				MessageBox.error(i18nModel.getProperty("eventDetail.metadataFail"));
			}.bind(this));

			messageLogModel.attachRequestFailed(function(event) {
				ErrorDialogHelper.showError(event);
			});

			this.getRouter().initialize();
		},

		getServiceUri: function(serviceName) {
			return this.getManifestEntry("sap.app").dataSources[serviceName].uri;
		},

		toUrl: function(serviceName) {
			var serviceUri, componentName, componentPath, url;
			serviceUri = this.getServiceUri(serviceName);
			componentName = this.getManifestObject().getComponentName();
			componentPath = componentName.replace(/\./g, "/");
			url = sap.ui.require.toUrl(componentPath + "/" + serviceUri);
			return url;
		}
	});
});
