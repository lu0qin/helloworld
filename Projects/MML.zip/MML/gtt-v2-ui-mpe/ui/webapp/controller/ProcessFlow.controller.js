sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"sap/suite/ui/commons/ProcessFlowLaneHeader",
	"sap/suite/ui/commons/ProcessFlowConnectionLabel",
	"com/sap/gtt/v2/mpe/util/Formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(
	Controller,
	JSONModel,
	Device,
	ProcessFlowLaneHeader,
	ProcessFlowConnectionLabel,
	Formatter,
	Filter,
	FilterOperator) {

	"use strict";

	ProcessFlowLaneHeader.prototype._getAriaText = function() {
		return "";
	};

	return Controller.extend("com.sap.gtt.v2.mpe.controller.ProcessFlow", {

		metadata: {
			methods: {
				_getViewModel: {
					public: false,
					final: true
				},
				_getProcessFlow: {
					public: false,
					final: true
				},
				_getRequestId: {
					public: false,
					final: true
				},
				_getValidationMessage: {
					public: false,
					final: true
				},
				_formatNodeTitle: {
					public: false,
					final: true
				}
			}
		},

		formatter: Formatter,

		_getProcessFlow: function() {
			return this.getView().byId("processFlow");
		},

		_getViewModel: function() {
			return this.getView().getModel();
		},

		_getValidationMessage: function() {
			return sap.ui.getCore().byId("validationMessage");
		},

		onInit: function() {
			var router, view, viewModel, processFlow, model;

			view = this.getView();
			viewModel = new JSONModel({
				isZoomInEnabled: true,
				isZoomOutEnabled: true
			});
			view.setModel(viewModel);

			processFlow = this._getProcessFlow();
			model = new JSONModel({
				lanes: [],
				nodes: []
			});
			model.setSizeLimit(1000);
			processFlow.setModel(model);

			Device.media.attachHandler((function(oParam) {
				var zoomLevel;
				switch (oParam.name) {
				case "Phone":
					zoomLevel = "Three";
					break;
				case "Tablet":
				case "Desktop":
				default:
					zoomLevel = "Two";
				}
				processFlow.setZoomLevel(zoomLevel);
			})(Device.media.getCurrentRange(Device.media.RANGESETS.SAP_STANDARD)), processFlow);

			model.attachRequestCompleted(function(event) {
				var processFlow, isSuccessful, firstNode;

				processFlow = this._getProcessFlow();
				isSuccessful = event.getParameters().success;

				if (isSuccessful) {
					processFlow.updateModel();
					if (processFlow.getNodes().length > 0) {
						firstNode = processFlow.getNodes()[0];
						firstNode.addStyleClass("mmlPfFirstNode");

						processFlow.getNodes().forEach(node => {
							var context, navType, stateText;
							context = node.getBindingContext();
							navType = context.getProperty(context.getPath("navigationType"));
							stateText = context.getProperty(context.getPath("stateText"));
							if (navType === null) {
								node.addStyleClass("noNav");
							}
							if (stateText === "NOT_RELEVANT") {
								node.addStyleClass("notRelevantNode");
							}
						});
					}
				}

				processFlow.setBusy(false);
			}, this);

			model.regisetrRequestFailed();

			router = this.getOwnerComponent().getRouter();

			router.attachRouteMatched(function(event) {
				var routeName;
				routeName = event.getParameter("name");
				if (routeName === "messageLog") {
					this.onRouteMatched(event);
				}
			}, this);
		},

		onRouteMatched: function(event) {
			var requestId, serviceName, serviceUrl, processFlow, model, lang;

			requestId = event.getParameter("arguments").requestId;
			serviceName = "processFlowService";
			processFlow = this._getProcessFlow().setBusy(true);
			model = processFlow.getModel();

			model.clearAllProperties();

			this._getRequestId = function() {
				return requestId;
			};

			serviceUrl = this.getOwnerComponent().toUrl(serviceName);
			lang = sap.ui.getCore().getConfiguration().getLanguage();
			model.loadData(serviceUrl, {
				requestId: requestId
			}, true, "GET", false, false, {
				"Accept-Language": lang
			});
		},

		onZoomIn: function(event) {
			var zoomLevel, isZoomInEnabledPath, isZoomOutEnabledPath,
				viewModel, processFlow;

			isZoomInEnabledPath = "/isZoomInEnabled";
			isZoomOutEnabledPath = "/isZoomOutEnabled";
			viewModel = this._getViewModel();
			processFlow = this._getProcessFlow();
			processFlow.zoomIn();
			zoomLevel = processFlow.getZoomLevel();
			if (zoomLevel === "One") {
				viewModel.setProperty(isZoomInEnabledPath, false);
			}
			viewModel.setProperty(isZoomOutEnabledPath, true);
		},

		onZoomOut: function() {
			var zoomLevel, isZoomInEnabledPath, isZoomOutEnabledPath,
				viewModel, processFlow;

			isZoomInEnabledPath = "/isZoomInEnabled";
			isZoomOutEnabledPath = "/isZoomOutEnabled";
			viewModel = this._getViewModel();
			processFlow = this._getProcessFlow();
			processFlow.zoomOut();
			zoomLevel = processFlow.getZoomLevel();
			if (zoomLevel === "Four") {
				viewModel.setProperty(isZoomOutEnabledPath, false);
			}
			viewModel.setProperty(isZoomInEnabledPath, true);
		},

		onNodePress: function(event) {
			var context, router, routeName,
				idPathName, navTypePathName, navTypes,
				id, navType;

			context = event.getParameters().getBindingContext();
			navTypePathName = "navigationType";
			navType = context.getProperty(context.getPath(navTypePathName));

			if (navType === null) {
				return;
			}

			router = this.getOwnerComponent().getRouter();
			navTypes = ["WRITE_SERVICE_MAPPING", "EVENT", "EVENT_CORRELATION"];

			if (navTypes.find(item => item === navType) === undefined) {
				throw new Error("Wrong Navigation Type of process flow: " + navType);
			}

			if (navType === "WRITE_SERVICE_MAPPING") {
				idPathName = "requestId";
				id = context.getProperty(context.getPath(idPathName));
				routeName = "writeServiceEvent";
				router.navTo(routeName, {
					requestId: id
				});
			} else {
				idPathName = "executionUnitId";
				id = context.getProperty(context.getPath(idPathName));
				routeName = (function() {
					var arr, field;
					arr = navType.toLowerCase().split("_");
					field = "";
					arr.slice(1).forEach(function(item) {
						field = field.concat(item.charAt(0).toUpperCase() + item.slice(1));
					});
					return arr[0] + field;
				})();
				router.navTo(routeName, {
					id: id
				});
			}
		},

		onValidationLabelPress: function(event) {
			var processId, sourceNode,
				label, validationType,
				popover, validationMessageView, messageItemTemplate,
				popoverBar, closeButton, backButton,
				filters = [];

			sourceNode = event.getParameter("connections")[0].sourceNode;
			processId = (function(sourceNode) {
				var context, pathName, requestId;
				context = sourceNode.getBindingContext();
				pathName = "requestId";
				requestId = context.getProperty(context.getPath(pathName));
				return requestId;
			})(sourceNode);

			label = event.getParameter("selectedLabel");
			validationType = label.getCustomData()[0].getValue();

			filters.push(
				new Filter({
					path: "isValidationError",
					operator: FilterOperator.EQ,
					value1: true
				}));

			filters.push(
				new Filter({
					path: "processId",
					operator: FilterOperator.EQ,
					value1: processId
				})
			);

			messageItemTemplate = new sap.m.MessageItem({
				type: {
					path: 'messageLog>messageStatus',
					formatter: function(status) {
						return status.charAt(0).toUpperCase() + status.slice(1).toLowerCase();
					}
				},
				title: {
					parts: [
						'g>/keyCodeI18nClassName',
						'messageLog>shortMessage'
					],
					formatter: function(className, key) {
						return Formatter.key2Text(className, key, this);
					}.bind(this)
				},
				description: '{messageLog>longMessage}',
				subtitle: {
					path: 'messageLog>processAt',
					type: 'sap.ui.model.type.DateTime',
					formatOptions: {
						style: 'medium'
					}
				}
			});

			validationMessageView = new sap.m.MessageView({
				busyIndicatorDelay: 100,
				showDetailsPageHeader: false,
				itemSelect: function() {
					backButton.setVisible(true);
				},
				items: {
					path: "/MessageDetail",
					template: messageItemTemplate
				}
			});

			validationMessageView.addStyleClass("validationMessage");

			backButton = new sap.m.Button({
				icon: sap.ui.core.IconPool.getIconURI("nav-back"),
				visible: false,
				press: function() {
					validationMessageView.navigateBack();
					this.setVisible(false);
				}
			});

			closeButton =  new sap.m.Button({
				text: "Close",
				press: function() {
					popover.close();
					popover.destroy();
				}
			});

			popoverBar = new sap.m.Bar({
				contentLeft: [
					backButton,
					new sap.m.Text({
						text: Formatter.key2Text("validation", validationType, this)
					})
				]
			});

			popover = new sap.m.ResponsivePopover({
				customHeader: popoverBar,
				contentWidth: "500px",
				contentHeight: "384px",
				verticalScrolling: false,
				modal: true,
				content: [validationMessageView],
				endButton: closeButton
			});

			label.addDependent(popover);
			popover.openBy(label);

			validationMessageView.bindAggregation("items", {
				model: "messageLog",
				path: "/MessageDetail",
				filters: filters,
				template: messageItemTemplate,
				parameters: {
					countMode: "InlineRepeat"
				},
				events: {
					dataRequested: function() {
						validationMessageView.setBusy(true);
					},
					dataReceived: function() {
						validationMessageView.setBusy(false);
					}
				}
			});
		},

		onProcessFlowError: function(event) {
			console.info("process flow error");
		},

		connectionLabels: function(children) {
			var labels = [], label;

			for (var child of children) {
				if (child.connectionLabel && child.connectionLabel.id) {
					label = new ProcessFlowConnectionLabel({
						text: "",
						icon: "sap-icon://message-error",
						state: "Negative"
					});
					label.addCustomData(new sap.ui.core.CustomData({
						key: "type",
						value: child.connectionLabel.text
					}));

					labels.push({
						nodeId: child.nodeId,
						connectionLabel: label
					});
				} else if (typeof child === "number") {
					labels.push(child);
				}
			}
			return labels;
		},

		phaseIcon: function(phaseName) {
			var icon;
			switch (phaseName) {
			case "WRITE_SERVICE_PAYLOAD":
				icon = "sap-icon://example";
				break;
			case "EVENT":
				icon = "sap-icon://connected";
				break;
			case "CORRELATION":
				icon = "sap-icon://chain-link";
				break;
			case "IDOC":
				icon = "sap-icon://begin";
				break;
			case "VISIBILITY_PROVIDER":
				icon = "sap-icon://database";
				break;
			default:
				icon = "";
			}
			return icon;
		},

		_formatNodeTitle: function(className, title) {
			var model, key, text, separator = ": ";

			if (title === null) {
				return "";
			}

			model = this.getOwnerComponent().getModel("i18n");
			key = title.split(separator)[0];
			text = model.getProperty(className + "." + key);

			return text + ": " + title.split(separator)[1];
		},
	});
});
