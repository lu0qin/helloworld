sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("com.sap.gtt.v2.mpe.controller.Payload", {

		metadata: {
			methods: {
				_getRequestId: {
					public: false,
					final: true
				},
				bindPayload: {
					public: true,
					final: false
				}
			}
		},

		onInit: function() {
			var eventBus, view, _viewId, type, model;

			eventBus = sap.ui.getCore().getEventBus();

			view = this.getView();
			model = new JSONModel({
				writeServicePath: "",
				payload: ""
			});
			view.setModel(model);

			model.attachRequestSent(function(event) {
				this.getView().setBusy(true);
			}, this);

			model.attachRequestCompleted(function(event) {
				this.getView().setBusy(false);
			}, this);

			model.regisetrRequestFailed();

			_viewId = view.getId().split("--");
			type = _viewId[_viewId.length - 1].replace("View", "");

			eventBus.subscribe(type, "onDisplayed", function(type, event, data) {
				var requestId;

				if (type === "messageLogPayload") {
					requestId = data.customData.requestId;
				} else if (type === "eventPayload") {
					requestId = data.customData.id;
				} else if (type === "writeServicePayload") {
					requestId = data.customData.requestId;
				} else {
					throw new Error("Wrong Payload Type");
				}

				this._getRequestId = function() {
					return requestId;
				};

				this.bindPayload(type);
			}, this);
		},

		bindPayload: function(type) {
			var requestParams, serviceName, url, model, lang;
			var payloadData = {
				"messageLogPayload": {
					serviceName: "messagePayloadService",
					requestParams: {
						requestId: this._getRequestId()
					}
				},
				"writeServicePayload": {
					serviceName: "writeServicePayloadService",
					requestParams: {
						requestId: this._getRequestId()
					}
				},
				"eventPayload": {
					serviceName: "eventPayloadService",
					requestParams: {
						executionUnitId: this._getRequestId()
					}
				}
			};

			model = this.getView().getModel();
			model.clearAllProperties();

			requestParams = payloadData[type].requestParams;
			serviceName = payloadData[type].serviceName;
			url = this.getOwnerComponent().toUrl(serviceName);
			lang = sap.ui.getCore().getConfiguration().getLanguage();

			model.loadData(url, requestParams, true, "GET", false, false, {
				"Accept-Language": lang
			});
		},

		onCopy: function(event) {
			var range, button, copyDivClassName, el;

			button = event.getSource();
			copyDivClassName = button.getCustomData()[0].getValue();
			el = document.getElementsByClassName(copyDivClassName)[0];
			if (document.selection) {
				range = document.body.createTextRange();
				range.moveToElementText(el);
				range.select().createTextRange();
				document.execCommand("copy");
			  } else if (window.getSelection) {
				range = document.createRange();
				range.selectNode(el);
				window.getSelection().empty();
				window.getSelection().addRange(range);
				document.execCommand("copy");
			  }
		}
	});
});
