sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"com/sap/gtt/v2/mpe/util/Formatter"
], function(Controller, JSONModel, Formatter) {
	"use strict";

	return Controller.extend("com.sap.gtt.v2.mpe.controller.WriteServiceEvent", {

		metadata: {
			methods: {

			}
		},

		formatter: Formatter,

		onInit: function() {
			var view, model, router;

			model = new JSONModel({
				id: "",
				eventType: ""
			});

			model.regisetrRequestFailed();

			view = this.getView();
			view.setModel(model);

			router = this.getOwnerComponent().getRouter();

			router.attachRouteMatched(function(event) {
				var routeName;
				routeName = event.getParameter("name");
				if (routeName === "writeServiceEvent") {
					this.onRouteMatched(event);
				}
			}, this);
		},

		onRouteMatched: function(event) {
			var requestId, model, eventBus, serviceName, url, lang;

			requestId = event.getParameter("arguments").requestId;
			model = this.getView().getModel();
			serviceName = "writeServiceService";
			url = this.getOwnerComponent().toUrl(serviceName);
			lang = sap.ui.getCore().getConfiguration().getLanguage();

			model.loadData(url, {
				requestId: requestId
			}, true, "GET", false, false, {
				"Accept-Language": lang
			}).then(function() {
				model.setProperty("/id", requestId);
			});

			eventBus = sap.ui.getCore().getEventBus();
			eventBus.publish("writeServicePayload", "onDisplayed", {
				customData: {
					requestId: requestId
				}
			});
		}
	});
});
