sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/generic/app/navigation/service/NavigationHandler",
	"sap/ui/generic/app/navigation/service/SelectionVariant",
	"sap/ui/model/FilterOperator",
	"com/sap/gtt/v2/mpe/util/Formatter",
	"com/sap/gtt/v2/mpe/util/ErrorDialogHelper",
	"../util/AsyncUtils",
	"../util/RestClient"
], function(Controller, JSONModel, Filter, NavigationHandler, SelectionVariant, FilterOperator, Formatter, ErrorDialogHelper, AsyncUtils, RestClient) {
	"use strict";

	return Controller.extend("com.sap.gtt.v2.mpe.controller.MessageLogList", {

		metadata: {
			methods: {
				_getConstants: {
					public: false,
					final: false
				},
				_getFilterBar: {
					public: false,
					final: true
				},
				_getAllFilters: {
					public: false,
					final: false
				},
				_getCustomFilters: {
					public: false,
					final: true
				},
				_overWriteFilterPath: {
					public: false,
					final: true
				}
			}
		},

		formatter: Formatter,

		_getConstants: function() {
			return {
				CONTROL_TYPE_DROPDOWNLIST: "dropDownList",
				SELECTED_STATUS_KEYS: "/selectedStatusKeys",
				SELECTED_SOURCE_KEYS: "/selectedSourceKeys",
				SELECTED_ERROR_MESSAGE_KEYS: "/selectedErrorMessageKeys"
			}
		},

		_getFilterBar: function() {
			return this.getView().byId("messageLogFilterBar");
		},

		_getAllFilters: function() {
			var oFilterBar,
				aDefaultFilterKey = ["messageNo", "source", "sourceId", "receivedAt"],
				aAllFilter,
				aTrackingIdFilter, aEventTypeIdFilter, aDefaultFilter, aCustomFilter;

			oFilterBar = this._getFilterBar();
			aDefaultFilter = oFilterBar.getFilters(aDefaultFilterKey);
			aCustomFilter = this._getCustomFilters();

			// ["trackingId", "eventTypeId"],	// need to be overwrote filter path
			aTrackingIdFilter = this._overWriteFilterPath({
				key: "trackingId",
				filterPath: "trackingIds/trackingId"
			});

			aEventTypeIdFilter = this._overWriteFilterPath({
				key: "eventTypeId",
				filterPath: "eventTypes/eventType"
			});

			aAllFilter = aTrackingIdFilter.concat(aEventTypeIdFilter, aDefaultFilter, aCustomFilter);
			return aAllFilter;
		},

		_getCustomFilters: function() {
			var aFilter = [],
				filterBar = this._getFilterBar(),
				constants = this._getConstants();

			for (var controlConfig of filterBar.getControlConfiguration()) {
				var controlType = controlConfig.getControlType(),
					controlKey = controlConfig.getKey(),
					filterPath = controlKey,
					selector, customControlConfig;

				if (controlType === "auto") {
					continue;
				}

				selector = filterBar.getControlByKey(controlKey);

				customControlConfig = controlConfig.getCustomData();
				if (customControlConfig.length && customControlConfig[0].getKey() === "filterPath") {
					filterPath = customControlConfig[0].getValue();
				}

				// MultiComboBox
				if (controlType === constants.CONTROL_TYPE_DROPDOWNLIST && selector.getSelectedKeys().length) {
					selector.getSelectedKeys().forEach(key => {
						aFilter.push(new Filter({
							path: filterPath,
							operator: FilterOperator.EQ,
							value1: key
						}));
					});
					continue;
				}

				// DateRangePicker, ...
			}
			return aFilter;
		},

		_overWriteFilterPath: function(oParam) {
			var key = oParam.key,
				filterPath = oParam.filterPath,
				oFilterBar = this._getFilterBar(),
				aFilter,
				oFilterData = oFilterBar.getFilterData()[key];

			var overWriteFilterPath = function(oFilter) {
				var aFilters = oFilter.aFilters;
				if (Array.isArray(aFilters)) {
					aFilters.forEach(oFilter => {
						oFilter.sPath = filterPath;
						overWriteFilterPath(oFilter);
					});
				}
			};

			if (oFilterData === undefined) {
				aFilter = [];
			} else {
				aFilter = oFilterBar.getFilters([key]);
				overWriteFilterPath(aFilter[0]);
			}

			return aFilter;
		},

		/**
		 * Analyze startup parameter to decide OData filter.
		 *
		 * @ smartfilterbar initialise event
		 */

		 initAppState: function(oEvent) {

			var that = this;
			this._oNavigationHandler = this._oNavigationHandler || new NavigationHandler(this);
			var oParseNavigationPromise = this._oNavigationHandler.parseNavigation();

			oParseNavigationPromise.done(function(oAppData, oURLParameters, sNavType) {
				that._parseNaviationParameter(oAppData, oURLParameters, sNavType);
			});

			// this._oCrossAppNav = this._oCrossAppNav || sap.ushell.Container.getService("CrossApplicationNavigation");
		},

		/**
		 * parse navigation related parameter from x-appstate
		 *
		 * @param {object}
		 *            oAppData: which contains the navigation-related selection variant as a JSON-formatted string
		 * @param {object}
		 *            oURLParameters: url parameters.
		 * @param {string}
		 *            sNavType: navigation type
		 *
		 * @private
		 */
		_parseNaviationParameter:function(oAppData, oURLParameters, sNavType){
			var oSmartFilter = this._getFilterBar();
			var oSelectionVariant = new SelectionVariant(oAppData.selectionVariant);
			var aStatusPara = oSelectionVariant.getSelectOption("status");
			var oFilterData = oSmartFilter.getFilterData();
			var oCustomData = oFilterData._CUSTOM;
			var that = this;
			if (oCustomData){
				oCustomData.status = {keys:''};
			}
			var aCusColumn = ["status"];
			var statusParaStr = "[";
			// var aStatusFilterValue = new Array();
			if (aStatusPara){
				var iLength = aStatusPara.length - 1;
				aStatusPara.forEach(function(item, index){
					// aStatusFilterValue.push(item.Low);
					if (index === iLength){
						statusParaStr = statusParaStr+'"'+item.Low+'"';
					} else {
						statusParaStr = statusParaStr+'"'+item.Low+'"'+",";
					}
				});
				statusParaStr = statusParaStr+"]";
			}
			if (oCustomData && oCustomData.status){
				oCustomData.status.keys = statusParaStr;
			}
			switch (sNavType) {
			case sap.ui.generic.app.navigation.service.NavType.xAppState:
				//Handle corss navigation
				oSmartFilter.setDataSuiteFormat(oAppData.selectionVariant, true)
				aCusColumn.forEach(function(key) {
					that._setCustomModel(key, oCustomData[key]);
				});
				break;
			case sap.ui.generic.app.navigation.service.NavType.iAppState:
				//Handle inner navigation
				break;
			case sap.ui.generic.app.navigation.service.NavType.initial:
				break;
			default:
				break;
			}
		},

		onInit: function() {
			var model = this.getOwnerComponent().getModel("messageLog");
			this.getView().setModel(model);
			this.getView().setModel(new JSONModel(), "view");

			var oSelectOptionReceivedAt = this.getView().byId("selectOptionReceivedAt");
			oSelectOptionReceivedAt.setOperator("GE");
			oSelectOptionReceivedAt.setLow((new Date(new Date().setHours(0, 0, 0))).toString());
		},

		onExit: function() {
		},

		onBeforeRebindTable: function(event) {
			var binding = event.getParameter("bindingParams");
			binding.filters = this._getAllFilters();
			binding.parameters.expand = "trackingIds,messages,eventTypes";
			binding.parameters.countMode = "InlineRepeat";
		},

		onMessageLogEntrySelected: function(event) {
			var item = event.getSource();
			var context = item.getBindingContext();
			var router = this.getOwnerComponent().getRouter();
			router.navTo("messageLog", {
				requestId: context.getProperty("requestId")
			});
		},

		getRetentionService: function() {
			var serviceName = "retentionSettingService";
			return this.getOwnerComponent().toUrl(serviceName);
		},

		onPressRetention: function(oEvent) {
			var retentionDialog = new sap.m.Dialog({
				id: "retentionDlg",
				title: "{i18n>eventDetail.retention}",
				content: [
					new sap.m.Label({
						text: "{i18n>eventDetail.period}",
						labelFor: "retentionPeriod"
					}),
					new sap.m.Input({
						id: "retentionPeriod",
						editable: true,
						type: "Number",
						value: "{/retentionPeriod}",
						valueStateText: "{i18n>eventDetail.inputRangeInfo}",
						description: "{i18n>eventDetail.retentionPeriod}",
						change: this._onChangeInputText
					}).addStyleClass("sapUiContentPadding sapUiLargeMarginBottom")
				],
				beginButton: new sap.m.Button({
					type: sap.m.ButtonType.Emphasized,
					text: "{i18n>eventDetail.ok}",
					press: function() {
						this.saveRetentionSetting();
					}.bind(this)
				}),
				endButton: new sap.m.Button({
					text: "{i18n>eventDetail.close}",
					press: function() {
						retentionDialog.destroy();
					}.bind(this)
				})
			}).addStyleClass("sapUiContentPadding sapUiLargeMargin");

			var oView = this.getView();
			oView.addDependent(retentionDialog);
			oView.setBusy(true);

			var url = this.getRetentionService();

			this.backendCall("GET", url, {}, oView)
				.then(
					function(data) {
						retentionDialog.setModel(new JSONModel({ retentionPeriod: data.logRetentionIntervalDay }));
						retentionDialog.open();
					}.bind(this),
					function(error) {
						ErrorDialogHelper.showErrorForCoreEngine(error);
					}.bind(this)
				);
		},

		validateRententionSetting: function() {
			var inputRetentionCtrl = sap.ui.getCore().byId("retentionPeriod");
			var iPeriod = inputRetentionCtrl.getValue().trim();
			if (this._isValidRetentionVal(iPeriod)) {
				return true;
			}
			inputRetentionCtrl.setValueState(sap.ui.core.ValueState.Error);
			return false;
		},

		_isValidRetentionVal: function(iPeriod) {
			return iPeriod !== undefined && iPeriod !== "" && Number.isInteger(iPeriod / 1) && iPeriod / 1 < 31 && iPeriod / 1 > 0;
		},

		_onChangeInputText: function(oEvent) {
			var oControl = oEvent.getSource(),
				sNewValue = oEvent.getParameter("value");
			var messageLogListView = oControl.getParent().getParent();
			// 1. Set value state to error if no text entered for input box
			if (!messageLogListView.getController()._isValidRetentionVal(sNewValue)) {
				oControl.setValueState(sap.ui.core.ValueState.Error);
				return;
			}
			oControl.setValueState(sap.ui.core.ValueState.None);
		},

		saveRetentionSetting: function() {
			if (!this.validateRententionSetting()) {
				return;
			}
			var oView = this.getView();
			oView.setBusy(true);
			var retentionDialog = sap.ui.getCore().byId("retentionDlg");
			var iInputRetention = sap.ui.getCore().byId("retentionPeriod").getValue().trim();

			var url = this.getRetentionService()
				.concat(
					"?logRetentionIntervalDay=",
					iInputRetention
				);


			this.backendCall("POST", url, {}, oView)
				.then(
					function(data) {
						retentionDialog.destroy();
					}.bind(this),
					function(error) {
						ErrorDialogHelper.showErrorForCoreEngine(error);
					}.bind(this)
				);
		},

		backendCall: function(callMethod, url, callOptions, oView) {
			var request;
			if (callMethod === "GET") {
				request = RestClient.get(url);
			} else if (callMethod === "POST") {
				request = RestClient.post(url, callOptions);
			}

			var promise = AsyncUtils.finally(request, function() {
				oView.setBusy(false);
			});

			return promise;
		},
		// ========================================================================
		// Variant Management
		// ========================================================================

		onAfterVariantLoad: function() {
			var smartFilterBar = this.byId("messageLogFilterBar");
			var data = smartFilterBar.getFilterData();
			var customData = data._CUSTOM;
			var cusColumn = ["status", "messageId", "source"];
			cusColumn.forEach(jQuery.proxy(function(key) {
				this._setCustomModel(key, customData[key]);
			}), this);
			smartFilterBar.search();
		},

		/*
		 * when load Variant, write custom column selected keys back to json model
		 * if keys is empty, clear the control of filter bar
		 */
		_setCustomModel(key, propertyVal) {
			var model = this.getView().getModel("view");
			var propertyName = this._getPropertyName(key);
			if (propertyVal.keys) {
				model.setProperty(propertyName, JSON.parse(propertyVal.keys));
			} else {
				model.setProperty(propertyName, []);
			}
		},

		/*
		 * get property name according to key
		 */
		_getPropertyName(key) {
			var constants = this._getConstants();
			switch (key) {
			case "source":
				return constants.SELECTED_SOURCE_KEYS;
			case "messageId":
				return constants.SELECTED_ERROR_MESSAGE_KEYS;
			case "status":
				return constants.SELECTED_STATUS_KEYS;
			}
		},

		onBeforeVariantSave: function(event) {
			if (event.getParameter("context") === "STANDARD") {
				this.updateCustomFilter();
			}
		},

		onBeforeVariantFetch: function() {
			this.updateCustomFilter();
		},

		updateCustomFilter: function() {
			var customData = {
				status: {
					keys: this._getPropertyVal("status")
				},
				messageId: {
					keys: this._getPropertyVal("messageId")
				},
				source: {
					keys: this._getPropertyVal("source")
				}
			};

			var smartFilterBar = this.byId("messageLogFilterBar");
			smartFilterBar.setFilterData({
				_CUSTOM: customData
			});
		},

		/*
		 * get property value according to key.at the meantime, convert the perperty value to json object for save purpose
		 */
		_getPropertyVal(key) {
			var model = this.getView().getModel("view");
			return JSON.stringify(model.getProperty(this._getPropertyName(key)));
		}

	});
});
