sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"com/sap/gtt/v2/mpe/util/Formatter",
	"sap/m/MessageToast",
	"com/sap/gtt/v2/mpe/util/ErrorDialogHelper",
	"sap/m/MessageBox",
	"sap/ui/core/Fragment",
	"sap/ui/core/syncStyleClass",
	"../util/AsyncUtils",
	"../util/RestClient"
], function (Controller, JSONModel, Filter, FilterOperator, Formatter, MessageToast, ErrorDialogHelper, MessageBox, Fragment, syncStyleClass, AsyncUtils, RestClient) {
	"use strict";
	return Controller.extend("com.sap.gtt.v2.mpe.controller.EventDetail", {
		metadata: {
			methods: {
				_getExecutionUnitId: {
					public: false,
					final: true
				},
				_getModel: {
					public: false,
					final: true
				},
				_composeFilters: {
					public: false,
					final: true
				},
				_getControlById: {
					public: false,
					final: true
				},
				_getControl: {
					public: false,
					final: true
				},
				_unsetButtonState: {
					public: false,
					final: true
				},
				_getResourceBundle: {
					public: false,
					final: true
				},
				_getConstants: {
					public: false,
					final: false
				}
			}
		},

		formatter: Formatter,

		router: null,

		executionUnitId: null,

		routerNameArray: ["event", "eventCorrelation"],

		vpProcessPhaseArray: ["INIT", "MERGE", "DB", "EVENT2ACTIONINTERNAL", "EVENT2ACTIONEXTERNAL"],

		vpCorrelationPhaseArray: ["VALIDATION", "PROCESS", "DB", "EVENT2ACTIONINTERNAL", "EVENT2ACTIONEXTERNAL"],

		_getControlById: function (id) {
			return this.getView().byId(id);
		},

		_getControl: function (id) {
			return sap.ui.getCore().byId(id);
		},

		_unsetButtonState: function () {
			var timeLine = this._getControlById("idTimeline");

			timeLine.getContent().forEach(function (item) {
				var oLayout = {};
				oLayout = item.getEmbeddedControl().getItems()[0].getContent()[0].getItems()[5].getItems()[0];
				var oToggleButton = {};
				oToggleButton = oLayout.getItems()[0];
				oToggleButton.setPressed(false);
				oToggleButton = oLayout.getItems()[1];
				oToggleButton.setPressed(false);
			})
		},

		_getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		_getConstants: function() {
			return {
				EVENT_TYPE: "/eventType",
				CORRELATION_LIST_VISIBLE: "/correlatedTPList/visible",
				CORRELATION_LIST_COUNT: "/correlatedTPList/TPListCount",
				CORRELATION_LOG_VISIBLE: "/correlatedLogDetail/visible",
				CORRELATION_LOG_COUNT: "/correlatedLogDetail/logsCount"
			}
		},

		onInit: function () {
			this._iUpdateInterval = null;
			this._iTimer = null;
			this.fnHandleClearInterval = jQuery.proxy(function () {
				if (this._iUpdateInterval !== null) {
					clearInterval(this._iUpdateInterval);
					clearTimeout(this._iTimer);
					this._iUpdateInterval = null;
					this._iTimer = null;
				}
			}, this);
			this._initModel();
			this.attachBusyEventListener();

			var routeName;
			this.router = this.getOwnerComponent().getRouter();
			this.router.attachRouteMatched(function (event) {
				routeName = event.getParameter("name");
				if (this.routerNameArray.indexOf(routeName) > -1) {
					this.autoRefresh = true;
					this._setUILayout(routeName);
					this.onRouteMatched(event);
				}
			}, this);
		},

		onExit: function () {
			this.detachBusyEventListener();
			this._clearViewCache();
		},

		_stopPeriodicUpdate: function () {
			this.fnHandleClearInterval();
		},

		_startPeriodicUpdate: function () {
			var that = this;
			var resourceBundle = this._getResourceBundle();
			var iUpdateInterval = setInterval(function () {
				if (that._iUpdateInterval !== null) {
					that._readEventHistory();
				}
			}, 3000);

			this.autoRefresh = false;

			this._iTimer = setTimeout(function () {
				if (that._iUpdateInterval !== null) {
					clearInterval(that._iUpdateInterval);
					clearTimeout(that._iTimer);
					that._iUpdateInterval = null;
					that._iTimer = null;
					var constants = that._getConstants();
					var viewModel = that._getModel("viewModel");
					var eventType = viewModel.getProperty(constants.EVENT_TYPE);
					if (eventType === that.routerNameArray[0].toUpperCase()) {
						MessageToast.show(resourceBundle.getText("eventDetail.messageTimeOutEvent"), {width: "35rem"});
					} else {
						MessageToast.show(resourceBundle.getText("eventDetail.messageTimeOutCorrelate"), {width: "35rem"});
					}
					that._setPageBusyStatus(false);
					that.autoRefresh = false;
				}
			}, 30000);

			return iUpdateInterval;
		},

		_setUpdateInterval: function (iUpdateInterval) {
			this._iUpdateInterval = iUpdateInterval;
		},

		attachBusyEventListener: function () {
			window.addEventListener("hashchange", this.fnHandleClearInterval);
		},

		detachBusyEventListener: function () {
			window.removeEventListener("hashchange", this.fnHandleClearInterval);
		},

		onRouteMatched: function (event) {
			var _args, executionUnitId;
			_args = event.getParameter("arguments");
			executionUnitId = _args.id;
			this.executionUnitId = executionUnitId;

			this._getExecutionUnitId = function () {
				return executionUnitId;
			};

			this._getModel = function (modelName) {
				return this.view.getModel(modelName);
			}

			//destroy obsolete control
			this._clearViewCache();

			this._readEventHistory();

			// //header
			this.view.bindObject({
				model: "messageLog",
				path: "/EventHistory(guid'" + executionUnitId + "')"
			});

			//icontab bar if payload tab is selected fire event to retrieve payload
			var iconTabBar = this._getControlById("iconTabBar");
			var payloadTab = this._getControlById("payloadTab");
			if (iconTabBar.getSelectedKey().endsWith("-payload") && payloadTab.getVisible()) {
				iconTabBar.fireSelect({
					key: "event-payload"
				})
			}

			//read process history
			this._readProcessHistory();
		},

		_initModel: function () {
			var viewModel;
			this.view = this.getView();
			viewModel = new JSONModel({
				eventType: "",
				isProcessEvent: "",
				processHistory: {
					count: 0
				},
				correlatedLogDetail: {
					logsCount: 0,
					visible: false
				},
				correlatedTPList: {
					TPListCount: 0,
					visible: true
				},
				logDetail: {
					busy: true
				},
				busy: false
			});
			this.view.setModel(viewModel, "viewModel");
		},

		_readEventHistory: function () {
			var that = this;
			var messageLog = this.view.getModel("messageLog"), executionUnitId = this._getExecutionUnitId();
			messageLog.read("/EventHistory(guid'" + executionUnitId + "')", {
				success: function (oData) {
					var bInterval = (that._iUpdateInterval === null || that._iUpdateInterval === undefined || that._iUpdateInterval === "");
					if (oData.status === "PENDING") {
						if (bInterval && that.autoRefresh) {
							that._setPageBusyStatus(true);
							that._setUpdateInterval(that._startPeriodicUpdate());
						}
					} else {
						if (!bInterval && !that.autoRefresh) {
							that._stopPeriodicUpdate();
							that._setPageBusyStatus(false);
							that._readProcessHistory();
						} else {
							that._setPageBusyStatus(false);
						}
					}
				}
			});
		},

		_setPageBusyStatus: function (bBusyStatus) {
			var viewModel = this._getModel("viewModel");
			viewModel.setProperty("/busy", bBusyStatus);
		},

		_readProcessHistory: function () {
			var timeLineModel = new JSONModel(), viewModel = {}, timeLine = {};
			viewModel = this._getModel("viewModel");
			timeLine = this._getControlById("idTimeline");
			timeLine.setModel(timeLineModel, "timeLineModel");

			var messageLog = this.view.getModel("messageLog"), that = this, filterMap = new Map();
			var constants = this._getConstants();

			filterMap.set("executionUnitId", this.executionUnitId);

			timeLine.setBusy(true);
			messageLog.read("/ProcessHistory", {
				filters: that._composeFilters(filterMap),
				success: function (oData) {
					timeLine.setBusy(false);
					timeLineModel.setData(oData.results);
					viewModel.setProperty("/processHistory/count", oData.results.length);
					if (oData.results.length > 0) {
						viewModel.setProperty("/isProcessEvent", oData.results[0].isProcessEvent);

						var oContentObjArr = timeLine.getContent();
						if (oContentObjArr.length === 0) {
							return;
						}
						var oLayout = oContentObjArr[0].getEmbeddedControl().getItems()[0].getContent()[0].getItems()[5].getItems()[0];
						var oToggleButton = {};

						if (viewModel.getProperty(constants.EVENT_TYPE) === "EVENT") {
							oToggleButton = oLayout.getItems()[0];
						} else {
							oToggleButton = oLayout.getItems()[1];
						}

						if (oToggleButton !== undefined) {
							var controlName = oToggleButton.getMetadata().getName();
							if (controlName === "sap.m.ToggleButton") {
								oToggleButton.firePress();
							}
						}
					}
				},
				error: function (oResponse) {
					timeLine.setBusy(false);
				}
			});
		},

		_setUILayout: function (router) {
			this._setHeaderLayout(router);
			this._setLogDetailLayout(router);
		},

		_setHeaderLayout: function (router) {
			var viewModel, constants = this._getConstants();
			viewModel = this.view.getModel("viewModel");

			switch (router) {
				case this.routerNameArray[0]:
					viewModel.setProperty(constants.EVENT_TYPE, this.routerNameArray[0].toUpperCase());
					break;
				case this.routerNameArray[1]:
					viewModel.setProperty(constants.EVENT_TYPE, Formatter.applyRouterFormat(this.routerNameArray[1]));
					break;
			}
		},

		_setLogDetailLayout: function (router) {
			var viewModel, constants = this._getConstants();
			viewModel = this.view.getModel("viewModel");

			switch (router) {
				case this.routerNameArray[0]:
					viewModel.setProperty(constants.CORRELATION_LIST_VISIBLE, false);
					viewModel.setProperty(constants.CORRELATION_LIST_COUNT, 0);
					viewModel.setProperty(constants.CORRELATION_LOG_VISIBLE, true);
					viewModel.setProperty(constants.CORRELATION_LOG_count, 0);
					break;
				case this.routerNameArray[1]:
					viewModel.setProperty(constants.CORRELATION_LIST_VISIBLE, false);
					viewModel.setProperty(constants.CORRELATION_LIST_COUNT, 0);
					viewModel.setProperty(constants.CORRELATION_LOG_VISIBLE, false);
					viewModel.setProperty(constants.CORRELATION_LOG_COUNT, 0);
					break;
			}
		},

		displayLogDetail: function (event) {
			var viewModel, constants = this._getConstants();

			// header visibility
			viewModel = this._getModel("viewModel");
			viewModel.setProperty(constants.CORRELATION_LOG_VISIBLE, true);
			viewModel.setProperty(constants.CORRELATION_LIST_VISIBLE, false);

			//highlight pressed button
			this._unsetButtonState();
			var displayLogButton = event.getSource();
			displayLogButton.setPressed(true);

			var processId = event.getSource().data("processId");
			this._readEventDetail(processId, viewModel.getProperty(constants.EVENT_TYPE));
		},

		_readEventDetail: function (processId, navigationType) {
			// compose filter condition
			var filterMap = new Map();
			filterMap.clear();

			//exception handling for the message detail
			filterMap.set("processId", processId);
			filterMap.set("navigationType", navigationType);

			//destroy obsolete control
			this._clearViewCache();

			// call the backend service
			var messageLog = this._getModel("messageLog");
			var that = this;
			var logDetailPanel = this._getControlById("logDetailPnl");
			logDetailPanel.setBusy(true);

			messageLog.read("/MessageDetail", {
				success: jQuery.proxy(function (oData) {
					logDetailPanel.setBusy(false);

					switch (navigationType) {
						case "EVENT_CORRELATION":
							var processingArr = this._getProcessingPhaseArr();
							this._prepareCorrelated(oData, processingArr);
							break;
						case "EVENT":
							this._prepareActual(oData);
							break;
					}
				}, this),
				error: jQuery.proxy(function (oResponse) {
					logDetailPanel.setBusy(false);
				}, this),
				filters: that._composeFilters(filterMap)
			});
		},

		_getProcessingPhaseArr: function () {
			var viewModel = this._getModel("viewModel");
			var isProcessEvent = viewModel.getProperty("/isProcessEvent");
			if (isProcessEvent) {
				return this.vpProcessPhaseArray;
			} else {
				return this.vpCorrelationPhaseArray;
			}
		},

		// destroy event correlation and process event and its children
		// destroy actual event message view in case cache
		_clearViewCache: function () {
			//cache
			for (var i = 0; i < this.vpCorrelationPhaseArray.length; i++) {
				this._destroyObsoleteControl(this.vpCorrelationPhaseArray[i].toLowerCase() + "Id");
			}
			this._destroyObsoleteControl("trackingId");
			this._destroyObsoleteControl("messageViewId");
			this._destroyObsoleteControl("idProgressBar");
			this._destroyObsoleteControl("idVPProgressBar");
		},

		_prepareActual: function (data) {
			var that = this, constants = this._getConstants();
			var logDetailPanel = that._getControlById("logDetailPnl");

			var viewModel = this._getModel("viewModel");
			var msgView = this._getControl("messageViewId");

			if (msgView !== undefined) {
				msgView.destroy();
			}

			Fragment.load({
				name: "com.sap.gtt.v2.mpe.view.ActualEventLogDetail",
				controller: this
			}).then(function (actualMsgView) {
				actualMsgView.setModel(new JSONModel(data.results));
				viewModel.setProperty(constants.CORRELATION_LOG_COUNT, data.results.length);
				actualMsgView.bindObject({
					path: "/",
					events: {
						change: function () {
							that._onBindingChange(actualMsgView);
						}
					}
				});
				logDetailPanel.insertContent(actualMsgView);
			});
		},

		_prepareCorrelated: function (data, phaseArr) {
			var that = this, fragmentName = "com.sap.gtt.v2.mpe.view.VPProcessEventLogDetail";
			this._destroyObsoleteControl("idProgressBar");
			this._destroyObsoleteControl("idVPProgressBar");

			Fragment.load({
				name: fragmentName,
				controller: this
			}).then(function (progressBar) {
				progressBar.setModel(that._composeCorrelatedModel(data, phaseArr));
				progressBar.bindObject({
					path: "/",
					events: {
						change: function () {
							that._onBindingChange(progressBar);
						}
					}
				});
				var logDetailPanel = that._getControlById("logDetailPnl");
				logDetailPanel.insertContent(progressBar);
			});
		},

		_computePhaseStatus: function (phaseStatus, item) {
			return !phaseStatus ? item.phaseStatus : phaseStatus;
		},

		_computeCurrentPhaseIndex: function (phaseIndex, phaseStatus, currentPhaseIndex) {
			return phaseStatus ? Math.max(phaseIndex, currentPhaseIndex) : currentPhaseIndex;
		},

		_composeCorrelatedModel: function (data, phaseArr) {
			var resultArray = [], lastPhase = 0, status = [], that = this, constants = this._getConstants();
			var viewModel, totalLogCount = 0, arrSize = phaseArr.length;
			viewModel = this._getModel("viewModel");
			var logDetailModel = this.composeJsonModel(phaseArr);
			logDetailModel.setProperty("/correlation/phaseName", phaseArr);

			if (data.results.length === 0) {
				return logDetailModel;
			}

			for (var k = 0; k < arrSize; k++) {
				resultArray[k] = [];
			}

			data.results.forEach(function (item) {
				for (var i = 0; i < phaseArr.length; i++) {
					if (item.phase === phaseArr[i] && !!item.phaseStatus) {
						resultArray[i].push(item);
						status[i] = that._computePhaseStatus(status[i], item);
						lastPhase = item.lastPhase;
						totalLogCount++;
					}
				}
			});

			viewModel.setProperty(constants.CORRELATION_LOG_COUNT, totalLogCount);
			logDetailModel = this.writeModelItemData(logDetailModel, resultArray, arrSize);
			logDetailModel = this.writeModelStatusData(logDetailModel, status, arrSize);
			logDetailModel.setProperty("/correlation/currentPhase", this.vpCorrelationPhaseArray[phaseArr.indexOf(lastPhase)].toLowerCase());

			return logDetailModel;
		},

		writeModelItemData: function (jsonModel, resultArray, arrSize) {
			if (resultArray.length !== 0) {
				jsonModel.setProperty("/correlation/validation", resultArray[0]);
				jsonModel.setProperty("/correlation/process", resultArray[1]);
				jsonModel.setProperty("/correlation/DB", resultArray[2]);
				jsonModel.setProperty("/correlation/e2ain", resultArray[3]);
				jsonModel.setProperty("/correlation/e2aex", resultArray[arrSize - 1]);
				jsonModel.setProperty("/correlation/validationCount", resultArray[0].length);
				jsonModel.setProperty("/correlation/processCount", resultArray[1].length);
				jsonModel.setProperty("/correlation/DBCount", resultArray[2].length);
				jsonModel.setProperty("/correlation/e2ainCount", resultArray[3].length);
				jsonModel.setProperty("/correlation/e2aexCount", resultArray[arrSize - 1].length);
			}
			return jsonModel;
		},

		writeModelStatusData: function (jsonModel, statusArr, arrSize) {
			jsonModel.setProperty("/correlation/validationStatus", statusArr[0]);
			jsonModel.setProperty("/correlation/processStatus", statusArr[1]);
			jsonModel.setProperty("/correlation/DBStatus", statusArr[2]);
			jsonModel.setProperty("/correlation/e2ainStatus", statusArr[3]);
			jsonModel.setProperty("/correlation/e2aexStatus", statusArr[arrSize - 1]);
			return jsonModel;
		},

		composeJsonModel: function (phaseArr) {
				return new JSONModel({
					correlation: {
						validation: [],
						DB: [],
						process: [],
						e2ain: [],
						e2aex: [],
						currentPhase: null,
						validationStatus: null,
						DBStatus: null,
						processStatus: null,
						e2ainStatus: null,
						e2aexStatus: null,
						validationCount: 0,
						DBCount: 0,
						e2ainCount: 0,
						e2aexCount: 0,
						processCount: 0
					}
				});
		},

		displayProcesses: function (event) {
			var viewModel, constants = this._getConstants();
			viewModel = this._getModel("viewModel");
			viewModel.setProperty(constants.CORRELATION_LOG_VISIBLE, false);
			viewModel.setProperty(constants.CORRELATION_LIST_VISIBLE, true);

			this._unsetButtonState();
			var displayProcessButton = event.getSource();
			displayProcessButton.setPressed(true);

			this._clearViewCache();

			var processId = event.getSource().data("processId");
			var filterMap = new Map();
			filterMap.set("executionId", processId);

			var correlatedTPModel = new JSONModel();
			var correlatedTP = this._getControlById("correlatedTPlistId");
			correlatedTP.setModel(correlatedTPModel, "correlatedTPModel");
			correlatedTP.setBusy(true);

			var messageLog = this._getModel("messageLog");
			messageLog.read("/CorrelatedTrackedProcess", {
				success: jQuery.proxy(function (oData) {
					correlatedTPModel.setData(oData.results);
					viewModel.setProperty(constants.CORRELATION_LIST_COUNT, oData.results.length);
					correlatedTP.setBusy(false);
				}, this),
				error: jQuery.proxy(function (oData) {
					correlatedTP.setBusy(false);
				}, this),
				filters: this._composeFilters(filterMap)
			});
		},

		handleIconTabBarSelect: function (event) {
			var eventBus = sap.ui.getCore().getEventBus(),
				key = event.getParameter("key");
			if (key === "event-payload") {
				eventBus.publish("eventPayload", "onDisplayed", {
					customData: {
						id: this.executionUnitId
					}
				});
			}
			var device = this._getModel("device");
			if (!device.getProperty("/system/phone") && key === "processHistory") {
				var dp = this._getControlById("eventDetailView");
				dp.setHeaderExpanded(true);
			}
		},

		_destroyObsoleteControl: function (contrlId) {
			var oCtrol = this._getControl(contrlId);
			if (oCtrol !== undefined) {
				oCtrol.destroy();
			}
		},

		_composeFilters: function (filterMap) {
			var filterArr, filter;
			filterArr = [];
			filterMap.forEach(function (value, key) {
				filter = new Filter({
					path: key,
					operator: FilterOperator.EQ,
					value1: value
				});
				filterArr.push(filter);
			});
			return filterArr;
		},

		_onBindingChange: function (oControl) {
			if (oControl !== undefined) {
				oControl.rerender();
			}
		},

		onRetrigger: function (oEvent) {
			this.autoRefresh = true;
			this.retriggerEvent(false);
		},

		retriggerEvent: function (isRiskyEvent) {
			var that = this;
			var serviceName = "retriggerService";
			var resourceBundle = this._getResourceBundle();
			var url = this.getOwnerComponent().toUrl(serviceName)
				.concat(
					"?executionUnitId=",
					that._getExecutionUnitId()
				).concat(
					"&force=",
					isRiskyEvent
				);
			var oView = this.getView();
			oView.setBusy(true);

			var request = RestClient.post(url);
			var promise = AsyncUtils.finally(request, function () {
				oView.setBusy(false);
			});

			promise.then(
				function (data) {
					that.refreshAfterRetrigger();
					// Success case
					MessageToast.show(resourceBundle.getText("eventDetail.eventRetriggered"));
				}.bind(this),
				function (error) {
					var isRiskyEvent = ErrorDialogHelper.showErrorForCoreEngine(error);
					if (isRiskyEvent) {
						that.showRiskyEventMessage(isRiskyEvent);
					} else {
						that.refreshAfterRetrigger();
					}
				}.bind(this)
			);
		},

		refreshAfterRetrigger: function () {
			this._readEventHistory();
			this._readProcessHistory();
		},

		showRiskyEventMessage: function () {
			var oBundle = this._getResourceBundle();
			var sConfirmActionText = oBundle.getText("eventDetail.confirm");
			var sCancelActionText = oBundle.getText("eventDetail.cancel");
			var sMsg = oBundle.getText("eventDetail.riskyEvent");
			var that = this;
			MessageBox.warning(
				sMsg, {
				icon: MessageBox.Icon.WARNING,
				actions: [sConfirmActionText, sCancelActionText],
				initialFocus: sConfirmActionText,
				onClose: function (sAction) {
					if (sAction === sConfirmActionText) {
						that.retriggerEvent(true);
					}
				}
			});
		}
	});
});
