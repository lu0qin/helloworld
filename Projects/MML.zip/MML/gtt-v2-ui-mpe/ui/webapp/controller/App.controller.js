sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.sap.gtt.v2.mpe.controller.App", {
		metadata: {
			methods: {
				_getApp: {
					public: false,
					final: true
				}
			}
		},

		onInit: function() {
			var app = this.getView().byId("appMml");
			this._getApp = function() {
				return app;
			};
		},

		onNavigate: function(event) {
			var app = this._getApp();
			app.setBusy(true);
		},

		afterNavigate: function(event) {
			var app = this._getApp();
			app.setBusy(false);
		}
	});
});
