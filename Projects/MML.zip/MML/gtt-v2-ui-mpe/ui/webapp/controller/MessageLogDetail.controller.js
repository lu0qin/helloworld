sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/sap/gtt/v2/mpe/util/Formatter",
	"sap/ui/core/Fragment"
], function(Controller, Formatter, Fragment) {
	"use strict";

	return Controller.extend("com.sap.gtt.v2.mpe.controller.MessageLogDetail", {

		metadata: {
			methods: {
				_getRequestId: {
					public: false,
					final: true
				}
			}
		},

		formatter: Formatter,

		onInit: function() {
			var router;

			router = this.getOwnerComponent().getRouter();

			router.attachRouteMatched(function(event) {
				var routeName;
				routeName = event.getParameter("name");
				if (routeName === "messageLog") {
					this.onRouteMatched(event);
				}
			}, this);
		},

		onRouteMatched: function(event) {
			var _args, requestId, tab, tabId, view, page;

			_args = event.getParameter("arguments");
			requestId = _args.requestId;
			tab = _args.tab || "process-flow";
			tabId = (function() {
				var arr = tab.split("-");
				if (arr.length > 1) {
					return arr[0] + arr[1].charAt(0).toUpperCase() + arr[1].slice(1);
				} else {
					return arr[0];
				}
			})();
			view = this.getView();

			this._getRequestId = function() {
				return requestId;
			};

			view.bindObject({
				// model: "messageLog",
				path: "/MessageLogs(guid'" + requestId + "')",
				parameters: {
					expand: "trackingIds,messages,eventTypes"
				}
			});

			page = view.byId("messageLogDetailPage");
			page.setSelectedSection(view.byId(tabId));
		},

		onNavigateTab: function(event) {
			var eventBus, tabId, requestId;
			tabId = event.getParameters().section.getId();
			if (tabId.endsWith("-payload")) {
				eventBus = sap.ui.getCore().getEventBus();
				requestId = this._getRequestId();

				eventBus.publish("messageLogPayload", "onDisplayed", {
					customData: {
						requestId: requestId
					}
				});
			}
		}
	});
});
