module.exports = function(grunt) {
	"use strict";

	grunt.loadNpmTasks("@sap/grunt-sapui5-bestpractice-build");
	grunt.config.merge({
		compatVersion: "edge",
		deploy_mode: "html_repo"
	});

	grunt.registerTask("default", [
		"clean",
		"lint",
		"build"
	]);

	// sonar scan
	const sonarGroupId = 'com.sap.gtt.v2';
	const sonarArtifactId = process.env.npm_package_name;
	const sonarBranch = process.env.SONAR_BRANCH || 'master';
	const sonarProjectKey = `${sonarGroupId}:${sonarArtifactId}:${sonarBranch}`;

	grunt.loadNpmTasks('grunt-sonar-runner');
	grunt.config.set('sonarRunner', {
		analysis: {
			options: {
				debug: true,
				projectHome: './',
				sonar: {
					host: {
						url: 'https://sonarce.wdf.sap.corp/sonar'
					},
					login: '4716347bf1abc1e3386aaeb0542ceef83ebfc912',
					projectKey: sonarProjectKey,
					projectName: process.env.npm_package_description,
					projectVersion: process.env.npm_package_version,
					sources: 'webapp',
					tests: 'webapp/test',
					exclusions: 'webapp/test/**',
					// eslint: {
					//   reportPaths: 'target/eslint.json'
					// },
					javascript: {
						// eslint: {
						//   reportPath: 'target/jslint-result.xml',
						//   overrideSeverity: false
						// },
						qunit: {
							reportPath: 'target/surefire-reports'
						},
						lcov: {
							reportPaths: 'coverage/lcov.info'
						}
					},
					coverage: {
						exclusions: 'webapp/localService/**'
					}
				}
			}
		}
	});

	grunt.registerTask("sonar", function() {
		if (process.env.SONAR_BRANCH) {
			grunt.task.run("sonarRunner:analysis");
		}
	});
};