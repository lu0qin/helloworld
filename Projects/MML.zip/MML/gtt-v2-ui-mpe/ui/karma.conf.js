module.exports = function(config) {
	"use strict";

	const UI5_URL = process.env.UI5_URL;

	config.set({

		// base path that will be used to resolve all patterns (eg. files, exclude)
		// basePath: "",


		// frameworks to use
		frameworks: ["ui5"],


		// list of files / patterns to load in the browser
		// files: [
		// ],


		// list of files / patterns to exclude
		// exclude: [
		// ],


		// preprocess matching files before serving them to the browser
		preprocessors: {
			"webapp/util/*.js": "coverage",
			"webapp/controller/*.js": "coverage",
			"webapp/Component.js": "coverage"
		},


		// test results reporter to use
		// possible values: 'dots', 'progress'
		reporters: ["progress", "coverage", "junit"],


		// web server port
		// port: 9876,


		// enable / disable colors in the output (reporters and logs)
		colors: true,


		// level of logging
		// possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
		// logLevel: config.LOG_INFO,


		// enable / disable watching file and executing tests whenever any file changes
		autoWatch: false,


		// start these browsers
		// available browser launchers: https://npmjs.org/browse/keyword/karma-launcher
		browsers: ["ChromeHeadless"],


		// Continuous Integration mode
		// if true, Karma captures browsers, runs the tests and exits
		singleRun: true,

		// Concurrency level
		// how many browser should be started simultaneous
		concurrency: Infinity,

		proxies: {
			"/base/resources/": "/base/webapp/resources",
			"/base/test-resources/": "/base/webapp/test"
		},

		junitReporter: {
			outputDir: "target/surefire-reports",
			outputFile: "unit.allTests.xml"
		},

		coverageReporter: {
			includeAllSources: true,
			dir: "coverage",
			reporters: [
				{
					type: "html",
					subdir: "html"
				},
				{
					type: "text"
				},
				{
					type: "text-summary"
				},
				{
					type: "cobertura",
					subdir: "."
				},
				{
					type: "lcovonly",
					subdir: "."
				}
			]
		},

		// ui5 config
		ui5: {
			url: UI5_URL,
			testpage: "/base/test-resources/testsuite.qunit.html"
		},

		// How long will Karma wait for a message from a browser before disconnecting from it (in ms)
		browserNoActivityTimeout: 120000
	});
};