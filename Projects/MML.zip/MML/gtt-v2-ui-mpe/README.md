# gtt-v2-ui-mpe
ui for Manage Message Logs

## Pre-requisites

- Node.js - https://nodejs.org/
- Download: http://nexus.wdf.sap.corp:8081/nexus/content/groups/build.releases.xmake/com/sap/mta/mta_archive_builder/

Set registry to internal site

```sh
$ npm config set registry http://nexus.wdf.sap.corp:8081/nexus/content/groups/build.milestones.npm/
```

## Run

### SAPUI5 Application

Run web application in a local web server.

```sh
cd ui
npm start
```

To visit live app by link http://localhost:5000/.
To visit mock app by http://localhost:5000/test/.

Run unit test in a debug mode
```sh
cd ui
npm run test:debug
```

