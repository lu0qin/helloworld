require('dotenv').config();

const { describe, it, before, beforeEach, after, afterEach } = require('mocha');
const { expect } = require('chai');
const { By, Key, until } = require('selenium-webdriver');
const { suite } = require('selenium-webdriver/testing');

const seleniumUrl = process.env['SELENIUM_REMOTE_URL'];
console.log('seleniumUrl :', seleniumUrl);

const SearchPage = require('../pages/searchPage');

suite(function (env) {

  describe('Search', function () {
    let driver;

    before(async function () {
      console.log('before');
      const builder = await env.builder();

      if (process.env.SELENIUM_GRID_APPLICATION_NAME) {
        builder.withCapabilities({
          applicationName: process.env.SELENIUM_GRID_APPLICATION_NAME
        });
      }

      driver = builder.build();
    });

    after(async function () {
      console.log('after');

      await driver.quit();
    });

    beforeEach(function () {
      console.log('beforeEach');
    });

    afterEach(function () {
      console.log('afterEach');
    });

    it('DuckDuckGo', async function () {
      const searchPage = new SearchPage(driver);
      await searchPage.open();

      const query = 'webdriver';
      await searchPage.search(query);

      await driver.wait(until.titleContains(query), 10000);

      expect(await searchPage.searchedCorrectly(query)).to.be.true;
    });
  });
});
