const { By, Key, until } = require('selenium-webdriver');

const Page = require('./page');

class SearchPage extends Page {
  get searchbox() {
    return By.css('#search_form_input_homepage');
  }

  async open() {
    await super.open('https://duckduckgo.com');
  }

  async search(text) {
    const searchbox = await this.find(this.searchbox);
    await searchbox.sendKeys(text, Key.RETURN);
  }

  async searchedCorrectly(text) {
    const textbox = await this.find(By.name('q'));
    const ftext = await textbox.getAttribute('value');
    return ftext === text;
  }
}

module.exports = SearchPage;
