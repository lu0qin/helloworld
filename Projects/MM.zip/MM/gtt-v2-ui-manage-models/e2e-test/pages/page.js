class Page {
  constructor(driver) {
    this.driver = driver;
    this.title = 'Page';
  }

  async open(url) {
    await this.driver.get(url);
  }

  async find(locator) {
    return await this.driver.findElement(locator);
  }
}

module.exports = Page;
