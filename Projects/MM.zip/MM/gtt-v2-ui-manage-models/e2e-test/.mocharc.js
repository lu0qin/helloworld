module.exports = {
  timeout: 30000,
  reporter: 'xunit',
  // reporterOptions: ['output=target/surefire-reports/TEST-com.sap.gtt.app.sample.ChromeTest.xml'],
};
