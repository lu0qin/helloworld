sap.ui.define(
  [
    "./BaseController",
    "sap/base/Log",
    "sap/base/util/merge",
    "sap/ui/core/ValueState",
    "sap/ui/model/json/JSONModel",
    "sap/m/ObjectStatus",
    "sap/m/Text",
    "sap/m/VBox",
    "sap/suite/ui/commons/TimelineItem",
    "sap/suite/ui/commons/util/DateUtils",
    "../constant/ActionResult",
    "../constant/DeployAction",
    "../constant/ModelViewType",
    "../util/AsyncUtils",
    "../util/RestClient",
    "../util/ServiceUtils",
  ],
  function (
    BaseController,
    Log,
    merge,
    ValueState,
    JSONModel,
    ObjectStatus,
    Text,
    VBox,
    TimelineItem,
    DateUtils,
    ActionResult,
    DeployAction,
    ModelViewType,
    AsyncUtils,
    RestClient,
    ServiceUtils
  ) {
    "use strict";

    return BaseController.extend("com.sap.gtt.v2.model.manage.controller.History", {
      initModel: function () {
        var model = new JSONModel({
          model: {},
          modelViewType: ModelViewType.History,
        });
        this.setModel(model, "store");

        var data = {
          busy: false,
          records: [],
          promises: {},
        };
        var viewModel = new JSONModel(data);
        this.setModel(viewModel, "view");
      },

      initRoute: function () {
        // route to history
        this.getRouter()
          .getRoute("history")
          .attachPatternMatched(
            function (event) {
              this.onRouteMatched(event);
            }.bind(this)
          );
      },

      onRouteMatched: function (oEvent) {
        // get arguments
        var args = oEvent.getParameter("arguments");
        this.refresh(args);
      },

      onViewSelected: function (oEvent) {
        var item = oEvent.getParameter("item");
        var key = item.getKey();

        var viewRoute = {};
        viewRoute[ModelViewType.Draft] = "modelDraft";
        viewRoute[ModelViewType.Runtime] = "deployment";
        viewRoute[ModelViewType.Deployed] = "modelDetail";
        viewRoute[ModelViewType.History] = "history";

        var route = viewRoute[key];
        var context = this.getStoreContext();
        var namespace = context.getProperty("namespace");

        this.getRouter().navTo(route, {
          namespace: namespace,
        });
      },

      subscribeEvents: function () {
        var eventBus = this.getEventBus();
        eventBus.subscribe("modelHistory", "modelUpdated", this.onBindingChange, this);
      },

      unsubscribeEvents: function () {
        var eventBus = this.getEventBus();
        eventBus.unsubscribe("modelHistory", "modelUpdated", this.onBindingChange, this);
      },

      onBindingChange: function (channelId, eventId, promiseModelUpdated) {
        Log.info("onBindingChange", this.getView().getId());

        // update data
        promiseModelUpdated.then(this.updateData.bind(this));
      },

      getViewModel: function () {
        return this.getModel("view");
      },

      getStoreContext: function () {
        var objectPageLayout = this.byId("objectPageLayout");
        return objectPageLayout.getBindingContext("store");
      },

      refresh: function (options) {
        var promise = this.updateHeaderData(options.namespace);

        promise.catch(
          function (error) {
            Log.error(error);
            this.getRouter().getTargets().display("notFound");
          }.bind(this)
        );

        // trigger model data change event
        this.getEventBus().publish("modelHistory", "modelUpdated", promise);
      },

      updateHeaderData: function (namespace) {
        this.setBusy(true);

        var dataSource = ServiceUtils.getDataSource("mainService");
        var url = ServiceUtils.getUrl(dataSource.uri).concat(
          "/models/",
          namespace,
          "/deployments/current/info"
        );
        var request = RestClient.get(url);

        var promise = AsyncUtils.finally(
          request,
          function () {
            this.setBusy(false);
          }.bind(this)
        );

        return promise.then(
          function (data) {
            return this.updateModelData(data);
          }.bind(this)
        );
      },

      updateData: function () {
        this.setBusy(true);

        var context = this.getStoreContext();
        var namespace = context.getProperty("namespace");

        var dataSource = ServiceUtils.getDataSource("mainService");
        var url = ServiceUtils.getUrl(dataSource.uri).concat("/models/", namespace, "/history");
        var request = RestClient.get(url);

        var promise = AsyncUtils.finally(
          request,
          function () {
            this.setBusy(false);
          }.bind(this)
        );

        return promise.then(
          function (data) {
            var items = this.processData(data);
            return this.updateHistoryData(items);
          }.bind(this),
          function (error) {
            this.handleServerError(error);
          }.bind(this)
        );
      },

      processData: function (data) {
        return (data.value || []).map(function (obj) {
          var item = merge({}, obj);
          item.changedAt = DateUtils.parseDate(obj.changedAt); // convert ISO8601 date time string to Date object
          item.action = item.action || DeployAction.Deploy;

          return item;
        });
      },

      updateModelData: function (data) {
        var context = this.getStoreContext();
        var model = context.getModel();
        model.setProperty("", data, context);

        return data;
      },

      updateHistoryData: function (items) {
        var viewModel = this.getViewModel();

        viewModel.setProperty("/records", items);

        return items;
      },

      createTimeLineItem: function (id, context) {
        var timeLineItem = new TimelineItem(id, {
          dateTime: "{view>changedAt}",
          icon: {
            path: "view>messageType",
            formatter: this.formatter.deployHistoryTimelineItemIcon.bind(this),
          },
          title: "",
          status: {
            path: "view>messageType",
            formatter: this.formatter.deployHistoryTimelineItemStatus.bind(this),
          },
        });

        var timelineItemContent = this.createTimelineItemContent(context);
        timeLineItem.setEmbeddedControl(timelineItemContent);

        return timeLineItem;
      },

      createTimelineItemContent: function (context) {
        var oResourceBundle = this.getResourceBundle();
        var messageType = context.getProperty("messageType");
        var action = context.getProperty("action");
        var message = context.getProperty("message");

        var msgDeployTechnicalError = oResourceBundle.getText(
          "changeHistoryDeployWithTechnicalErrorText"
        );
        var msgDeleteTechnicalError = oResourceBundle.getText(
          "changeHistoryDeleteWithTechnicalErrorText"
        );
        var msgDeployValidationError = oResourceBundle.getText(
          "changeHistoryDeployWithValidationErrorText"
        );
        var msgLogIncident = oResourceBundle.getText("logIncidentInBCPSystem");
        var msgActivate = oResourceBundle.getText("deploymentHistoryTextForActivate");
        var msgDeactivate = oResourceBundle.getText("deploymentHistoryTextForDeactivate");

        var messageText = new Text().addStyleClass("sapUiTinyMarginTopBottom");
        messageText.setText(message);
        var contactSAPText = new ObjectStatus({
          text: msgLogIncident,
          state: ValueState.Error,
        });

        var control = new VBox({
          items: [messageText],
        });

        switch (messageType) {
          case ActionResult.ValidationError:
            messageText.setText([message, msgDeployValidationError].join("\n"));
            break;
          case ActionResult.TechnicalError:
            var msgTechnicalError =
              action === DeployAction.Delete ? msgDeleteTechnicalError : msgDeployTechnicalError;
            messageText.setText([message, msgTechnicalError].join("\n"));
            control.addItem(contactSAPText);
            break;
          default:
            if (action === DeployAction.Activate) {
              messageText.setText(msgActivate);
            }

            if (action === DeployAction.Deactivate) {
              messageText.setText(msgDeactivate);
            }
            break;
        }

        return control;
      },
    });
  }
);
