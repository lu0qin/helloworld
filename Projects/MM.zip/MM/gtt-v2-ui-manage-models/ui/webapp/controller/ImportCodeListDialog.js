sap.ui.define(
  ["sap/ui/core/ValueState", "./BaseDialog", "../util/ServiceUtils", "../util/RestClient"],
  function (ValueState, BaseDialog, ServiceUtils, RestClient) {
    "use strict";

    return BaseDialog.extend("com.sap.gtt.v2.model.manage.controller.ImportCodeListDialog", {
      onBeforeOpen: function (oEvent) {
        var dialog = oEvent.getSource();

        // Init private property to store dialog model
        this._dialog = dialog;
        this._dialogModel = dialog.getModel("dialog");
        this._loadLBNCodeLists();
      },

      onSelectionChange: function (oEvent) {
        var oSelectedItem = oEvent.getParameter("selectedItem");

        if (!oSelectedItem) {
          return;
        }

        this._loadLBNCodeListDetail(oSelectedItem.getKey());
      },
      
      onUpdateFinished: function (oEvent) {
        var sTitle;

        var oTable = oEvent.getSource();
        var oItemsBinding = oTable.getBinding("items");
        var iTotalItems = oItemsBinding.getLength();
        if (oItemsBinding.isLengthFinal()) {
          sTitle = this.getResourceBundle().getText("previewCodes", [iTotalItems]);
        } else {
          sTitle = this.getResourceBundle().getText("previewCodes");
        }
        this._dialogModel.setProperty("/info/tableTitle", sTitle);
      },

      setDialogState: function (valueState) {
        this._dialogModel.setProperty("/info/state", valueState);
      },

      setCodeListsData: function (codeLists) {
        this._dialogModel.setProperty("/info/lists", codeLists);
      },

      setCodeListDetailData: function (codeList) {
        this._dialogModel.setProperty("/data", codeList);
      },

      fireSelectionChangeForCodeListSelect: function (key) {
        var oCodeListSelect = this.byId("codeListSelect");
        if (!oCodeListSelect || !key) {
          return;
        }

        var oTargetSelectItem = oCodeListSelect.getItemByKey(key);
        oCodeListSelect.fireChange({ selectedItem: oTargetSelectItem });
      },

      // ========================================================
      // HTTP Request
      // ========================================================
      _handleLoadRequest: function (urlParam, successHandler, errorHandler) {
        var that = this;

        that._dialog.setBusy(true);

        var dataSource = ServiceUtils.getDataSource("mainService");
        var url = ServiceUtils.getUrl(dataSource.uri).concat(urlParam);

        var request = RestClient.get(url);

        request.then(successHandler, errorHandler).finally(function () {
          that._dialog.setBusy(false);
        });
      },

      _loadLBNCodeLists: function () {
        var that = this;

        var urlParam = "/lbn/codelists";
        this._handleLoadRequest(
          urlParam,
          function (data) {
            var codeLists = data.value;
            that.setCodeListsData(codeLists);
            that.setDialogState(ValueState.None);

            // if code lists is not empty, by default select the first one
            if (codeLists && codeLists.length > 0) {
              that.fireSelectionChangeForCodeListSelect(codeLists[0].name);
            }
          },
          function (error) {
            // show error message in subHeader
            that.setDialogState(ValueState.Error);
            // reset codeLists to empty array
            that.setCodeListsData([]);
          }
        );
      },

      _loadLBNCodeListDetail: function (codeListName) {
        var that = this;

        if (!codeListName) {
          return;
        }

        var urlParam = "/lbn/codelists".concat("/", codeListName);
        that._handleLoadRequest(
          urlParam,
          function (data) {
            that.setCodeListDetailData(data);
            that.setDialogState(ValueState.None);
          },
          function (error) {
            // show error message in subHeader
            that.setDialogState(ValueState.Error);
            // reset codeLists to empty JSON object
            that.setCodeListDetailData({});
          }
        );
      },
    });
  }
);
