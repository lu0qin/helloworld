sap.ui.define(
  [
    "./BaseDialog",
    "sap/m/MessageBox",
    "sap/ui/unified/FileUploaderParameter",
    "sap/m/MessageToast",
    "../util/RestClient",
    "../util/ServiceUtils",
  ],
  function (BaseDialog, MessageBox, FileUploaderParameter, MessageToast, RestClient, ServiceUtils) {
    "use strict";
    return BaseDialog.extend("com.sap.gtt.v2.model.manage.controller.ImportDialog", {
      handleTypeMissmatch: function (oEvent) {
        var aFileTypes = oEvent.getSource().getFileType();
        aFileTypes = aFileTypes.map(function (sFileType) {
          return "*." + sFileType;
        });
        var sSupportedFileTypes = aFileTypes.join(", ");
        var sMsg = this.getResourceBundle().getText("FILE_TYPE_NOT_SUPPORTED", [
          oEvent.getParameter("fileType"),
          sSupportedFileTypes,
        ]);
        MessageBox.error(sMsg);
      },

      onAcceptPress: function (oEvent) {
        var oControl = oEvent.getSource();
        var oDialog = oControl.getParent();
        var oFileUploader = this.byId("fileUploader");

        if (!oFileUploader.getValue()) {
          return;
        }

        oDialog.setBusy(true);

        var dataSource = ServiceUtils.getDataSource("mainService");
        var url = ServiceUtils.getUrl(dataSource.uri).concat("/models/import");
        RestClient.getCSRFToken().then(
          function (token) {
            oFileUploader.destroyHeaderParameters();
            oFileUploader.setUploadUrl(url);
            oFileUploader.addHeaderParameter(
              new FileUploaderParameter({
                name: "x-csrf-token",
                value: token,
              })
            );
            oFileUploader.upload();
          },
          function (error) {
            oDialog.setBusy(false);
          }
        );
      },

      onUploadComplete: function (oEvent) {
        var oDialog = this.byId("dialog");
        oDialog.setBusy(false);

        var sResponse = oEvent.getParameter("responseRaw");
        var iStatus = oEvent.getParameter("status");

        switch (iStatus) {
          case 201:
            this.handleRequestSuccess(sResponse);
            break;
          case 409:
            var oMsgJson = JSON.parse(sResponse);
            var sCode = oMsgJson.error.code;
            var sModelName = oMsgJson.error.details[0].name;
            MessageBox.warning(this.getResourceBundle().getText(sCode, sModelName), {
              actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
              emphasizedAction: MessageBox.Action.OK,
              onClose: function (sAction) {
                switch (sAction) {
                  case MessageBox.Action.OK:
                    var oMsgDetail = oMsgJson.error.details[0];
                    var sNamespace = oMsgDetail.namespace;
                    var sStagingId = oMsgDetail.stagingId;
                    var dataSource = ServiceUtils.getDataSource("mainService");
                    var url = ServiceUtils.getUrl(dataSource.uri).concat(
                      "/models/" + sNamespace + "/draft/import"
                    );
                    var oData = {
                      stagingId: sStagingId,
                      overwrite: true,
                    };
                    var request = RestClient.put(url, oData);

                    request.then(
                      this.handleRequestSuccess.bind(this),
                      function (error) {
                        this.handleImportError(error);
                      }.bind(this)
                    );
                    break;
                  case MessageBox.Action.CANCEL:
                    break;
                }
              }.bind(this),
            });
            break;
          default:
            this.handleRequestError(sResponse);
            break;
        }
      },

      handleRequestSuccess: function () {
        var sMsg = this.getResourceBundle().getText("MODEL_IMPORT_SUCCESS");
        MessageToast.show(sMsg);
        this.byId("dialog").close();
        this.updateListBinding();
      },

      handleRequestError: function (sResponse) {
        var oDMsgJson = JSON.parse(sResponse);
        var sdMsg = oDMsgJson.error.message;
        MessageBox.error(sdMsg);
      },

      getResourceBundle: function () {},
    });
  }
);
