sap.ui.define(
  [
    "./BaseController",
    "sap/base/Log",
    "sap/base/util/each",
    "sap/base/util/extend",
    "sap/base/strings/formatMessage",
    "sap/ui/model/json/JSONModel",
    "../util/AsyncUtils",
    "../util/RestClient",
    "../util/ServiceUtils",
  ],
  function (
    BaseController,
    Log,
    each,
    extend,
    formatMessage,
    JSONModel,
    AsyncUtils,
    RestClient,
    ServiceUtils
  ) {
    "use strict";

    return BaseController.extend("com.sap.gtt.v2.model.manage.controller.SwaggerUIController", {
      getDefaultData: function () {
        var defaults = {
          busy: false,
          specPath: "/model/{0}/spec",
          spec: null,
          testServer: {
            description: "Try it out",
            url: "/api/sandbox/rest/v1",
          },
          promises: {},
        };

        defaults.swaggerUi = null;

        return defaults;
      },

      initModel: function () {
        var data = this.getDefaultData();
        var viewModel = new JSONModel(data);
        this.setModel(viewModel, "view");
      },

      getViewModel: function () {
        return this.getModel("view");
      },

      subscribeEvents: function () {
        var eventBus = this.getEventBus();
        eventBus.subscribe("modelDeployment", "modelUpdated", this.onBindingChange, this);
      },

      unsubscribeEvents: function () {
        var eventBus = this.getEventBus();
        eventBus.unsubscribe("modelDeployment", "modelUpdated", this.onBindingChange, this);
      },

      initControls: function () {
        var oHtml = this.byId("swagger-ui");
        oHtml.setContent("<div></div>");
      },

      onBindingChange: function (channelId, eventId, promiseModelUpdated) {
        Log.info("onBindingChange", this.getView().getId());

        // update data
        var promiseDataUpdated = promiseModelUpdated.then(this.updateData.bind(this));

        // wait for dom rendered
        var promiseDomRendered = this.getPromise("promiseDomRendered");

        // update DOM content
        Promise.all([promiseDataUpdated, promiseDomRendered]).then(
          function (values) {
            var data = values[0];
            this.renderDom(data);
          }.bind(this)
        );
      },

      updateData: function () {
        return this.updateSpec();
      },

      renderDom: function (data) {
        Log.info("renderDom", this.getView().getId());
        this.renderSpec(data);
      },

      getStoreContext: function () {
        var view = this.getView();
        return view.getBindingContext("store");
      },

      updateSpec: function () {
        this.setBusy(true);
        this.clearSpec();

        var context = this.getStoreContext();
        var namespace = context.getProperty("namespace");
        var viewModel = this.getViewModel();
        var specPath = viewModel.getProperty("/specPath");
        var dataSource = ServiceUtils.getDataSource("metadataService");
        var url = ServiceUtils.getUrl(dataSource.uri).concat(formatMessage(specPath, namespace));
        var request = RestClient.get(url);

        var promise = AsyncUtils.finally(
          request,
          function () {
            this.setBusy(false);
          }.bind(this)
        );

        return promise.then(
          function (data) {
            var spec = this.getSpec(data, namespace);
            return this.updateModelData(spec);
          }.bind(this),
          function (error) {
            this.handleServerError(error);
          }.bind(this)
        );
      },

      getSpec: function (spec) {
        var viewModel = this.getViewModel();

        // add servers
        var apiServer = {};
        var serverInfo = viewModel.getProperty("/serverInfo");
        var dataSource = ServiceUtils.getDataSource(serverInfo.dataSource);
        apiServer.description = serverInfo.description;
        apiServer.url = formatMessage("{0}/{1}", window.location.origin, "api/inbound/rest/v1"); // "https://<host>/api/inbound/rest/v1"
        spec.servers = [apiServer];

        // override server url in each path object
        var testServerUrl = ServiceUtils.getUrl(dataSource.uri); // "../api/inbound/rest/v1"
        each(spec.paths, function (path, pathObj) {
          pathObj.servers = [
            {
              url: testServerUrl,
            },
          ];
        });

        // add security
        extend(spec.components, {
          securitySchemes: {
            CSRFToken: {
              type: "apiKey",
              in: "header",
              name: "X-CSRF-Token",
            },
          },
        });

        spec.security = [
          {
            CSRFToken: [],
          },
        ];

        return spec;
      },

      updateModelData: function (spec) {
        var viewModel = this.getViewModel();
        viewModel.setProperty("/spec", spec);

        return spec;
      },

      clearSpec: function () {
        var swaggerUi = this.getSwaggerUi();

        if (swaggerUi) {
          swaggerUi.specActions.updateLoadingStatus("loading");
          swaggerUi.errActions.clear({ source: "fetch" });
        }
      },

      getSwaggerUi: function () {
        var viewModel = this.getViewModel();
        return viewModel.getProperty("/swaggerUi");
      },

      setSwaggerUi: function (swaggerUi) {
        var viewModel = this.getViewModel();
        viewModel.setProperty("/swaggerUi", swaggerUi);
      },

      renderSpec: function (spec) {
        var swaggerUiElem = this.byId("swagger-ui");
        var swaggerUiDomNode = swaggerUiElem.getDomRef();

        var config = {
          domNode: swaggerUiDomNode,
          spec: spec,
          plugins: [
            // SwaggerUIBundle.plugins.DownloadUrl,
          ],
        };

        var context = this.getStoreContext();
        var status = context.getProperty("status");
        if (status !== "ACTIVE") {
          config.supportedSubmitMethods = [];
        }

        var swaggerUi = SwaggerUIBundle(
          extend(config, {
            onComplete: function () {
              // set CSRF token
              RestClient.getCSRFToken().then(function (csrfToken) {
                swaggerUi.preauthorizeApiKey("CSRFToken", csrfToken);
              });
            },
          })
        );

        this.setSwaggerUi(swaggerUi);
      },
    });
  }
);
