sap.ui.define(["../constant/ObjectType", "../constant/FieldType", "./WhereUsedListHelper"], function (
  ObjectType,
  FieldType,
  WhereUsedListHelper
) {
  "use strict";

  var IntegrationMappingHelper = {
    controllerContext: this,

    init: function (controllerContext) {
      this._controllerContext = controllerContext;

      // set where used list helper
      var whereUsedListHelper = controllerContext.whereUsedListHelper;
      if (!controllerContext.whereUsedListHelper) {
        whereUsedListHelper = new WhereUsedListHelper();
        whereUsedListHelper.init(controllerContext);
      }
      this._whereUsedListHelper = whereUsedListHelper;
    },

    /**
     *
     * @param {object} item current user field item
     * @param {object} object current objects, processType or eventType
     */
    updateIDocMapping: function (item, object) {
      // Get target tp.idocMapping
      if (object.idocMapping && object.idocMapping.fieldMapping) {
        var aFieldMapping = object.idocMapping.fieldMapping;
        this.addFieldMappingElement(item, aFieldMapping);
      }
    },

    /**
     *
     * @param {object} item current user field item
     * @param {object} object current objects, processType or eventType
     */
    updateVPMapping: function (item, object) {
      if (object.vpMapping && object.vpMapping.fieldMapping) {
        var aFieldMapping = object.vpMapping.fieldMapping;
        if (object._objectType === ObjectType.EventType) {
          this.addFieldMappingElement(item, aFieldMapping);
        }
      }
    },

    addFieldMappingElement: function (item, aFieldMapping) {
      // no need to add when type is AssociationToMany
      if (FieldType.isItemAssociationToMany(item)) {
        return;
      }

      var newField = {
        _ref: {
          field: item,
        },
      };

      // add dependency to where-used list
      this._whereUsedListHelper.addMappingItemDependency(newField);

      if (item.type === FieldType.Composition && item._ref && item._ref.target) {
        var targetItemType = item._ref.target;
        newField._ref.target = targetItemType;
        newField.composition = targetItemType.elements.map(function (element) {
          var newCompositionField = {
            _ref: {
              field: element,
            },
          };
          // add dependency to where-used list
          this._whereUsedListHelper.addMappingItemDependency(newCompositionField);
          return newCompositionField;
        }, this);
      }

      aFieldMapping.push(newField);
    },

    /**
     *
     * @param {object} itemTypeElement current user field item
     * @param {object} itemType itemType holds item
     * @param {object} object current objects, eventType
     */
    updateItemTypeInIDocMapping: function (itemTypeElement, itemType, object) {
      if (object.idocMapping && object.idocMapping.fieldMapping) {
        var aFieldMapping = object.idocMapping.fieldMapping;
        this.addCompositionMappingElement(itemTypeElement, object, itemType, aFieldMapping);
      }
    },

    /**
     *
     * @param {object} itemTypeElement current user field item
     * @param {object} itemType itemType holds item
     * @param {object} object current objects, eventType
     */
    updateItemTypeInVPMapping: function (itemTypeElement, itemType, object) {
      if (
        object._objectType === ObjectType.EventType &&
        object.vpMapping &&
        object.vpMapping.fieldMapping
      ) {
        var aFieldMapping = object.vpMapping.fieldMapping;
        this.addCompositionMappingElement(itemTypeElement, object, itemType, aFieldMapping);
      }
    },

    addCompositionMappingElement: function (itemTypeElement, object, itemType, aFieldMapping) {
      aFieldMapping.forEach(function (oField) {
        if (oField._ref && oField._ref.target === itemType) {
          if (!oField.composition) {
            oField.composition = [];
          }
          if (
            !oField.composition.find(function (field) {
              return field._ref && field._ref.field === itemTypeElement;
            })
          ) {
            var newCompositionField = {
              _ref: {
                field: itemTypeElement,
              },
            };
            oField.composition.push(newCompositionField);
            this._whereUsedListHelper.addMappingItemDependency(newCompositionField);
          }
        }
      }, this);
    },
  };

  return IntegrationMappingHelper;
});
