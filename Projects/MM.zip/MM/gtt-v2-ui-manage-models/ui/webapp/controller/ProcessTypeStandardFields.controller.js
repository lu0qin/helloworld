sap.ui.define(
  ["./StandardFields", "sap/ui/model/json/JSONModel"],
  function (StandardFieldsController, JSONModel) {
    "use strict";
    return StandardFieldsController.extend(
      "com.sap.gtt.v2.model.manage.controller.ProcessTypeStandardFields",
      {
        initModel: function () {
          // Set relevant info for view
          var view = new JSONModel({
            tableTitle: "",
            isShowDppColumn: true,
            isShowKeyColumn: false,
            isShowAuthScopeColumn: true,
          });
          this.setModel(view, "view");
        },
      }
    );
  }
);
