sap.ui.define(
  ["./StandardFields", "sap/ui/model/json/JSONModel"],
  function (StandardFieldsController, JSONModel) {
    "use strict";
    return StandardFieldsController.extend(
      "com.sap.gtt.v2.model.manage.controller.ItemTypeStandardFields",
      {
        initModel: function () {
          // Set relevant info for view
          var view = new JSONModel({
            tableTitle: "",
            isShowDppColumn: false,
            isShowKeyColumn: true,
            isShowAuthScopeColumn: false,
          });
          this.setModel(view, "view");
        },
      }
    );
  }
);
