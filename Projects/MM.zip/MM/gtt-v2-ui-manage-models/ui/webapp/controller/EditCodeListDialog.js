sap.ui.define(["./EditTypeDialog"], function (EditTypeDialog) {
  "use strict";

  return EditTypeDialog.extend("com.sap.gtt.v2.model.manage.controller.EditCodeListDialog", {
    getMandatoryControls: function () {
      return [this.byId("name")];
    },
  });
});
