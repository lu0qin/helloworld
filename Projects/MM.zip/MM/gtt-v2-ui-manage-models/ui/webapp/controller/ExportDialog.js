sap.ui.define(["./BaseDialog", "../util/ServiceUtils"], function (BaseDialog, ServiceUtils) {
  "use strict";
  return BaseDialog.extend("com.sap.gtt.v2.model.manage.controller.ExportDialog", {
    getView: function () {},
    onAcceptPress: function (oEvent) {
      var oControl = oEvent.getSource();
      var oModel = oControl.getModel("dialog");
      var aData = oModel.getProperty("/data");
      var sNamespace = aData[0].namespace;
      var bDraftSelected = aData[0].draftSelected;
      var dataSource = ServiceUtils.getDataSource("mainService");
      var url = ServiceUtils.getUrl(dataSource.uri);
      if (bDraftSelected) {
        url = url.concat("/models/", sNamespace, "/draft/export");
      } else {
        url = url.concat("/models/", sNamespace, "/deployments/current/export");
      }
      window.location.href = url;

      var oDialog = oEvent.getSource().getParent();
      oDialog.close();
    },
  });
});
