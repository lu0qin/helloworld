sap.ui.define(["../SwaggerUIController", "sap/ui/model/json/JSONModel"], function (
  SwaggerUIController,
  JSONModel
) {
  "use strict";

  return SwaggerUIController.extend("com.sap.gtt.v2.model.manage.controller.ReadAPI", {
    initModel: function () {
      var data = this.getDefaultData();
      Object.assign(data, {
        specPath: "/model/{0}/spec/read",
        serverInfo: {
          description: "Read Service",
          dataSource: "outboundService",
        },
      });

      var viewModel = new JSONModel(data);
      this.setModel(viewModel, "view");
    },
  });
});
