sap.ui.define(
  [
    "../SwaggerUIController",
    "sap/base/util/extend",
    "sap/base/strings/formatMessage",
    "sap/ui/model/json/JSONModel",
  ],
  function (SwaggerUIController, extend, formatMessage, JSONModel) {
    "use strict";

    return SwaggerUIController.extend("com.sap.gtt.v2.model.manage.controller.WriteAPI", {
      initModel: function () {
        var data = extend(this.getDefaultData(), {
          specPath: "/model/{0}/spec/write",
          serverInfo: {
            description: "Write Service",
            dataSource: "inboundService",
          },
        });

        var viewModel = new JSONModel(data);
        this.setModel(viewModel, "view");
      },
    });
  }
);
