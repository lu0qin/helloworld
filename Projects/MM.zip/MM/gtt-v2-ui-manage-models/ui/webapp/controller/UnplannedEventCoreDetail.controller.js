sap.ui.define(["./BaseController", "sap/ui/model/json/JSONModel"], function (
  BaseController,
  JSONModel
) {
  "use strict";
  return BaseController.extend("com.sap.gtt.v2.model.manage.controller.UnplannedEventCoreDetail", {

    initModel: function () {
      // Set relevant info for planned event extension view
      var view = new JSONModel({
        tableTitle: "",
      });
      this.setModel(view, "view");
    },

    onUpdateFinished: function () {
      var oTable = this.byId("table");
      var sTitle;
      var iTotalItems = oTable.getBinding("items").getLength();
      if (oTable.getBinding("items").isLengthFinal()) {
        sTitle = this.getResourceBundle().getText("coreUnplannedEventTableTitle", [iTotalItems]);
      } else {
        sTitle = this.getResourceBundle().getText("coreUnplannedEventTableTitle");
      }
      this.getModel("view").setProperty("/tableTitle", sTitle);
    },
  });
});
