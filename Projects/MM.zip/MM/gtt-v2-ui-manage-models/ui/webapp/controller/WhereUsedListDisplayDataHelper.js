sap.ui.define(
  [
    "sap/base/strings/formatMessage",
    "sap/base/util/merge",
    "./WhereUsedListHelper",
    "../constant/UsedType",
    "../constant/ObjectType",
    "../constant/FieldType",
  ],
  function (formatMessage, merge, WhereUsedListHelper, UsedType, ObjectType, FieldType) {
    "use strict";

    var WhereUsedListDisplayDataHelper = {
      _controllerContext: this,

      init: function (controllerContext) {
        this._controllerContext = controllerContext;

        // set resource bundle
        var resourceBundle = controllerContext.getResourceBundle();
        if (!resourceBundle) {
          resourceBundle = controllerContext.getView().getModel("i18n").getResourceBundle();
        }
        this._resourceBundle = resourceBundle;

        // set where used list helper
        var whereUsedListHelper = controllerContext.whereUsedListHelper;
        if (!controllerContext.whereUsedListHelper) {
          whereUsedListHelper = new WhereUsedListHelper();
          whereUsedListHelper.init(controllerContext);
        }
        this._whereUsedListHelper = whereUsedListHelper;
      },

      _getStoreModel: function () {
        // set store model
        return this._controllerContext.getView().getModel("store");
      },

      /**
       * General function to get display data for Delete Dialog
       * @param {object} item object of the item to delete
       * @returns {array} empty if no data for display
       */
      getDisplayData: function (item) {
        switch (item._objectType) {
          case ObjectType.ProcessType:
            return this._getProcessTypeListData(item);
          case ObjectType.ItemType:
            return this._getItemTypeListData(item);
          case ObjectType.EventType:
            return this._getEventTypeListData(item);
          case ObjectType.CodeList:
            return this._getCodeListData(item);
          case ObjectType.UserField:
            return this._getUserFieldDisplayData(item);
          case ObjectType.PlannedEventExtension:
            return this._getPlannedEventExtensionListData(item);
          default:
            break;
        }

        return [];
      },

      checkIfEntityIsUsed: function (oEntity) {
        var whereUsedList = this._whereUsedListHelper.getWhereUsedList();

        var result = whereUsedList.find(function (listItem) {
          return listItem.object === oEntity && listItem.usedType === UsedType.Dependency;
        });

        return !!result;
      },

      checkIfUserFieldUsedByMapping: function (userField) {
        // Planned Event Extension
        if (!userField._parent) {
          return false;
        }

        var result = [];

        switch (userField._parent._objectType) {
          case ObjectType.ProcessType:
            result = this._getProcessTypeUserFieldMappingListData(userField);
            break;
          case ObjectType.ItemType:
            result = this._getItemTypeUserFieldListData(userField);
            break;
          case ObjectType.EventType:
            result = this._getEventTypeUserFieldMappingListData(userField);
            break;
          default:
            break;
        }

        return result.length !== 0;
      },

      checkIfProcessTypeUserFieldUsedByAssociationToMany: function (userField) {
        if (!FieldType.isItemAssociationToOne(userField)) {
          return false;
        }

        return this._getAssociationToManyUserFieldListDisplayData(userField).length !== 0;
      },

      // true for be used, false for not be used. For planned event extension and user field of event type
      checkIfUserFieldUsedByMatchExtensionField: function (userField) {
        if (!userField._parent || userField._parent._objectType === ObjectType.EventType) {
          return this._getMatchExtensionOrPlanEventDisplayData(userField).length !== 0;
        }

        return false;
      },

      /**
       * General function to get display data of user field for Delete Dialog
       * @param {object} item object of the user field to delete
       * @returns {array} empty if no data for display
       */
      _getUserFieldDisplayData: function (item) {
        if (!item._parent) {
          return [];
        }

        switch (item._parent._objectType) {
          case ObjectType.ProcessType:
            return this._getProcessTypeUserFieldListData(item);
          case ObjectType.ItemType:
            return this._getItemTypeUserFieldListData(item);
          case ObjectType.EventType:
            return this._getEventTypeUserFieldListData(item);
          default:
            break;
        }

        return [];
      },

      _getProcessTypeUserFieldListData: function (item) {
        var mappingItems = this._getProcessTypeUserFieldMappingListData(item);
        var assoToManyItems = this._getAssociationToManyUserFieldListDisplayData(item);

        return [].concat(mappingItems, assoToManyItems);
      },

      _getEventTypeUserFieldListData: function (item) {
        var extensionItems = this._getMatchExtensionOrPlanEventDisplayData(item);
        var mappingItems = this._getEventTypeUserFieldMappingListData(item);

        return [].concat(extensionItems, mappingItems);
      },

      _getItemTypeUserFieldListData: function (item) {
        var that = this;

        var itemType = item._parent;
        var itemTypeUsedByObjectListDependency = this._whereUsedListHelper.getUsedByObjectList(
          itemType,
          UsedType.Dependency
        );

        var mappingItems = [];
        var idocMappingItem = [];
        var vpMappingItem = [];

        itemTypeUsedByObjectListDependency.forEach(function (usedByObject) {
          var objectType = usedByObject._parent._objectType;
          if (objectType === "ProcessType") {
            idocMappingItem = that._getIDocDisplayData(usedByObject);
            vpMappingItem = that._getProcessTypeUserFieldVPMappingDisplayData(usedByObject);

            idocMappingItem = that._filterIDocMappingItem(item, idocMappingItem);
            vpMappingItem = that._filterVPMappingItem(item, vpMappingItem);

            mappingItems = mappingItems.concat(idocMappingItem, vpMappingItem);
          }

          if (objectType === "EventType") {
            idocMappingItem = that._getIDocDisplayData(usedByObject);
            vpMappingItem = that._getEventTypeUserFieldVPMappingListData(usedByObject);

            idocMappingItem = that._filterIDocMappingItem(item, idocMappingItem);
            vpMappingItem = that._filterVPMappingItem(item, vpMappingItem);

            mappingItems = mappingItems.concat(idocMappingItem, vpMappingItem);
          }
        });

        return mappingItems;
      },

      _getMatchExtensionOrPlanEventDisplayData: function (item) {
        var usedByObjectListDependency = this._whereUsedListHelper.getUsedByObjectList(
          item,
          UsedType.Dependency
        );
        var usedByObjectListAssociation = this._whereUsedListHelper.getUsedByObjectList(
          item,
          UsedType.Association
        );
        var usedByObjectList = usedByObjectListDependency.concat(usedByObjectListAssociation);

        var matchItems = [];
        var resourceBundle = this._resourceBundle;

        usedByObjectList.forEach(function (usedByObject) {
          var admPlannedEvent = usedByObject._parent;

          if (admPlannedEvent && usedByObject._ref) {
            if (usedByObject.operator && admPlannedEvent._ref) {
              var eventType = admPlannedEvent._ref.eventType;
              var processType = eventType._ref.context;

              matchItems.push({
                object: formatMessage("{0}.{1}.{2}={3}", [
                  processType.name,
                  eventType.name,
                  usedByObject._ref.actualEventField.name,
                  usedByObject._ref.plannedEventField.name,
                ]),
                objectType: resourceBundle.getText("actualPlannedMatch"),
              });
            } else if (admPlannedEvent.matchPlanFieldsForUpdatePlan && usedByObject._ref.name) {
              matchItems.push({
                object: usedByObject._ref.name,
                objectType: resourceBundle.getText("plannedPlannedMatch"),
              });
            }
          }
        });

        return matchItems;
      },

      _getPlannedEventExtensionListData: function (item) {
        return this._getMatchExtensionOrPlanEventDisplayData(item);
      },

      _getIDocDisplayData: function (item) {
        var that = this;

        var usedByObjectListDependency = that._whereUsedListHelper.getUsedByObjectList(
          item,
          UsedType.Dependency
        );
        usedByObjectListDependency = usedByObjectListDependency.filter(function (usedByOjectItem) {
          return !usedByOjectItem.operator;
        });

        var entity = item._parent;
        var isProcessType = entity._objectType === ObjectType.ProcessType;
        var processType = isProcessType ? entity : entity._ref.context;
        var enableIDoc = isProcessType ? entity.enableIDoc : processType.enableIDoc;
        var type = item.type;
        var idocMappingItem = [];

        // handle idoc info
        usedByObjectListDependency.forEach(function (usedByObject) {
          if (type === "composition") {
            that._getCompositionIDocDisplayData(
              entity,
              processType,
              isProcessType,
              usedByObject,
              idocMappingItem
            );
          } else if (!FieldType.isItemAssociationToMany(usedByObject)) {
            that._getSimpleIDocDisplayData(
              entity,
              processType,
              isProcessType,
              usedByObject,
              idocMappingItem
            );
          }
        });

        return enableIDoc ? idocMappingItem : [];
      },

      _getSimpleIDocDisplayData: function (
        entity,
        processType,
        isProcessType,
        usedByObject,
        idocMappingItem
      ) {
        var resourceBundle = this._resourceBundle;
        var sMappingWith = resourceBundle.getText("mappingWith");

        var userField = usedByObject._ref.field;
        var idoc = entity.idocMapping.idoc || "";
        var idocSegment = usedByObject.idocSegment || "";
        var idocField = usedByObject.idocField || "";

        if (usedByObject.idocSegment || usedByObject.idocField) {
          idocMappingItem.push({
            object: isProcessType
              ? formatMessage("{0}Event.{1} {2} {3}.{4}.{5}", [
                entity.name,
                userField.name,
                sMappingWith,
                idoc,
                idocSegment,
                idocField,
              ])
              : formatMessage("{0}.{1}.{2}.{3}.{4}.{5}", [
                processType.name,
                entity.name,
                userField.name,
                idoc,
                idocSegment,
                idocField,
              ]),
            objectType: resourceBundle.getText("iDocIntegrationFieldMapping"),
          });
        }
      },

      _getCompositionIDocDisplayData: function (
        entity,
        processType,
        isProcessType,
        usedByObject,
        idocMappingItem
      ) {
        var resourceBundle = this._resourceBundle;
        var sMappingWith = resourceBundle.getText("mappingWith");

        var userField = usedByObject._ref.field;
        var idoc = entity.idocMapping.idoc || "";

        var childrenMappingItems = [];
        usedByObject.composition.forEach(function (compositionItem) {
          if (compositionItem.idocSegment || compositionItem.idocField) {
            childrenMappingItems.push({
              object: formatMessage("{0} {1} {2}.{3}.{4}", [
                compositionItem._ref.field.name,
                sMappingWith,
                idoc,
                compositionItem.idocSegment || "",
                compositionItem.idocField || "",
              ]),
              objectType: resourceBundle.getText("iDocIntegrationFieldMapping"),
            });
          }
        });
        if (childrenMappingItems.length !== 0) {
          idocMappingItem.push({
            object: isProcessType
              ? formatMessage("{0}Event.{1}", [entity.name, userField.name])
              : formatMessage("{0}.{1}.{2}", [processType.name, entity.name, userField.name]),
            objectType: resourceBundle.getText("iDocIntegrationFieldMapping"),
            categories: childrenMappingItems,
          });
        }
      },

      _getEventTypeUserFieldVPMappingListData: function (item) {
        var entity = item._parent;
        var processType = entity._ref.context;
        var enableVP = processType.enableVP;
        var resourceBundle = this._resourceBundle;
        var vpMappingItems = [];
        var sMappingWith = resourceBundle.getText("mappingWith");
        var type = item.type;
        var usedByObjectListDependency = this._whereUsedListHelper.getUsedByObjectList(
          item,
          UsedType.Dependency
        );

        usedByObjectListDependency.forEach(function (usedByObject) {
          if (usedByObject.trackingField) {
            var userField = usedByObject._ref.field;
            var vpMappingItem = {
              object: formatMessage("{0}.{1}.{2} {3} {4}", [
                processType.name,
                entity.name,
                userField.name,
                sMappingWith,
                usedByObject.label,
              ]),
              objectType: resourceBundle.getText("vpIntegrationFieldMapping"),
            };

            if (type === "composition") {
              vpMappingItem.categories = [];

              usedByObject.composition.forEach(function (compositionItem) {
                if (compositionItem.trackingField && compositionItem._ref.field) {
                  vpMappingItem.categories.push({
                    object: formatMessage("{0} {1} {2}", [
                      compositionItem.label,
                      sMappingWith,
                      compositionItem._ref.field.name,
                    ]),
                    objectType: resourceBundle.getText("vpIntegrationFieldMapping"),
                  });
                }
              });
            }
            vpMappingItems.push(vpMappingItem);
          }
        });

        vpMappingItems = enableVP ? vpMappingItems : [];
        return vpMappingItems;
      },

      _getProcessTypeUserFieldVPMappingDisplayData: function (item) {
        var usedByObjectListAssociation = this._whereUsedListHelper.getUsedByObjectList(
          item,
          UsedType.Association
        );
        var resourceBundle = this._resourceBundle;
        var sMappingWith = resourceBundle.getText("mappingWith");
        var vpMappingItems = [];
        var entity = item._parent;
        var enableVP = entity.enableVP;
        var type = item.type;

        // handle vp mapping
        usedByObjectListAssociation.forEach(function (usedByObject) {
          var userField = usedByObject._ref.field;
          var vpMappingItem = {
            object: formatMessage("{0}Event.{1} {2} {3}", [
              entity.name,
              usedByObject.label,
              sMappingWith,
              userField.name,
            ]),
            objectType: resourceBundle.getText("vpIntegrationFieldMapping"),
          };
          if (type === "composition") {
            vpMappingItem.categories = [];

            usedByObject.composition.forEach(function (compositionItem) {
              if (compositionItem.trackingField && compositionItem._ref.field) {
                vpMappingItem.categories.push({
                  object: formatMessage("{0} {1} {2}", [
                    usedByObject.label,
                    sMappingWith,
                    compositionItem._ref.field.name,
                  ]),
                  objectType: resourceBundle.getText("vpIntegrationFieldMapping"),
                });
              }
            }, this);
          }

          vpMappingItems.push(vpMappingItem);
        }, this);

        return enableVP ? vpMappingItems : [];
      },

      _getProcessTypeUserFieldMappingListData: function (item) {
        var idocMappingItems = this._getIDocDisplayData(item);
        var vpMappingItems = this._getProcessTypeUserFieldVPMappingDisplayData(item);
        // filter children node
        vpMappingItems.forEach(function (vpMappingItem) {
          if (vpMappingItem.categories) {
            vpMappingItem.categories = [];
          }
        });

        return [].concat(idocMappingItems, vpMappingItems);
      },

      _getAssociationToManyUserFieldListDisplayData: function (item) {
        var that = this;

        var userFields = [];

        var usedByObjectList = that._whereUsedListHelper.getUsedByObjectList(
          item,
          UsedType.Dependency
        );
        usedByObjectList.forEach(function (usedByObject) {
          if (
            usedByObject._objectType === ObjectType.UserField &&
            FieldType.isItemAssociationToMany(usedByObject) &&
            usedByObject._parent
          ) {
            userFields.push({
              object: formatMessage("{0}.{1}", [usedByObject._parent.name, usedByObject.name]),
              objectType: that._resourceBundle.getText("associationToManyUserModelField"),
            });
          }
        }, this);

        return userFields;
      },

      _getEventTypeUserFieldMappingListData: function (item) {
        var idocMappingItems = this._getIDocDisplayData(item);

        var vpMappingItems = this._getEventTypeUserFieldVPMappingListData(item);
        // filter children node to empty
        vpMappingItems.forEach(function (vpMappingItem) {
          if (vpMappingItem.categories) {
            vpMappingItem.categories = [];
          }
        });

        return [].concat(idocMappingItems, vpMappingItems);
      },

      _getEntityListData: function (item) {
        var that = this;

        var usedByObjectListDependency = that._whereUsedListHelper.getUsedByObjectList(
          item,
          UsedType.Dependency
        );
        var items = [];
        var resourceBundle = that._resourceBundle;
        var childNodes;

        usedByObjectListDependency.forEach(function (usedByObject) {
          var parent = usedByObject._parent;
          var objectType;

          switch (parent._objectType) {
            case ObjectType.ProcessType:
              childNodes = that._getProcessTypeUserFieldListData(usedByObject);
              objectType = resourceBundle.getText("userModelFieldsInTrackedProcess");
              items.push({
                object: formatMessage("{0}.{1}", [parent.name, usedByObject.name]),
                objectType: objectType,
                categories: childNodes,
              });
              break;
            case ObjectType.ItemType:
              objectType = resourceBundle.getText("userModelFieldsInFieldType");
              childNodes = that._getItemTypeUserFieldListData(usedByObject);
              items.push({
                object: formatMessage("{0}.{1}.{2}", [
                  parent._ref.context.name,
                  parent.name,
                  usedByObject.name,
                ]),
                objectType: objectType,
                categories: childNodes,
              });
              break;
            case ObjectType.EventType:
              objectType = resourceBundle.getText("userModelFieldsInEventType");
              childNodes = that._getEventTypeUserFieldListData(usedByObject);
              items.push({
                object: formatMessage("{0}.{1}.{2}", [
                  parent._ref.context.name,
                  parent.name,
                  usedByObject.name,
                ]),
                objectType: objectType,
                categories: childNodes,
              });
              break;
            default:
              break;
          }
        });

        return items;
      },

      _getCodeListData: function (item) {
        return this._getEntityListData(item);
      },

      _getEventTypeListData: function (item) {
        var admEventItems = this._getAdmEventListData(item);

        var idocEventItems = this._getEventTypeIDocListData(item);
        var vpEventItems = this._getEventTypeVPListData(item);

        return idocEventItems.concat(vpEventItems, admEventItems);
      },

      _getEventTypeIDocListData: function (item) {
        var resourceBundle = this._resourceBundle;
        var result = [];
        var sMappingWith = resourceBundle.getText("mappingWith");
        var processType = item._ref.context;
        var enableIDoc = processType.enableIDoc;

        var idocMapping = item.idocMapping;
        if (idocMapping && idocMapping.idoc && idocMapping.erpEventCode) {
          result.push({
            object: formatMessage("{0}.{1} {2} {3}.{4}", [
              processType.name,
              item.name,
              sMappingWith,
              idocMapping.idoc,
              idocMapping.erpEventCode,
            ]),
            objectType: resourceBundle.getText("iDocIntegrationEventTypeMapping"),
          });
        }

        return enableIDoc ? result : [];
      },

      _getEventTypeVPListData: function (item) {
        var resourceBundle = this._resourceBundle;
        var result = [];
        var sMappingWith = resourceBundle.getText("mappingWith");
        var processType = item._ref.context;
        var enableVP = processType.enableVP;

        var vpMapping = item.vpMapping;
        if (vpMapping && vpMapping.lbnEventType) {
          result.push({
            object: formatMessage("{0}.{1} {2} {3}.{4}", [
              processType.name,
              item.name,
              sMappingWith,
              vpMapping.lbnEventType,
            ]),
            objectType: resourceBundle.getText("vpIntegrationEventTypeMapping"),
          });
        }

        return enableVP ? result : [];
      },

      _getAdmEventListData: function (item) {
        var usedByObjectList = this._whereUsedListHelper.getUsedByObjectList(
          item,
          UsedType.Dependency
        );
        var resourceBundle = this._resourceBundle;
        var result = [];
        usedByObjectList.forEach(function (usedByObject) {
          var objectType = usedByObject._objectType;
          var parent = usedByObject._parent;

          if (objectType === ObjectType.AdmissiblePlannedEvent) {
            result.push({
              object: formatMessage("{0}.{1}", [parent.name, item.name]),
              objectType: resourceBundle.getText("plannedEvent"),
            });
          }

          if (objectType === ObjectType.AdmissibleUnplannedEvent) {
            result.push({
              object: formatMessage("{0}.{1}", [parent.name, item.name]),
              objectType: resourceBundle.getText("unplannedEvent"),
            });
          }
        });

        return result;
      },

      _getItemTypeListData: function (item) {
        return this._getEntityListData(item);
      },

      _getProcessTypeUsedByFieldListData: function (item) {
        var that = this;

        var usedByObjectList = that._whereUsedListHelper.getUsedByObjectList(
          item,
          UsedType.Dependency
        );
        var resourceBundle = that._resourceBundle;
        var elements = [];
        var childNodes = [];

        var usedByUserFields = usedByObjectList.filter(function (usedByObject) {
          return usedByObject._objectType && usedByObject._objectType === ObjectType.UserField;
        });

        // filter user fields belong to other tracked process
        usedByUserFields.forEach(function (usedByUserField) {
          var parent = usedByUserField._parent;
          var objectType;

          switch (parent._objectType) {
            case ObjectType.ProcessType:
              objectType = resourceBundle.getText("userModelFieldsInTrackedProcess");
              if (parent.name !== item.name) {
                childNodes = that._getProcessTypeUserFieldListData(usedByUserField);
                elements.push({
                  object: formatMessage("{0}.{1}", [parent.name, usedByUserField.name]),
                  objectType: objectType,
                  categories: childNodes,
                });
              }
              break;
            case ObjectType.ItemType:
              objectType = resourceBundle.getText("userModelFieldsInFieldType");
              if (parent._ref.context.name !== item.name) {
                childNodes = that._getItemTypeUserFieldListData(usedByUserField);
                elements.push({
                  object: formatMessage("{0}.{1}.{2}", [
                    parent._ref.context.name,
                    parent.name,
                    usedByUserField.name,
                  ]),
                  objectType: objectType,
                  categories: childNodes,
                });
              }
              break;
            case ObjectType.EventType:
              objectType = resourceBundle.getText("userModelFieldsInEventType");
              if (parent._ref.context.name !== item.name) {
                childNodes = that._getEventTypeUserFieldListData(usedByUserField);
                elements.push({
                  object: formatMessage("{0}.{1}.{2}", [
                    parent._ref.context.name,
                    parent.name,
                    usedByUserField.name,
                  ]),
                  objectType: objectType,
                  categories: childNodes,
                });
              }
              break;
            default:
              break;
          }
        });

        var upstreamItems = that._getProcessTypeUsedByUpstreamListData(item);

        return [
          {
            object: item.name,
            objectType: resourceBundle.getText("trackedProcess"),
            categories: elements.concat(upstreamItems),
          },
        ];
      },

      _getProcessTypeUsedByUpstreamListData: function (item) {
        var usedByObjectList = this._whereUsedListHelper.getUsedByObjectList(
          item,
          UsedType.Association
        );
        var resourceBundle = this._resourceBundle;
        var upstreamItems = [];

        usedByObjectList.forEach(function (usedByObject) {
          var processType = usedByObject._ref.eventType;
          var enableVP = processType.enableVP;
          if (enableVP) {
            upstreamItems.push({
              object: usedByObject._ref.eventType.name,
              objectType: resourceBundle.getText("vpIntegrationUpstreamProcessType"),
            });
          }
        });

        return upstreamItems;
      },

      _getItemTypeUsedByOtherFieldListData: function (item) {
        var that = this;

        var resourceBundle = that._resourceBundle;
        var itemTypes = that._getStoreModel().getProperty("/itemTypes");

        var itemUsedLists = [];
        itemTypes = itemTypes.filter(function (itemType) {
          return itemType._ref.context.name === item.name;
        });

        itemTypes.forEach(function (itemType) {
          var itemUsedList = that._getEntityListData(itemType);

          itemUsedList = itemUsedList.filter(function (listItem) {
            return listItem.object.split(".")[0] !== item.name;
          });

          var categoryArray = {
            object: itemType.name,
            objectType: resourceBundle.getText("fieldType"),
            categories: itemUsedList,
          };

          if (itemUsedList && itemUsedList.length !== 0) {
            itemUsedLists = itemUsedLists.concat(categoryArray);
          }
        });

        return itemUsedLists;
      },

      _getEventTypeUsedByOtherEventsListData: function (item) {
        var that = this;

        var resourceBundle = that._resourceBundle;
        var eventTypes = that._getStoreModel().getProperty("/eventTypes");
        var itemUsedLists = [];
        eventTypes = eventTypes.filter(function (eventType) {
          return eventType._ref.context.name === item.name;
        });

        eventTypes.forEach(function (eventType) {
          var itemUsedList = that._getEventTypeListData(eventType);

          itemUsedList = itemUsedList.filter(function (listItem) {
            return listItem.object.split(".")[0] !== item.name;
          });

          var categoryArray = {
            object: eventType.name,
            objectType: resourceBundle.getText("eventType"),
            categories: itemUsedList,
          };

          itemUsedLists = itemUsedLists.concat(categoryArray);
        }, this);

        itemUsedLists = itemUsedLists.filter(function (itemUsedList) {
          return itemUsedList.categories.length !== 0;
        });

        return itemUsedLists;
      },

      _getProcessTypeListData: function (item) {
        var elementItems = this._getProcessTypeUsedByFieldListData(item);
        elementItems = elementItems.filter(function (elementItem) {
          return elementItem.categories.length !== 0;
        });

        var itemTypeItems = this._getItemTypeUsedByOtherFieldListData(item);

        var eventTypeItems = this._getEventTypeUsedByOtherEventsListData(item);

        return elementItems.concat(itemTypeItems, eventTypeItems);
      },

      _filterIDocMappingItem: function (item, idocMappingItem) {
        // filter children node
        idocMappingItem.forEach(function (mapItem) {
          if (mapItem.categories) {
            mapItem.categories = mapItem.categories.filter(function (categoryItem) {
              return categoryItem.object.split(" ")[0] === item.name;
            });
          }
        });

        return idocMappingItem.filter(function (arrayItem) {
          return arrayItem.categories.length !== 0;
        });
      },

      _filterVPMappingItem: function (item, vpMappingItem) {
        // filter children node
        vpMappingItem.forEach(function (mapItem) {
          if (mapItem.categories) {
            mapItem.categories = mapItem.categories.filter(function (categoryItem) {
              return categoryItem.object.split(" ").pop() === item.name;
            });
          }
        });

        return vpMappingItem.filter(function (arrayItem) {
          return arrayItem.categories.length !== 0;
        });
      },
    };

    return WhereUsedListDisplayDataHelper;
  }
);
