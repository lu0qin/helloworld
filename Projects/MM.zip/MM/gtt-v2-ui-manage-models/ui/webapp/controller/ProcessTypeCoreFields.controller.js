sap.ui.define(["./BaseController", "sap/ui/model/json/JSONModel"], function (
  BaseController,
  JSONModel
) {
  "use strict";
  return BaseController.extend("com.sap.gtt.v2.model.manage.controller.ProcessTypeCoreFields", {
    initModel: function () {
      var tableInfo = new JSONModel();
      this.setModel(tableInfo, "tableInfo");
    },

    onUpdateFinished: function () {
      var oCoreModelTable = this.byId("table"),
        sTitle,
        iTotalItems = oCoreModelTable.getBinding("items").getLength();
      if (oCoreModelTable.getBinding("items").isLengthFinal()) {
        sTitle = this.getResourceBundle().getText("coreModelFieldsTitleCount", [iTotalItems]);
      } else {
        sTitle = this.getResourceBundle().getText("coreModelFieldsTitleCount");
      }
      this.getModel("tableInfo").setProperty("/tableTitle", sTitle);
    },
  });
});
