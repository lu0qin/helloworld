sap.ui.define(
  [
    "./BaseDetailController",
    "sap/ui/model/json/JSONModel",
    "sap/base/util/merge",
    "sap/base/util/deepClone",
    "../constant/FieldType",
    "../constant/ObjectType",
    "../constant/UsedType",
    "../constant/TextType",
    "../constant/ModelCategory",
    "./EditFieldDialog",
    "./EntityValidator",
  ],
  function (
    BaseDetailController,
    JSONModel,
    merge,
    deepClone,
    FieldType,
    ObjectType,
    UsedType,
    TextType,
    ModelCategory,
    EditFieldDialog,
    EntityValidator
  ) {
    "use strict";
    return BaseDetailController.extend("com.sap.gtt.v2.model.manage.controller.UserFields", {
      initModel: function () {
        // Set relevant info for view
        var view = new JSONModel({
          tableTitle: "",
          isCreateEnabled: true,
          isShowDppColumn: false,
          isShowKeyColumn: false,
          isShowAuthScopeColumn: false,
          selectedCount: 0,
          type: [],
        });
        this.setModel(view, "view");
      },

      initCreateAndEditDialogController: function () {
        var oView = this.getView();
        var oResourceBundle = this.getResourceBundle();

        var oDialogController = new EditFieldDialog();
        this.oDialogController = merge({}, oDialogController, {
          onDialogAccepted: function (type, data, context, info) {
            this.onDialogAccepted(type, data, context, info);
          }.bind(this),
          handleCompositionTargetChange: function (oControl, oSelectedItemObject) {
            return this.validateCompositionTarget(oControl, oSelectedItemObject);
          }.bind(this),
          onAssociationToOneFieldChange: function (oEvent) {
            var oControl = oEvent.getSource();
            this.handleAssociationToOneFieldChange(oControl);
          }.bind(this),
          getView: function () {
            return oView;
          },
          getResourceBundle: function () {
            return oResourceBundle;
          },
        });

        var typeArray = this.getFieldTypeArray();
        this.getModel("view").setProperty("/type", typeArray);
      },

      getFieldTypeArray: function () {
        return [
          { name: FieldType.String },
          { name: FieldType.Uuid },
          { name: FieldType.Boolean },
          { name: FieldType.Integer },
          { name: FieldType.Decimal },
          { name: FieldType.Date },
          { name: FieldType.Timestamp },
          { name: FieldType.AssociationToOne },
          { name: FieldType.Composition },
          { name: FieldType.CodeList },
        ];
      },

      subscribeEvents: function () {
        var eventBus = this.getEventBus();
        eventBus.subscribe("modelDetail", "refreshFieldListBinding", this.refreshBinding, this);
      },

      unsubscribeEvents: function () {
        var eventBus = this.getEventBus();
        eventBus.unsubscribe("modelDetail", "refreshFieldListBinding", this.refreshBinding, this);
      },

      removeListSelections: function () {
        var table = this.byId("table");
        table.removeSelections();
        // update the binding selectedCount.
        if (table.getSelectedItems().length === 0) {
          this.getModel("view").setProperty("/selectedCount");
        }
      },

      getItemsBinding: function () {
        var table = this.byId("table");
        return table.getBinding("items");
      },

      onUpdateFinished: function (oEvent) {
        var table = oEvent.getSource();
        var binding = table.getBinding("items");
        var sTitle,
          iTotalItems = binding.getLength();
        if (table.getBinding("items").isLengthFinal()) {
          sTitle = this.getResourceBundle().getText("userModelFieldsTitleCount", [iTotalItems]);
        } else {
          sTitle = this.getResourceBundle().getText("userModelFieldsTitleCount");
        }
        this.getModel("view").setProperty("/tableTitle", sTitle);

        // reset selectedCount
        this.setSelectedCount();
      },

      onSelectionChange: function (oEvent) {
        this.setSelectedCount();
      },

      setSelectedCount: function (oControl) {
        var table = this.byId("table");
        var selectedItems = table.getSelectedItems();
        this.getModel("view").setProperty("/selectedCount", selectedItems.length);
      },

      // ========================================================
      // CRUD
      // ========================================================
      /* Create User Field */
      onAddItem: function () {
        var sTitle = this.getResourceBundle().getText("createUserModelField");
        var table = this.byId("table");
        var oContext = table.getBindingContext("store");

        var oModelData = this.getCreateDialogData(oContext);
        var oModel = new JSONModel({
          type: "create",
          // this context is used for adding/editing items into user fields model
          context: oContext,
          title: sTitle,
          data: oModelData,
          info: {
            isUsedByMapping: false,
            isUsedByMatchExtensionField: false,
            isUsedByAssociationToMany: false,
          },
        });

        var options = {
          fragmentId: "editFieldDialog",
          fragmentName: "EditFieldDialog",
          controller: this.oDialogController,
          model: oModel,
        };
        this.openDialog(options);
      },

      getCreateDialogData: function (oContext) {
        // set parent as null in PlannedEventExtension
        var parentObject;
        var objectType;
        if (oContext.getObject()._objectType) {
          parentObject = oContext.getObject();
          objectType = ObjectType.UserField;
        } else {
          parentObject = null;
          objectType = ObjectType.PlannedEventExtension;
        }

        return {
          name: "",
          label: "",
          type: FieldType.String,
          readable: true,
          writable: true,
          length: null,
          precision: null,
          scale: null,
          codeListTarget: null,
          processTypeTarget: null,
          itemTypeTarget: null,
          backlink: null,
          key: false,
          dpp: [],
          authScopes: [],
          translation: {
            label: {
              textType: TextType.Label,
              translation: {},
            },
          },
          // parent object of current user field table
          _parent: parentObject,
          _objectType: objectType,
          _category: ModelCategory.User,
        };
      },

      /* Edit User Field */
      onEditItem: function (oEvent) {
        var oContext = oEvent.getSource().getBindingContext("store");
        this.openEditItemDialog(oContext);
      },

      onEditButtonPress: function () {
        var oTable = this.byId("table");
        var oListItem = oTable.getSelectedItem();
        var oContext = oListItem.getBindingContext("store");
        this.openEditItemDialog(oContext);
      },

      openEditItemDialog: function (oContext) {
        var oItem = oContext.getObject();
        var sTitle = this.getResourceBundle().getText("editUserModelField");

        var isUsedByMapping = this.whereUsedListDisplayDataHelper.checkIfUserFieldUsedByMapping(
          oItem
        );
        var isUsedByMatchExtensionField = this.whereUsedListDisplayDataHelper.checkIfUserFieldUsedByMatchExtensionField(
          oItem
        );
        var isUsedByAssociationToMany = this.whereUsedListDisplayDataHelper.checkIfProcessTypeUserFieldUsedByAssociationToMany(
          oItem
        );

        var oModelData = this.getEditDialogData(oContext);

        var oModel = new JSONModel({
          type: "edit",
          context: oContext,
          title: sTitle,
          data: oModelData,
          info: {
            isUsedByMapping: isUsedByMapping,
            isUsedByMatchExtensionField: isUsedByMatchExtensionField,
            isUsedByAssociationToMany: isUsedByAssociationToMany,
            previousItem: Object.assign({}, oContext.getObject()),
          },
        });

        var options = {
          fragmentId: "editFieldDialog",
          fragmentName: "EditFieldDialog",
          controller: this.oDialogController,
          model: oModel,
        };
        this.openDialog(options);
      },

      getEditDialogData: function (oContext) {
        var oModelData = [
          "name",
          "label",
          "type",
          "readable",
          "writable",
          "key",
          "dpp",
          "authScopes",
          "translation",
          "_parent",
          "_objectType",
          "_category",
        ].reduce(function (result, key) {
          result[key] = oContext.getProperty(key);
          return result;
        }, {});

        // set i18n translation for label & placeholder
        this.setTranslationPropertiesForDialogModel("label", oModelData, oContext.getObject());

        // convert association type to asso-to-one/many
        if (oModelData.type === FieldType.Association) {
          // _ref is not copied to oModelData
          // use oContext.getObject() to check Association type
          oModelData.type = FieldType.isItemAssociationToMany(oContext.getObject())
            ? FieldType.AssociationToMany
            : FieldType.AssociationToOne;
        }

        // set additional information according to Type
        var oRefTarget = oContext.getProperty("_ref/target");
        switch (oModelData.type) {
          case FieldType.Decimal:
            oModelData.precision = oContext.getProperty("precision");
            oModelData.scale = oContext.getProperty("scale");
            break;
          case FieldType.String:
            oModelData.length = oContext.getProperty("length");
            break;
          case FieldType.CodeList:
            oModelData.codeListTarget = oRefTarget;
            break;
          case FieldType.AssociationToOne:
            oModelData.processTypeTarget = oRefTarget;
            break;
          case FieldType.AssociationToMany:
            oModelData.processTypeTarget = oRefTarget;
            oModelData.backlink = oContext.getProperty("_ref/backlink");
            break;
          case FieldType.Composition:
            oModelData.itemTypeTarget = oRefTarget;
            break;
          default:
            break;
        }

        return oModelData;
      },

      onDialogAccepted: function (type, data, context, info) {
        var newItem = {
          name: data.name,
          label: data.label,
          type: data.type,
          writable: data.writable,
          readable: data.readable,
          translation: data.translation,
          _parent: data._parent,
          _objectType: data._objectType,
          _category: data._category,
        };

        // set i18n label & translation property
        this.setTranslationPropertiesForListItem(
          "label",
          newItem,
          type === "edit" ? context.getProperty("label") : "",
          type
        );

        var isDppShow = this.getModel("view").getProperty("/isShowDppColumn");
        var isKeyShow = this.getModel("view").getProperty("/isShowKeyColumn");
        var isAuthScopeShow = this.getModel("view").getProperty("/isShowAuthScopeColumn");

        if (isDppShow) {
          newItem.dpp = data.dpp;
        }
        if (isKeyShow) {
          newItem.key = data.key;
        }
        if (isAuthScopeShow) {
          newItem.authScopes = data.authScopes;
        }

        switch (data.type) {
          case FieldType.Decimal:
            newItem.precision = data.precision;
            newItem.scale = data.scale;
            break;
          case FieldType.String:
            newItem.length = data.length;
            break;
          case FieldType.CodeList:
            newItem._ref = {};
            newItem._ref.target = data.codeListTarget;
            break;
          case FieldType.Composition:
            newItem._ref = {};
            newItem._ref.target = data.itemTypeTarget;
            newItem.cardinality = {
              max: "*",
            };
            delete newItem.dpp;
            break;
          case FieldType.AssociationToOne:
            // reset type to association
            newItem.type = FieldType.Association;
            newItem._ref = {};
            newItem._ref.target = data.processTypeTarget;
            newItem.cardinality = {
              max: 1,
            };
            delete newItem.dpp;
            break;
          case FieldType.AssociationToMany:
            // reset type to association
            newItem.type = FieldType.Association;
            newItem._ref = {};
            newItem._ref.target = data.processTypeTarget;
            newItem.cardinality = {
              max: "*",
            };
            if (typeof data.backlink === "object") {
              newItem._ref.backlink = data.backlink;
            } else {
              this.handleCreateAssociationToOneItem(data.backlink, newItem);
            }
            delete newItem.dpp;
            break;
          default:
            break;
        }

        if (type === "edit") {
          // context.getModel().setProperty(context.getPath(), newItem, context);
          var originItem = context.getObject();
          this.handleUpdateItem(newItem, originItem, info);
        } else {
          var elements = context.getProperty("elements");
          elements.push(newItem);
          this.handleCreateItem(newItem);
        }

        this.changeToEditMode();
        this.refreshBinding();
      },

      /**
       * Overwrite general function
       * to remove useless properties from UserField
       * @param {object} originItem the origin item in the elements
       * @param {object} newItem the new item edited
       */
      modify: function (originItem, newItem) {
        Object.keys(originItem).forEach(function (key) {
          delete originItem[key];
        });

        Object.keys(newItem).forEach(function (key) {
          originItem[key] = newItem[key];
        });
      },

      /**
       * Function is used for add new item to whereUsedListHelper and idoc/vp mapping
       * when creating an item
       * @param {object} item item will add
       */
      handleCreateItem: function (item) {
        this.whereUsedListHelper.addElementDependency(item);
        this.handleUpdateIntegrationMapping(item);
      },

      /**
       * function is used for udpate whereUsedListHelper and idoc mapping
       * when editing an item
       *
       * @param {object} newItem newItem
       * @param {object} originItem item before edit
       * @param {info} info information in dialog model
       */
      handleUpdateItem: function (newItem, originItem, info) {
        var shouldDeleteAssoToManyUserFields = EntityValidator.checkIfDeleteAssoToManyUserFields(
          originItem,
          newItem,
          info.isUsedByAssociationToMany
        );
        var shouldUpdateMappingItems = EntityValidator.checkIfUpdateMappingItems(
          originItem,
          newItem
        );
        var shouldDeleteMatchExtensionField = EntityValidator.checkIfDeleteReferenceForMatchExtensionField(
          originItem,
          newItem,
          info.isUsedByMatchExtensionField
        );

        // delete mapping items & reference
        if (shouldUpdateMappingItems) {
          this.deleteHelper.deleteUserFieldReferenceObjects(originItem);
        }
        // delete asso-to-many fields & reference
        if (shouldDeleteAssoToManyUserFields) {
          this.deleteHelper.deleteAssoToManyUserField(originItem);
        }
        // delete match extension fields & reference
        if (shouldDeleteMatchExtensionField) {
          this.deleteHelper.deleteReferencedMatchExtensionOrPlannedFields(originItem);
        }
        // delete references when originItem has references and plays as object
        this.whereUsedListHelper.removeElementDependency(originItem);

        // update originItem data
        this.modify(originItem, newItem);

        if (shouldUpdateMappingItems) {
          this.handleCreateItem(originItem);
        } else {
          this.whereUsedListHelper.addElementDependency(originItem);
        }

        this.getEventBus().publish("modelDetail", "refreshPlannedEventsBinding", {});
      },

      handleUpdateIntegrationMapping: function (item) {
        var entity = item._parent;

        switch (entity._objectType) {
          // Update Item in IDOC/VP: Process/Event Type
          case ObjectType.ProcessType:
          case ObjectType.EventType:
            this.integrationMappingHelper.updateIDocMapping(item, entity);
            this.integrationMappingHelper.updateVPMapping(item, entity);
            break;

          // Search for all the objects using current ItemType entity
          // Iterate and update item in IDOC/VP
          case ObjectType.ItemType:
            // delete will be done separately, only auto-changed name of itemType related to idoc/vpMapping
            var usedByObjectList = this.whereUsedListHelper.getUsedByObjectList(
              entity,
              UsedType.Dependency
            );

            usedByObjectList.forEach(function (usedByObject) {
              var parentObject = usedByObject._parent;
              this.integrationMappingHelper.updateItemTypeInIDocMapping(item, entity, parentObject);
              this.integrationMappingHelper.updateItemTypeInVPMapping(item, entity, parentObject);
            }, this);
            break;
          default:
            break;
        }
      },

      // Only used in ProcessTypeDetail
      handleCreateAssociationToOneItem: function (backlinkItemName, currentItem) {},

      // Only used in ItemTypeUserFields
      validateCompositionTarget: function (oControl, oSelectedItemObject) {},

      // Only used in ProcessTypeDetail
      handleAssociationToOneFieldChange: function (oControl) {},

      /* Delete User Field */
      getItemToDelete: function () {
        var table = this.byId("table");
        var oBinding = table.getBinding("items");
        var oContext = oBinding.getContext();
        var items = oContext.getProperty(oBinding.getPath());
        var aSelectedItems = table.getSelectedItems();
        var aDeleteItems = [];

        if (aSelectedItems.length > 0) {
          aSelectedItems.forEach(function (item, index) {
            var sPath = item.getBindingContextPath();
            var aPathParts = sPath.split("/");
            var iIndex = aPathParts.pop();
            aDeleteItems.push(items[iIndex]);
          });
        }

        return aDeleteItems;
      },

      // ========================================================
      // Translation
      // ========================================================
      getEntityTranslationDialogItems: function (oEntityContext) {
        var result = [];

        // ignore entity translation when it is standard item
        if (oEntityContext.getProperty("_category") === ModelCategory.Standard) {
          return result;
        }

        var sObjectType = oEntityContext.getProperty("_objectType");

        if (sObjectType === ObjectType.EventType || sObjectType === ObjectType.ProcessType) {
          var oDescrTranslation = deepClone(oEntityContext.getProperty("translation"));

          result.push({
            name: oEntityContext.getProperty("name"),
            translation: {
              defaultText: oEntityContext.getProperty("descr"),
              textType: TextType.Descr,
              fieldPath: "descr",
              info: oDescrTranslation
                ? oDescrTranslation.descr
                : { textType: TextType.Descr, translation: {} },
            },
          });
        }

        return result;
      },
    });
  }
);
