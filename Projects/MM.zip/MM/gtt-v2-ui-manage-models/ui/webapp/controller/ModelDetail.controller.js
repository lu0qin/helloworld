sap.ui.define(
  [
    "./BaseController",
    "sap/base/util/merge",
    "sap/base/util/deepClone",
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/type/String",
    "../constant/ViewMode",
    "../constant/TextType",
    "../constant/DraftStatus",
    "../constant/ModelViewType",
    "../constant/LanguageCode",
    "../constant/ModelCategory",
    "../util/AsyncUtils",
    "../util/ServiceUtils",
    "../util/RestClient",
    "../util/ValidationHelper",
    "../util/TranslationHelper",
    "./TranslationDialog",
    "./WhereUsedListHelper",
    "./ModelDataPopulator",
    "./ModelDataProcessor",
    "./ModelDataValidator",
  ],
  function (
    BaseController,
    merge,
    deepClone,
    MessageBox,
    MessageToast,
    Fragment,
    JSONModel,
    StringType,
    ViewMode,
    TextType,
    DraftStatus,
    ModelViewType,
    LanguageCode,
    ModelCategory,
    AsyncUtils,
    ServiceUtils,
    RestClient,
    ValidationHelper,
    TranslationHelper,
    TranslationDialog,
    WhereUsedListHelper,
    ModelDataPopulator,
    ModelDataProcessor,
    ModelDataValidator
  ) {
    "use strict";

    var NAMESPACE_PREFIX_PATH = "/namespacePrefix";

    // init store model data
    var _initStoreModelData = function () {
      return {
        modelCategory: ModelCategory.User, // USER, STANDARD
        modelVersion: DraftStatus.Draft, // DRAFT, DEPLOYED
        mode: ViewMode.Display, // display, create, edit
        modelViewType: ModelViewType.Draft, // draftView, runtimeView, deployedView, history
        lastOperationStatus: "",
        model: {
          coreModel: {
            version: "1.0.0",
          },
          customModel: {
            schemaVersion: "1.0.0",
            eventCorrelationLevel: 1,
            eventToAction: "",
            subModels: [],
            plannedEvent: {},
          },
        },
        coreModel: {
          baseProcessType: {
            elements: [],
          },
          baseEventType: {
            elements: [],
          },
          eventTypes: [],
        },
        codeLists: [],
        processTypes: [],
        itemTypes: [],
        eventTypes: [],
        whereUsedList: [],
        plannedEvent: {
          elements: [],
        },
        idocPresets: {},
        vpPresets: {},
        lbnEventType: [],
        eventCoreFields: [],
      };
    };

    var _requestUrl = {
      idocPresets: "/idoc/presets",
      vpPresets: "/vp/presets",
      namespace: "/system/namespace",
      coreModel: "/models/coremodel",
    };

    var _requestType = {
      Get: "GET",
      Post: "POST",
      Put: "PUT",
    };

    return BaseController.extend("com.sap.gtt.v2.model.manage.controller.ModelDetail", {
      whereUsedListHelper: WhereUsedListHelper,
      modelDataPopulator: ModelDataPopulator,
      modelDataProcessor: ModelDataProcessor,
      modelDataValidator: ModelDataValidator,

      // ========================================================
      // Initialize
      // ========================================================
      onInit: function () {
        this.initModel();
        this.initControls();
        this.initRoute();
        this.subscribeEvents();
        this.createMessagePopover();
      },

      initModel: function () {
        var model = new JSONModel(_initStoreModelData());
        this.setModel(model, "store");

        var oMessageModel = new JSONModel({
          items: [],
        });
        this.setModel(oMessageModel, "message");
      },

      initControls: function () {
        var oView = this.getView();
        var oResourceBundle = this.getResourceBundle();

        this.whereUsedListHelper.init(this);

        // modelDataPopulator
        // modelDataProcessor
        this.modelDataProcessor = merge({}, this.modelDataProcessor, {
          whereUsedListHelper: this.whereUsedListHelper,
          formatter: this.formatter,
        });

        this.modelDataValidator = merge({}, this.modelDataValidator, {
          getView: function () {
            return oView;
          },

          getResourceBundle: function () {
            return oResourceBundle;
          },
        });
      },

      initRoute: function () {
        // route to model deployed version
        this.getRouter()
          .getRoute("modelDetail")
          .attachPatternMatched(
            function (event) {
              // set modelVersion: DEPLOYED
              // set mode: display
              var oArgs = event.getParameter("arguments");
              this.showDisplayMode(oArgs.namespace, DraftStatus.Deployed);
            }.bind(this)
          );

        // route to model draft
        this.getRouter()
          .getRoute("modelDraft")
          .attachPatternMatched(
            function (event) {
              // set modelVersion: DRAFT
              // set mode: display
              var oArgs = event.getParameter("arguments");
              this.showDisplayMode(oArgs.namespace, DraftStatus.Draft);
            }.bind(this)
          );

        // route to create new model
        this.getRouter()
          .getRoute("newModel")
          .attachPatternMatched(
            function (event) {
              // set modelVersion: DRAFT
              // set mode: create
              // set modelCategory: USER
              this.showCreateMode();
            }.bind(this)
          );
      },

      subscribeEvents: function () {
        var eventBus = this.getEventBus();
        eventBus.subscribe("modelDetail", "requestChangeMode", this.showEditMode, this);
      },

      unsubscribeEvents: function () {
        var eventBus = this.getEventBus();
        eventBus.unsubscribe("modelDetail", "requestChangeMode", this.showEditMode, this);
      },

      getStoreContext: function () {
        var objectPageLayout = this.byId("objectPageLayout");
        return objectPageLayout.getBindingContext("store");
      },

      // ========================================================
      // Clear model
      // ========================================================
      clearModel: function () {
        this.clearStoreModel();
        this.clearValidationMessage();
        this.clearModelHeaderValidation();
        this.clearEventToActionValidationMessage();
      },

      clearStoreModel: function () {
        var storeModel = this.getModel("store");
        storeModel.setProperty("/", _initStoreModelData());
        storeModel.refresh(true);
      },

      clearValidationMessage: function () {
        this.getModel("message").setProperty("/items", []);
      },

      clearModelHeaderValidation: function () {
        var oModelNameInput = Fragment.byId(this.createId("headerFragment"), "inputModelName");
        ValidationHelper.resetControlValidation(oModelNameInput);
      },

      clearEventToActionValidationMessage: function () {
        var oEventToActionView = this.byId("eventToActionView");

        oEventToActionView.getModel("view").setProperty("/validationMessage", []);
        oEventToActionView.byId("eventToActionDynamicSideContent").setShowSideContent(false);
      },

      // ========================================================
      // HTTP Requests
      // ========================================================
      /**
       * @param {string} requestType GET/POST/PUT
       * @param {string} urlParam suffix of url string
       * @param {object} [payload] optional param when requestType is POST/PUT
       * @returns {object} request promise
       * */
      _getMainServiceRequest: function (requestType, urlParam, payload) {
        var dataSource = ServiceUtils.getDataSource("mainService");
        var url = ServiceUtils.getUrl(dataSource.uri).concat(urlParam);

        switch (requestType) {
          case _requestType.Get:
            return RestClient.get(url);
          case _requestType.Post:
            return RestClient.post(url, payload);
          case _requestType.Put:
            return RestClient.put(url, payload);
          default:
            return new Promise();
        }
      },

      _loadNamespace: function () {
        var request = this._getMainServiceRequest(_requestType.Get, _requestUrl.namespace);

        return request.then(
          function (data) {
            this.getModel("store").setProperty(NAMESPACE_PREFIX_PATH, data.prefix);
          }.bind(this)
        );
      },

      _loadIDocPresets: function () {
        var request = this._getMainServiceRequest(_requestType.Get, _requestUrl.idocPresets);

        return request.then(
          function (data) {
            this.getModel("store").setProperty("/idocPresets", data.value);
          }.bind(this)
        );
      },

      _loadVPPresets: function () {
        var request = this._getMainServiceRequest(_requestType.Get, _requestUrl.vpPresets);

        return request.then(
          function (data) {
            var storeModel = this.getModel("store");
            storeModel.setProperty("/vpPresets", data);

            var lbnEventType = data.lbnEventType || {};
            var fields = lbnEventType.fields || [];
            storeModel.setProperty("/lbnEventType", fields);
          }.bind(this)
        );
      },

      _loadCoreModel: function () {
        var request = this._getMainServiceRequest(_requestType.Get, _requestUrl.coreModel);

        return request.then(
          function (data) {
            var model = this.getModel("store");
            model.setProperty("/model/coreModel", data);
            this.modelDataProcessor.updateDataForProcessTypeCoreModel(data, model);
            this.modelDataProcessor.updateDataForEventTypeCoreModel(data, model);
          }.bind(this)
        );
      },

      _loadModelDetail: function (version, namespace) {
        var urlParam = "/models/".concat(namespace);
        if (version === DraftStatus.Draft) {
          urlParam = urlParam.concat("/draft");
        }
        return this._getMainServiceRequest(_requestType.Get, urlParam);
      },

      /**
       * @param {object} request grouped request promise
       * @param {function} successCallback callback function after all all requests end with success
       * @param {function} errorCallback callback function after any requests end with error
       * */
      handleModelDetailRestRequest: function (request, successCallback, errorCallback) {
        var oView = this.getView();
        var promise = AsyncUtils.finally(request, function () {
          oView.setBusy(false);
        });

        promise.then(
          function (value) {
            successCallback(value);
          },
          function (error) {
            errorCallback(error);
          }
        );
      },

      // ========================================================
      // View Action
      // ========================================================
      onViewSelected: function (oEvent) {
        var item = oEvent.getParameter("item");
        var key = item.getKey();

        var viewRoute = {};
        viewRoute[ModelViewType.Draft] = "modelDraft";
        viewRoute[ModelViewType.Runtime] = "deployment";
        viewRoute[ModelViewType.Deployed] = "modelDetail";
        viewRoute[ModelViewType.History] = "history";

        var route = viewRoute[key];
        var context = this.getStoreContext();
        var namespace = context.getProperty("namespace");

        this.getRouter().navTo(route, {
          namespace: namespace,
        });
      },

      navToModelList: function () {
        this.getRouter().navTo("modelList");
        this.clearModel();
      },

      resetViewState: function (mode, modelVersion) {
        var storeModel = this.getModel("store");

        // set model detail view settings
        if (mode === ViewMode.Display) {
          var modelViewType =
            modelVersion === DraftStatus.Deployed ? ModelViewType.Deployed : ModelViewType.Draft;
          storeModel.setProperty("/modelViewType", modelViewType);
        }
        storeModel.setProperty("/mode", mode);
        storeModel.setProperty("/modelVersion", modelVersion);

        // reset menu view button visibility
        var viewButton = this.byId("viewButton");
        viewButton.setVisible(mode === ViewMode.Display);

        // notify mode change
        this.getEventBus().publish("modelDetail", "modeChanged", { mode: mode });
      },

      resetProcessTypeView: function () {
        var objectPageLayout = this.byId("objectPageLayout");
        objectPageLayout.setSelectedSection(this.byId("trackedProcessSection"));
        var trackedProcessSection = this.byId("trackedProcessSection");
        var subSection = trackedProcessSection.getSubSections()[0];
        var processTypeView = subSection.getBlocks()[0];
        var processTypeController = processTypeView.getController();
        processTypeController.resetViewState();
      },

      refreshModelBinding: function () {
        var storeModel = this.getModel("store");
        storeModel.updateBindings(true);

        var eventBus = this.getEventBus();
        eventBus.publish("modelDetail", "refreshIDocBinding", {});
        eventBus.publish("modelDetail", "refreshVPBinding", {});
        eventBus.publish("modelDetail", "refreshFieldListBinding", {});
        eventBus.publish("modelDetail", "refreshPlannedEventsBinding", {});
      },

      showDisplayMode: function (namespace, version, currentPage) {
        var oView = this.getView();
        oView.setBusy(true);

        this.clearModel();
        this.resetViewState(ViewMode.Display, version || DraftStatus.Draft);

        var storeModel = this.getModel("store");
        var lastIndexOfDot = namespace.lastIndexOf(".");
        storeModel.setProperty(NAMESPACE_PREFIX_PATH, namespace.substring(0, lastIndexOfDot));

        var promiseAll = Promise.all([
          this._loadIDocPresets(),
          this._loadVPPresets(),
          this._loadModelDetail(version, namespace),
        ]);

        this.handleModelDetailRestRequest(
          promiseAll,
          function (value) {
            this.modelDataProcessor.updateData(value[2], storeModel);
            if (!currentPage) {
              this.resetProcessTypeView();
            }
            this.refreshModelBinding();
          }.bind(this),
          function (error) {
            this.handleServerError(error);
            this.clearModel();
          }.bind(this)
        );
      },

      showCreateMode: function () {
        var oView = this.getView();
        oView.setBusy(true);

        this.clearModel();
        this.resetViewState(ViewMode.Create, DraftStatus.Draft);

        var storeModel = this.getModel("store");
        storeModel.setProperty("/modelCategory", ModelCategory.User);

        var objectPageLayout = this.byId("objectPageLayout");
        objectPageLayout.setSelectedSection(this.byId("headerSection"));

        var promiseAll = Promise.all([
          this._loadCoreModel(),
          this._loadNamespace(),
          this._loadIDocPresets(),
          this._loadVPPresets(),
        ]);

        this.handleModelDetailRestRequest(
          promiseAll,
          function (value) {},
          function (error) {
            this.handleServerError(error);
            this.clearModel();
          }.bind(this)
        );
        this.handleDescriptionBindingChange();
      },

      showEditMode: function (channelId, eventId, object) {
        this.resetViewState(ViewMode.Edit, DraftStatus.Draft);

        this.handleDescriptionBindingChange();
      },

      handleDescriptionBindingChange: function () {
        var sHeaderFragmentId = this.createId("headerFragment");
        var oDescriptionControl = Fragment.byId(sHeaderFragmentId, "inputDescription");
        var currentLanguageCode = TranslationHelper.getCurrentLanguageCode();
        var isLanguageSupported = TranslationHelper.checkIfLanguageIsSupported(currentLanguageCode);

        var oContext = this.getStoreContext();
        var oTranslation = oContext.getProperty("translation");
        if (!oTranslation) {
          this.getModel("store").setProperty("/model/translation", {
            descr: { textType: TextType.Descr, translation: {} },
          });
        }

        var sPath =
          currentLanguageCode === LanguageCode.English || !isLanguageSupported
            ? "store>descr"
            : "store>translation/descr/translation/" + currentLanguageCode;
        oDescriptionControl.bindProperty("value", {
          path: sPath,
          type: new StringType(),
        });

        if (currentLanguageCode !== LanguageCode.English) {
          oDescriptionControl.bindProperty("placeholder", {
            path: "store>descr",
          });
        }
      },

      onEditPress: function () {
        this.showEditMode();
      },

      onDeployPress: function () {
        MessageBox.confirm(this.getResourceBundle().getText("deployThisModel"), {
          onClose: function (action) {
            if (action === MessageBox.Action.OK) {
              this.doDeploy();
            }
          }.bind(this),
        });
      },

      doDeploy: function () {
        var oView = this.getView();
        oView.setBusy(true);

        var sNamespace = this.getStoreContext().getProperty("namespace");
        var urlParam = "/models/".concat(sNamespace, "/deployments");
        var request = this._getMainServiceRequest(_requestType.Post, urlParam, {});

        this.handleModelDetailRestRequest(
          request,
          function () {
            this.navToModelList();
          }.bind(this),
          function (error) {
            this.handleServerError(error);
          }.bind(this)
        );
      },

      onSavePress: function () {
        this.doSave();
      },

      doSave: function () {
        var storeModel = this.getModel("store");
        var mode = storeModel.getProperty("/mode");

        // populate data
        var postData = this.modelDataPopulator.populateData(storeModel);

        // validate data
        var oResult = this.modelDataValidator.validateData(postData);
        if (oResult.error) {
          this.handleClientError(oResult);
          return;
        }

        // check message model
        var isNoError = ValidationHelper.checkMessageModel();
        if (!isNoError) {
          return;
        }

        // if validation check passed, clear all old messages in message model.
        // start doing save
        this.clearValidationMessage();
        var oView = this.getView();
        oView.setBusy(true);

        // format url for request
        var sNamespace = postData.namespace;
        var urlParam = mode === ViewMode.Create ? "/models" : "/models".concat("/", sNamespace);
        var requestType = mode === ViewMode.Create ? _requestType.Post : _requestType.Put;

        var request = this._getMainServiceRequest(requestType, urlParam, postData);

        this.handleModelDetailRestRequest(
          request,
          function (value) {
            if (mode === ViewMode.Edit) {
              this.showDisplayMode(sNamespace, DraftStatus.Draft, true);
            } else {
              this.navToModelList();
            }
            MessageToast.show(this.getResourceBundle().getText("modelSaved", sNamespace), {
              closeOnBrowserNavigation: false,
            });
          }.bind(this),
          function (error) {
            this.handleServerError(error);
          }.bind(this)
        );
      },

      openDiscardPopover: function (oEvent) {
        // create popover
        var oView = this.getView();
        var oButton = oEvent.getSource();

        var popover = this.oDiscardPopover;

        var promise = popover
          ? Promise.resolve(popover)
          : Fragment.load({
            id: oView.getId(),
            name: "com.sap.gtt.v2.model.manage.view.fragments.DiscardPopover",
            controller: this,
          });

        promise.then(
          function (Popover) {
            this.oDiscardPopover = Popover;
            this.getView().addDependent(this.oDiscardPopover);
            this.oDiscardPopover.openBy(oButton);
          }.bind(this)
        );
      },

      onDiscardButtonPress: function () {
        var sNamespace = this.getStoreContext().getProperty("namespace");
        var mode = this.getModel("store").getProperty("/mode");
        if (mode === ViewMode.Edit) {
          this.showDisplayMode(sNamespace, DraftStatus.Draft, true);
        } else if (mode === ViewMode.Create) {
          this.navToModelList();
        }
      },

      onCancelPress: function (oEvent) {
        this.openDiscardPopover(oEvent);
      },

      onMessagePopoverPress: function (oEvent) {
        if (!this.oMP) {
          this.createMessagePopover();
        }
        this.oMP.toggle(oEvent.getSource());
      },

      // ========================================================
      // Model Header
      // ========================================================
      onChangeModelName: function (oEvent) {
        var oInput = oEvent.getSource();
        var sValue = oInput.getValue();
        var oRegExp = /^[a-z]+[a-z0-9]*$/;

        if (sValue.startsWith("gtt")) {
          ValidationHelper.setControlValidationError(
            oInput,
            this.getResourceBundle().getText("msgModelNameShouldNotStartWithGTT")
          );
        } else if (!oRegExp.test(sValue)) {
          ValidationHelper.setControlValidationError(
            oInput,
            this.getResourceBundle().getText(
              "msgOnlyNumbersLowercaseLettersSupportAndStartWithLetters"
            )
          );
        } else {
          ValidationHelper.resetControlValidation(oInput);
        }
      },

      onOpenTranslationDialog: function () {
        var oView = this.getView();
        var oTranslationDialogController = new TranslationDialog();
        oTranslationDialogController = merge({}, oTranslationDialogController, {
          textType: "descr",
          getView: function () {
            return oView;
          },
          getResourceBundle: function () {
            return this.getResourceBundle();
          }.bind(this),
        });

        var aDefaultSelectedKeys = TranslationHelper.getDefaultLanguageKeys();

        var sMode = this.getModel("store").getProperty("/mode");
        var oContext = this.byId("objectPageLayout").getBindingContext("store");

        var sFullName = oContext.getProperty("name");
        var sTitle = this.getResourceBundle().getText("translationDialogTitle", [sFullName]);
        var sTableTitle = this.getResourceBundle().getText("titleCount", [1]);

        var sFragmentName =
          sMode === ViewMode.Display ? "TranslationDialog" : "EditTranslationDialog";

        var oDescrTranslation = deepClone(oContext.getProperty("translation"));
        var items = [];
        items.push({
          name: oContext.getProperty("name"),
          translation: {
            defaultText: oContext.getProperty("descr"),
            textType: TextType.Descr,
            fieldPath: "descr",
            info: oDescrTranslation
              ? oDescrTranslation.descr
              : { textType: TextType.Descr, translation: {} },
          },
        });

        var oModel = new JSONModel({
          type: sMode,
          context: oContext,
          data: {
            items: items,
          },
          info: {},
          selectedLanguages: aDefaultSelectedKeys,
          title: sTitle,
          tableTitle: sTableTitle,
        });
        var options = {
          fragmentId: "translationDialog",
          fragmentName: sFragmentName,
          controller: oTranslationDialogController,
          model: oModel,
        };

        this.openDialog(options);
      },
    });
  }
);
