sap.ui.define(["./BaseDialog", "../constant/LanguageCode"], function (BaseDialog, LanguageCode) {
  "use strict";
  return BaseDialog.extend("com.sap.gtt.v2.model.manage.controller.TranslationDialog", {
    validate: function () {
      return true;
    },

    onAfterOpen: function (oEvent) {
      var oLanguages = Object.values(LanguageCode).map(function (code) {
        return {
          language: code,
        };
      });

      var oDialog = oEvent.getSource();
      var oModel = oDialog.getModel("dialog");
      oModel.setProperty("/languages", oLanguages);

      this.order = 4;

      this._handleTableColumn(LanguageCode.English, true);
      var selectedLanguages = oModel.getProperty("/selectedLanguages");
      selectedLanguages.forEach(
        function (sKey) {
          this._handleTableColumn(sKey, true);
        }.bind(this)
      );
    },

    onLanguageSelectionChange: function (oEvent) {
      var changedItem = oEvent.getParameter("changedItem");
      var sKey = changedItem.getKey();
      var status = oEvent.getParameter("selected");

      this._handleTableColumn(sKey, status);
    },

    _handleTableColumn: function (sKey, bAdd) {
      var oTable = this.byId("table");
      var oCol = this.byId(sKey);

      if (!oCol) {
        return;
      }

      oCol.setVisible(bAdd);

      if (bAdd) {
        oCol.setOrder(this.order);
        this.order++;
        oTable.rerender();
      }
    },

    onDialogAccepted: function (type, data, context, info) {
      if (type === "create" || type === "edit") {
        var oModel = context.getModel();
        data.items.forEach(function (item) {
          var oTranslation = item.translation;
          var transPath = this.joinPath(oTranslation.contextPath, "translation");
          if (!oModel.getProperty(transPath, context)) {
            oModel.setProperty(transPath, {}, context);
          }

          oModel.setProperty(
            this.joinPath(transPath, oTranslation.fieldPath),
            oTranslation.info,
            context
          );

          oModel.setProperty(
            this.joinPath(oTranslation.contextPath, oTranslation.fieldPath),
            oTranslation.defaultText,
            context
          );
        }, this);

        this.handleModelRefresh();
      }
    },

    joinPath: function () {
      var parts = Array.from(arguments).filter(function (path) {
        return !!path;
      });

      return parts.join("/");
    },

    handleModelRefresh: function () {},
  });
});
