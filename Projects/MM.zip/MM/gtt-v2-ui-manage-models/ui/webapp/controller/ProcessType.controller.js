sap.ui.define(
  [
    "./BaseEntityList",
    "sap/ui/model/json/JSONModel",
    "sap/m/GroupHeaderListItem",
    "sap/m/MessageBox",
    "./EditProcessTypeDialog",
    "../constant/ObjectType",
    "../constant/ModelCategory",
  ],
  function (
    BaseEntityList,
    JSONModel,
    GroupHeaderListItem,
    MessageBox,
    EditProcessTypeDialog,
    ObjectType,
    ModelCategory
  ) {
    "use strict";

    var IS_CREATED_ENABLED_PATH = "/isCreateEnabled";

    return BaseEntityList.extend("com.sap.gtt.v2.model.manage.controller.ProcessType", {
      initModel: function () {
        var oListViewInfo = new JSONModel({
          busy: false,
          count: 0,
          listTitle: this.getResourceBundle().getText("listTitle"),
          selectedCount: 0,
          showingSideView: "fieldLists",
        });
        this.setModel(oListViewInfo, "listViewInfo");
      },

      getGroupHeader: function (oGroup) {
        var sId = this.createId(oGroup.key);

        var bShouldGroup =
          this.getModel("store").getProperty("/modelCategory") === ModelCategory.Standard;

        var sTitle = this.getResourceBundle().getText("userDefined");
        if (oGroup.key === ModelCategory.Standard) {
          sTitle = this.getResourceBundle().getText("standard");
        }

        return new GroupHeaderListItem({
          id: sId,
          title: sTitle,
          visible: bShouldGroup,
        });
      },

      initCreateAndEditDialogController: function () {
        var oDialogController = new EditProcessTypeDialog();
        this.oDialogController = this.mergeViewFunctionsIntoCreateAndEditDialog(oDialogController);

        this._createAndEditDialogFragmentId = "editProcessTypeDialog";
        this._createAndEditDialogFragmentName = "EditProcessTypeDialog";
      },

      setSideContentEditable: function (isEditable) {
        var detailView = this.byId("detailView");

        detailView
          .byId("processTypeUserFieldsView")
          .getModel("view")
          .setProperty(IS_CREATED_ENABLED_PATH, isEditable);
        detailView
          .byId("plannedEventView")
          .byId("plannedEventUserView")
          .getModel("view")
          .setProperty(IS_CREATED_ENABLED_PATH, isEditable);
        detailView
          .byId("unplannedEventView")
          .byId("unplannedEventUserView")
          .getModel("view")
          .setProperty(IS_CREATED_ENABLED_PATH, isEditable);
      },

      onItemSelected: function (listItem) {
        var sPath = listItem.getBindingContextPath();
        var oContext = listItem.getBindingContext("store");
        var aElements = oContext.getProperty("elements");
        var oStore = this.getModel("store");

        if (aElements === undefined || aElements === null) {
          oStore.setProperty("elements", [], oContext);
        }

        var admissiblePlannedEvents = oContext.getProperty("admissiblePlannedEvents");
        if (admissiblePlannedEvents === undefined || admissiblePlannedEvents === null) {
          oStore.setProperty("admissiblePlannedEvents", [], oContext);
        }

        var admissibleUnplannedEvents = oContext.getProperty("admissibleUnplannedEvents");
        if (admissibleUnplannedEvents === undefined || admissibleUnplannedEvents === null) {
          oStore.setProperty("admissibleUnplannedEvents", [], oContext);
        }

        this.byId("detailView").bindElement({
          path: sPath,
          model: "store",
        });
      },

      resetViewState: function () {
        var listViewModel = this.getModel("listViewInfo");
        listViewModel.setProperty("/selectedCount", 0);
        listViewModel.setProperty("/showingSideView", "fieldLists");

        // select first process type list item
        this.selectFirstListItem();
      },

      selectFirstListItem: function () {
        var oList = this.byId("list");
        var isFireEvent = true;
        var selectedItem = this.getFirstListItem();
        if (selectedItem) {
          oList.setSelectedItem(selectedItem, true, isFireEvent);
        }
      },

      getCreateDialogData: function () {
        return {
          name: "",
          descr: "",
          trackingIdType: "",
          elements: [],
          enableIDoc: false,
          enableVP: false,
          _parent: null,
          _objectType: ObjectType.ProcessType,
          _category: ModelCategory.User,
        };
      },

      onDialogAccepted: function (type, data, context) {
        this.setTranslationPropertiesForListItem(
          "descr",
          data,
          type === "edit" ? context.getProperty("descr") : "",
          type
        );

        if (type === "edit") {
          this.modify(context.getObject(), data);
          this.refreshBinding();
          this.updateRelatedName();
        } else {
          // Create in model
          var items = context.getProperty("/processTypes");
          items.push(data);

          this.refreshBinding();
          this.updateListSelection(data.name);
          this.scrollToNewCreatedItem(data.name);
        }
        this.changeToEditMode();
      },

      handleDeleteItemWithNoReference: function (item) {
        if (item._objectType === ObjectType.ProcessType) {
          MessageBox.warning(
            this.getResourceBundle().getText("deleteTPWarningMessage", item.name),
            {
              actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
              onClose: function (action) {
                if (action === MessageBox.Action.OK) {
                  this.onItemDeleted(item);
                }
              }.bind(this),
            }
          );
        }
      },

      updateRelatedName: function () {
        // refresh bindings
        var eventBus = this.getEventBus();
        this.refreshBinding();
        // trigger re-group
        eventBus.publish("modelDetail", "refreshItemTypesBinding", {});
        eventBus.publish("modelDetail", "refreshEventTypesBinding", {});
        // refresh mapping binding
        eventBus.publish("modelDetail", "refreshVPBinding", {});
        eventBus.publish("modelDetail", "refreshIDocBinding", {});
      },
    });
  }
);
