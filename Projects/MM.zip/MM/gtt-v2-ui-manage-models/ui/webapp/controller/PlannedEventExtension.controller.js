sap.ui.define(["./BaseController"], function (BaseController) {
  "use strict";

  return BaseController.extend("com.sap.gtt.v2.model.manage.controller.PlannedEventExtension", {});
});
