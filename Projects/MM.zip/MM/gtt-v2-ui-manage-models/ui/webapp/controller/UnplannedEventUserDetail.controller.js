sap.ui.define(
  [
    "./BaseDetailController",
    "sap/ui/model/json/JSONModel",
    "sap/base/util/merge",
    "../constant/ObjectType",
    "../constant/ModelCategory",
    "./EditUnplannedEventDialog",
  ],
  function (
    BaseDetailController,
    JSONModel,
    merge,
    ObjectType,
    ModelCategory,
    EditUnplannedEventDialog
  ) {
    "use strict";
    return BaseDetailController.extend(
      "com.sap.gtt.v2.model.manage.controller.UnplannedEventUserDetail",
      {
        initModel: function () {
          // Set relevant info for view
          var view = new JSONModel({
            tableTitle: "",
            selectedCount: 0,
            isCreateEnabled: true,
          });
          this.setModel(view, "view");
        },

        initCreateAndEditDialogController: function () {
          var oView = this.getView();
          var oDialogController = new EditUnplannedEventDialog();
          this.oDialogController = merge({}, oDialogController, {
            onDialogAccepted: function (type, data, context, info) {
              this.onDialogAccepted(type, data, context, info);
            }.bind(this),
            getView: function () {
              return oView;
            },
          });
        },

        getItemsBinding: function () {
          var oList = this.byId("table");

          return oList.getBinding("items");
        },

        removeListSelections: function () {
          var table = this.byId("table");
          table.removeSelections();
        },

        onUpdateFinished: function () {
          var oTable = this.byId("table");
          var sTitle;
          var iTotalItems = oTable.getBinding("items").getLength();
          if (oTable.getBinding("items").isLengthFinal()) {
            sTitle = this.getResourceBundle().getText("userUnplannedEventTableTitle", [
              iTotalItems,
            ]);
          } else {
            sTitle = this.getResourceBundle().getText("userUnplannedEventTableTitle");
          }
          this.getModel("view").setProperty("/tableTitle", sTitle);

          this.setSelectedCount();
        },

        onSelectionChange: function (oEvent) {
          this.setSelectedCount();
        },

        setSelectedCount: function () {
          var table = this.byId("table");
          var selectedItems = table.getSelectedItems();
          this.getModel("view").setProperty("/selectedCount", selectedItems.length);
        },

        /* Add Unplanned Event */
        onAddItem: function () {
          var sTitle = this.getResourceBundle().getText("addUnplannedEventType");
          var oContext = this.byId("table").getBindingContext("store");
          var eventTypes = this.filterUnplannedEventTypes();

          var oModel = new JSONModel({
            type: "create",
            context: oContext,
            title: sTitle,
            data: {
              _ref: {
                eventType: null,
              },
              _category: ModelCategory.User,
            },
            info: {
              eventTypes: eventTypes,
            },
          });

          var options = {
            fragmentId: "editUnplannedEventDialog",
            fragmentName: "EditUnplannedEventDialog",
            controller: this.oDialogController,
            model: oModel,
          };
          this.openDialog(options);
        },

        /* Edit Unplanned Event */
        onEditItem: function (oEvent) {
          var oContext = oEvent.getSource().getBindingContext("store");
          this.openEditItemDialog(oContext);
        },

        onEditButtonPress: function () {
          var oTable = this.byId("table");
          var oListItem = oTable.getSelectedItem();
          var oContext = oListItem.getBindingContext("store"); // "/processTypes/0/admissibleUnplannedEvents/0"
          this.openEditItemDialog(oContext);
        },

        openEditItemDialog: function (oContext) {
          var sTitle = this.getResourceBundle().getText("editUnplannedEventType");

          // prepare list for event types
          var eventTypes = this.filterUnplannedEventTypes();
          var selectedEventType = oContext.getProperty("_ref/eventType");
          selectedEventType.selectable = true;

          var oModel = new JSONModel({
            type: "edit",
            context: oContext,
            title: sTitle,
            data: {
              _ref: {
                eventType: selectedEventType,
              },
              _category: oContext.getProperty("_category"),
            },
            info: {
              eventTypes: eventTypes,
            },
          });

          var options = {
            fragmentId: "editUnplannedEventDialog",
            fragmentName: "EditUnplannedEventDialog",
            controller: this.oDialogController,
            model: oModel,
          };
          this.openDialog(options);
        },

        onDialogAccepted: function (type, data, context, info) {
          if (type === "edit") {
            var originData = context.getObject();
            this.updateOriginData(originData, data);
          } else {
            var items = this.getListItems();
            var newItems = items.slice();

            data._objectType = ObjectType.AdmissibleUnplannedEvent;
            data._parent = context.getObject();
            newItems.push(data);
            this.setListItems(newItems);

            this.whereUsedListHelper.addAdmissibleEventDependency(data);
          }

          this.refreshBinding();
          this.changeToEditMode();
        },

        updateOriginData: function (originData, dialogData) {
          // update dependency for eventType when target changes
          this.whereUsedListHelper.updateAdmissibleEventDependency(
            originData,
            dialogData._ref.eventType
          );

          // modify properties
          this.modify(originData, dialogData);
        },

        /* Delete Unplanned Event */
        onDeleteItem: function () {
          var oTable = this.byId("table");
          var oSelectedContexts = oTable.getSelectedContexts();

          // Use for-loop to start deleting from the last item
          // to avoid index change by deleting the starting item
          for (var i = oSelectedContexts.length - 1; i >= 0; i--) {
            var oSelectedContext = oSelectedContexts[i];
            var oSelectedObject = oSelectedContext.getObject();

            this.onItemDeleted(oSelectedObject);
          }

          this.changeToEditMode();
          this.refreshBinding();
        },

        onItemDeleted: function (oItem) {
          this.deleteHelper.deleteObject(oItem);
        },

        filterUnplannedEventTypes: function () {
          var items = this.getListItems();
          var usedEventTypes = items.map(function (item) {
            return item._ref.eventType;
          });

          var userDefinedEventTypes = this.getUserDefinedEventTypes();

          userDefinedEventTypes.forEach(function (eventType) {
            eventType.selectable = usedEventTypes.indexOf(eventType) === -1;
          });

          return userDefinedEventTypes;
        },

        getUserDefinedEventTypes: function () {
          var allEventTypes = this.getModel("store").getProperty("/eventTypes");

          return allEventTypes.filter(function (eventType) {
            // filter Core Model & Standard event types
            return (
              eventType._ref.context.name !== "CoreModel" &&
              eventType._category !== ModelCategory.Standard
            );
          });
        },
      }
    );
  }
);
