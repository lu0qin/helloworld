sap.ui.define(
  [
    "./BaseDialog",
    "sap/ui/core/Fragment",
    "sap/ui/core/ValueState",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/base/strings/formatMessage",
    "./EntityValidator",
    "../util/ValidationHelper",
    "../constant/FieldType",
    "../constant/ObjectType",
    "../constant/ModelCategory",
    "../constant/ViewMode",
  ],
  function (
    BaseDialog,
    Fragment,
    ValueState,
    JSONModel,
    Filter,
    FilterOperator,
    formatMessage,
    EntityValidator,
    ValidationHelper,
    FieldType,
    ObjectType,
    ModelCategory,
    ViewMode
  ) {
    "use strict";
    return BaseDialog.extend("com.sap.gtt.v2.model.manage.controller.EditFieldDialog", {
      validate: function () {
        // set type
        var select = this.byId("type");
        var item = select.getSelectedItem();
        select.fireChange({ selectedItem: item });
        // set asso-to-one field
        if (select.getSelectedKey() === FieldType.AssociationToMany) {
          var assoToOneField = this.byId("associationToOneFieldTarget");
          var sValue = assoToOneField.getValue();
          var bIsItemPressed = Boolean(assoToOneField.getSelectedKey());
          assoToOneField.fireChange({
            value: sValue,
            itemPressed: bIsItemPressed,
          });
        }
        var aCheckValueStateControls = this.getValidationControls();
        var aMandatoryControls = this.getMandatoryControls();
        var aErrors = [].concat(
          ValidationHelper.validateMandatory(aMandatoryControls),
          ValidationHelper.checkValueState(aCheckValueStateControls)
        );
        return aErrors.length === 0;
      },

      getValidationControls: function () {
        var aControls = this.getControls();

        var oDpp = this.byId("dpp");
        aControls.push(oDpp);

        return aControls;
      },

      getMandatoryControls: function () {
        return this.getControls();
      },

      getControls: function () {
        var aControls = [];
        var oInput = this.byId("name");
        var oSelectType = this.byId("type");
        aControls.push(oInput);
        aControls.push(oSelectType);

        var sTypeValue = oSelectType.getSelectedKey();
        switch (sTypeValue) {
          case FieldType.Decimal:
            var oInputPrecision = this.byId("precision");
            var oInputScale = this.byId("scale");
            aControls.push(oInputPrecision);
            aControls.push(oInputScale);
            break;
          case FieldType.String:
            var oInputLength = this.byId("length");
            aControls.push(oInputLength);
            break;
          case FieldType.CodeList:
            var oInputTarget = this.byId("codeListTarget");
            aControls.push(oInputTarget);
            break;
          case FieldType.AssociationToOne:
            var oAssoTOneProcessTypeTarget = this.byId("processTypeTarget");
            aControls.push(oAssoTOneProcessTypeTarget);
            break;
          case FieldType.AssociationToMany:
            var oAssoToManyProcessTypeTarget = this.byId("processTypeTarget");
            aControls.push(oAssoToManyProcessTypeTarget);
            var oAssociationToOneTarget = this.byId("associationToOneFieldTarget");
            aControls.push(oAssociationToOneTarget);
            break;
          case FieldType.Composition:
            var oItemTypeTarget = this.byId("itemTypeTarget");
            aControls.push(oItemTypeTarget);
            break;
          default:
            break;
        }
        return aControls;
      },

      autoSelectWritable: function (oEvent) {
        var oCheckBoxWritable = this.byId("writable");
        oCheckBoxWritable.fireSelect({
          checked: true,
        });
      },

      _configValueHelpSelection: function (aFields, sInputValue) {
        aFields.forEach(function (oField) {
          if (oField._ref && oField._ref.context) {
            oField.selected =
              formatMessage("{0}.{1}", [oField._ref.context.name, oField.name]) === sInputValue;
          } else {
            oField.selected = oField.name === sInputValue;
          }
        });
      },

      handleProcessTypeValueHelp: function (oEvent) {
        var sInputValue = oEvent.getSource().getValue();
        var processTypes = this.getView().getBindingContext("store").getProperty("/processTypes");
        this._configValueHelpSelection(processTypes, sInputValue);
        var oProcessTypeValueHelp = new JSONModel({
          processTypes: processTypes,
        });
        var oView = Fragment.byId("editFieldDialog", "dialog");
        if (!Fragment.byId("processTypeValueHelp", "processTypeTargetDialog")) {
          Fragment.load({
            id: "associationValueHelp",
            name: "com.sap.gtt.v2.model.manage.view.fragments.ProcessTypeValueHelp",
            controller: this,
          }).then(function (oDialog) {
            oView.addDependent(oDialog);
            oDialog.setModel(oProcessTypeValueHelp, "processTypeValueHelp");
            oDialog.open();
          });
        } else {
          Fragment.byId("processTypeValueHelp", "processTypeTargetDialog").open();
        }
      },

      handleProcessTypeValueHelpClose: function (oEvent) {
        var processTypeTargetInput = this.byId("processTypeTarget");

        var aContexts = oEvent.getParameter("selectedContexts");
        var oDialog = oEvent.getSource();
        var oDialogModel = oDialog.getModel("dialog");

        if (aContexts && aContexts.length) {
          var oProcessTypeTarget = aContexts[0].getObject();
          oDialogModel.setProperty("/data/processTypeTarget", oProcessTypeTarget);
          // clear backlink when change processTypeTarget
          oDialogModel.setProperty("/data/backlink", null);
          // validate target
          var sWarningMsg = EntityValidator.validateProcessTypeTarget(
            oDialogModel,
            this.getResourceBundle()
          );
          if (sWarningMsg) {
            ValidationHelper.setControlValidationWarning(processTypeTargetInput, sWarningMsg);
          } else {
            ValidationHelper.resetControlValidation(processTypeTargetInput);
          }
        }

        oDialog.destroy();
      },

      handleProcessTypeValueHelpSearch: function (oEvent) {
        var sValue = oEvent.getParameter("value");
        var oFilter = new Filter({
          filters: [
            new Filter("name", FilterOperator.Contains, sValue),
            new Filter("trackingIdType", FilterOperator.Contains, sValue),
            new Filter("descr", FilterOperator.Contains, sValue),
          ],
        });
        var oBinding = oEvent.getSource().getBinding("items");
        oBinding.filter([oFilter]);
      },

      handleItemTypeValueHelp: function (oEvent) {
        var oInput = oEvent.getSource();
        var sInputValue = oInput.getValue();
        var oContext = oInput.getBindingContext("store");
        var sObjectName = oContext.getProperty("name");
        var itemTypes = oContext.getProperty("/itemTypes").filter(function (itemType) {
          return itemType.name !== sObjectName;
        });
        this._configValueHelpSelection(itemTypes, sInputValue);
        var oItemTypeValueHelp = new JSONModel({
          itemTypes: itemTypes,
        });
        var oView = Fragment.byId("editFieldDialog", "dialog");
        if (!Fragment.byId("itemTypeValueHelp", "itemTypeTargetDialog")) {
          Fragment.load({
            id: "compositionValueHelp",
            name: "com.sap.gtt.v2.model.manage.view.fragments.ItemTypeValueHelp",
            controller: this,
          }).then(function (oDialog) {
            oView.addDependent(oDialog);
            oDialog.setModel(oItemTypeValueHelp, "itemTypeValueHelp");
            oDialog.open();
          });
        } else {
          Fragment.byId("itemTypeValueHelp", "itemTypeTargetDialog").open();
        }
      },

      handleItemTypeValueHelpClose: function (oEvent) {
        var oSelectedItem = oEvent.getParameter("selectedItem");
        var oDialog = oEvent.getSource();
        var model = oDialog.getModel("dialog");
        var oInput = this.byId("itemTypeTarget");

        if (oSelectedItem) {
          var itemObject = oSelectedItem.getBindingContext("itemTypeValueHelp").getObject();
          model.setProperty("/data/itemTypeTarget", itemObject);
          var sWarningMsg = EntityValidator.validateItemTypeTarget(model, this.getResourceBundle());
          if (sWarningMsg) {
            ValidationHelper.setControlValidationWarning(oInput, sWarningMsg);
          } else {
            ValidationHelper.resetControlValidation(oInput);
          }
        }

        oDialog.destroy();

        this.handleCompositionTargetChange(oInput, itemObject);
      },

      handleItemTypeValueHelpSearch: function (oEvent) {
        var sValue = oEvent.getParameter("value");
        var oFilter = new Filter({
          filters: [
            new Filter("name", FilterOperator.Contains, sValue),
            new Filter("context", FilterOperator.Contains, sValue),
          ],
        });
        var oBinding = oEvent.getSource().getBinding("items");
        oBinding.filter([oFilter]);
      },

      handleCodeListValueHelp: function (oEvent) {
        var sInputValue = oEvent.getSource().getValue();
        var codeLists = this.getView().getBindingContext("store").getProperty("/codeLists");

        codeLists.forEach(function (codeList) {
          codeList.selected = codeList.name === sInputValue;
        });

        var oCodeListValueHelp = new JSONModel({
          codeLists: codeLists,
        });

        var oView = Fragment.byId("editFieldDialog", "dialog");

        if (!Fragment.byId("codeListValueHelp", "codeListTargetDialog")) {
          Fragment.load({
            id: "codeListValueHelp",
            name: "com.sap.gtt.v2.model.manage.view.fragments.CodeListValueHelp",
            controller: this,
          }).then(function (oDialog) {
            oView.addDependent(oDialog);
            oDialog.setModel(oCodeListValueHelp, "codeListValueHelp");
            oDialog.open();
          });
        } else {
          Fragment.byId("codeListValueHelp", "codeListTargetDialog").open();
        }
      },

      handleCodeListValueHelpClose: function (oEvent) {
        var oSelectedItem = oEvent.getParameter("selectedItem");
        var oDialog = oEvent.getSource();
        var model = oDialog.getModel("dialog");

        if (oSelectedItem) {
          var itemObject = oSelectedItem.getBindingContext("codeListValueHelp").getObject();
          model.setProperty("/data/codeListTarget", itemObject);
        }

        oDialog.destroy();
      },

      handleCodeListValueHelpSearch: function (oEvent) {
        var sValue = oEvent.getParameter("value");
        var oFilter = new Filter({
          filters: [new Filter("name", FilterOperator.Contains, sValue)],
        });
        var oBinding = oEvent.getSource().getBinding("items");
        oBinding.filter([oFilter]);
      },

      onChangeName: function (oEvent) {
        var oControl = oEvent.getSource();
        this.handleNameChange(oControl);
      },

      onDppChange: function (oEvent) {
        var oControl = oEvent.getSource();
        this.handleDppChange(oControl);
      },

      onFieldTypeSelectionChange: function (oEvent) {
        var oSelect = oEvent.getSource();
        var oModel = oSelect.getModel(this.modelName);
        var dialogType = oModel.getProperty("/type");

        // set type value
        var selectedType = this.byId("type").getSelectedKey();
        oModel.setProperty("/data/type", selectedType);

        // set writable to false when type is AssociationToMany
        if (selectedType === FieldType.AssociationToMany) {
          oModel.setProperty("/data/writable", false);
        }

        // check type validation - should warn update effect
        if (dialogType === ViewMode.Edit) {
          var sWarningMsg = EntityValidator.validateFieldType(oModel, this.getResourceBundle());
          if (sWarningMsg) {
            ValidationHelper.setControlValidationWarning(oSelect, sWarningMsg);
          } else {
            ValidationHelper.resetControlValidation(oSelect);
          }
        }
      },

      onPrecisionChange: function (oEvent) {
        var oControl = oEvent.getSource();
        this.handlePrecisionChange(oControl);
      },

      onScaleChange: function (oEvent) {
        var oControl = oEvent.getSource();
        this.handleScaleChange(oControl);
      },

      onAssociationToOneFieldChange: function (oEvent) {},

      onAssociationToOneFieldSelectionChange: function (oEvent) {},

      handleNameChange: function (oControl) {
        var oModel = oControl.getModel("dialog");

        var oValidationResult = this.validateName(oModel);
        oControl.setValueState(oValidationResult.valueState);
        oControl.setValueStateText(oValidationResult.msg);
      },

      handleDppChange: function (oControl) {
        var keys = oControl.getSelectedKeys();
        var oModel = oControl.getModel("dialog");
        var sType = oModel.getProperty("/type");
        var oContext = oModel.getProperty("/context");

        // In edit dialog mode, if the field already includes DataSubjectID, do not check update
        if (sType === ViewMode.Edit) {
          if (
            oContext.getProperty("dpp") &&
            oContext.getProperty("dpp").includes("DATA_SUBJECT_ID")
          ) {
            return;
          } else {
            // reset value of 'context' to parent entity binding context
            var oParentPath = oContext.getPath().split("/elements")[0];
            var oStoreModel = oContext.getModel("store");
            oContext = oStoreModel.getContext(oParentPath);
          }
        }

        var items = oContext.getObject().elements;
        var bWillContainDataSubjectId = keys.includes("DATA_SUBJECT_ID");
        var duplicateItem = items.find(function (item) {
          return item.dpp && item.dpp.includes("DATA_SUBJECT_ID");
        });

        if (bWillContainDataSubjectId && duplicateItem) {
          ValidationHelper.setControlValidationError(
            oControl,
            this.getResourceBundle().getText("dppValueDataSubjectIDErrorMessage")
          );
        } else {
          oControl.setValueState(ValueState.None);
          oControl.setValueStateText("");
        }
      },

      handleScaleChange: function (oControl) {
        var oModel = oControl.getModel("dialog");
        var iScaleValue = oControl.getBinding("value").getValue();
        var iPrecisionValue = oModel.getProperty("/data/precision");

        if (iPrecisionValue && iScaleValue && iPrecisionValue < iScaleValue) {
          ValidationHelper.setControlValidationError(
            oControl,
            this.getResourceBundle().getText("scaleErrorMessage")
          );
        }
      },

      handlePrecisionChange: function (oControl) {
        var oModel = oControl.getModel("dialog");
        var iPrecisionValue = oControl.getBinding("value").getValue();
        var iScaleValue = oModel.getProperty("/data/scale");

        if (iPrecisionValue && iScaleValue && iPrecisionValue < iScaleValue) {
          ValidationHelper.setControlValidationError(
            oControl,
            this.getResourceBundle().getText("precisionErrorMessage")
          );
        }
      },

      // Only used in ItemTypeUserFields
      handleCompositionTargetChange: function () {},

      validateName: function (oModel) {
        var oResourceBundle = this.getResourceBundle();

        var result = {
          valueState: ValueState.None,
          msg: "",
        };

        // check empty, constraint, duplicate, reserved, start with GTT
        var aErrors = this.validateNameError(oModel, oResourceBundle);

        if (aErrors.length === 0) {
          var aWarnings = EntityValidator.validateNameUpdate(oModel, oResourceBundle);
          if (aWarnings.length !== 0) {
            result.valueState = ValueState.Warning;
            result.msg = aWarnings[0].message;
          }
        } else {
          result.valueState = ValueState.Error;
          result.msg = aErrors[0].message;
        }

        return result;
      },

      validateNameError: function (oModel, oResourceBundle) {
        var aErrors = [];

        var sType = oModel.getProperty("/type");
        var oCurrentItem = oModel.getProperty("/data");
        var sCurrentName = oCurrentItem.name;
        var oContext = oModel.getProperty("/context");
        var oStoreModel = oContext.getModel("store");

        if (sType === ViewMode.Edit && sCurrentName.toLowerCase() === oContext.getProperty("name").toLowerCase()) {
          return [];
        }

        var oParentObject = oCurrentItem._parent || oStoreModel.getProperty("/plannedEvent");
        var sParentObjectType = oParentObject._objectType || ObjectType.PlannedEventExtension;

        var oPreviousItemName = sType === ViewMode.Create ? "" : oContext.getProperty("name");

        if (oParentObject._category === ModelCategory.Standard) {
          aErrors = aErrors.concat(
            EntityValidator.validateNotStartWithZZ(
              sCurrentName,
              oCurrentItem._objectType,
              sParentObjectType,
              oResourceBundle
            )
          );
        }

        aErrors = aErrors.concat(
          EntityValidator.validateEmpty(sCurrentName, oResourceBundle),
          EntityValidator.validateStringConstraint(sCurrentName, true, true, oResourceBundle),
          EntityValidator.validateDuplicateEntityFieldName(
            sCurrentName,
            oPreviousItemName,
            oParentObject.elements,
            oResourceBundle
          ),
          EntityValidator.validateReservedEntityFieldName(
            sCurrentName,
            oParentObject,
            oStoreModel,
            oResourceBundle
          ),
          EntityValidator.validateStartWithGTT(sCurrentName, oResourceBundle)
        );

        return aErrors;
      },

      checkIfItemShowInBacklinkList: function (oItem) {
        return (
          this.checkIfItemAssoToTargetProcessType(oItem) &&
          !this.checkIfItemSameAsCurrentField(oItem)
        );
      },

      checkIfItemAssoToTargetProcessType: function (oItem) {
        var oDialogModel = this.byId("dialog").getModel("dialog");
        var oParentObject = oDialogModel.getProperty("/data/_parent");

        var bIsReferToCurrentFieldParent = oItem._ref && oItem._ref.target === oParentObject;

        return FieldType.isItemAssociationToOne(oItem) && bIsReferToCurrentFieldParent;
      },

      checkIfItemSameAsCurrentField: function (oItem) {
        var oDialogModel = this.byId("dialog").getModel("dialog");

        var sDialogType = oDialogModel.getProperty("/type");
        var oContext = oDialogModel.getProperty("/context");

        return sDialogType === ViewMode.Edit && oContext.getObject() === oItem;
      },
    });
  }
);
