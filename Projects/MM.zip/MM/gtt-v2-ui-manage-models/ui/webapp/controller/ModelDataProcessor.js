sap.ui.define(
  [
    "sap/base/strings/formatMessage",
    "sap/base/util/merge",
    "sap/base/util/deepClone",
    "../constant/ObjectType",
    "../constant/FieldType",
    "../constant/ModelCategory",
    "../util/StatusMappingUtil",
  ],
  function (
    formatMessage,
    merge,
    deepClone,
    ObjectType,
    FieldType,
    ModelCategory,
    StatusMappingUtil
  ) {
    "use strict";

    var PROCESS_TYPES_PATH = "/processTypes";
    var ITEM_TYPES_PATH = "/itemTypes";
    var EVENT_TYPES_PATH = "/eventTypes";
    var CORE_MODEL_PATH = "/coreModel";

    var ModelDataProcessor = {
      _bModelIsStandard: false, // will be updated in every updateData call

      _checkArrayNotUndefinedOrEmpty: function (arr) {
        return arr && arr.length !== 0;
      },

      _checkJsonNotEmpty: function (jsonObj) {
        return jsonObj && Object.keys(jsonObj) && Object.keys(jsonObj).length !== 0;
      },

      _getGTTCodeListSubModel: function (aSubmodels) {
        return (
          aSubmodels.find(function (subModel) {
            return subModel.name === "GTTCodeList";
          }) || {}
        );
      },

      /**
       * Convert JSON Data from backend to UI data object for display.
       * Should update data in order to generate UI Object relationship.
       * 1. Update Data for Model Header Info, Category and Core Model
       * 2. Update Data for Code Lists and its codes
       * 3. Update Data Planned Event Extension, Process Types, Field Types and Event Types WITHOUT elements
       * 4. Update Data for above elements WITHOUT those elements whose type is Association to Many
       * 5. Update Data for Association to Many elements
       * 6. Update IDOC and VP Mapping for Process Types or Event Types
       *
       * @param {object} data source data: result of request from backend
       * @param {object} model store model
       */
      updateData: function (data, model) {
        this.updateDataForModelHeaderInfo(data, model);
        this.updateDataForModelCategory(data.modelCategory, model);
        this.updateDataForModelLastOperationStatus(data, model);

        // Update core model
        this.updateDataForProcessTypeCoreModel(data.coreModel, model);
        this.updateDataForEventTypeCoreModel(data.coreModel, model);

        if (data.standardModel || data.customModel) {
          // Update separate codeLists
          this.updateDataForCodeLists(data, model);

          // Update plannedEvent without elements
          this.updateDataForPlannedEventExtension(data, model);

          // Update entities without elements, admissibleUn/PlannedEvents, idoc/vpMapping
          this.updateDataForProcessTypes(data, model);
          this.updateDataForItemAndEventTypes(model);

          // Update Elements
          var plannedEvent = model.getProperty("/plannedEvent");
          var itemTypes = model.getProperty(ITEM_TYPES_PATH);
          var eventTypes = model.getProperty(EVENT_TYPES_PATH);
          var processTypes = model.getProperty(PROCESS_TYPES_PATH);

          var userDefinedEventTypes = eventTypes.filter(function (eventType) {
            return eventType._ref.context.name !== "CoreModel";
          });

          // Update plannedEventExtension elements
          this.updateDataForElements(plannedEvent, model);

          // Update elements according to _source in order by ItemType, EventType and ProcessType
          this.updateDataForEntityElements(itemTypes, model);
          this.updateDataForEntityElements(userDefinedEventTypes, model);
          this.updateDataForEntityElements(processTypes, model);
          this.updateDataForProcessTypeAssociationToManyElements(processTypes, model);

          // whole entity of plannedEvent and itemTypes are done, delete _source
          this.deleteSourceReference(plannedEvent);

          itemTypes.forEach(function (itemType) {
            this.deleteSourceReference(itemType);
          }, this);

          // Update admissibleUn/PlannedEvents
          this.updateDataForAdmissibleEvents(processTypes, model);

          // Update idoc/vpMapping
          this.updateDataForIDocMapping(processTypes);
          this.updateDataForIDocMapping(userDefinedEventTypes);
          this.updateDataForVPMapping(processTypes, model);
          this.updateDataForVPMapping(userDefinedEventTypes, model);

          // whole entity of processTypes and eventTypes are done, delete _source
          processTypes.forEach(function (processType) {
            this.deleteSourceReference(processType);
          }, this);
          eventTypes.forEach(function (eventType) {
            this.deleteSourceReference(eventType);
          }, this);
        }
      },

      deleteSourceReference: function (object) {
        delete object._source;
      },

      formatItemSource: function (item, sourceItem) {
        if (item._category === ModelCategory.Standard) {
          item._source.standard = sourceItem;
        } else {
          item._source.user = sourceItem;
        }
      },

      /**
       * Set original JSON data into store/model
       * @param {object} data fetched original JSON data
       * @param {object} model store model
       */
      updateDataForModelHeaderInfo: function (data, model) {
        model.setProperty("/model", data);
      },

      /**
       * Reset flag to indicate if current model is Standard
       * @param {string} modelCategory value of enum ModelCategory: USER, STANDARD
       * @param {object} model store model
       */
      updateDataForModelCategory: function (modelCategory, model) {
        model.setProperty("/modelCategory", modelCategory);
        this._bModelIsStandard = modelCategory === ModelCategory.Standard;
      },

      updateDataForModelLastOperationStatus: function (data, model) {
        model.setProperty(
          "/lastOperationStatus",
          StatusMappingUtil.getOperationStatus(data.draftStatus, data.lastActionResult)
        );
      },

      // ========================================================
      // Update Data for Core Model
      // ========================================================
      // data will differ between display/create mode
      updateDataForEventTypeCoreModel: function (coreModelData, model) {
        var coreModel = model.getProperty(CORE_MODEL_PATH);

        var eventTypes = [];
        coreModelData.eventTypes.forEach(function (item) {
          if (item.name !== "Event") {
            var newItem = deepClone(item);
            newItem.context = "CoreModel";

            this.setReferenceForCoreModelElements(newItem.elements || []);
            eventTypes.push(newItem);
          }
        }, this);

        var baseEventType = coreModelData.eventTypes.find(function (item) {
          return item.name === "Event";
        });

        var baseEventTypeFields = [];
        if (baseEventType) {
          this.setReferenceForCoreModelElements(baseEventType.elements);

          baseEventTypeFields = baseEventType.elements.filter(function (item) {
            return item.type !== FieldType.Association && item.type !== FieldType.Composition;
          });
        }

        model.setProperty(
          CORE_MODEL_PATH,
          merge(coreModel, {
            baseEventType: {
              elements: baseEventTypeFields,
            },
            eventTypes: eventTypes,
          })
        );

        // set reference for pre-defined eventTypes
        var referencedEventTypes = [];
        eventTypes.forEach(function (sourceEventType) {
          var eventType = {
            name: sourceEventType.name,
            _ref: {
              context: { name: "CoreModel" },
            },
            parent: sourceEventType.parent,
            descr: sourceEventType.descr,
            translation: sourceEventType.translation,
            elements: sourceEventType.elements,
            _parent: null,
            _objectType: ObjectType.EventType,
            _category: ModelCategory.User,
          };

          referencedEventTypes.push(eventType);
        }, this);

        model.setProperty(EVENT_TYPES_PATH, referencedEventTypes);
      },

      updateDataForProcessTypeCoreModel: function (coreModelData, model) {
        var coreModel = model.getProperty(CORE_MODEL_PATH);

        var processType = coreModelData.processTypes[0];

        var elements = [];
        if (processType.elements) {
          this.setReferenceForCoreModelElements(processType.elements);

          elements = processType.elements.filter(function (element) {
            return element.type !== FieldType.Association && element.type !== FieldType.Composition;
          });
        }

        model.setProperty(
          CORE_MODEL_PATH,
          merge(coreModel, {
            baseProcessType: {
              elements: elements,
            },
          })
        );
      },

      // For display data in core model table - same as custom user fields data
      setReferenceForCoreModelElements: function (elements) {
        elements.forEach(function (element) {
          if (element.target) {
            element._ref = {
              target: {
                name: element.target.split(".")[1],
              },
            };
          }
        });
      },

      // ========================================================
      // Update Data for Code List
      // based on GTTCodeList SubModel
      // ========================================================
      /**
       * Merge Standard and Custom CodeLists from same SubModel: GTTCodeList
       * then update codes of individual codelist
       *
       * @param {object} data fetched original JSON data
       * @param {object} model store model
       */
      updateDataForCodeLists: function (data, model) {
        var codeLists = [];

        if (this._bModelIsStandard) {
          this.updateDataForStandardCodeLists(data.standardModel, codeLists);
        }

        this.updateDataForCustomCodeLists(data.customModel, codeLists);

        codeLists.forEach(function (codeList) {
          codeList.values = this.formatCodeListValues(codeList);
          this.deleteSourceReference(codeList);
        }, this);

        model.setProperty("/codeLists", codeLists);
      },

      updateDataForStandardCodeLists: function (standardModel, codeLists) {
        if (!standardModel || !this._checkArrayNotUndefinedOrEmpty(standardModel.subModels)) {
          return;
        }

        var sourceStandardGTTCodeListSubModel = this._getGTTCodeListSubModel(
          standardModel.subModels
        );
        var sourceStandardCodeLists = sourceStandardGTTCodeListSubModel.codeLists;

        if (this._checkArrayNotUndefinedOrEmpty(sourceStandardCodeLists)) {
          sourceStandardCodeLists.forEach(function (sourceStandardCodeList) {
            codeLists.push(this.formatCodeList(sourceStandardCodeList, ModelCategory.Standard));
          }, this);
        }
      },

      updateDataForCustomCodeLists: function (customModel, codeLists) {
        if (!customModel || !this._checkArrayNotUndefinedOrEmpty(customModel.subModels)) {
          return;
        }

        var sourceCustomGTTCodeListSubModel = this._getGTTCodeListSubModel(customModel.subModels);
        var sourceCustomCodeLists = sourceCustomGTTCodeListSubModel.codeLists;

        if (this._checkArrayNotUndefinedOrEmpty(sourceCustomCodeLists)) {
          sourceCustomCodeLists.forEach(function (sourceCustomCodeList) {
            var codeList = codeLists.find(function (item) {
              return item.name === sourceCustomCodeList.name;
            });

            if (codeList) {
              // if current sourceCustomCodeList is extension of Standard Code List
              // set source reference to extension part instead of generating a new custom codeList
              codeList._source.user = sourceCustomCodeList;
            } else {
              codeLists.push(this.formatCodeList(sourceCustomCodeList, ModelCategory.User));
            }
          }, this);
        }
      },

      formatCodeList: function (sourceCodeList, category) {
        var codeList = {
          name: sourceCodeList.name,
          elements: sourceCodeList.elements,
          _objectType: ObjectType.CodeList,
          _category: category,
          _source: {},
        };

        this.formatItemSource(codeList, sourceCodeList);

        return codeList;
      },

      /**
       * @param {object} codeList UI Object item of current codeList
       * @returns {array} return array of formatted UI Object values of current codeList
       */
      formatCodeListValues: function (codeList) {
        var values = [];

        // merge user & standard values from _source entity
        var sourceCodeList = codeList._source;
        var sourceValues = [];
        if (sourceCodeList.user) {
          var sourceCustomEntity = sourceCodeList.user;
          sourceValues = sourceValues.concat(sourceCustomEntity.values);
        }
        if (sourceCodeList.standard) {
          var sourceStandardEntity = sourceCodeList.standard;
          sourceValues = sourceValues.concat(sourceStandardEntity.values);
        }

        // add _category tag for every Code List value
        if (this._checkArrayNotUndefinedOrEmpty(sourceValues)) {
          sourceValues.forEach(function (sourceValue) {
            var value = {
              code: sourceValue.code,
              name: sourceValue.name,
              translation: sourceValue.translation,
              _objectType: ObjectType.Code,
              _parent: codeList,
            };

            if (codeList._category === ModelCategory.Standard) {
              // if codeList is Standard
              // distingush _category of each code by prefix 'zz'
              value._category = value.code.toLowerCase().startsWith("zz")
                ? ModelCategory.User
                : ModelCategory.Standard;
            } else {
              // if codeList is User
              // _category of each code is User by default
              value._category = ModelCategory.User;
            }

            values.push(value);
          });
        }

        return values;
      },

      // ========================================================
      // Update Data for Planned Event Extension
      // ========================================================
      /**
       * Generate UI Object: Planned Event Extension with _source reference
       * into store model: store/plannedEvent.
       * Its elements will be processed later.
       *
       * @param {object} data fetched original JSON data
       * @param {object} model store model
       */
      updateDataForPlannedEventExtension: function (data, model) {
        var plannedEventExtension = {
          _category: this._bModelIsStandard ? ModelCategory.Standard : ModelCategory.User,
          _source: {},
        };

        if (data.customModel) {
          plannedEventExtension._source.user = data.customModel.plannedEvent;
        }

        if (this._bModelIsStandard && data.standardModel) {
          plannedEventExtension._source.standard = data.standardModel.plannedEvent;
        }

        model.setProperty("/plannedEvent", plannedEventExtension);
      },

      // ========================================================
      // Update Data for Process Types based on Submodels
      // ========================================================
      /**
       * Merge Standard and Custom ProcessTypes into store model: store/processTypes.
       * This function founds for the processing of item types and event types.
       * Its elements will be processed later.
       *
       * @param {object} data fetched original JSON data
       * @param {object} model store model
       */
      updateDataForProcessTypes: function (data, model) {
        var processTypes = [];

        // Push standard submodels(process types) first when model is standard
        if (this._bModelIsStandard) {
          this.updateDataForStandardProcessTypes(data.standardModel, processTypes);
        }

        // push custom submodels(process types)
        this.updateDataForCustomProcessTypes(data.customModel, processTypes);

        model.setProperty(PROCESS_TYPES_PATH, processTypes);
      },

      updateDataForStandardProcessTypes: function (standardModel, processTypes) {
        if (!standardModel || !this._checkArrayNotUndefinedOrEmpty(standardModel.subModels)) {
          return;
        }

        var standardSubModels = standardModel.subModels.filter(function (standardSubModel) {
          return standardSubModel.name !== "GTTCodeList";
        });
        if (this._checkArrayNotUndefinedOrEmpty(standardSubModels)) {
          standardSubModels.forEach(function (standardSubModel) {
            if (this._checkArrayNotUndefinedOrEmpty(standardSubModel.processTypes)) {
              var standardProcessType = this.formatProcessType(
                standardSubModel,
                ModelCategory.Standard
              );
              processTypes.push(standardProcessType);
            }
          }, this);
        }
      },

      updateDataForCustomProcessTypes: function (customModel, processTypes) {
        if (!customModel || !this._checkArrayNotUndefinedOrEmpty(customModel.subModels)) {
          return;
        }

        var customSubModels = customModel.subModels.filter(function (subModel) {
          return subModel.name !== "GTTCodeList";
        });
        if (this._checkArrayNotUndefinedOrEmpty(customSubModels)) {
          customSubModels.forEach(function (customSubModel) {
            if (this._checkArrayNotUndefinedOrEmpty(customSubModel.processTypes)) {
              var processType = processTypes.find(function (item) {
                return item.name === customSubModel.name;
              });

              if (processType) {
                // if current customSubModel is extension of Standard SubModel
                // set source reference to extension part instead of generating a new custom processType
                processType._source.user = customSubModel;
                // enable IDOC/VP could be overwritten in custom model, so follow the custom data
                processType.enableIDoc = customSubModel.enableIDoc;
                processType.enableVP = customSubModel.enableVP;
              } else {
                processType = this.formatProcessType(customSubModel, ModelCategory.User);
                processTypes.push(processType);
              }
            }
          }, this);
        }
      },

      formatProcessType: function (sourceSubModel, category) {
        var sourceProcessType = sourceSubModel.processTypes[0];

        var processType = {
          name: sourceSubModel.name,
          descr: sourceProcessType.descr,
          trackingIdType: sourceProcessType.trackingIdType,
          translation: sourceProcessType.translation,
          enableIDoc: sourceSubModel.enableIDoc || false,
          enableVP: sourceSubModel.enableVP || false,
          _parent: null,
          _objectType: ObjectType.ProcessType,
          _category: category,
          _source: {},
        };

        // use submodel as _source entity for processing item/event types
        this.formatItemSource(processType, sourceSubModel);

        return processType;
      },

      // ========================================================
      // Update Data for Item Types & Event Types based on Process Type
      // ========================================================
      updateDataForItemAndEventTypes: function (model) {
        var itemTypes = [];
        var eventTypes = [];

        var processTypes = model.getProperty(PROCESS_TYPES_PATH);
        processTypes.forEach(function (processType) {
          this.updateDataForItemTypes(processType, itemTypes);
          this.updateDataForEventTypes(processType, eventTypes);
        }, this);

        model.setProperty(ITEM_TYPES_PATH, itemTypes);
        // concat coreModel eventTypes
        var coreModelEventTypes = model.getProperty(EVENT_TYPES_PATH);
        model.setProperty(EVENT_TYPES_PATH, eventTypes.concat(coreModelEventTypes));
      },

      /**
       * Merge Standard and Custom ItemTypes into store model: store/itemTypes.
       * Its elements will be processed later.
       *
       * @param {object} processType processed UI Object of parent processType
       * @param {object} itemTypes result array of itemTypes
       */
      updateDataForItemTypes: function (processType, itemTypes) {
        var standardSubModel = processType._source.standard;
        if (standardSubModel && standardSubModel.itemTypes) {
          standardSubModel.itemTypes.forEach(function (sourceStandardItemType) {
            var standardItemType = this.formatItemType(
              sourceStandardItemType,
              processType,
              ModelCategory.Standard
            );

            // generate where used
            this.whereUsedListHelper.addEntityDependency(standardItemType);
            itemTypes.push(standardItemType);
          }, this);
        }

        var customSubModel = processType._source.user;
        if (customSubModel && customSubModel.itemTypes) {
          customSubModel.itemTypes.forEach(function (sourceCustomItemType) {
            var itemType = itemTypes.find(function (item) {
              return item.name === sourceCustomItemType.name;
            });

            if (itemType) {
              itemType._source.user = sourceCustomItemType;
            } else {
              itemType = this.formatItemType(sourceCustomItemType, processType, ModelCategory.User);

              // generate where used
              this.whereUsedListHelper.addEntityDependency(itemType);
              itemTypes.push(itemType);
            }
          }, this);
        }
      },

      formatItemType: function (sourceItemType, processType, category) {
        var itemType = {
          name: sourceItemType.name,
          _ref: {
            context: processType,
          },
          _parent: null,
          _objectType: ObjectType.ItemType,
          _category: category,
          _source: {},
        };

        this.formatItemSource(itemType, sourceItemType);

        return itemType;
      },

      /**
       * Merge Standard and Custom ItemTypes into store model: store/eventTypes.
       * Its elements will be processed later.
       *
       * @param {object} processType processed UI Object of parent processType
       * @param {object} eventTypes result array of eventTypes
       */
      updateDataForEventTypes: function (processType, eventTypes) {
        var standardSubModel = processType._source.standard;
        if (standardSubModel && standardSubModel.eventTypes) {
          standardSubModel.eventTypes.forEach(function (sourceStandardEventType) {
            var standardEventType = this.formatEventType(
              sourceStandardEventType,
              processType,
              ModelCategory.Standard
            );
            // generate where used
            this.whereUsedListHelper.addEntityDependency(standardEventType);

            eventTypes.push(standardEventType);
          }, this);
        }

        var customSubModel = processType._source.user;
        if (customSubModel && customSubModel.eventTypes) {
          customSubModel.eventTypes.forEach(function (sourceEventType) {
            var eventType = eventTypes.find(function (item) {
              return item.name === sourceEventType.name;
            });
            if (eventType) {
              eventType._source.user = sourceEventType;
            } else {
              eventType = this.formatEventType(sourceEventType, processType, ModelCategory.User);
              // generate where used
              if (eventType._ref.context.name !== "CoreModel") {
                this.whereUsedListHelper.addEntityDependency(eventType);
              }

              eventTypes.push(eventType);
            }
          }, this);
        }
      },

      formatEventType: function (sourceEventType, processType, category) {
        var eventType = {
          name: sourceEventType.name,
          _ref: {
            // set context with name "CoreModel" for coreModel eventTypes
            context: processType || { name: "CoreModel" },
          },
          parent: sourceEventType.parent,
          descr: sourceEventType.descr,
          translation: sourceEventType.translation,
          // add private UI tag
          _parent: null,
          _objectType: ObjectType.EventType,
          _category: category,
          _source: {},
        };

        this.formatItemSource(eventType, sourceEventType);

        return eventType;
      },

      // ========================================================
      // Update Data for Elements
      // of Planned Event Extension, Process Type, Item Type and Event Type
      // ========================================================
      updateDataForEntityElements: function (entities, model) {
        if (this._checkArrayNotUndefinedOrEmpty(entities)) {
          entities.forEach(function (entity) {
            this.updateDataForElements(entity, model);
          }, this);
        }
      },

      updateDataForElements: function (entity, model) {
        var elements = [];

        var bEntityIsProcessType = entity._objectType === ObjectType.ProcessType;

        var sourceElements = [];

        // merge elements from _source.standard and _source.user for later format
        var sourceEntity = entity._source;
        if (sourceEntity.user) {
          var sourceCustomEntity = bEntityIsProcessType
            ? sourceEntity.user.processTypes[0]
            : sourceEntity.user;
          sourceElements = sourceElements.concat(sourceCustomEntity.elements);
        }
        if (sourceEntity.standard) {
          var sourceStandardEntity = bEntityIsProcessType
            ? sourceEntity.standard.processTypes[0]
            : sourceEntity.standard;
          sourceElements = sourceElements.concat(sourceStandardEntity.elements);
        }

        if (this._checkArrayNotUndefinedOrEmpty(sourceElements)) {
          sourceElements.forEach(function (sourceElement) {
            var element = this.formatElement(sourceElement, entity, model);

            // generate element where used - target used by element (Association, Composition, CodeList)
            // exclude asso-to-many dependency for now
            if (element._ref && !element._source) {
              this.whereUsedListHelper.addElementDependency(element);
            }

            elements.push(element);
          }, this);
        }

        entity.elements = elements;
      },

      formatElement: function (sourceElement, entity, model) {
        var processTypes = model.getProperty(PROCESS_TYPES_PATH);
        var itemTypes = model.getProperty(ITEM_TYPES_PATH);
        var codeLists = model.getProperty("/codeLists");

        var element = {
          name: sourceElement.name,
          label: sourceElement.label,
          type: sourceElement.type,
          readable: sourceElement.readable,
          writable: sourceElement.writable,
          translation: sourceElement.translation,
        };

        // distinguish element category according to its name and entity category
        if (entity._category === ModelCategory.Standard) {
          element._category = element.name.toLowerCase().startsWith("zz")
            ? ModelCategory.User
            : ModelCategory.Standard;
        } else {
          element._category = ModelCategory.User;
        }

        // distinguish plannedEvent _parent and _objectType from UserField
        if (entity._objectType) {
          element._parent = entity;
          element._objectType = ObjectType.UserField;
        } else {
          element._parent = null;
          element._objectType = ObjectType.PlannedEventExtension;
        }

        // Only not-null in ProcessType
        if (sourceElement.dpp) {
          element.dpp = sourceElement.dpp;
        }
        if (sourceElement.authScopes) {
          element.authScopes = sourceElement.authScopes;
        }

        // Only not-null in ItemType
        if (sourceElement.key) {
          element.key = sourceElement.key;
        }

        // handle additional information according to type of User Field
        switch (element.type) {
          case FieldType.String:
            element.length = sourceElement.length;
            break;
          case FieldType.Decimal:
            element.precision = sourceElement.precision;
            element.scale = sourceElement.scale;
            break;
          case FieldType.Association:
            var targetProcessType = this.getTargetItem(sourceElement.target, processTypes);
            element._ref = {
              target: targetProcessType,
            };
            element.cardinality = sourceElement.cardinality;
            // reserve source backlink value for later reference set-up
            if (sourceElement.cardinality.max === "*") {
              element._source = sourceElement;
            }
            break;
          case FieldType.Composition:
            var targetItemType = this.getTargetItem(sourceElement.target, itemTypes);
            element._ref = {
              target: targetItemType,
            };
            element.cardinality = sourceElement.cardinality;
            break;
          case FieldType.CodeList:
            var targetCodeList = this.getTargetItem(sourceElement.target, codeLists);
            element._ref = {
              target: targetCodeList,
            };
            break;
          default:
            break;
        }

        return element;
      },

      // Update data for Association-to-Many elements after all other elements are processed
      // because to-Many elements will reference to-One elements
      updateDataForProcessTypeAssociationToManyElements: function (processTypes) {
        function _isTargetProcessTypeElementsAvailable(element) {
          return element._ref && element._ref.target && element._ref.target.elements;
        }

        processTypes.forEach(function (processType) {
          var elements = processType.elements;
          if (elements) {
            elements.forEach(function (element) {
              if (
                element._source &&
                element._source.backlink &&
                _isTargetProcessTypeElementsAvailable(element)
              ) {
                element._ref.backlink = element._ref.target.elements.find(function (targetElement) {
                  return targetElement.name === element._source.backlink;
                });
                // add _ref.backlink dependency
                this.whereUsedListHelper.addElementDependency(element);
              }
              delete element._source;
            }, this);
          }
        }, this);
      },

      // ========================================================
      // Update Data for Admissible Planned & Unplanned Events
      // of Process Type
      // ========================================================
      updateDataForAdmissibleEvents: function (processTypes, model) {
        processTypes.forEach(function (processType) {
          var plannedEvents = [];
          var unplannedEvents = [];

          var sourceProcessType = processType._source;

          if (sourceProcessType.standard) {
            var sourceStandardProcessType = sourceProcessType.standard.processTypes[0];
            this.updateDataForAdmissiblePlannedEvents(
              sourceStandardProcessType.admissiblePlannedEvents,
              processType,
              model,
              ModelCategory.Standard,
              plannedEvents
            );
            this.updateDataForAdmissibleUnplannedEvents(
              sourceStandardProcessType.admissibleUnplannedEvents,
              processType,
              model,
              ModelCategory.Standard,
              unplannedEvents
            );
          }

          if (sourceProcessType.user) {
            var customStandardProcessType = sourceProcessType.user.processTypes[0];
            this.updateDataForAdmissiblePlannedEvents(
              customStandardProcessType.admissiblePlannedEvents,
              processType,
              model,
              ModelCategory.User,
              plannedEvents
            );
            this.updateDataForAdmissibleUnplannedEvents(
              customStandardProcessType.admissibleUnplannedEvents,
              processType,
              model,
              ModelCategory.User,
              unplannedEvents
            );
          }

          processType.admissiblePlannedEvents = plannedEvents;
          processType.admissibleUnplannedEvents = unplannedEvents;
        }, this);
      },

      // ====> Planned Events
      updateDataForAdmissiblePlannedEvents: function (
        sourcePlannedEvents,
        processType,
        model,
        category,
        plannedEvents
      ) {
        var eventTypes = model.getProperty(EVENT_TYPES_PATH);

        if (!this._checkArrayNotUndefinedOrEmpty(sourcePlannedEvents)) {
          return;
        }

        sourcePlannedEvents.forEach(function (sourcePlannedEvent) {
          var refEventType = this.getTargetItem(sourcePlannedEvent.eventType.target, eventTypes);

          // check if planned event is standard but edited
          var plannedEvent = plannedEvents.find(function (item) {
            return (
              category === ModelCategory.User &&
              item._category === ModelCategory.Standard &&
              item._ref &&
              item._ref.eventType === refEventType
            );
          });

          if (plannedEvent) {
            plannedEvent._edited = true; // store the result to property: _edited
          } else {
            plannedEvent = {
              _objectType: ObjectType.AdmissiblePlannedEvent,
              _parent: processType,
              _ref: {
                eventType: refEventType,
              },
              _category: category,
            };

            // generate where used list for admissible planned event
            this.whereUsedListHelper.addAdmissibleEventDependency(plannedEvent);
            plannedEvents.push(plannedEvent);
          }

          // always overwrite settings according to order of reading data: standard ==> custom
          this.updateDataForPlannedEventSettings(plannedEvent, sourcePlannedEvent, model);
        }, this);
      },

      updateDataForPlannedEventSettings: function (plannedEvent, sourcePlannedEvent, model) {
        var plannedEventExtensions = model.getProperty("/plannedEvent/elements");

        // update detail info
        [
          "businessToleranceUnit",
          "businessToleranceValue",
          "matchLocation",
          "maxOverdueDetection",
          "periodicOverdueDetection",
          "periodicOverdueDetectionUnit",
          "technicalToleranceUnit",
          "technicalToleranceValue",
        ].forEach(function (key) {
          plannedEvent[key] = sourcePlannedEvent[key];
        });

        // update data for plannedEvent.matchExtensionFields
        var sourceMatchExtensionFields = sourcePlannedEvent.matchExtensionFields;
        this.updateDataForMatchExtensionFields(
          plannedEvent,
          sourceMatchExtensionFields,
          plannedEvent._ref.eventType.elements,
          plannedEventExtensions
        );
        // format string for display
        plannedEvent.matchExtensionFieldsText = this.formatter.formatExtensionMatchKey(
          plannedEvent.matchExtensionFields
        );

        // update data for plannedEvent.matchPlanFieldsForUpdatePlan
        var sourceMatchPlanFieldsForUpdatePlan = sourcePlannedEvent.matchPlanFieldsForUpdatePlan;
        this.updateDataForMatchPlanFieldsForUpdatePlan(
          plannedEvent,
          sourceMatchPlanFieldsForUpdatePlan,
          plannedEventExtensions
        );
      },

      updateDataForMatchExtensionFields: function (
        plannedEvent,
        sourceMatchExtensionFields,
        refEventElements,
        plannedEventExtensions
      ) {
        // format matchExtensionFields
        var matchExtensionFields = [];

        if (this._checkArrayNotUndefinedOrEmpty(sourceMatchExtensionFields)) {
          sourceMatchExtensionFields.forEach(function (sourceField) {
            var field = {
              operator: sourceField.operator,
              _parent: plannedEvent,
              _ref: {
                plannedEventField: this.getTargetElement(
                  sourceField.plannedEventField,
                  plannedEventExtensions
                ),
                actualEventField: this.getTargetElement(
                  sourceField.actualEventField,
                  refEventElements
                ),
              },
            };

            // generate where used list for match extension fields
            this.whereUsedListHelper.addMatchExtensionFieldDependency(field);

            matchExtensionFields.push(field);
          }, this);
        }

        plannedEvent.matchExtensionFields = matchExtensionFields;
      },

      /**
       * If sourceMatchPlanFieldsForUpdatePlan is undefined,
       * it should be initialized as all planned/actual match are selected in planned/planned match
       *
       * @param {object} plannedEvent UI object of editing Planned Event
       * @param {object} sourceMatchPlanFieldsForUpdatePlan undefined or array of source data for matchPlanFieldsForUpdatePlan
       * @param {array} plannedEventExtensions array of UI object data Planned Event Extension elements
       */
      updateDataForMatchPlanFieldsForUpdatePlan: function (
        plannedEvent,
        sourceMatchPlanFieldsForUpdatePlan,
        plannedEventExtensions
      ) {
        var matchPlanFieldsForUpdatePlan = [];

        if (!sourceMatchPlanFieldsForUpdatePlan) {
          // special initialize
          matchPlanFieldsForUpdatePlan = this.updateDataForNewIncomingMatchPlanFieldsForUpdatePlan(
            plannedEvent
          );
        } else if (sourceMatchPlanFieldsForUpdatePlan.length !== 0) {
          // skip empty array
          matchPlanFieldsForUpdatePlan = this.updateDataForExistingMatchPlanFieldsForUpdatePlan(
            plannedEvent,
            sourceMatchPlanFieldsForUpdatePlan,
            plannedEventExtensions
          );
        }

        plannedEvent.matchPlanFieldsForUpdatePlan = matchPlanFieldsForUpdatePlan;
      },

      updateDataForNewIncomingMatchPlanFieldsForUpdatePlan: function (plannedEvent) {
        // init with pre-defined eventMatchKey
        var result = [
          {
            name: "eventMatchKey",
            _parent: plannedEvent,
          },
        ];

        // default enable locationAltKey when matchLocation is true
        var matchLocation = plannedEvent.matchLocation;
        if (matchLocation) {
          result.push({
            name: "locationAltKey",
            _parent: plannedEvent,
          });
        }

        // default enable all _ref/plannedEventField from Actual/Planned match
        var matchExtensionFields = plannedEvent.matchExtensionFields || [];
        matchExtensionFields.forEach(function (matchExtensionField) {
          if (matchExtensionField._ref && matchExtensionField._ref.plannedEventField) {
            var refPlannedEventField = matchExtensionField._ref.plannedEventField;

            // avoid pushing duplicate plannedEventField
            if (
              result.findIndex(function (existingItem) {
                return existingItem._ref === refPlannedEventField;
              }) === -1
            ) {
              var field = {
                _ref: refPlannedEventField,
                _parent: plannedEvent,
              };
              result.push(field);

              // generate where used list for match extension fields
              this.whereUsedListHelper.addMatchPlanFieldDependency(field);
            }
          }
        }, this);

        return result;
      },

      updateDataForExistingMatchPlanFieldsForUpdatePlan: function (
        plannedEvent,
        sourceMatchPlanFieldsForUpdatePlan,
        plannedEventExtensions
      ) {
        var result = [];

        sourceMatchPlanFieldsForUpdatePlan.forEach(function (sourceField) {
          var field = {};

          if (sourceField === "locationAltKey" || sourceField === "eventMatchKey") {
            field = {
              name: sourceField,
            };
          } else {
            field = {
              _ref: this.getTargetElement(sourceField, plannedEventExtensions),
            };
          }
          // add parent reference
          field._parent = plannedEvent;

          // generate where used list for match extension fields
          this.whereUsedListHelper.addMatchPlanFieldDependency(field);

          result.push(field);
        }, this);

        return result;
      },

      // ====> Unplanned Events
      updateDataForAdmissibleUnplannedEvents: function (
        sourceUnplannedEvents,
        processType,
        model,
        category,
        unplannedEvents
      ) {
        var eventTypes = model.getProperty(EVENT_TYPES_PATH);

        if (!this._checkArrayNotUndefinedOrEmpty(sourceUnplannedEvents)) {
          return;
        }

        sourceUnplannedEvents.forEach(function (sourceUnplannedEvent) {
          var refEventType = this.getTargetItem(sourceUnplannedEvent.eventType.target, eventTypes);
          var unplannedEvent = {
            _objectType: ObjectType.AdmissibleUnplannedEvent,
            _parent: processType,
            _ref: {
              eventType: refEventType,
            },
            _category: category,
          };

          // generate where used list for unplanned event
          this.whereUsedListHelper.addAdmissibleEventDependency(unplannedEvent);

          unplannedEvents.push(unplannedEvent);
        }, this);
      },

      // ========================================================
      // Update Data for IDoc Mapping
      // of Process Type, Event Type
      // ========================================================
      updateDataForIDocMapping: function (entities) {
        if (!this._checkArrayNotUndefinedOrEmpty(entities)) {
          return;
        }

        entities.forEach(function (entity) {
          var idocMapping = {};
          var fieldMapping = [];

          // all properties (EXCEPT fieldMapping) will load Standard data first
          this.updateDataForStandardIDocMapping(entity, idocMapping, fieldMapping);
          this.updateDataForCustomIDocMapping(entity, idocMapping, fieldMapping);

          // set new generated idocMapping to entity
          if (this._checkJsonNotEmpty(idocMapping)) {
            idocMapping.fieldMapping = fieldMapping;
            entity.idocMapping = idocMapping;
          }
        }, this);
      },

      updateDataForStandardIDocMapping: function (entity, idocMapping, fieldMapping) {
        var sourceEntity = entity._source;
        if (!sourceEntity || !sourceEntity.standard) {
          return;
        }

        var bEntityIsProcessType = entity._objectType === ObjectType.ProcessType;

        var sourceStandardEntity = bEntityIsProcessType
          ? sourceEntity.standard.processTypes[0]
          : sourceEntity.standard;
        var sourceStandardIDocMapping = sourceStandardEntity.idocMapping;

        if (sourceStandardIDocMapping) {
          this.updateDataForIDocEventMapping(entity, sourceStandardIDocMapping, idocMapping);
          this.updateDataForIDocFieldMapping(
            entity,
            ModelCategory.Standard,
            sourceStandardIDocMapping.fieldMapping,
            fieldMapping
          );
        }
      },

      updateDataForCustomIDocMapping: function (entity, idocMapping, fieldMapping) {
        var sourceEntity = entity._source;
        if (!sourceEntity || !sourceEntity.user) {
          return;
        }

        var bEntityIsProcessType = entity._objectType === ObjectType.ProcessType;

        var sourceUserEntity = bEntityIsProcessType
          ? sourceEntity.user.processTypes[0]
          : sourceEntity.user;
        var sourceUserIDocMapping = sourceUserEntity.idocMapping;

        if (sourceUserIDocMapping && entity._category !== ModelCategory.Standard) {
          this.updateDataForIDocEventMapping(entity, sourceUserIDocMapping, idocMapping);
        }

        // extension idocMapping of standard model could be undefined but should be initialized
        // because the standard entity already owns fieldMapping
        if (sourceUserIDocMapping || entity._category === ModelCategory.Standard) {
          var sourceFieldMapping = sourceUserIDocMapping ? sourceUserIDocMapping.fieldMapping : [];
          this.updateDataForIDocFieldMapping(
            entity,
            ModelCategory.User,
            sourceFieldMapping,
            fieldMapping
          );
        }
      },

      updateDataForIDocEventMapping: function (entity, sourceIDocMapping, idocMapping) {
        // share property: idoc
        idocMapping.idoc = sourceIDocMapping.idoc;

        if (entity._objectType === ObjectType.ProcessType) {
          idocMapping.erpObjectType = sourceIDocMapping.erpObjectType;
          idocMapping.applicationObjectType = sourceIDocMapping.applicationObjectType;
          idocMapping._ref = {
            eventType: entity,
          };
        }

        if (entity._objectType === ObjectType.EventType) {
          idocMapping.erpEventCode = sourceIDocMapping.erpEventCode;
        }
      },

      updateDataForIDocFieldMapping: function (entity, category, sourceFieldMapping, fieldMapping) {
        // entity elements have been updated, use these for convenient reference
        var elements = entity.elements || [];
        var filteredElements = elements.filter(function (element) {
          return element._category === category;
        });

        filteredElements.forEach(function (element) {
          var sourceMappedItem = this.getTargetMappingField(element.name, sourceFieldMapping);

          // filter Standard fields & asso-to-many fields
          if (!FieldType.isItemAssociationToMany(element)) {
            // no matter the element is mapped or not, push a new mappingItem into fieldMapping array
            // init mappingItem with _ref to element
            var mappingItem = {
              _ref: {
                field: element,
              },
            };

            // generate where used list for mappingItem
            this.whereUsedListHelper.addMappingItemDependency(mappingItem);

            if (element.type === "composition") {
              this.updateDataForCompositionElementInIDocFieldMapping(
                element,
                sourceMappedItem,
                mappingItem
              );
            } else if (sourceMappedItem) {
              mappingItem.idocSegment = sourceMappedItem.idocSegment;
              mappingItem.idocField = sourceMappedItem.idocField;
            }

            fieldMapping.push(mappingItem);
          }
        }, this);
      },

      updateDataForCompositionElementInIDocFieldMapping: function (
        element,
        sourceMappedItem,
        mappingItem
      ) {
        // result
        var composition = [];

        var targetItemType = element._ref.target;
        mappingItem._ref.target = targetItemType;

        targetItemType.elements.forEach(function (targetElement) {
          // init mappingItem with _ref to targetElement
          var compositionItem = {
            _ref: {
              field: targetElement,
            },
          };

          if (sourceMappedItem && sourceMappedItem.composition) {
            var sourceMappedCompositionItem = this.getTargetMappingField(
              targetElement.name,
              sourceMappedItem.composition
            );

            if (sourceMappedCompositionItem) {
              compositionItem.idocSegment = sourceMappedCompositionItem.idocSegment;
              compositionItem.idocField = sourceMappedCompositionItem.idocField;
            }
          }

          // generate where used list for composition item
          this.whereUsedListHelper.addMappingItemDependency(compositionItem);

          composition.push(compositionItem);
        }, this);

        mappingItem.composition = composition;
      },

      // ========================================================
      // Update Data for VP Mapping
      // of Process Type, Event Type
      // ========================================================
      updateDataForVPMapping: function (entities, model) {
        if (!this._checkArrayNotUndefinedOrEmpty(entities)) {
          return;
        }

        entities.forEach(function (entity) {
          var vpMapping = {};
          var fieldMapping = [];

          this.updateDataForStandardVPMapping(entity, model, vpMapping, fieldMapping);
          this.updateDataForCustomVPMapping(entity, model, vpMapping, fieldMapping);

          if (this._checkJsonNotEmpty(vpMapping)) {
            vpMapping.fieldMapping = fieldMapping;
            entity.vpMapping = vpMapping;
          }
        }, this);
      },

      updateDataForStandardVPMapping: function (entity, model, vpMapping, fieldMapping) {
        var sourceEntity = entity._source;
        if (!sourceEntity || !sourceEntity.standard) {
          return;
        }

        var bEntityIsProcessType = entity._objectType === ObjectType.ProcessType;
        var processTypes = model.getProperty(PROCESS_TYPES_PATH);
        var vpPresets = this.getVPPresets(model);
        var targetVPPresets = vpPresets[entity._objectType];

        var sourceStandardEntity = bEntityIsProcessType
          ? sourceEntity.standard.processTypes[0]
          : sourceEntity.standard;
        var sourceStandardVPMapping = sourceStandardEntity.vpMapping;

        if (sourceStandardVPMapping) {
          this.updateDataForVPEventMapping(
            entity,
            processTypes,
            sourceStandardVPMapping,
            vpMapping
          );
          this.updateDataForVPFieldMapping(
            entity,
            ModelCategory.Standard,
            targetVPPresets,
            sourceStandardVPMapping.fieldMapping,
            fieldMapping
          );
        }
      },

      updateDataForCustomVPMapping: function (entity, model, vpMapping, fieldMapping) {
        var sourceEntity = entity._source;
        if (!sourceEntity || !sourceEntity.user) {
          return;
        }

        var bEntityIsProcessType = entity._objectType === ObjectType.ProcessType;
        var processTypes = model.getProperty(PROCESS_TYPES_PATH);
        var vpPresets = this.getVPPresets(model);
        var targetVPPresets = vpPresets[entity._objectType];

        var sourceUserEntity = bEntityIsProcessType
          ? sourceEntity.user.processTypes[0]
          : sourceEntity.user;
        var sourceUserVPMapping = sourceUserEntity.vpMapping;

        if (sourceUserVPMapping && entity._category !== ModelCategory.Standard) {
          this.updateDataForVPEventMapping(entity, processTypes, sourceUserVPMapping, vpMapping);
        }

        if (sourceUserVPMapping || entity._category === ModelCategory.Standard) {
          var sourceFieldMapping = sourceUserVPMapping ? sourceUserVPMapping.fieldMapping : [];
          this.updateDataForVPFieldMapping(
            entity,
            ModelCategory.User,
            targetVPPresets,
            sourceFieldMapping,
            fieldMapping
          );
        }
      },

      updateDataForVPEventMapping: function (entity, processTypes, sourceVPMapping, vpMapping) {
        if (entity._objectType === ObjectType.ProcessType) {
          vpMapping._ref = {
            eventType: entity,
          };
          vpMapping.trackingIndicator = sourceVPMapping.trackingIndicator;

          // set _ref.upstreamProcessType when indicator=02 and the upstreamProcessType name is not empty
          if (sourceVPMapping.trackingIndicator === "02" && !!sourceVPMapping.upstreamProcessType) {
            vpMapping._ref.upstreamProcessType = processTypes.find(function (processType) {
              return processType.name === sourceVPMapping.upstreamProcessType;
            });

            // generate where used list for upstream processType
            this.whereUsedListHelper.addUpstreamProcessTypeAssociation(vpMapping);
          }
        }

        if (entity._objectType === ObjectType.EventType) {
          vpMapping.lbnEventType = sourceVPMapping.lbnEventType;
        }
      },

      updateDataForVPFieldMapping: function (
        entity,
        category,
        vpPresets,
        sourceFieldMapping,
        fieldMapping
      ) {
        // no extension fields for Custom field mapping of Standard ProcessType
        if (
          entity._objectType === ObjectType.ProcessType &&
          !(category === ModelCategory.User && entity._category === ModelCategory.Standard)
        ) {
          this.updateDataForVPFieldMappingForProcessType(
            vpPresets,
            category,
            entity,
            sourceFieldMapping,
            fieldMapping
          );
        }

        if (entity._objectType === ObjectType.EventType) {
          this.updateDataForVPFieldMappingForEventType(
            vpPresets,
            category,
            entity,
            sourceFieldMapping,
            fieldMapping
          );
        }
      },

      updateDataForVPFieldMappingForProcessType: function (
        vpProcessTypePresets,
        category,
        entity,
        sourceFieldMapping,
        fieldMapping
      ) {
        var elements = entity.elements || [];
        var filteredElements = elements.filter(function (element) {
          return element._category === category;
        });

        if (!this._checkArrayNotUndefinedOrEmpty(vpProcessTypePresets)) {
          return;
        }

        vpProcessTypePresets.forEach(function (presetField) {
          // processType mappingItem is based on preset
          var mappingItem = {
            trackingField: presetField.name,
            label: presetField.label,
            required: presetField.required,
            _ref: {},
          };

          var sourceMappedItem = sourceFieldMapping.find(function (sourceMappingItem) {
            return sourceMappingItem.trackingField === presetField.name;
          });

          // set reference of field to target element first
          if (sourceMappedItem) {
            mappingItem._ref.field = this.getTargetElement(
              sourceMappedItem.field,
              filteredElements
            );
          }

          // generate where used list for processType vpMapping - association
          if (mappingItem._ref && mappingItem._ref.field) {
            this.whereUsedListHelper.addMappingItemAssociation(mappingItem);
          }

          // indicate if the mapping will have composition
          if (presetField.fields) {
            this.updateDataForVPFieldMappingForProcessTypeCompositionElement(
              presetField,
              sourceMappedItem,
              mappingItem
            );
          }

          fieldMapping.push(mappingItem);
        }, this);
      },

      updateDataForVPFieldMappingForProcessTypeCompositionElement: function (
        presetField,
        sourceMappedItem,
        mappingItem
      ) {
        // result
        var composition = [];

        if (sourceMappedItem) {
          mappingItem._ref.target = mappingItem._ref.field._ref.target;
        }

        var presetElements = presetField.fields || [];

        presetElements.forEach(function (presetElement) {
          // new item
          var compositionItem = {
            trackingField: presetElement.name,
            label: presetElement.label,
            required: presetElement.required,
            _ref: {},
          };

          if (sourceMappedItem && sourceMappedItem.composition) {
            var sourceMappedCompositionItem = sourceMappedItem.composition.find(function (
              mappingCompositionItem
            ) {
              return mappingCompositionItem.trackingField === presetElement.name;
            });

            if (sourceMappedCompositionItem) {
              compositionItem._ref.field = this.getTargetElement(
                sourceMappedCompositionItem.field,
                mappingItem._ref.target.elements
              );
            }
          }

          // generate where used list for vp mapping composition item
          if (compositionItem._ref && compositionItem._ref.field) {
            this.whereUsedListHelper.addMappingItemAssociation(compositionItem);
          }

          composition.push(compositionItem);
        }, this);

        mappingItem.composition = composition;
      },

      updateDataForVPFieldMappingForEventType: function (
        vpEventTypePresets,
        category,
        entity,
        sourceFieldMapping,
        fieldMapping
      ) {
        var vpFlatEventTypePresets = this.getEventTypePresetsAsFlatArray(vpEventTypePresets);

        var elements = entity.elements || [];
        var filteredElements = elements.filter(function (element) {
          return element._category === category;
        });
        filteredElements.forEach(function (element) {
          // result item, init with _ref to element
          var mappingItem = {
            _ref: {
              field: element,
            },
          };

          var sourceMappedItem = this.getTargetMappingField(element.name, sourceFieldMapping);

          if (sourceMappedItem) {
            var sourceTrackingField = sourceMappedItem.trackingField;
            mappingItem.trackingField = sourceTrackingField;

            // set label for UI display
            var sourceMappedItemLabel = this.getEventTypePresetLabel(
              sourceTrackingField,
              vpFlatEventTypePresets
            );
            if (sourceMappedItemLabel) {
              mappingItem.label = sourceMappedItemLabel.label;
            }
          }

          // generate where used list for eventType vpMapping - dependency
          this.whereUsedListHelper.addMappingItemDependency(mappingItem);

          if (element.type === "composition") {
            this.updateDataForVPFieldMappingForEventTypeCompositionElement(
              element,
              sourceMappedItem,
              mappingItem,
              vpFlatEventTypePresets
            );
          }

          fieldMapping.push(mappingItem);
        }, this);
      },

      updateDataForVPFieldMappingForEventTypeCompositionElement: function (
        element,
        sourceMappedItem,
        mappingItem,
        vpFlatEventTypePresets
      ) {
        // result
        var composition = [];

        var targetItemType = element._ref.target;
        mappingItem._ref.target = targetItemType;

        var targetElements = targetItemType.elements || [];
        targetElements.forEach(function (targetElement) {
          // result compositionItem
          var compositionItem = {
            _ref: {
              field: targetElement,
            },
          };

          if (sourceMappedItem && sourceMappedItem.composition) {
            var sourceMappedCompositionItem = this.getTargetMappingField(
              targetElement.name,
              sourceMappedItem.composition
            );

            if (sourceMappedCompositionItem) {
              var sourceTrackingField = sourceMappedCompositionItem.trackingField;
              compositionItem.trackingField = sourceTrackingField;

              // set label for UI display
              var sourceMappedCompositionItemLabel = this.getEventTypePresetLabel(
                sourceTrackingField,
                vpFlatEventTypePresets
              );
              if (sourceMappedCompositionItemLabel) {
                compositionItem.label = sourceMappedCompositionItemLabel.label;
              }
            }
          }

          // generate where used list for vp mapping composition item
          if (compositionItem._ref && compositionItem._ref.field) {
            this.whereUsedListHelper.addMappingItemDependency(compositionItem);
          }

          composition.push(compositionItem);
        }, this);

        mappingItem.composition = composition;
      },

      getTargetItem: function (target, entities) {
        return (
          entities.find(function (entity) {
            return entity.name === target.split(".")[1];
          }) || {}
        );
      },

      getTargetElement: function (targetName, elements) {
        return (
          elements.find(function (element) {
            return element.name === targetName;
          }) || {}
        );
      },

      getTargetMappingField: function (targetName, fieldMapping) {
        return (
          fieldMapping.find(function (mappingItemData) {
            return targetName === mappingItemData.field;
          }) || {}
        );
      },

      getEventTypePresetLabel: function (targetName, vpFlatEventTypePresets) {
        return (
          vpFlatEventTypePresets.find(function (preset) {
            return preset.name === targetName;
          }) || {}
        );
      },

      getEventTypePresetsAsFlatArray: function (vpEventTypePresets) {
        var result = [];

        vpEventTypePresets.forEach(function (item) {
          if (item.fields) {
            // Only concat name - label mapping without 'fields'
            result = result.concat({
              name: item.name,
              label: item.label,
            });
            result = result.concat(item.fields);
          } else {
            result = result.concat(item);
          }
        });

        return result;
      },

      getVPPresets: function (model) {
        var vpProcessTypePresets = model.getProperty("/vpPresets/processType/fields") || [];
        var vpEventTypePresets = model.getProperty("/vpPresets/eventType/fields") || [];

        return {
          ProcessType: vpProcessTypePresets,
          EventType: vpEventTypePresets,
        };
      },
    };

    return ModelDataProcessor;
  }
);
