sap.ui.define(
  [
    "./BaseDialog",
    "sap/base/util/deepClone",
    "sap/ui/core/ValueState",
    "sap/ui/core/Fragment",
    "sap/m/BadgeCustomData",
    "../util/ValidationHelper",
  ],
  function (BaseDialog, deepClone, ValueState, Fragment, BadgeCustomData, ValidationHelper) {
    "use strict";

    var DATA_MATCH_EXTENSION_FIELDS_PATH = "/data/matchExtensionFields";
    var DATA_MATCH_PLAN_FIELDS_FOR_UPDATE_PLAN_PATH = "/data/matchPlanFieldsForUpdatePlan";
    var DATA_REF_EVENT_PATH = "/data/_ref/eventType";

    return BaseDialog.extend("com.sap.gtt.v2.model.manage.controller.EditPlannedEventDialog", {
      //======================================
      // Validate Dialog Controls
      //======================================
      getValidationControls: function () {
        var aControls = this.getMandatoryControls();
        var sDetailFragmentId = Fragment.createId(this.fragmentId, "detailFragment");
        aControls.push(Fragment.byId(sDetailFragmentId, "businessTolerance"));
        aControls.push(Fragment.byId(sDetailFragmentId, "technicalTolerance"));
        aControls = aControls.concat(this.getActualEventControls());
        return aControls;
      },

      getMandatoryControls: function () {
        var aControls = [];
        var sDetailFragmentId = Fragment.createId(this.fragmentId, "detailFragment");
        var oNameSelect = Fragment.byId(sDetailFragmentId, "name");
        var oInputPeriodicOverdueDetection = Fragment.byId(
          sDetailFragmentId,
          "periodicOverdueDetection"
        );
        var oInputMaxOverdueDetection = Fragment.byId(sDetailFragmentId, "maxOverdueDetection");
        aControls.push(oNameSelect);
        aControls.push(oInputPeriodicOverdueDetection);
        aControls.push(oInputMaxOverdueDetection);
        return aControls;
      },

      getActualEventControls: function () {
        var controls = [];
        var actualMatchList = Fragment.byId(this.getActualEventFragmentId(), "actualMatchList");
        var items = actualMatchList.getItems();
        items.forEach(function (item) {
          var oAeControl = item.getContent()[2];
          controls.push(oAeControl);
        });
        return controls;
      },

      validate: function () {
        var aCheckValueStateControls = this.getValidationControls();
        var aMandatoryControls = this.getMandatoryControls();
        var aErrors = [].concat(
          ValidationHelper.validateMandatory(aMandatoryControls),
          ValidationHelper.checkValueState(aCheckValueStateControls)
        );

        this.updateTabBadge(aCheckValueStateControls, aMandatoryControls);

        return aErrors.length === 0;
      },

      updateTabBadge: function (aCheckValueStateControls, aMandatoryControls) {
        // add BadgeCustomData to Icon Filter Tab header whose content is invalid
        var bDetailTabError = false;
        var bActualPlanTabError = false;
        aCheckValueStateControls.forEach(function (oControl) {
          if (oControl.getValueState() === ValueState.Error) {
            if (aMandatoryControls.includes(oControl)) {
              bDetailTabError = true;
            } else {
              bActualPlanTabError = true;
            }
          }
        });
        this.byId("iconTabBar").getItems()[0].addCustomData(new BadgeCustomData({visible: bDetailTabError}));
        this.byId("iconTabBar").getItems()[1].addCustomData(new BadgeCustomData({visible: bActualPlanTabError}));
      },

      //======================================
      // Admissible Planned Event Details
      // Change listener
      //======================================
      onChangeEventType: function (oEvent) {
        var oSelect = oEvent.getSource();
        var oModel = oSelect.getModel(this.modelName);
        var selectedItem = oSelect.getSelectedItem();
        var context = selectedItem.getBindingContext(this.modelName);
        var eventType = context.getObject();
        oModel.setProperty(DATA_REF_EVENT_PATH, eventType);

        // reset matchExtensionFields
        oModel.setProperty(DATA_MATCH_EXTENSION_FIELDS_PATH, [
          this.getEmptyActualPlannedMatch(eventType),
        ]);

        // reset matchPlanFieldsForUpdatePlan
        oModel.setProperty(DATA_MATCH_PLAN_FIELDS_FOR_UPDATE_PLAN_PATH, [
          {
            name: "eventMatchKey",
            selected: true,
          },
        ]);
      },

      onToleranceChange: function (oEvent) {
        var oInput = oEvent.getSource();
        var iValue = oInput.getBinding("value").getValue();
        // reg allows empty string or positive integers
        var integerReg = /^\d*$/;
        if (!integerReg.test(iValue)) {
          oInput.setValueState(ValueState.Error);
          oInput.setValueStateText(
            oInput.getModel("i18n").getResourceBundle().getText("numberGreaterThanZero")
          );
        } else {
          oInput.setValueState(ValueState.None);
          oInput.setValueStateText("");
        }
      },

      //======================================
      // Actual Event Match
      // CRUD Operations
      // Change Listener
      //======================================

      /**
       * Get template empty match field in Actual/Planned Event Match
       * @param {object} oEventType selected Event Type in Details Tab
       * @returns {object} JSON data of template field
       * */
      getEmptyActualPlannedMatch: function (oEventType) {
        return {
          _ref: {
            plannedEventField: null,
            actualEventField: null,
          },
          operator: "EQ",
          info: {
            showAddButton: true,
            actualFields: this.getMatchExtensionFieldActualFields(oEventType, null),
          },
        };
      },

      /**
       * Get dropdown options of Actual Event Field Select for every match field in Actual/Planned Event Match
       * @param {object} oEventType selected Event Type in Details Tab
       * @param {string} sPlannedEventFieldType type of Planned Event Field in current match field
       * @returns {object} array of name - selectable
       * */
      getMatchExtensionFieldActualFields: function (oEventType, sPlannedEventFieldType) {
        if (!oEventType || !oEventType.elements || oEventType.elements.length === 0) {
          return [];
        }

        var aElements = oEventType.elements;
        return aElements.map(function (element) {
          return {
            name: element.name,
            selectable: sPlannedEventFieldType ? sPlannedEventFieldType === element.type : false,
          };
        });
      },

      onAddItem: function (oEvent) {
        var oTable = Fragment.byId(this.getActualEventFragmentId(), "actualMatchList");
        var oBinding = oTable.getBinding("items");
        var oModel = oBinding.getModel(this.modelName);
        var items = oModel.getProperty(oBinding.getPath());

        if (!items) {
          items = [];
        }

        // Hide add button in last line
        items[items.length - 1].info.showAddButton = false;

        items.push(this.getEmptyActualPlannedMatch(oModel.getProperty(DATA_REF_EVENT_PATH)));

        this.refreshActualMatchListBinding();
      },

      onRemoveItem: function (oEvent) {
        var oSource = oEvent.getSource();
        var oContext = oSource.getBindingContext(this.modelName);
        var oPlannedEventField = oContext.getProperty("_ref/plannedEventField");
        var oMatchField = oContext.getObject();
        var oDialogModel = oSource.getModel(this.modelName);

        var aMatchExtensionFields = oDialogModel.getProperty(DATA_MATCH_EXTENSION_FIELDS_PATH);
        var iIndex = aMatchExtensionFields.findIndex(function (field) {
          return field === oMatchField;
        });
        aMatchExtensionFields.splice(iIndex, 1);

        var iLength = aMatchExtensionFields.length;
        if (iLength === 0) {
          aMatchExtensionFields[0] = this.getEmptyActualPlannedMatch(
            oContext.getProperty(DATA_REF_EVENT_PATH)
          );
        } else {
          aMatchExtensionFields[iLength - 1].info.showAddButton = true;
        }

        // update match plan fields
        this.updateMatchPlanFieldsForUpdatePlanInDialog(oDialogModel, oPlannedEventField, null);

        // refresh actual event match list
        this.refreshActualMatchListBinding();
      },

      onSwitchChange: function (oEvent) {
        var oControl = oEvent.getSource();
        var oContext = oControl.getBindingContext(this.modelName);
        var aMatchPlanFieldsForUpdatePlan = oContext.getProperty(
          DATA_MATCH_PLAN_FIELDS_FOR_UPDATE_PLAN_PATH
        );
        // push/remove locationALtKey from planned/planned match
        // keep the index as 2
        if (oControl.getState()) {
          aMatchPlanFieldsForUpdatePlan.splice(1, 0, {
            name: "locationAltKey",
            selected: true,
          });
        } else {
          aMatchPlanFieldsForUpdatePlan.splice(1, 1);
        }
      },

      onPEFieldChange: function (oEvent) {
        var oPlannedEventSelect = oEvent.getSource();
        var oDialogModel = oPlannedEventSelect.getModel(this.modelName);

        // update _ref/plannedEventField reference object
        var sMatchFieldPath = oPlannedEventSelect.getBindingContext(this.modelName).getPath();
        var sPlannedEventPath = sMatchFieldPath.concat("/_ref/plannedEventField");

        var oOriginItem = oDialogModel.getProperty(sPlannedEventPath);
        var oSelectedPlannedEvent = oPlannedEventSelect
          .getSelectedItem()
          .getBindingContext(this.modelName)
          .getObject();
        oDialogModel.setProperty(sPlannedEventPath, oSelectedPlannedEvent);

        // remove old selected item if this is the last actual/planned match of the old item
        // add new selected item if no planned/planned match has been added
        this.updateMatchPlanFieldsForUpdatePlanInDialog(oDialogModel, oOriginItem, oSelectedPlannedEvent);

        // reset info/actualFields according to type change
        if (!oOriginItem || oOriginItem.type !== oSelectedPlannedEvent.type) {
          var sType = oSelectedPlannedEvent.type;
          var aElements = oDialogModel.getProperty("/data/_ref/eventType/elements") || [];
          var aActualFields = aElements.map(function (element) {
            return {
              name: element.name,
              selectable: sType === element.type,
            };
          });

          var sActualFieldsPath = sMatchFieldPath.concat("/info/actualFields");
          oDialogModel.setProperty(sActualFieldsPath, aActualFields);
        }

        // set actual field reference to null
        var sActualEventPath = sMatchFieldPath.concat("/_ref/actualEventField");
        oDialogModel.setProperty(sActualEventPath, null);
      },

      updateMatchPlanFieldsForUpdatePlanInDialog: function (model, originItem, newItem) {
        var matchPlanFieldsForUpdatePlan = model.getProperty(
          DATA_MATCH_PLAN_FIELDS_FOR_UPDATE_PLAN_PATH
        );
        // actual/planned match is updated by the new selected item
        var matchExtensionFields = model.getProperty(DATA_MATCH_EXTENSION_FIELDS_PATH);

        // remove originItem when it is not related to any actual/planned match
        if (
          originItem &&
          matchExtensionFields.findIndex(function (item) {
            return item._ref.plannedEventField === originItem;
          }) === -1
        ) {
          var indexOfOriginItemInMatchPlanFieldsForUpdatePlan = matchPlanFieldsForUpdatePlan.findIndex(
            function (item) {
              return item._ref === originItem;
            }
          );
          matchPlanFieldsForUpdatePlan.splice(indexOfOriginItemInMatchPlanFieldsForUpdatePlan, 1);
        }

        // add newItem when it is never added to the planned/planned list
        if (
          newItem &&
          matchPlanFieldsForUpdatePlan.findIndex(function (item) {
            return item._ref === newItem;
          }) === -1
        ) {
          matchPlanFieldsForUpdatePlan.push({
            _ref: newItem,
            selected: true,
          });
        }
      },

      onAEChange: function (oEvent) {
        var oActualEventSelect = oEvent.getSource();
        var oDialogModel = oActualEventSelect.getModel(this.modelName);
        var oContext = oActualEventSelect.getBindingContext(this.modelName);

        // update _ref/actualEventField object reference
        var oSelectedContext = oActualEventSelect
          .getSelectedItem()
          .getBindingContext(this.modelName);
        var sSelectedName = oSelectedContext.getProperty("name");
        var aElements = oDialogModel.getProperty("/data/_ref/eventType/elements");
        var oSelectedActualEvent = aElements.find(function (element) {
          return element.name === sSelectedName;
        });
        var sActualEventPath = oActualEventSelect
          .getBindingContext(this.modelName)
          .getPath()
          .concat("/_ref/actualEventField");
        oDialogModel.setProperty(sActualEventPath, oSelectedActualEvent);

        // check validation error: duplicate Actual/Planned match
        var oMatchField = oContext.getObject();
        var aMatchExtensionFields = oContext.getProperty(DATA_MATCH_EXTENSION_FIELDS_PATH);
        if (this.checkIfMatchFieldDuplicate(aMatchExtensionFields, oMatchField)) {
          ValidationHelper.setControlValidationError(
            oActualEventSelect,
            this.getResourceBundle().getText("matchDuplicated")
          );
        } else {
          ValidationHelper.resetControlValidation(oActualEventSelect);
        }
      },

      checkIfMatchFieldDuplicate: function (aMatchExtensionFields, oMatchField) {
        return (
          aMatchExtensionFields.findIndex(function (field) {
            return (
              field !== oMatchField &&
              field._ref &&
              field._ref.actualEventField === oMatchField._ref.actualEventField &&
              field._ref.plannedEventField === oMatchField._ref.plannedEventField
            );
          }) !== -1
        );
      },

      refreshActualMatchListBinding: function () {
        var oActualMatchList = Fragment.byId(this.getActualEventFragmentId(), "actualMatchList");
        var oBinding = oActualMatchList.getBinding("items");

        var oModel = oBinding.getModel();
        var data = oModel.getProperty(oBinding.getPath(), oBinding.getContext());
        oModel.setProperty(oBinding.getPath(), data, oBinding.getContext());

        oBinding.refresh(true);
      },

      getActualEventFragmentId: function () {
        return Fragment.createId(this.fragmentId, "actualEventMatchFragment");
      },
    });
  }
);
