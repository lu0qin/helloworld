sap.ui.define(
  [
    "./BaseDetailController",
    "sap/ui/model/json/JSONModel",
    "sap/m/GroupHeaderListItem",
    "sap/base/util/merge",
    "../constant/InheritEvent",
    "../constant/ModelCategory",
  ],
  function (
    BaseDetailController,
    JSONModel,
    GroupHeaderListItem,
    merge,
    InheritEvent,
    ModelCategory
  ) {
    "use strict";

    var SELECTED_COUNT_PATH = "/selectedCount";
    var IS_STANDARD_MODEL_PATH = "/isStandardModel";

    return BaseDetailController.extend("com.sap.gtt.v2.model.manage.controller.BaseEntityList", {
      initModel: function () {
        var oListViewInfo = new JSONModel({
          busy: false,
          count: 0,
          listTitle: this.getResourceBundle().getText("listTitle"),
          isStandardModel: true,
          selectedCount: 0,
        });
        this.setModel(oListViewInfo, "listViewInfo");
      },

      mergeViewFunctionsIntoCreateAndEditDialog: function (oDialogController) {
        return merge({}, oDialogController, {
          onDialogAccepted: function (type, data, context, info) {
            this.onDialogAccepted(type, data, context);
          }.bind(this),
          getResourceBundle: function () {
            return this.getResourceBundle();
          }.bind(this),
          getView: function () {
            return this.getView();
          }.bind(this),

          whereUsedListHelper: this.whereUsedListHelper,
        });
      },

      subscribeEvents: function () {
        var eventBus = this.getEventBus();
        eventBus.subscribe("modelDetail", "refreshListBinding", this.refreshBinding, this);
      },

      unsubscribeEvents: function () {
        var eventBus = this.getEventBus();
        eventBus.unsubscribe("modelDetail", "refreshListBinding", this.refreshBinding, this);
      },

      getItemsBinding: function () {
        var list = this.byId("list");
        return list.getBinding("items");
      },

      getGroupHeader: function (oGroup) {
        var sId = this.createId(oGroup.key);

        return new GroupHeaderListItem({
          id: sId,
          title: oGroup.key,
        });
      },

      scrollToNewCreatedItem: function (sName) {
        var list = this.byId("list");
        var listItem = this.getListItemByKey(sName);
        var itemIndex = list.indexOfItem(listItem);

        // avoid scrolling to bottom, reset to 0
        if (itemIndex === -1) {
          itemIndex = 0;
        }

        list.scrollToIndex(itemIndex);
      },

      onUpdateFinished: function (oEvent) {
        var oList = oEvent.getSource();
        this.updateListSelection();

        var sTitle;
        var iTotalItems = oList.getBinding("items").getLength();
        if (oList.getBinding("items").isLengthFinal()) {
          sTitle = this.getResourceBundle().getText("titleCount", [iTotalItems]);
        } else {
          sTitle = this.getResourceBundle().getText("titleCount");
        }
        this.getModel("listViewInfo").setProperty("/listTitle", sTitle);
      },

      updateListSelection: function (sName) {
        var oList = this.byId("list");
        // Check create button in user fields
        var hasItem = oList.getSelectedItem() !== null;
        this.setSideContentEditable(hasItem);

        var isFireEvent = true;
        var selectedItem = null;

        if (sName) {
          selectedItem = this.getListItemByKey(sName);
        } else {
          if (oList.getSelectedItem()) {
            this.getModel("listViewInfo").setProperty(SELECTED_COUNT_PATH, 1);
            this.onItemSelected(oList.getSelectedItem());
            return;
          }

          selectedItem = this.getFirstListItem();
        }

        if (selectedItem) {
          oList.setSelectedItem(selectedItem, true, isFireEvent);
        } else {
          this.getModel("listViewInfo").setProperty(SELECTED_COUNT_PATH, 0);
        }
      },

      setSideContentEditable: function (isEditable) {},

      getFirstListItem: function () {
        var oList = this.byId("list");
        var firstItem = null;
        var items = oList.getItems();
        if (items) {
          firstItem = items.find(function (item) {
            return !item.isGroupHeader();
          });
        }
        return firstItem;
      },

      getListItemByKey: function (key) {
        var oList = this.byId("list");
        var items = oList.getItems();

        return items.find(function (oItem) {
          var context = oItem.getBindingContext("store");
          return context.getProperty("name") === key;
        }, this);
      },

      onSelectionChange: function (oEvent) {
        // reset toolbar button state
        var oList = oEvent.getSource();
        var aSelectedItems = oList.getSelectedItems();
        this.getModel("listViewInfo").setProperty(SELECTED_COUNT_PATH, aSelectedItems.length);
        if (aSelectedItems.length !== 0) {
          var sItemCategory = aSelectedItems[0].getBindingContext("store").getProperty("_category");
          this.getModel("listViewInfo").setProperty(
            IS_STANDARD_MODEL_PATH,
            sItemCategory === ModelCategory.Standard
          );
        }

        // trigger item selection listener
        var oListItem = oEvent.getParameter("listItem");
        this.onItemSelected(oListItem);
      },

      onItemSelected: function (listItem) {},

      // ========================================================
      // CRUD Operations
      // ========================================================
      getDialogTitle: function (objectType, dialogMode) {
        var sTitleKey = dialogMode.concat(objectType);
        return this.getResourceBundle().getText(sTitleKey);
      },

      /* Create Entity */
      onAddItem: function () {
        // dialog type
        var sDialogType = "create";

        // binding context of current list
        var oContext = this.byId("list").getBindingContext("store");

        // get the initial business data of the item
        var oModelData = this.getCreateDialogData();

        // title of Create Dialog
        var sTitle = this.getDialogTitle(oModelData._objectType, sDialogType);

        // create dialog model
        var oModel = new JSONModel({
          type: sDialogType,
          context: oContext,
          title: sTitle,
          data: oModelData,
          info: {
            isUsed: false,
            inherits: Object.values(InheritEvent),
          },
        });

        var options = {
          fragmentId: this._createAndEditDialogFragmentId,
          fragmentName: this._createAndEditDialogFragmentName,
          controller: this.oDialogController,
          model: oModel,
        };
        this.openDialog(options);
      },

      getCreateDialogData: function () {
        return {};
      },

      /* Edit Entity */
      onEditItem: function () {
        // dialog type
        var sDialogType = "edit";

        // item to be edit
        var oListItem = this.byId("list").getSelectedItem();
        var oContext = oListItem.getBindingContext("store");
        var oItem = oContext.getObject();

        // check if the item is used
        var bIsUsed = this.whereUsedListDisplayDataHelper.checkIfEntityIsUsed(oItem);

        // get the business data of the item
        var oModelData = this.getEditDialogData(oContext);

        // title of Edit Dialog
        var sTitle = this.getDialogTitle(oModelData._objectType, sDialogType);

        // edit dialog model
        var oModel = new JSONModel({
          type: sDialogType,
          context: oContext,
          title: sTitle,
          data: oModelData,
          info: {
            isUsed: bIsUsed,
            inherits: Object.values(InheritEvent),
          },
        });

        var options = {
          fragmentId: this._createAndEditDialogFragmentId,
          fragmentName: this._createAndEditDialogFragmentName,
          controller: this.oDialogController,
          model: oModel,
        };
        this.openDialog(options);
      },

      getEditDialogData: function (oContext) {
        var oListItemData = oContext.getObject();
        var oDialogModelData = {};
        this.modify(oDialogModelData, oListItemData);
        this.setNestedPropertiesForDialogModel(oDialogModelData, oListItemData);

        return oDialogModelData;
      },

      // set nested properties to avoid reference the table item object
      setNestedPropertiesForDialogModel: function (oDialogModelData, oListItemData) {
        this.setContextRefForDialogModel(oDialogModelData, oListItemData);
        this.setTranslationPropertiesForDialogModel("descr", oDialogModelData, oListItemData);
        this.setParentTargetForDialogModel(oDialogModelData, oListItemData);
      },

      // set _ref/context when edit Item/Event Type
      setContextRefForDialogModel: function (oDialogModelData, oListItemData) {
        if (!oListItemData._ref || !oListItemData._ref.context) {
          return;
        }

        oDialogModelData._ref = {
          context: oListItemData._ref.context,
        };
      },

      // set parent/target when edit Event Type
      setParentTargetForDialogModel: function (oDialogModelData, oListItemData) {
        if (!oListItemData.parent || !oListItemData.parent.target) {
          return;
        }

        oDialogModelData.parent = {
          target: oListItemData.parent.target,
        };
      },

      /* Delete Entity  */
      getItemToDelete: function () {
        var oList = this.byId("list");
        var oSelectedItem = oList.getSelectedItem();
        var oSelectedContext = oSelectedItem.getBindingContext("store");
        return oSelectedContext.getObject();
      },
    });
  }
);
