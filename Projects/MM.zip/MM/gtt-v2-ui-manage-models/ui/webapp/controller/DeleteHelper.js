sap.ui.define(
  ["../constant/FieldType", "../constant/ObjectType", "../constant/UsedType", "../model/formatter", "./WhereUsedListHelper"],
  function (FieldType, ObjectType, UsedType, formatter, WhereUsedListHelper) {
    "use strict";

    var WHERE_USED_LIST_PATH = "/whereUsedList";

    var DeleteHelper = {
      _controllerContext: this,

      init: function (controllerContext) {
        this._controllerContext = controllerContext;
        this._formatter = controllerContext.formatter;

        // set where used list helper
        var whereUsedListHelper = controllerContext.whereUsedListHelper;
        if (!controllerContext.whereUsedListHelper) {
          whereUsedListHelper = new WhereUsedListHelper();
          whereUsedListHelper.init(controllerContext);
        }
        this._whereUsedListHelper = whereUsedListHelper;
      },

      _getStoreModel: function () {
        // set store model
        return this._controllerContext.getView().getModel("store");
      },

      deleteReferenceInWhereUsedList: function (item) {
        var model = this._getStoreModel();
        var whereUsedList = model.getProperty(WHERE_USED_LIST_PATH);

        whereUsedList = whereUsedList.filter(function (listItem) {
          return listItem.object !== item && listItem.usedByObject !== item;
        });

        model.setProperty(WHERE_USED_LIST_PATH, whereUsedList);
      },

      deleteObject: function (object) {
        switch (object._objectType) {
          case ObjectType.UserField:
            this._deleteUserField(object);
            break;
          case ObjectType.ProcessType:
            this._deleteProcessType(object);
            break;
          case ObjectType.ItemType:
            this._deleteItemType(object);
            break;
          case ObjectType.EventType:
            this._deleteEventType(object);
            break;
          case ObjectType.CodeList:
            this._deleteCodeList(object);
            break;
          case ObjectType.AdmissiblePlannedEvent:
            this._deleteAdmissiblePlannedEvent(object);
            break;
          case ObjectType.AdmissibleUnplannedEvent:
            this._deleteAdmissibleUnplannedEvent(object);
            break;
          case ObjectType.PlannedEventExtension:
            this._deletePlannedEventExtensionField(object);
            break;
          default:
            break;
        }
      },

      _deleteUserField: function (userField) {
        this.deleteUserFieldReferenceObjects(userField);

        // remove userField from parent's elements
        var parent = userField._parent;
        if (parent && parent.elements) {
          var elements = parent.elements;
          var index = elements.indexOf(userField);
          if (index !== -1) {
            elements.splice(index, 1);
          }
        }
      },

      deleteUserFieldReferenceObjects: function (userField) {
        if (
          userField.type === FieldType.Composition &&
          userField._parent._objectType !== ObjectType.ItemType
        ) {
          this.deleteCompositionUserField(userField);
        } else {
          this.deleteSimpleUserField(userField);
        }
      },

      deleteSimpleUserField: function (userField) {
        var parent = userField._parent;

        switch (parent._objectType) {
          case ObjectType.ProcessType:
            this._deleteProcessTypeSimpleField(userField);
            break;
          case ObjectType.EventType:
            this._deleteEventTypeSimpleField(userField);
            break;
          case ObjectType.ItemType:
            this.deleteItemTypeSimpleField(userField);
            break;
        }
      },

      deleteCompositionUserField: function (userField) {
        // get idoc/vp mapping item that use this user field - dependency
        var model = this._getStoreModel();
        var whereUsedList = model.getProperty(WHERE_USED_LIST_PATH);
        var entity = userField._parent;

        var usedList = whereUsedList.filter(function (listItem) {
          return listItem.object === userField;
        });

        usedList.forEach(function (usedListItem) {
          var mappingComposition = usedListItem.usedByObject;

          // delete children mapping info in where used list
          mappingComposition.composition.forEach(function (mappingCompositionItem) {
            whereUsedList = whereUsedList.filter(function (listItem) {
              return listItem.usedByObject !== mappingCompositionItem;
            });
          });
          if (usedListItem.usedType === UsedType.Association) {
            // association
            mappingComposition._ref.field = null;
            mappingComposition.composition.forEach(function (compositionItem) {
              compositionItem._ref.field = null;
            });
          }

          // delete itself mapping info in where used list
          whereUsedList = whereUsedList.filter(function (listItem) {
            return listItem !== usedListItem;
          });

          entity.idocMapping.fieldMapping = entity.idocMapping.fieldMapping.filter(function (item) {
            return item !== usedListItem.usedByObject;
          });

          if (entity._objectType === ObjectType.EventType) {
            entity.vpMapping.fieldMapping = entity.vpMapping.fieldMapping.filter(function (item) {
              return item !== usedListItem.usedByObject;
            });
          }

          model.setProperty(WHERE_USED_LIST_PATH, whereUsedList);
        });

        this.deleteReferenceInWhereUsedList(userField);
      },

      _deleteProcessTypeSimpleField: function (userField) {
        // delete user field in element array - handled in onDeleteItem fn by using item.splice()

        // delete asso-to-many user field backlinked to current user field
        this.deleteAssoToManyUserField(userField);

        // delete user field in idoc mapping
        this.deleteSimpleFieldInIDocMapping(userField);

        // delete user field in vp mapping - association - set vp mapping item tracking field as null
        this.deleteFieldInVPMappingAssociation(userField);

        // delete user field in where used list - idoc, vp and element(codelist association composition)
        this.deleteReferenceInWhereUsedList(userField);
      },

      _deleteEventTypeSimpleField: function (userField) {
        this.deleteSimpleFieldInIDocMapping(userField);
        this.deleteSimpleFieldInVPMappingDependency(userField);
        this.deleteReferencedMatchExtensionOrPlannedFields(userField);
        this.deleteReferenceInWhereUsedList(userField);
      },

      deleteAssoToManyUserField: function (userField) {
        var usedByObjects = this._whereUsedListHelper.getUsedByObjectList(
          userField,
          UsedType.Dependency
        );

        usedByObjects.forEach(function (item) {
          if (
            item._objectType === ObjectType.UserField &&
            FieldType.isItemAssociationToMany(item) &&
            item._parent &&
            item._parent.elements
          ) {
            var itemIndex = item._parent.elements.indexOf(item);
            if (itemIndex !== -1) {
              this._whereUsedListHelper.removeAssoToManyDependency(userField, item);
              item._parent.elements.splice(itemIndex, 1);
            }
          }
        }, this);
      },

      // delete user field in processType, eventType in idoc mapping
      deleteSimpleFieldInIDocMapping: function (userField) {
        var that = this;
        var entity = userField._parent;

        if (!entity.idocMapping || !entity.idocMapping.fieldMapping) {
          return;
        }

        // idoc fieldMapping item list
        var usedByObjects = this._whereUsedListHelper.getUsedByObjectList(
          userField,
          UsedType.Dependency
        );

        var fieldMapping = entity.idocMapping.fieldMapping;
        usedByObjects.forEach(function (mappingItem) {
          that.deleteSimpleMappingItem(mappingItem, fieldMapping);
        });
      },

      deleteFieldInVPMappingAssociation: function (userField) {
        var associationList = this._whereUsedListHelper.getAssociationList(
          userField,
          UsedType.Association
        );

        associationList.forEach(function (association) {
          var usedByObjectProperty = association.usedByObjectProperty;
          var mappingItemRef = association.usedByObject._ref;
          mappingItemRef[usedByObjectProperty] = null;
        });
      },

      deleteSimpleFieldInVPMappingDependency: function (userField) {
        var that = this;

        var entity = userField._parent;
        if (!entity.vpMapping || !entity.vpMapping.fieldMapping) {
          return;
        }

        // event type mapping items
        var usedByObjects = this._whereUsedListHelper.getUsedByObjectList(
          userField,
          UsedType.Dependency
        );

        var fieldMapping = entity.vpMapping.fieldMapping;
        usedByObjects.forEach(function (mappingItem) {
          that.deleteSimpleMappingItem(mappingItem, fieldMapping);
        });
      },

      deleteSimpleMappingItem: function (mappingItem, fieldMapping) {
        var mappingItemIndex = fieldMapping.indexOf(mappingItem);
        if (mappingItemIndex !== -1) {
          fieldMapping.splice(mappingItemIndex, 1);
        }
      },

      deleteItemTypeSimpleField: function (userField) {
        // delete in itemType's elements array

        // delete in idoc/vp mapping if its parent is used as a composition
        this.deleteItemTypeFieldInIdocVPMapping(userField);

        // delete in vp association mapping
        this.deleteFieldInVPMappingAssociation(userField);

        // delete item in where used list
        this.deleteReferenceInWhereUsedList(userField);
      },

      deleteItemTypeFieldInIdocVPMapping: function (userField) {
        var itemType = userField._parent;
        // usedByObject: user field of process/event type
        var itemTypeUsedByObjects = this._whereUsedListHelper.getUsedByObjectList(
          itemType,
          UsedType.Dependency
        );
        if (!itemTypeUsedByObjects) {
          return;
        }

        itemTypeUsedByObjects.forEach(function (entityUserField) {
          // get mappingItem of entityUserField
          var entityUserFieldUsedByObjects = this._whereUsedListHelper.getUsedByObjectList(
            entityUserField,
            UsedType.Dependency
          );
          entityUserFieldUsedByObjects.forEach(function (mappingItem) {
            if (mappingItem.composition) {
              var composition = mappingItem.composition;
              var index = composition.findIndex(function (compositionItem) {
                return compositionItem._ref && compositionItem._ref.field === userField;
              });
              if (index !== -1) {
                composition.splice(index, 1);
              }
            }
          }, this);
        }, this);
      },

      removeVPSimpleAssociationInfo: function (vpMappingItem) {
        var model = this._getStoreModel();
        var whereUsedList = model.getProperty(WHERE_USED_LIST_PATH);

        // field used by current vpMappingItem - association
        whereUsedList = whereUsedList.filter(function (listItem) {
          return listItem.usedByObject !== vpMappingItem;
        });

        model.setProperty(WHERE_USED_LIST_PATH, whereUsedList);
      },

      _deletePlannedEventExtensionField: function (extensionField) {
        // Delete reference by AdmissiblePlannedEvent.matchExtensionFields
        this.deleteReferencedMatchExtensionOrPlannedFields(extensionField);

        // Delete PlannedEventExtension element
        var model = this._getStoreModel();
        var plannedEvents = model.getProperty("/plannedEvent/elements");
        this.deleteItemInArray(extensionField, plannedEvents);
      },

      deleteReferencedMatchExtensionOrPlannedFields: function (userField) {
        var usedByObjects = this._whereUsedListHelper.getUsedByObjectList(
          userField,
          UsedType.Dependency
        );
        usedByObjects.forEach(function (field) {
          var admPlannedEvent = field._parent;

          if (admPlannedEvent && field._ref) {
            var matchExtensionFields = admPlannedEvent.matchExtensionFields;
            var matchPlanFieldsForUpdatePlan = admPlannedEvent.matchPlanFieldsForUpdatePlan;

            // check if field is Match Extension Field
            if (
              matchExtensionFields &&
              field._ref.plannedEventField &&
              field._ref.actualEventField
            ) {
              var matchExtensionFieldIndex = matchExtensionFields.indexOf(field);
              if (matchExtensionFieldIndex !== -1) {
                this._whereUsedListHelper.removeMatchExtensionFieldDependency(field);
                matchExtensionFields.splice(matchExtensionFieldIndex, 1);
                admPlannedEvent.matchExtensionFieldsText = this._formatter.formatExtensionMatchKey(
                  matchExtensionFields
                );
              }
            }

            // check if field is Match Plan Field For Update Plan
            if (matchPlanFieldsForUpdatePlan && field._ref.name) {
              var matchPlanFieldIndex = matchPlanFieldsForUpdatePlan.indexOf(field);
              this._whereUsedListHelper.removeMatchPlanFieldDependency(field);
              matchPlanFieldsForUpdatePlan.splice(matchPlanFieldIndex, 1);
            }
          }
        }, this);
      },

      _deleteEventType: function (eventType) {
        // Delete Children - User Fields
        this.deleteChildrenUserFields(eventType);

        // Delete Referenced Admissible Planned/Unplanned Events
        var usedByObjects = this._whereUsedListHelper.getUsedByObjectList(
          eventType,
          UsedType.Dependency
        );
        usedByObjects.forEach(function (object) {
          this.deleteObject(object);
        }, this);

        // Remove Dependency - processType used by event type
        this.deleteReferenceInWhereUsedList(eventType);

        // Delete event type
        var model = this._getStoreModel();
        var eventTypes = model.getProperty("/eventTypes");
        this.deleteItemInArray(eventType, eventTypes);
      },

      _deleteAdmissiblePlannedEvent: function (admPlannedEvent) {
        // Delete match extension fields
        if (admPlannedEvent.matchExtensionFields) {
          admPlannedEvent.matchExtensionFields.forEach(function (matchExtensionField) {
            this._whereUsedListHelper.removeMatchExtensionFieldDependency(matchExtensionField);
          }, this);
        }

        // Remove reference for this admPlanned event
        this.deleteReferenceInWhereUsedList(admPlannedEvent);

        // Delete this planned event in parent process Type
        var processType = admPlannedEvent._parent;
        if (processType) {
          this.deleteItemInArray(admPlannedEvent, processType.admissiblePlannedEvents);
        }
      },

      _deleteAdmissibleUnplannedEvent: function (admUnplannedEvent) {
        // Remove reference for this unplanned event
        this.deleteReferenceInWhereUsedList(admUnplannedEvent);

        // Delete this unplanned event in parent process Type
        var processType = admUnplannedEvent._parent;
        if (processType) {
          this.deleteItemInArray(admUnplannedEvent, processType.admissibleUnplannedEvents);
        }
      },

      _deleteCodeList: function (codeList) {
        // Delete User Field - type is CodeList
        var usedByObjects = this._whereUsedListHelper.getUsedByObjectList(
          codeList,
          UsedType.Dependency
        );
        usedByObjects.forEach(function (object) {
          this.deleteObject(object);
        }, this);

        // Delete Code List
        var model = this._getStoreModel();
        var codeLists = model.getProperty("/codeLists");
        this.deleteItemInArray(codeList, codeLists);
      },

      _deleteItemType: function (itemType) {
        // Delete children User Field
        this.deleteChildrenUserFields(itemType);

        // Delete User Field - type is Composition
        var usedByObjects = this._whereUsedListHelper.getUsedByObjectList(
          itemType,
          UsedType.Dependency
        );
        usedByObjects.forEach(function (object) {
          this.deleteObject(object);
        }, this);

        // Remove Dependency - processType used by item type
        this.deleteReferenceInWhereUsedList(itemType);

        // Delete Item Type
        var model = this._getStoreModel();
        var itemTypes = model.getProperty("/itemTypes");
        this.deleteItemInArray(itemType, itemTypes);
      },

      _deleteProcessType: function (processType) {
        // Delete Children - elements, admissible un/planned events. idoc & vp item will be automatically deleted.
        this.deleteProcessTypeChildrenItems(processType);

        // Delete Dependency - Item Type, Event Type, User Field(association type)
        var usedByObjectList = this._whereUsedListHelper.getUsedByObjectList(
          processType,
          UsedType.Dependency
        );
        if (usedByObjectList && usedByObjectList.length !== 0) {
          usedByObjectList.forEach(function (item) {
            this.deleteObject(item);
          }, this);
        }

        // Remove Association - VPMapping upstreamProcessType
        var upstreamAssociations = this._whereUsedListHelper.getUpstreamProcessTypeAssociations(
          processType
        );
        upstreamAssociations.forEach(function (association) {
          // set reference to null
          var vpMapping = association.usedByObject;
          vpMapping._ref[association.usedByObjectProperty] = null;
          // delete association
          this._whereUsedListHelper.remove(association);
        }, this);

        // Remove References
        this.deleteReferenceInWhereUsedList(processType);

        // Delete Process Type
        var model = this._getStoreModel();
        var processTypes = model.getProperty("/processTypes");
        this.deleteItemInArray(processType, processTypes);
      },

      deleteProcessTypeChildrenItems: function (processType) {
        // Delete Children - Elements
        this.deleteChildrenUserFields(processType);

        // Delete Children - Planned events
        var plannedEvents = processType.admissiblePlannedEvents;
        if (plannedEvents && plannedEvents.length !== 0) {
          plannedEvents.forEach(function (plannedEvent) {
            this._deleteAdmissiblePlannedEvent(plannedEvent);
          }, this);
        }

        // Delete Children - Unplanned events
        var unplannedEvents = processType.admissibleUnplannedEvents;
        if (unplannedEvents && unplannedEvents.length !== 0) {
          unplannedEvents.forEach(function (unplannedEvent) {
            this._deleteAdmissibleUnplannedEvent(unplannedEvent);
          }, this);
        }
      },

      deleteChildrenUserFields: function (entity) {
        if (entity.elements) {
          entity.elements.forEach(function (element) {
            this._deleteUserField(element);
          }, this);
        }
      },

      deleteItemInArray: function (item, array) {
        if (!array) {
          return;
        }

        var index = array.indexOf(item);
        if (index !== -1) {
          array.splice(index, 1);
        }
      },
    };

    return DeleteHelper;
  }
);
