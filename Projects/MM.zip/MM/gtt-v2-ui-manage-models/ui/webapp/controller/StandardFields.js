sap.ui.define(
  ["./BaseController", "sap/ui/model/json/JSONModel"],
  function (BaseController, JSONModel) {
    "use strict";
    return BaseController.extend("com.sap.gtt.v2.model.manage.controller.StandardFields", {
      initModel: function () {
        // Set relevant info for view
        var view = new JSONModel({
          tableTitle: "",
          isShowDppColumn: false,
          isShowKeyColumn: false,
          isShowAuthScopeColumn: false,
        });
        this.setModel(view, "view");
      },

      onUpdateFinished: function (oEvent) {
        var table = oEvent.getSource();
        var binding = table.getBinding("items");
        var sTitle,
          iTotalItems = binding.getLength();
        if (table.getBinding("items").isLengthFinal()) {
          sTitle = this.getResourceBundle().getText("standardModelFieldsTitleCount", [iTotalItems]);
        } else {
          sTitle = this.getResourceBundle().getText("standardModelFieldsTitleCount");
        }
        this.getModel("view").setProperty("/tableTitle", sTitle);
      },
    });
  }
);
