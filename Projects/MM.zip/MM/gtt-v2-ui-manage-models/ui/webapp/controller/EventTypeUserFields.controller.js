sap.ui.define(
  ["./UserFields", "sap/ui/model/json/JSONModel"],
  function (UserFieldsController, JSONModel) {
    "use strict";

    return UserFieldsController.extend(
      "com.sap.gtt.v2.model.manage.controller.EventTypeUserFields",
      {
        initModel: function () {
          // Set relevant info for view
          var view = new JSONModel({
            tableTitle: "",
            isCreateEnabled: true,
            isShowDppColumn: false,
            isShowKeyColumn: false,
            isShowAuthScopeColumn: false,
            selectedCount: 0,
          });
          this.setModel(view, "view");
        },
      }
    );
  }
);
