sap.ui.define(
  [
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "sap/m/GroupHeaderListItem",
    "sap/base/util/merge",
    "../constant/OperationStatus",
    "../constant/ModelCategory",
    "../util/AsyncUtils",
    "../util/RestClient",
    "../util/ServiceUtils",
    "../util/StatusMappingUtil",
    "./ImportDialog",
    "./ExportDialog",
  ],
  function (
    BaseController,
    JSONModel,
    Filter,
    FilterOperator,
    MessageBox,
    MessageToast,
    GroupHeaderListItem,
    merge,
    OperationStatus,
    ModelCategory,
    AsyncUtils,
    RestClient,
    ServiceUtils,
    StatusMappingUtil,
    ImportDialog,
    ExportDialog
  ) {
    "use strict";

    return BaseController.extend("com.sap.gtt.v2.model.manage.controller.ModelList", {
      // TODO: Feature Toggle
      // remove after official release of Standard Model
      shouldGroup: false,

      onBeforeRendering: function () {
        this.updateData();
      },

      onInit: function () {
        this.initModel();
        this.getRouter()
          .getRoute("modelList")
          .attachPatternMatched(
            function (event) {
              this.updateData();
            }.bind(this)
          );
      },

      initModel: function () {
        var model = new JSONModel({
          isDeleteEnabled: false,
          modelList: [],
          modelListTitle: "",
          selected: false,
        });
        this.setModel(model, "view");
      },

      getGroupHeader: function (oGroup) {
        var oResourceBundle = this.getResourceBundle();

        return new GroupHeaderListItem({
          id: oGroup.key,
          title:
            oGroup.key === ModelCategory.Standard
              ? oResourceBundle.getText("standardModels")
              : oResourceBundle.getText("userModels"),
          visible: this.shouldGroup,
          upperCase: false,
        });
      },

      updateData: function () {
        var oView = this.getView();
        oView.setBusy(true);
        var oList = this.byId("gridList");
        oList.removeSelections(true);
        this.onSelectionChange();
        var dataSource = ServiceUtils.getDataSource("mainService");
        var url = ServiceUtils.getUrl(dataSource.uri.concat("/models"));
        var request = RestClient.get(url);
        var promise = AsyncUtils.finally(request, function () {
          oView.setBusy(false);
        });
        promise.then(
          function (data) {
            var res = data.value.map(function (item) {
              if (item.modelCategory === ModelCategory.Standard) {
                this.shouldGroup = true;
              }

              // model info
              return {
                name: item.namespace.split(".").pop(),
                modelCategory: item.modelCategory,
                status: item.status,
                draftStatus: item.draftStatus,
                originalStatus: item.originalStatus,
                lastActionResult: item.lastActionResult,
                lastOperationStatus: StatusMappingUtil.getOperationStatus(
                  item.draftStatus,
                  item.lastActionResult
                ),
                namespace: item.namespace,
                descr: item.descr,
                version: item.version,
              };
            }, this);

            var viewModel = this.getModel("view");
            viewModel.setProperty("/modelList", res);
            viewModel.refresh(true);
          }.bind(this),
          function (error) {
            this.handleServerError(error);
          }.bind(this)
        );
      },

      setDeleteEnabled: function (bValue) {
        this.getModel("view").setProperty("/isDeleteEnabled", bValue);
      },

      onSelectionChange: function () {
        var oList = this.byId("gridList");
        var oSelectedItem = oList.getSelectedItem();

        if (!oSelectedItem) {
          this.setDeleteEnabled(false);
        } else {
          var oSelectedModelContext = oSelectedItem.getBindingContext("view");
          var sLastOperationStatus = oSelectedModelContext.getProperty("lastOperationStatus");
          var sModelCategory = oSelectedModelContext.getProperty("modelCategory");

          var bEnabled =
            sLastOperationStatus !== OperationStatus.DeployPending &&
            sLastOperationStatus !== OperationStatus.DeletePending &&
            sModelCategory !== ModelCategory.Standard;
          this.setDeleteEnabled(bEnabled);
        }

        this.getModel("view").setProperty("/selected", Boolean(oSelectedItem));
      },

      onUpdateFinished: function () {
        // update the worklist's object counter after the table update
        var sTitle;
        var oList = this.byId("gridList");
        var iTotalItems = oList.getBinding("items").getLength();
        if (oList.getBinding("items").isLengthFinal()) {
          sTitle = this.getResourceBundle().getText("overviewListTitleCount", [iTotalItems]);
        } else {
          sTitle = this.getResourceBundle().getText("overviewListTitleCount");
        }
        this.getModel("view").setProperty("/modelListTitle", sTitle);
      },

      onSearch: function (oEvent) {
        var sQuery = oEvent.getSource().getValue();
        if (sQuery && sQuery.length > 0) {
          var filter = new Filter("name", FilterOperator.Contains, sQuery);
        }

        // update list
        var oList = this.byId("gridList");
        var binding = oList.getBinding("items");
        binding.filter(filter);
      },

      onCreatePress: function (oEvent) {
        this.getRouter().navTo("newModel");
      },

      onItemPress: function (oEvent) {
        var oContext = oEvent.getParameter("listItem").getBindingContext("view");
        var sNamespace = oContext.getProperty("namespace");
        this.getRouter().navTo("modelDraft", {
          namespace: sNamespace,
        });
      },

      deleteModel: function (oModel) {
        var oView = this.getView();
        oView.setBusy(true);
        var sNamespace = oModel.namespace;
        var sModelName = oModel.name;
        var dataSource = ServiceUtils.getDataSource("mainService");
        var url = ServiceUtils.getUrl(dataSource.uri).concat("/models/", sNamespace);

        var request = RestClient.delete(url);
        var promise = AsyncUtils.finally(request, function () {
          oView.setBusy(false);
        });
        promise.then(
          function (result) {
            this.updateData();
            MessageToast.show(this.getResourceBundle().getText("modelDeleted", sModelName), {
              duration: 5000,
              closeOnBrowserNavigation: false,
            });
          }.bind(this),
          function (error) {
            this.handleServerError(error);
          }.bind(this)
        );
      },

      onDeleteItem: function () {
        var oList = this.byId("gridList");
        var oContext = oList.getSelectedContexts("view")[0];
        var sModelName = oContext.getProperty("name");
        var oModel = oContext.getObject();
        MessageBox.warning(
          this.getResourceBundle().getText("deleteModelWarningMessage", sModelName),
          {
            actions: [MessageBox.Action.DELETE, MessageBox.Action.CANCEL],
            onClose: function (sAction) {
              if (sAction === MessageBox.Action.DELETE) {
                this.deleteModel(oModel);
              }
            }.bind(this),
          }
        );
      },

      onRefreshPressed: function (oEvent) {
        this.updateData();
      },

      onImportController: ImportDialog,

      onImportPress: function () {
        var oImportDialogModel = new JSONModel();

        var oController = new ImportDialog();
        oController = merge({}, oController, {
          updateListBinding: function () {
            this.updateData();
          }.bind(this),
          getResourceBundle: function () {
            return this.getResourceBundle();
          }.bind(this),
          handleImportError: function (error) {
            return this.handleServerError(error);
          }.bind(this),
        });

        var options = {
          fragmentId: "importDialog",
          fragmentName: "ImportModelDialog",
          controller: oController,
          model: oImportDialogModel,
        };

        this.openDialog(options);
      },

      onExportPress: function () {
        var oList = this.byId("gridList");
        var aSelectedContexts = oList.getSelectedContexts("view");
        var aDataArr = aSelectedContexts.map(function (oContext) {
          var oItemData = oContext.getObject();
          return merge({}, oItemData, {
            draftSelected: !oItemData.status,
          });
        });

        var oExportDialogModel = new JSONModel({
          data: aDataArr,
        });

        var oController = new ExportDialog();

        var options = {
          fragmentId: "exportDialog",
          fragmentName: "ExportModelDialog",
          controller: oController,
          model: oExportDialogModel,
        };

        this.openDialog(options);
      },
    });
  }
);
