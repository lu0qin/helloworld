sap.ui.define(
  ["./StandardFields", "sap/ui/model/json/JSONModel"],
  function (StandardFieldsController, JSONModel) {
    "use strict";
    return StandardFieldsController.extend(
      "com.sap.gtt.v2.model.manage.controller.PlannedEventExtensionStandardFields",
      {
        initModel: function () {
          // Set relevant info for planned event extension view
          var view = new JSONModel({
            tableTitle: "",
            isShowDppColumn: false,
            isShowKeyColumn: false,
            isShowAuthScopeColumn: false,
          });
          this.setModel(view, "view");

          // bind plannedEvent to view
          this.getView().bindElement({
            path: "/plannedEvent",
            model: "store",
          });
        },
      }
    );
  }
);
