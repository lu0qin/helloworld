sap.ui.define(
  [
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/base/strings/formatMessage",
    "sap/base/util/merge",
    "sap/base/util/ObjectPath",
    "../constant/ViewMode",
    "../constant/ObjectType",
    "../constant/LanguageCode",
    "../constant/TextType",
    "../constant/ModelCategory",
    "../util/TranslationHelper",
    "./TranslationDialog",
    "./WhereUsedListHelper",
    "./WhereUsedListDisplayDataHelper",
    "./IntegrationMappingHelper",
    "./DeleteHelper",
    "./WhereUsedDialog",
  ],
  function (
    BaseController,
    JSONModel,
    formatMessage,
    merge,
    ObjectPath,
    ViewMode,
    ObjectType,
    LanguageCode,
    TextType,
    ModelCategory,
    TranslationHelper,
    TranslationDialog,
    WhereUsedListHelper,
    WhereUsedListDisplayDataHelper,
    IntegrationMappingHelper,
    DeleteHelper,
    WhereUsedDialog
  ) {
    "use strict";

    return BaseController.extend("com.sap.gtt.v2.model.manage.controller.BaseDetailController", {
      whereUsedListHelper: WhereUsedListHelper,
      whereUsedListDisplayDataHelper: WhereUsedListDisplayDataHelper,
      integrationMappingHelper: IntegrationMappingHelper,
      deleteHelper: DeleteHelper,

      /**
       * Initialize model & controls
       * */
      initControls: function () {
        this.bindingContext = this.getView().getBindingContext("store");

        this.initHelpers();
        this.initCreateAndEditDialogController();
      },

      initHelpers: function () {
        // must follow the order since the later one will refer to the former one
        this.whereUsedListHelper.init(this);
        this.whereUsedListDisplayDataHelper.init(this);
        this.integrationMappingHelper.init(this);
        this.deleteHelper.init(this);
      },

      changeToEditMode: function () {
        if (this.getModel("store").getProperty("/mode") === ViewMode.Display) {
          this.getEventBus().publish("modelDetail", "requestChangeMode", { mode: ViewMode.Edit });
        }
      },

      refreshBinding: function () {
        this.removeListSelections();

        var oItemsBinding = this.getItemsBinding();
        this.refreshListBinding(oItemsBinding);
      },

      getItemsBinding: function () {},

      removeListSelections: function () {},

      getListItems: function () {
        var oBinding = this.getItemsBinding();
        var oContext = oBinding.getContext();
        var sPath = oBinding.getPath();

        return oContext.getProperty(sPath) || [];
      },

      setListItems: function (items) {
        var oBinding = this.getItemsBinding();
        var oContext = oBinding.getContext();
        var sPath = oBinding.getPath();

        oBinding.getModel().setProperty(sPath, items, oContext);
      },

      // ========================================================
      // CRUD Operations
      // ========================================================
      onAddItem: function () {},

      onEditItem: function () {},

      // Shared by UserFields & BaseEntityList
      // Overwritten by PlannedEvent & UnplannedEvent & CodeListDetail for multi-delete
      onDeleteItem: function () {
        var oSelectedItem = this.getItemToDelete();
        this.handleDeleteItem(oSelectedItem);
      },

      getItemToDelete: function () {},

      handleDeleteItem: function (oDeleteItem) {
        var that = this;
        var deleteItemWhereUsedListData = [];
        var bNoWhereUsedData = true;
        var itemObjectType = null;
        if (Array.isArray(oDeleteItem)) {
          oDeleteItem.forEach(function (item, index) {
            var oDisPlayData = {
              object: null,
              objectType: null,
              categories: [],
            };
            var aWhereUsedDisData = that.whereUsedListDisplayDataHelper.getDisplayData(item);
            // for multiple delete, evenif no where used, it also need to show dialog
            bNoWhereUsedData = false;
            oDisPlayData.object = item.name;
            oDisPlayData.objectType = itemObjectType = that.getDeleteItemObjectType(item);
            oDisPlayData.categories = aWhereUsedDisData;
            deleteItemWhereUsedListData.push(oDisPlayData);
          });
        } else {
          deleteItemWhereUsedListData = this.whereUsedListDisplayDataHelper.getDisplayData(oDeleteItem);
          if (deleteItemWhereUsedListData.length > 0) {
            bNoWhereUsedData = false;
          }
          itemObjectType = this.getDeleteItemObjectType(oDeleteItem);
        }

        if (bNoWhereUsedData) {
          // directly delete the item in common
          // show warning message box when item is Process Type
          this.handleDeleteItemWithNoReference(oDeleteItem);
        } else {
          // show delete dialog
          this.openWhereUsedListDialog(oDeleteItem, deleteItemWhereUsedListData, itemObjectType);
        }
      },

      getDeleteItemObjectType: function (item) {
        var oResourceBundle = this.getResourceBundle();

        switch (item._objectType) {
          case ObjectType.UserField:
            return oResourceBundle.getText("userModelField");
          case ObjectType.PlannedEventExtension:
            return oResourceBundle.getText("plannedEventExtension");
          case ObjectType.ProcessType:
            return oResourceBundle.getText("trackedProcess");
          case ObjectType.ItemType:
            return oResourceBundle.getText("fieldType");
          case ObjectType.EventType:
            return oResourceBundle.getText("eventType");
          case ObjectType.CodeList:
            return oResourceBundle.getText("codeList");
          default:
            return item._objectType;
        }
      },

      // Overwritten in ProcessType
      handleDeleteItemWithNoReference: function (item) {
        this.onItemDeleted(item);
      },

      onItemDeleted: function (item) {
        var that = this;
        if (Array.isArray(item)) {
          item.forEach(function (delItem, index) {
            that.deleteHelper.deleteObject(delItem);
          });
        } else {
          this.deleteHelper.deleteObject(item);
        }

        this.afterItemDeleted();
      },

      afterItemDeleted: function () {
        this.changeToEditMode();
        this.refreshBinding();
        this.getEventBus().publish("modelDetail", "refreshPlannedEventsBinding", {});
      },

      openWhereUsedListDialog: function (item, displayData, itemObjectType) {
        var oView = this.getView();
        var oResourceBundle = this.getResourceBundle();

        var oWhereUsedDialogController = new WhereUsedDialog();
        var sWarningText = null;
        var sWhereUsedListTitle = null;

        oWhereUsedDialogController = merge({}, oWhereUsedDialogController, {
          getView: function () {
            return oView;
          },
          getResourceBundle: function () {
            return oResourceBundle;
          },

          onDialogAccepted: function () {
            this.onItemDeleted(item);
          }.bind(this),

          whereUsedListHelper: this.whereUsedListHelper,
        });

        if (Array.isArray(item)) {
          sWarningText = oResourceBundle.getText("msgDeleteWarningTextForMultiUserFields", [
            itemObjectType,
          ]);
          sWhereUsedListTitle = oResourceBundle.getText("multiDelObjects");
        } else {
          sWarningText = oResourceBundle.getText("msgDeleteWarningText", [
            itemObjectType,
            item.name,
          ]);
          sWhereUsedListTitle = oResourceBundle.getText("whereUsedList");
        }
        var sTitle = oResourceBundle.getText("delete");
        var oModel = new JSONModel({
          title: sTitle,
          warningText: sWarningText,
          whereUsedListTitle:sWhereUsedListTitle,
          state: "Warning",
          data: displayData,
        });

        var options = {
          fragmentId: "whereUsedDialog",
          fragmentName: "WhereUsedDialog",
          controller: oWhereUsedDialogController,
          model: oModel,
        };
        this.openDialog(options);
      },

      // ========================================================
      // Translation
      // ========================================================

      /**
       * Open Translation Dialog in:
       * User Field Table of TP, FT, ET and Codes Table of Code List
       * @param {object} oEvent translate button click listener event
       * */
      onOpenTranslationDialog: function (oEvent) {
        var oEntityContext = oEvent.getSource().getBindingContext("store");
        var sEntityObjectType = oEntityContext.getProperty("_objectType");

        var sMode = oEntityContext.getProperty("/mode");

        var sFragmentName = this.getTranslationDialogFragmentName(sMode, sEntityObjectType);
        var oTranslationDialogController = this.getTranslationDialogController(sEntityObjectType);
        var oTranslationDialogModel = this.getTranslationDialogModel(oEntityContext);

        var options = {
          fragmentId: "translationDialog",
          fragmentName: sFragmentName,
          controller: oTranslationDialogController,
          model: oTranslationDialogModel,
        };

        this.openDialog(options);
      },

      getTranslationDialogFragmentName: function (sMode, sEntityObjectType) {
        var sFragmentName = "TranslationDialog";

        if (sEntityObjectType === ObjectType.CodeList) {
          sFragmentName = "CodeList".concat(sFragmentName);
        }

        if (sMode !== ViewMode.Display) {
          sFragmentName = "Edit".concat(sFragmentName);
        }

        return sFragmentName;
      },

      getTranslationDialogController: function (sEntityObjectType) {
        var oView = this.getView();
        var oResourceBundle = this.getResourceBundle();

        var oTranslationDialogController = new TranslationDialog();
        oTranslationDialogController = merge({}, oTranslationDialogController, {
          textType: sEntityObjectType === ObjectType.CodeList ? TextType.Name : TextType.Label,
          handleModelRefresh: function () {
            this.refreshBinding();
          }.bind(this),
          getView: function () {
            return oView;
          },
          getResourceBundle: function () {
            return oResourceBundle;
          },
        });

        return oTranslationDialogController;
      },

      getTranslationDialogModel: function (oEntityContext) {
        var oResourceBundle = this.getResourceBundle();
        var sMode = oEntityContext.getProperty("/mode");

        var aDefaultSelectedKeys = TranslationHelper.getDefaultLanguageKeys();

        var sTitle = this.getTranslationDialogTitle(oEntityContext);

        var aTranslationDialogItems = this.getTranslationDialogItems(oEntityContext);
        var sTranslationTableTitle = oResourceBundle.getText("titleCount", [
          aTranslationDialogItems.length,
        ]);

        return new JSONModel({
          type: sMode,
          context: oEntityContext,
          data: {
            items: aTranslationDialogItems,
          },
          info: {},
          selectedLanguages: aDefaultSelectedKeys,
          title: sTitle,
          tableTitle: sTranslationTableTitle,
        });
      },

      getTranslationDialogTitle: function (oEntityContext) {
        var oResourceBundle = this.getResourceBundle();

        var sObjectType = oEntityContext.getProperty("_objectType");

        if (!sObjectType) {
          // Planned Event Extension
          return oResourceBundle.getText("translationDialogTitle", [
            oResourceBundle.getText("plannedEventExtension"),
          ]);
        }

        if (sObjectType === ObjectType.ProcessType) {
          return oResourceBundle.getText("translationDialogForTrackedProcessTitle", [
            oEntityContext.getProperty("name"),
          ]);
        }

        if (sObjectType === ObjectType.CodeList) {
          return oResourceBundle.getText("translationDialogTitle", [
            formatMessage("GTTCodeList.{0}", oEntityContext.getProperty("name")),
          ]);
        }

        // Item Type, Event Type
        if (oEntityContext.getProperty("_ref/context")) {
          return oResourceBundle.getText("translationDialogTitle", [
            formatMessage(
              "{0}.{1}",
              oEntityContext.getProperty("_ref/context/name"),
              oEntityContext.getProperty("name")
            ),
          ]);
        }

        return oResourceBundle.getText("translationDialogTitle");
      },

      getTranslationDialogItems: function (oEntityContext) {
        var aEntityTranslationItem = this.getEntityTranslationDialogItems(oEntityContext);
        var aFieldTranslationItems = this.getUserFieldTranslationDialogItems(oEntityContext);

        return [].concat(aEntityTranslationItem, aFieldTranslationItems);
      },

      // overwrite in UserFields.controller.js
      getEntityTranslationDialogItems: function (oEntityContext) {
        return [];
      },

      getUserFieldTranslationDialogItems: function (oEntityContext) {
        var bEntityIsCodeList = oEntityContext.getProperty("_objectType") === ObjectType.CodeList;

        var sTextType = bEntityIsCodeList ? TextType.Name : TextType.Label;
        var sContextPath = bEntityIsCodeList ? "values" : "elements";
        var sFieldPath = bEntityIsCodeList ? "name" : "label";

        // only enable translation for User-Defined fields
        // create new array to avoid overwrite elements node
        var aOriginValues = oEntityContext.getProperty(sContextPath);
        var aValues = aOriginValues.filter(function (value) {
          return value._category !== ModelCategory.Standard;
        });

        aValues.forEach(function (value, index) {
          if (!value.translation) {
            value.translation = {
              info: {
                textType: sTextType,
                translation: {},
              },
            };
          } else {
            if (!value.translation[sFieldPath]) {
              value.translation[sFieldPath] = {
                textType: sTextType,
                translation: {},
              };
            }
            value.translation.info = value.translation[sFieldPath];
          }

          value.translation = merge({}, value.translation, {
            defaultText: value[sFieldPath],
            textType: sTextType,
            fieldPath: sFieldPath,
            contextPath: sContextPath.concat("/", index),
          });
        });

        return aValues;
      },

      /* Generate Translation Properties when CRUD */
      // Called by getEditDialogData
      setTranslationPropertiesForDialogModel: function (
        sPropertyName,
        oDialogItemData,
        oListItemData
      ) {
        if (!oDialogItemData.translation) {
          return;
        }

        var currentLanguageCode = TranslationHelper.getCurrentLanguageCode();
        var isLanguageSupported = TranslationHelper.checkIfLanguageIsSupported(currentLanguageCode);

        // set label to current language translation if supported
        if (currentLanguageCode !== LanguageCode.English && isLanguageSupported) {
          oDialogItemData[sPropertyName] = ObjectPath.get(
            ["translation", sPropertyName, "translation", currentLanguageCode],
            oListItemData
          );
        }
        // show English placeholder
        oDialogItemData.placeholder = oListItemData[sPropertyName];
      },

      /**
       * Called by onDialogAccepted or handleCreateAssociationToOneItem
       * @param {string} sPropertyName value of the property to set
       * @param {object} oItemData item to save from dialog to list
       * @param {object} sOriginalPropertyValue value of the target property from item before change, value will be "" when create item
       * @param {string} sDialogType type of dialog - create, edit, display
       * */
      setTranslationPropertiesForListItem: function (
        sPropertyName,
        oItemData,
        sOriginalPropertyValue,
        sDialogType
      ) {
        var currentLanguageCode = TranslationHelper.getCurrentLanguageCode();
        var isLanguageSupported = TranslationHelper.checkIfLanguageIsSupported(currentLanguageCode);

        if (currentLanguageCode !== LanguageCode.English && isLanguageSupported) {
          // set i18n language to corresponding translation node
          ObjectPath.set(
            ["translation", sPropertyName, "translation", currentLanguageCode],
            oItemData[sPropertyName],
            oItemData
          );

          // set property - label/descr
          // when edit: keep original label
          // when create: set label as ""
          ObjectPath.set(
            sPropertyName,
            sDialogType === ViewMode.Edit ? sOriginalPropertyValue : "",
            oItemData
          );
        }
      },
    });
  }
);
