sap.ui.define(
  [
    "./EditTypeDialog",
    "./EntityValidator",
    "../util/ValidationHelper",
    "../constant/ModelCategory",
    "../constant/ObjectType",
  ],
  function (EditTypeDialog, EntityValidator, ValidationHelper, ModelCategory, ObjectType) {
    "use strict";

    return EditTypeDialog.extend("com.sap.gtt.v2.model.manage.controller.EditProcessTypeDialog", {
      getMandatoryControls: function () {
        return [this.byId("name"), this.byId("trackingIdType")];
      },

      onTrackingIdTypeChange: function (oEvent) {
        var oControl = oEvent.getSource();

        var sTrackingIdType = oControl.getValue();
        var oModel = oControl.getModel("dialog");
        var sType = oModel.getProperty("/type");
        var oContext = oModel.getProperty("/context");
        var sModelCategory = oContext.getProperty("/modelCategory");

        if (
          sType === "edit" &&
          oContext.getProperty("trackingIdType").toLowerCase() === sTrackingIdType.toLowerCase()
        ) {
          return;
        }

        var aErrors = this.validateTrackingIdType(sTrackingIdType, sModelCategory);
        if (aErrors.length > 0) {
          var errorMessage = aErrors[0].message;
          ValidationHelper.setControlValidationError(oControl, errorMessage);
        }
      },

      validateTrackingIdType: function (sTrackingIdType, sModelCategory) {
        var aErrors = [];

        var oResourceBundle = this.getResourceBundle();

        if (sModelCategory === ModelCategory.Standard) {
          aErrors = aErrors.concat(
            EntityValidator.validateNotStartWithZZ(
              sTrackingIdType,
              ObjectType.ProcessType,
              "",
              oResourceBundle
            )
          );
        }

        aErrors = aErrors.concat(
          EntityValidator.validateEmpty(sTrackingIdType, oResourceBundle),
          EntityValidator.validateStringConstraint(sTrackingIdType, true, true, oResourceBundle)
        );

        return aErrors;
      },
    });
  }
);
