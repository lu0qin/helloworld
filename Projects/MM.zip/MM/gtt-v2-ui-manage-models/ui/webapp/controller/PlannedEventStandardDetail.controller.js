sap.ui.define(["./PlannedEventDetail"], function (PlannedEventDetail) {
  "use strict";
  return PlannedEventDetail.extend("com.sap.gtt.v2.model.manage.controller.PlannedEventStandardDetail", {
    onUpdateFinished: function () {
      var oTable = this.byId("table");
      var sTitle;
      var iTotalItems = oTable.getBinding("items").getLength();
      if (oTable.getBinding("items").isLengthFinal()) {
        sTitle = this.getResourceBundle().getText("standardPlannedEventTableTitle", [iTotalItems]);
      } else {
        sTitle = this.getResourceBundle().getText("standardPlannedEventTableTitle");
      }
      this.getModel("view").setProperty("/tableTitle", sTitle);

      this.setSelectedCount();
    },
  });
});
