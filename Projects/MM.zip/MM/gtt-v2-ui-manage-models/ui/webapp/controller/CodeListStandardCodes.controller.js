sap.ui.define(["./BaseController", "sap/ui/model/json/JSONModel"], function (BaseController, JSONModel) {
  "use strict";

  return BaseController.extend("com.sap.gtt.v2.model.manage.controller.CodeListStandardCodes", {
    initModel: function () {
      // Set relevant info for Code List Table view
      var oView = new JSONModel({
        tableTitle: "",
        count: 0,
      });
      this.setModel(oView, "view");
    },

    onUpdateFinished: function (oEvent) {
      var oView = this.getModel("view");
      var count = oEvent.getParameter("total");
      oView.setProperty("/count", count);
      oView.setProperty(
        "/tableTitle",
        this.getResourceBundle().getText("standardCodeListValuesTableTitle", [
          this.getModel("view").getProperty("/count"),
        ])
      );
    },
  });
});
