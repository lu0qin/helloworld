sap.ui.define(
  [
    "./BaseEntityList",
    "sap/ui/model/json/JSONModel",
    "../constant/ObjectType",
    "../constant/ModelCategory",
    "./EditItemTypeDialog",
  ],
  function (BaseEntityList, JSONModel, ObjectType, ModelCategory, EditItemTypeDialog) {
    "use strict";

    return BaseEntityList.extend("com.sap.gtt.v2.model.manage.controller.ItemType", {
      initModel: function () {
        var oListViewInfo = new JSONModel({
          busy: false,
          count: 0,
          listTitle: this.getResourceBundle().getText("listTitle"),
          selectedCount: 0,
        });
        this.setModel(oListViewInfo, "listViewInfo");
      },

      initCreateAndEditDialogController: function () {
        var oDialogController = new EditItemTypeDialog();
        this.oDialogController = this.mergeViewFunctionsIntoCreateAndEditDialog(oDialogController);

        this._createAndEditDialogFragmentId = "editItemTypeDialog";
        this._createAndEditDialogFragmentName = "EditItemTypeDialog";
      },

      getCreateDialogData: function () {
        return {
          _ref: {
            context: null,
          },
          name: "",
          elements: [],
          _parent: null,
          _objectType: ObjectType.ItemType,
          _category: ModelCategory.User,
        };
      },

      onDialogAccepted: function (type, data, context) {
        if (type === "edit") {
          var originData = context.getObject();
          this.whereUsedListHelper.updateEntityDependency(originData, data._ref.context);
          this.modify(originData, data);
          this.refreshBinding();
        } else {
          // Create in model
          var items = context.getProperty("/itemTypes");
          items.push(data);

          // add dependency to where-used list
          this.whereUsedListHelper.addEntityDependency(data);

          this.refreshBinding();
          this.updateListSelection(data.name);
          this.scrollToNewCreatedItem(data.name);
        }
        this.changeToEditMode();
      },

      onItemSelected: function (listItem) {
        var sPath = listItem.getBindingContextPath();

        var oContext = listItem.getBindingContext("store");
        var aElements = oContext.getProperty("elements");

        if (aElements === undefined || aElements === null) {
          this.getModel("store").setProperty(sPath + "/elements", []);
        }

        this.byId("detailView").bindElement({
          path: sPath,
          model: "store",
        });
      },

      setSideContentEditable: function (isEditable) {
        this.byId("detailView")
          .byId("itemTypeUserFieldsView")
          .getModel("view")
          .setProperty("/isCreateEnabled", isEditable);
      },
    });
  }
);
