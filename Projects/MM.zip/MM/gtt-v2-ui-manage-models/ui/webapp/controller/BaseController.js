sap.ui.define(
  [
    "sap/base/Log",
    "sap/base/strings/formatMessage",
    "sap/base/util/isPlainObject",
    "sap/base/util/merge",
    "sap/m/MessageBox",
    "sap/m/MessagePopover",
    "sap/m/MessageItem",
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/ValueState",
    "sap/ui/core/Fragment",
    "sap/ui/core/Element",
    "sap/ui/model/json/JSONModel",
    "../model/formatter",
    "../util/AsyncUtils",
  ],
  function (
    Log,
    formatMessage,
    isPlainObject,
    merge,
    MessageBox,
    MessagePopover,
    MessageItem,
    Controller,
    ValueState,
    Fragment,
    Element,
    JSONModel,
    formatter,
    AsyncUtils
  ) {
    "use strict";

    function delegateComponentMethods(classInfo) {
      var methodNames = ["getRouter", "getEventBus"];

      methodNames.forEach(function (methodName) {
        classInfo[methodName] = function () {
          var component = this.getOwnerComponent();
          return component[methodName].apply(component, arguments);
        };
      });

      return classInfo;
    }

    var controllerClassInfo = {
      formatter: formatter,

      onInit: function () {
        Log.info("onInit", this.getView().getId());
        this.initModel();
        this.subscribeEvents();
        this.initRoute();
        this.initPromises();
        this.initControls();
      },

      onExit: function () {
        this.unsubscribeEvents();
      },

      onBeforeRendering: function () {
        Log.info("onBeforeRendering", this.getView().getId());
      },

      onAfterRendering: function () {
        Log.info("onAfterRendering", this.getView().getId());

        // resolve DOM rendered promise
        var promiseDomRendered = this.getPromise("promiseDomRendered");
        if (promiseDomRendered) {
          promiseDomRendered.resolve(true);
        }
      },

      /**
       * Get startup parameters of component
       *
       * @returns {Object} The startup parameters
       */
      getStartupParameters: function () {
        var startupParameters = {};
        var component = this.getOwnerComponent();
        var componentData = component.getComponentData();

        if (componentData) {
          startupParameters = componentData.startupParameters;
        }

        return startupParameters;
      },

      /**
       * Convenience method for getting the view model by name.
       * @public
       * @param {string} [name] the model name
       * @returns {sap.ui.model.Model} the model instance
       */
      getModel: function (name) {
        return this.getView().getModel(name);
      },

      /**
       * Convenience method for setting the view model.
       * @public
       * @param {sap.ui.model.Model} model the model instance
       * @param {string} name the model name
       * @returns {sap.ui.mvc.View} the view instance
       */
      setModel: function (model, name) {
        return this.getView().setModel(model, name);
      },

      /**
       * General Method for modifying properties without changing reference
       * @param {object} originItem the origin item in the elements
       * @param {object} newItem the new item edited
       */
      modify: function (originItem, newItem) {
        Object.keys(newItem).forEach(function (key) {
          originItem[key] = newItem[key];
        });
      },

      /**
       * Getter for the resource bundle.
       * @public
       * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
       */
      getResourceBundle: function () {
        var component = this.getOwnerComponent();
        return component.getModel("i18n").getResourceBundle();
      },

      /**
       * Get component config
       * @returns {Object} The component config object
       */
      getComponentConfig: function () {
        var component = this.getOwnerComponent();
        return component.getManifestEntry("/sap.ui5/config");
      },

      setBusy: function (busy) {
        var viewModel = this.getModel("view");
        viewModel.setProperty("/busy", busy);
      },

      /**
       * @abstract
       */
      initModel: function () {},

      getViewModel: function () {
        return this.getModel("view");
      },

      /**
       * @abstract
       */
      initRoute: function () {},

      /**
       * @abstract
       */
      subscribeEvents: function () {},

      /**
       * @abstract
       */
      unsubscribeEvents: function () {},

      initPromises: function () {
        // We use jQuery Deferred object to resolve promise object externally
        var promiseDomRendered = AsyncUtils.deferredPromise();
        this.setPromise("promiseDomRendered", promiseDomRendered);
      },

      getPromise: function (name) {
        var promise;

        var model = this.getViewModel();
        if (model) {
          var promises = model.getProperty("/promises");
          if (!promises) {
            promises = {};
            model.setProperty("/promises", promises);
          }

          promise = promises[name];
        }

        return promise;
      },

      setPromise: function (name, promise) {
        var model = this.getViewModel();
        if (model) {
          var promises = model.getProperty("/promises");
          if (!promises) {
            promises = {};
            model.setProperty("/promises", promises);
          }

          promises[name] = promise;
        }
      },

      /**
       * @abstract
       */
      initControls: function () {},

      refreshListBinding: function (oBinding) {
        // make sure to update list in model
        var oModel = oBinding.getModel();
        var data = oModel.getProperty(oBinding.getPath(), oBinding.getContext());
        oModel.setProperty(oBinding.getPath(), data, oBinding.getContext());

        // make sure to refresh in ui
        oBinding.refresh(true);
      },

      validateInput: function (oInput) {
        var oBinding = oInput.getBinding("value");
        var sValueState = ValueState.None;
        var bValidationError = false;

        try {
          oBinding.getType().validateValue(oInput.getValue());
        } catch (oException) {
          sValueState = ValueState.Error;
          bValidationError = true;
        }

        oInput.setValueState(sValueState);

        return bValidationError;
      },

      createFragmentId: function (id) {
        var oView = this.getView();
        return oView.createId(id);
      },

      getI18NText: function (sKey, aArgs, bIgnoreKeyFallback) {
        var resourceBundle = this.getResourceBundle();
        resourceBundle.getText.apply(resourceBundle, arguments);
      },

      openDialog: function (options) {
        var op = options || {};
        var oView = this.getView();
        var oController = merge(op.controller, {
          fragmentId: op.fragmentId,
        });

        if (op.modelName) {
          oController.modelName = op.modelName;
        }

        if (!Fragment.byId(op.fragmentId, "dialog")) {
          Fragment.load({
            id: op.fragmentId,
            name: formatMessage("{0}.{1}.{2}", [
              this.getOwnerComponent().getComponentName(),
              "view.fragments",
              op.fragmentName,
            ]),
            controller: oController,
          }).then(function (oDialog) {
            oView.addDependent(oDialog);
            oDialog.setModel(op.model, oController.modelName);
            oDialog.open();
          });
        } else {
          Fragment.byId(op.fragmentId, "dialog").open();
        }
      },

      createMessagePopover: function () {
        this.oMP = new MessagePopover({
          activeTitlePress: function (oEvent) {},
          items: {
            path: "message>/items",
            template: new MessageItem({
              title: "{message>message}",
              subtitle: "{message>additionalText}",
              activeTitle: "{message>isPositional}",
              type: "{message>type}",
            }),
          },
        });
        this.getView().byId("messagePopoverButton").addDependent(this.oMP);

        this.oMP.getBinding("items").attachChange(
          function (oEvent) {
            this.oMP.navigateBack();
          }.bind(this)
        );
      },

      handleServerError: function (error) {
        var response = error.response;
        var data = response.data;
        this.handleError(data);
      },

      handleClientError: function (data) {
        var error = data.error;
        var items = error.details;
        var oMessagePopover = this.getModel("message");
        oMessagePopover.setProperty("/items", items);
        var oButton = this.getView().byId("messagePopoverButton");
        oButton.setVisible(true);

        setTimeout(
          function () {
            this.oMP.openBy(oButton);
          }.bind(this),
          100
        );
      },

      handleError: function (data) {
        if (!isPlainObject(data)) {
          MessageBox.error(data);
          return;
        }

        if (data.error) {
          var oError = data.error;

          var aMessages = (oError.details || []).map(function (detail) {
            return detail.message;
          });

          MessageBox.error(oError.message, {
            details: aMessages.join("<br>"),
          });
        }
      },
    };

    delegateComponentMethods(controllerClassInfo);

    return Controller.extend(
      "com.sap.gtt.v2.model.manage.controller.BaseController",
      controllerClassInfo
    );
  }
);
