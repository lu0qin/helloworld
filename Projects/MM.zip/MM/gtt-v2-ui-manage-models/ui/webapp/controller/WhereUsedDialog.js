sap.ui.define(["./BaseDialog"], function (BaseDialog) {
  "use strict";
  return BaseDialog.extend("com.sap.gtt.v2.model.manage.controller.WhereUsedDialog", {
    onCollapseAll: function (oEvent) {
      var oTreeTable = this.byId("whereUsedListTree");
      oTreeTable.collapseAll();
    },

    onExpandAll: function (oEvent) {
      var oTreeTable = this.byId("whereUsedListTree");
      oTreeTable.expandToLevel(5);
    },
  });
});
