sap.ui.define(
  [
    "./UserFields",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/ValueState",
    "../util/ValidationHelper",
  ],
  function (UserFieldsController, JSONModel, ValueState, ValidationHelper) {
    "use strict";

    return UserFieldsController.extend("com.sap.gtt.v2.model.manage.controller.ItemTypeUserFields", {
      initModel: function () {
        // Set relevant info for view
        var view = new JSONModel({
          tableTitle: "",
          isCreateEnabled: true,
          isShowDppColumn: false,
          isShowKeyColumn: true,
          isShowAuthScopeColumn: false,
          selectedCount: 0,
        });
        this.setModel(view, "view");
      },

      validateCompositionTarget: function (oControl, oSelectedItemObject) {
        if (oSelectedItemObject) {
          var oCurrentItemType = this.getView().getBindingContext("store").getObject();

          var isRecursive = this.findRecursiveComposition(oSelectedItemObject, oCurrentItemType);

          if (isRecursive) {
            ValidationHelper.setControlValidationError(
              oControl,
              this.getResourceBundle().getText("compositionTargetErrorMessage")
            );
          } else {
            oControl.setValueState(ValueState.None);
            oControl.setValueStateText("");
          }
        }
      },

      /**
       *
       * Check if it will cause endless loop in field types
       * @param {object} oSelectedItemObject object of the selected Item Type
       * @param {object} oCurrentItemObject object of parent Item Type of current adding/editing field
       * @return {boolean} True if exist endless loop in composition references
       */
      findRecursiveComposition: function (oSelectedItemObject, oCurrentItemObject) {
        var isRecursive = false;

        if (oSelectedItemObject && oSelectedItemObject.elements) {
          var compositionElements = oSelectedItemObject.elements.filter(function (element) {
            return element.type === "composition";
          });

          if (compositionElements && compositionElements.length !== 0) {
            var ilength = compositionElements.length;

            for (var i = 0; i < ilength; i++) {
              // immediately jump out the loop when isRecursive is true
              if (isRecursive) {
                break;
              }

              isRecursive = this.checkElementRecursive(compositionElements[i], oCurrentItemObject);
            }
          }
        }

        return isRecursive;
      },

      /**
       *
       * Check if the reference chain from the compositionElement have loop
       * @param {object} compositionElement object of next item type to check
       * @param {object} oCurrentItemObject object of parent Item Type of current adding/editing field
       * @return {boolean} True if exist endless loop in current composition element references
       */
      checkElementRecursive: function (compositionElement, oCurrentItemObject) {
        // if find the duplicate item type with the target one, stop searching, return true
        if (compositionElement._ref && compositionElement._ref.target === oCurrentItemObject) {
          return true;
        } else {
          // iterate over the composition elements along the reference chain
          // set value of isRecursive to the return value from the recursive call
          return this.findRecursiveComposition(compositionElement._ref.target, oCurrentItemObject);
        }
      },
    });
  }
);
