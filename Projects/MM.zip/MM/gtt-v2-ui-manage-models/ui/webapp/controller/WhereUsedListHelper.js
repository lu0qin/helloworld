sap.ui.define(
  [
    "sap/base/strings/formatMessage",
    "sap/base/util/merge",
    "../constant/UsedType",
    "../constant/ObjectType",
    "../constant/FieldType",
  ],
  function (formatMessage, merge, UsedType, ObjectType, FieldType) {
    "use strict";

    function _getElementDependencyObject(element) {
      var elementRef = element._ref;
      return FieldType.isItemAssociationToMany(element) ? elementRef.backlink : elementRef.target;
    }

    var UsedByObjectProperty = {
      Field: "field",
      UpstreamProcessType: "upstreamProcessType",
    };

    var WhereUsedListHelper = {
      _controllerContext: this,

      init: function (controllerContext) {
        this._controllerContext = controllerContext;
      },

      getWhereUsedList: function () {
        var view = this._controllerContext.getView();
        if (!view) {
          return [];
        }

        var model = view.getModel("store");
        if (!model) {
          return [];
        }

        return model.getProperty("/whereUsedList") || [];
      },

      getDependency: function (object, usedByObject) {
        var whereUsedList = this.getWhereUsedList();

        return whereUsedList.find(function (item) {
          return (
            item.object === object &&
            item.usedByObject === usedByObject &&
            item.usedType === UsedType.Dependency
          );
        });
      },

      getAssociation: function (object, usedByObject) {
        var whereUsedList = this.getWhereUsedList();

        return whereUsedList.find(function (item) {
          return (
            item.object === object &&
            item.usedByObject === usedByObject &&
            item.usedType === UsedType.Association
          );
        });
      },

      getAssociationList: function (object) {
        var whereUsedList = this.getWhereUsedList();

        return whereUsedList.filter(function (item) {
          return item.object === object && item.usedType === UsedType.Association;
        });
      },

      add: function (item) {
        var whereUsedList = this.getWhereUsedList();
        // item is not null/undefined or duplicate
        if (item && whereUsedList.indexOf(item) === -1) {
          this.getWhereUsedList().push(item);
        }
      },

      remove: function (item) {
        var whereUsedList = this.getWhereUsedList();
        var index = whereUsedList.indexOf(item);
        if (index !== -1) {
          whereUsedList.splice(index, 1);
        }
      },

      // Dependency - Item/Event Types - context
      addEntityDependency: function (entity) {
        if (!entity._ref) {
          return;
        }

        this.add({
          object: entity._ref.context,
          usedByObject: entity,
          usedType: UsedType.Dependency,
        });
      },

      updateEntityDependency: function (originEntity, newContext) {
        if (!originEntity._ref || originEntity._ref === newContext) {
          return;
        }

        var entityDependency = this.getDependency(originEntity._ref.context, originEntity);
        if (entityDependency) {
          entityDependency.object = newContext;
        }
      },

      removeEntityDependency: function (entity) {
        if (!entity._ref) {
          return;
        }

        var entityDependency = this.getDependency(entity._ref.context, entity);
        if (entityDependency) {
          this.remove(entityDependency);
        }
      },

      // Dependency - User Fields
      addElementDependency: function (element) {
        if (!element._ref) {
          return;
        }

        // When type is AssociationToMany, only add dependency for backlink target
        this.add({
          object: _getElementDependencyObject(element),
          usedByObject: element,
          usedType: UsedType.Dependency,
        });
      },

      removeElementDependency: function (element) {
        if (!element._ref) {
          return;
        }

        var elementAsUsedByObjectDependency = this.getDependency(
          _getElementDependencyObject(element),
          element
        );
        this.remove(elementAsUsedByObjectDependency);
      },

      removeAssoToManyDependency: function (assoToOneField, assoToManyField) {
        var assoToManyDependency = this.getDependency(assoToOneField, assoToManyField);
        this.remove(assoToManyDependency);
      },

      // Dependency - Admissible Un/Planned Events
      addAdmissibleEventDependency: function (event) {
        if (!event._ref) {
          return;
        }

        this.add({
          object: event._ref.eventType,
          usedByObject: event,
          usedType: UsedType.Dependency,
        });
      },

      updateAdmissibleEventDependency: function (originEvent, newTarget) {
        if (
          !originEvent ||
          !originEvent._ref ||
          !newTarget ||
          originEvent._ref.eventType === newTarget
        ) {
          return;
        }

        var originalDependency = this.getDependency(originEvent._ref.eventType, originEvent);
        if (originalDependency) {
          originalDependency.object = newTarget;
        }
      },

      removeAdmissibleEventDependency: function (event) {
        var originalDependency = this.getDependency(event._ref.eventType, event);
        this.remove(originalDependency);
      },

      getUsedByAdmissiblePlannedEventList: function (oEventType) {
        var list = [];

        this.getWhereUsedList().forEach(function (listItem) {
          if (
            listItem.object === oEventType &&
            listItem.usedByObject._objectType === ObjectType.AdmissiblePlannedEvent
          ) {
            list.push(listItem.usedByObject);
          }
        });

        return list;
      },

      // Dependency - Admissible Planned Events - Match Extension Fields
      addMatchExtensionFieldDependency: function (field) {
        if (!field._ref) {
          return;
        }

        var plannedEventItem = {
          object: field._ref.plannedEventField,
          usedByObject: field,
          usedType: UsedType.Dependency,
        };
        this.add(plannedEventItem);

        var actualEventItem = {
          object: field._ref.actualEventField,
          usedByObject: field,
          usedType: UsedType.Dependency,
        };
        this.add(actualEventItem);
      },

      removeMatchExtensionFieldDependency: function (field) {
        if (!field._ref) {
          return;
        }

        var plannedEventDependency = this.getDependency(field._ref.plannedEventField, field);
        this.remove(plannedEventDependency);

        var actualEventDependency = this.getDependency(field._ref.actualEventField, field);
        this.remove(actualEventDependency);
      },

      addMatchPlanFieldDependency: function (item) {
        if (!item._ref) {
          return;
        }

        var plannedEventItem = {
          object: item._ref,
          usedByObject: item,
          usedType: UsedType.Dependency,
        };
        this.add(plannedEventItem);
      },

      removeMatchPlanFieldDependency: function (item) {
        if (!item._ref) {
          return;
        }

        var plannedEventItemDependency = this.getDependency(item._ref, item);
        this.remove(plannedEventItemDependency);
      },

      // Dependency - IDOC Mapping, VP Mapping(Event Type)
      addMappingItemDependency: function (mappingItem) {
        if (!mappingItem) {
          return;
        }

        if (!mappingItem._ref) {
          return;
        }

        this.add({
          object: mappingItem._ref.field,
          usedByObject: mappingItem,
          usedType: UsedType.Dependency,
        });
      },

      // Association - VP Mapping(Process Type)
      addMappingItemAssociation: function (mappingItem) {
        this.add({
          object: mappingItem._ref.field,
          usedByObject: mappingItem,
          usedByObjectProperty: UsedByObjectProperty.Field,
          usedType: UsedType.Association,
        });
      },

      // Association - VP Mapping - Upstream Process Type
      addUpstreamProcessTypeAssociation: function (vpMapping) {
        this.add({
          object: vpMapping._ref.upstreamProcessType,
          usedByObject: vpMapping,
          usedByObjectProperty: UsedByObjectProperty.UpstreamProcessType,
          usedType: UsedType.Association,
        });
      },

      getUpstreamProcessTypeAssociations: function (processType) {
        var whereUsedList = this.getWhereUsedList();

        return whereUsedList.filter(function (item) {
          return (
            item.usedType === UsedType.Association &&
            item.object === processType &&
            item.usedByObjectProperty === UsedByObjectProperty.UpstreamProcessType
          );
        });
      },

      removeUpstreamProcessTypeAssociations: function (processType) {
        var association = this.getAssociation(
          processType.vpMapping._ref.upstreamProcessType,
          processType.vpMapping
        );
        this.remove(association);
      },

      getUsedByObjectList: function (object, usedType) {
        var result = [];

        this.getWhereUsedList().forEach(function (item) {
          if (item.object === object && item.usedType === usedType) {
            result.push(item.usedByObject);
          }
        });

        return result;
      },
    };

    return WhereUsedListHelper;
  }
);
