sap.ui.define(
  [
    "./BaseDetailController",
    "sap/ui/model/json/JSONModel",
    "sap/base/util/merge",
    "../constant/InheritEvent",
    "../constant/ModelCategory",
    "../constant/ViewMode",
    "./EditPlannedEventDialog",
  ],
  function (
    BaseDetailController,
    JSONModel,
    merge,
    InheritEvent,
    ModelCategory,
    ViewMode,
    EditPlannedEventDialog
  ) {
    "use strict";
    return BaseDetailController.extend(
      "com.sap.gtt.v2.model.manage.controller.PlannedEventDetail",
      {
        initModel: function () {
          var view = new JSONModel({
            tableTitle: "",
            selectedCount: 0,
          });
          this.setModel(view, "view");
        },

        initCreateAndEditDialogController: function () {
          var oView = this.getView();
          var oResourceBundle = this.getResourceBundle();

          var oDialogController = new EditPlannedEventDialog();
          this.oDialogController = merge({}, oDialogController, {
            onDialogAccepted: function (type, data, context, info) {
              this.onDialogAccepted(type, data, context, info);
            }.bind(this),
            getView: function () {
              return oView;
            },
            getResourceBundle: function () {
              return oResourceBundle;
            },
          });
        },

        subscribeEvents: function () {
          var eventBus = this.getEventBus();
          eventBus.subscribe(
            "modelDetail",
            "refreshPlannedEventsBinding",
            this.refreshBinding,
            this
          );
        },

        unsubscribeEvents: function () {
          var eventBus = this.getEventBus();
          eventBus.unsubscribe(
            "modelDetail",
            "refreshPlannedEventsBinding",
            this.refreshBinding,
            this
          );
        },

        // Overwrite to update match extension fields string
        refreshBinding: function () {
          this.removeListSelections();

          var oItemsBinding = this.getItemsBinding();
          this.refreshListBinding(oItemsBinding);

          this.updateMatchExtensionFieldsString(oItemsBinding);
        },

        getItemsBinding: function () {
          var table = this.byId("table");
          return table.getBinding("items");
        },

        removeListSelections: function () {
          var table = this.byId("table");
          table.removeSelections();
        },

        onSelectionChange: function (oEvent) {
          this.setSelectedCount();
        },

        setSelectedCount: function () {
          var table = this.byId("table");
          var selectedItems = table.getSelectedItems();
          this.getModel("view").setProperty("/selectedCount", selectedItems.length);
        },

        updateMatchExtensionFieldsString: function (itemsBinding) {
          var contexts = itemsBinding.getContexts();
          if (contexts && contexts.length !== 0) {
            contexts.forEach(function (context) {
              var object = context.getObject();
              object.matchExtensionFieldsText = this.formatter.formatExtensionMatchKey(
                object.matchExtensionFields
              );
            }, this);
          }
        },

        /* Display Planned Event with Detail Tab hidden */
        onDisplayItem: function (oEvent) {
          var oContext = oEvent.getSource().getBindingContext("store");
          this.onOpenPlannedEventDialog(
            ViewMode.Display,
            oContext,
            this.getEditDialogData(oContext)
          );
        },

        /* Edit Planned Event */
        onEditItem: function (oEvent) {
          var oContext = oEvent.getSource().getBindingContext("store");
          this.onOpenPlannedEventDialog(ViewMode.Edit, oContext, this.getEditDialogData(oContext));
        },

        onEditButtonPress: function () {
          var oTable = this.byId("table");
          var oListItem = oTable.getSelectedItem();
          var oContext = oListItem.getBindingContext("store");
          this.onOpenPlannedEventDialog(ViewMode.Edit, oContext, this.getEditDialogData(oContext));
        },

        getEditDialogData: function (oContext) {
          var oModelData = [
            "matchLocation",
            "businessToleranceValue",
            "businessToleranceUnit",
            "technicalToleranceValue",
            "technicalToleranceUnit",
            "periodicOverdueDetection",
            "periodicOverdueDetectionUnit",
            "maxOverdueDetection",
            "_category",
            "_parent",
            "_objectType",
          ].reduce(function (result, key) {
            result[key] = oContext.getProperty(key);
            return result;
          }, {});

          oModelData._ref = {
            eventType: oContext.getProperty("_ref/eventType"),
          };
          oModelData.matchExtensionFields = this.processMatchExtensionFieldsForDialog(
            oContext.getObject()
          );
          oModelData.matchPlanFieldsForUpdatePlan = this.processMatchPlanFieldsForDialog(
            oContext.getObject()
          );

          return oModelData;
        },

        // General function to open Planned Event Dialog
        onOpenPlannedEventDialog: function (sType, oContext, oModelData) {
          if (sType !== ViewMode.Display && oModelData.matchExtensionFields.length === 0) {
            var emptyActualPlannedMatch = this.oDialogController.getEmptyActualPlannedMatch(
              oModelData._ref.eventType
            );
            oModelData.matchExtensionFields = [emptyActualPlannedMatch];
          }

          var sTitle = this.getResourceBundle().getText(sType.concat("PlannedEventType"));

          var aEventTypes = this.filterPlannedEventTypes();
          var aExtensionFields = oContext.getProperty("/plannedEvent/elements");

          if (sType === ViewMode.Edit) {
            var selectedEventType = oContext.getProperty("_ref/eventType");
            selectedEventType.selectable = true;
          }

          var oModel = new JSONModel({
            type: sType,
            context: oContext,
            title: sTitle,
            data: oModelData,
            info: {
              eventTypes: aEventTypes,
            },
            extensionFields: aExtensionFields,
          });

          var options = {
            fragmentId: "editPlannedEventDialog",
            fragmentName: "EditPlannedEventDialog",
            controller: this.oDialogController,
            model: oModel,
          };
          this.openDialog(options);
        },

        // set data for dialog without dependency to source data
        processMatchExtensionFieldsForDialog: function (originData) {
          var result = [];

          var eventType = originData._ref.eventType;
          var originFields = originData.matchExtensionFields;

          // return empty array when no saved matchExtensionFields
          if (!originFields || originFields.length === 0) {
            return result;
          }

          originFields.forEach(function (field, index) {
            var newField = {
              _ref: {
                plannedEventField: field._ref.plannedEventField,
                actualEventField: field._ref.actualEventField,
              },
              operator: field.operator,
              info: {
                // only the last add button should be seen in the match settings table
                showAddButton: index === originFields.length - 1,
                actualFields: this.oDialogController.getMatchExtensionFieldActualFields(
                  eventType,
                  field._ref.plannedEventField.type
                ),
              },
            };

            result.push(newField);
          }, this);

          return result;
        },

        // pre-defined event: eventMatchKey, locationAltKey(depends on matchLocation)
        // user-defined actual/planned match
        processMatchPlanFieldsForDialog: function (originData) {
          var result = [];

          var originMatchExtensionFields = originData.matchExtensionFields;
          var originMatchPlanFieldsForUpdatePlan = originData.matchPlanFieldsForUpdatePlan || [];

          // must show eventMatchKey
          // if selected: depend on if originMatchPlanFieldsForUpdatePlan includes eventMatchKey
          result.push({
            name: "eventMatchKey",
            selected:
              originMatchPlanFieldsForUpdatePlan.findIndex(function (item) {
                return item.name === "eventMatchKey";
              }) !== -1,
          });

          // show locationAltKey when matchLocation is true
          // if selected: depend on if originMatchPlanFieldsForUpdatePlan includes locationAltKey
          if (originData.matchLocation) {
            result.push({
              name: "locationAltKey",
              selected:
                originMatchPlanFieldsForUpdatePlan.findIndex(function (item) {
                  return item.name === "locationAltKey";
                }) !== -1,
            });
          }

          // show unique plannedEvent in actual/planned match
          // if selected: depend on if originMatchPlanFieldsForUpdatePlan includes this plannedEvent
          if (originMatchExtensionFields && originMatchExtensionFields.length !== 0) {
            originMatchExtensionFields.forEach(function (field) {
              if (field._ref && field._ref.plannedEventField) {
                var refPlannedEventField = field._ref.plannedEventField;
                var bIsDuplicate =
                  result.findIndex(function (resultItem) {
                    return resultItem._ref === refPlannedEventField;
                  }) !== -1;

                // keep unique
                if (!bIsDuplicate) {
                  result.push({
                    _ref: refPlannedEventField,
                    selected:
                      originMatchPlanFieldsForUpdatePlan.findIndex(function (event) {
                        return event._ref === field._ref.plannedEventField;
                      }) !== -1,
                  });
                }
              }
            });
          }

          return result;
        },

        filterPlannedEventTypes: function () {
          // get event types without CoreModel events
          var userDefinedEventTypes = this.getUserDefinedEventTypes();
          // filter event types inherit GTTOnTime/DelayedEvent
          userDefinedEventTypes = userDefinedEventTypes.filter(function (eventType) {
            return (
              eventType.parent.target !== InheritEvent.GTTDelayedEvent.key &&
              eventType.parent.target !== InheritEvent.GTTOnTimeEvent.key
            );
          });

          // get event types occupied by other admissible planned events
          var bindingContext = this.byId("table").getBindingContext("store");
          var plannedEvents = bindingContext.getProperty("admissiblePlannedEvents");
          var usedEventTypes = [];
          plannedEvents.forEach(function (oPlannedEventType) {
            usedEventTypes.push(oPlannedEventType._ref.eventType);
          });

          userDefinedEventTypes.forEach(function (eventType) {
            // check if selectable = if the event type is not used by other admissible planned events
            eventType.selectable = usedEventTypes.indexOf(eventType) === -1;
          });

          return userDefinedEventTypes;
        },

        getUserDefinedEventTypes: function () {
          var allEventTypes = this.getModel("store").getProperty("/eventTypes");

          return allEventTypes.filter(function (eventType) {
            return eventType._ref.context.name !== "CoreModel";
          });
        },

        /* Planned Event Dialog Accept Handler */
        onDialogAccepted: function (type, data, context, info) {
          if (!data.businessToleranceValue) {
            data.businessToleranceValue = 0;
          }
          if (!data.technicalToleranceValue) {
            data.technicalToleranceValue = 0;
          }

          if (type === ViewMode.Edit) {
            var originData = context.getObject();
            // set _edited as true when save dialog data
            if (data._category === ModelCategory.Standard) {
              data._edited = true;
            }
            this.updateOriginData(originData, data);
          } else {
            var items = this.getListItems();
            var newItems = items.slice();

            // filter invalid fields and add dependency
            this.updateMatchExtensionFields(data);
            // process matchPlanFieldsForUpdatePlan
            this.updateMatchPlanFieldsForUpdatePlan(data);
            newItems.push(data);
            this.setListItems(newItems);

            // add dependency to where-used list
            this.whereUsedListHelper.addAdmissibleEventDependency(data);
          }

          this.changeToEditMode();
          this.refreshBinding();
        },

        updateOriginData: function (originData, dialogData) {
          // update dependency for eventType when target changes
          this.whereUsedListHelper.updateAdmissibleEventDependency(
            originData,
            dialogData._ref.eventType
          );

          // remove all dependencies for origin matchExtensionFields
          var originMatchExtensionFields = originData.matchExtensionFields;
          if (originMatchExtensionFields && originMatchExtensionFields.length !== 0) {
            originMatchExtensionFields.forEach(function (field) {
              this.whereUsedListHelper.removeMatchExtensionFieldDependency(field);
            }, this);
          }

          // remove all dependencies for origin matchPlanFieldsForUpdatePlan
          var originMatchPlanFieldsForUpdatePlan = originData.matchPlanFieldsForUpdatePlan;
          if (
            originMatchPlanFieldsForUpdatePlan &&
            originMatchPlanFieldsForUpdatePlan.length !== 0
          ) {
            originMatchPlanFieldsForUpdatePlan.forEach(function (item) {
              this.whereUsedListHelper.removeMatchPlanFieldDependency(item);
            }, this);
          }

          // modify properties
          this.modify(originData, dialogData);

          // update matchExtensionFields dependency
          this.updateMatchExtensionFields(originData);

          // update matchPlannedEvent dependency
          this.updateMatchPlanFieldsForUpdatePlan(originData);
        },

        updateMatchExtensionFields: function (data) {
          if (!data.matchExtensionFields || data.matchExtensionFields.length === 0) {
            data.matchExtensionFields = [];
            return;
          }

          // filter invalid matchExtensionFields
          data.matchExtensionFields = data.matchExtensionFields.filter(function (field) {
            return this.validateMatchExtensionField(field);
          }, this);

          // add new dependency for items
          data.matchExtensionFields.forEach(function (field) {
            delete field.info;
            field._parent = data;
            this.whereUsedListHelper.addMatchExtensionFieldDependency(field);
          }, this);

          // refresh display text
          data.matchExtensionFieldsText = this.formatter.formatExtensionMatchKey(
            data.matchExtensionFields
          );
        },

        updateMatchPlanFieldsForUpdatePlan: function (data) {
          if (
            !data.matchPlanFieldsForUpdatePlan ||
            data.matchPlanFieldsForUpdatePlan.length === 0
          ) {
            data.matchPlanFieldsForUpdatePlan = [];
            return;
          }

          data.matchPlanFieldsForUpdatePlan = data.matchPlanFieldsForUpdatePlan.filter(function (
            item
          ) {
            var bIsEventMatchKey = item.name === "eventMatchKey";
            // make sure the matchLocation is true for locationAltKey
            var bIsLocationAltKeyValid = item.name === "locationAltKey" && data.matchLocation;
            // make sure when item is user-defined planned event, it should be included in actual/planned match
            var bIsUserDefinedPlannedEventValid =
              item._ref &&
              data.matchExtensionFields.findIndex(function (field) {
                return field._ref && field._ref.plannedEventField === item._ref;
              }) !== -1;

            // filter not selected items
            return (
              item.selected &&
              (bIsEventMatchKey || bIsLocationAltKeyValid || bIsUserDefinedPlannedEventValid)
            );
          },
          this);

          data.matchPlanFieldsForUpdatePlan.forEach(function (item) {
            delete item.selected;
            item._parent = data;
            // add dependency to where-used list
            this.whereUsedListHelper.addMatchPlanFieldDependency(item);
          }, this);
        },

        // true for valid
        validateMatchExtensionField: function (field) {
          return (
            field &&
            field._ref &&
            field._ref.plannedEventField &&
            field._ref.actualEventField &&
            !!field.operator
          );
        },
      }
    );
  }
);
