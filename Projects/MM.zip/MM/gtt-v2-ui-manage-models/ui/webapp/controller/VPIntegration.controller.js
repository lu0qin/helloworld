/* eslint-disable no-shadow */
sap.ui.define(
  [
    "./BaseController",
    "sap/base/util/merge",
    "sap/m/ColumnListItem",
    "sap/m/Input",
    "sap/m/Select",
    "sap/m/Text",
    "sap/ui/core/Fragment",
    "sap/ui/core/ListItem",
    "sap/ui/model/json/JSONModel",
    "../constant/TrackingIndicator",
    "./DeleteHelper",
    "./WhereUsedListHelper",
    "../constant/ViewMode",
    "../constant/FieldType",
    "../constant/ObjectType",
    "../constant/ModelCategory",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
  ],
  function (
    BaseController,
    merge,
    ColumnListItem,
    Input,
    Select,
    Text,
    Fragment,
    ListItem,
    JSONModel,
    TrackingIndicator,
    DeleteHelper,
    WhereUsedListHelper,
    ViewMode,
    FieldType,
    ObjectType,
    ModelCategory,
    Filter,
    FilterOperator
  ) {
    "use strict";

    return BaseController.extend("com.sap.gtt.v2.model.manage.controller.VPIntegration", {
      deleteHelper: DeleteHelper,
      whereUsedListHelper: WhereUsedListHelper,

      initModel: function () {
        var model = new JSONModel({
          eventTitle: "",
          isProcessTypeEvent: true,
          isStandardEvent: false,
          upstreamProcessTypes: [],
          events: [],
          standardFields: [],
          userFields: [],
          trackingIndicatorSets: [
            {
              code: TrackingIndicator.Shipment,
              text: this.getResourceBundle().getText("trackingIndicator_SHIPMENT"),
            },
            {
              code: TrackingIndicator.Resource,
              text: this.getResourceBundle().getText("trackingIndicator_RESOURCE"),
            },
          ],
        });
        this.setModel(model, "view");
      },

      initControls: function () {
        this.whereUsedListHelper.init(this);
        this.deleteHelper.init(this);

        this.oEventsReadOnlyTemplate = new ColumnListItem({
          // hide user-defined Event Type in Standard Model VP Event List
          visible: "{= ${store>/modelCategory} !== 'STANDARD' || ${view>_ref/_objectType} !== 'EventType' || ${view>_ref/_category} === 'STANDARD' }",
          cells: [
            new Text({
              text:
                "{= Boolean(${view>_ref/vpMapping/_ref/eventType}) ? ${view>_ref/name} + 'Event' : ${view>_ref/name}}",
            }),
            new Text({
              text: "{view>_ref/vpMapping/lbnEventType}",
            }),
          ],
        });
        this.oEventsEditTemplate = new ColumnListItem({
          // hide user-defined Event Type in Standard Model VP Event List
          visible: "{= ${store>/modelCategory} !== 'STANDARD' || ${view>_ref/_objectType} !== 'EventType' || ${view>_ref/_category} === 'STANDARD' }",
          cells: [
            new Text({
              text:
                "{= Boolean(${view>_ref/vpMapping/_ref/eventType}) ? ${view>_ref/name} + 'Event' : ${view>_ref/name}}",
            }),
            new Input({
              value: "{view>_ref/vpMapping/lbnEventType}",
              showValueHelp: true,
              valueHelpOnly: true,
              valueHelpRequest: this.handleEventTypeValueHelp.bind(this),
              editable: "{= ${view>_ref/_category} !== 'STANDARD' }",
              // In standard model, hide LBN Event Type input for User-Defined Event Type
              visible: "{= !Boolean(${view>_ref/vpMapping/_ref/eventType}) && (${store>/modelCategory} !== 'STANDARD' || ${view>_ref/_category} === 'STANDARD') }",
            }),
          ],
        });

        var eventsTable = Fragment.byId(this.createFragmentId("eventTable"), "table");
        this._eventsTable = eventsTable;
      },

      subscribeEvents: function () {
        var eventBus = this.getEventBus();
        eventBus.subscribe("modelDetail", "modeChanged", this.onChangeTableMode, this);
        eventBus.subscribe("modelDetail", "refreshVPBinding", this.selectDefaultProcessType, this);
      },

      unsubscribeEvents: function () {
        var eventBus = this.getEventBus();
        eventBus.unsubscribe("modelDetail", "modeChanged", this.onChangeTableMode, this);
        eventBus.unsubscribe(
          "modelDetail",
          "refreshVPBinding",
          this.selectDefaultProcessType,
          this
        );
      },

      rebindTable: function (oTemplate, sKeyboardMode) {
        var selectedItem = this._eventsTable.getSelectedItem();

        if (selectedItem) {
          var itemPath = selectedItem.getBindingContextPath();
          var index = itemPath.split("/").pop();
        }

        this._eventsTable
          .bindItems({
            path: "view>/events",
            template: oTemplate,
          })
          .setKeyboardMode(sKeyboardMode);

        // select the previous item before rebinding
        if (selectedItem) {
          var isFireEvent = true;

          var items = this._eventsTable.getItems().filter(function (item) {
            return !item.isGroupHeader();
          });

          selectedItem = items[index] || items[0];
          this._eventsTable.setSelectedItem(selectedItem, true, isFireEvent);
        }
      },

      onBeforeRendering: function () {
        this.selectDefaultProcessType();
      },

      changeTableToNavigationMode: function () {
        this.rebindTable(this.oEventsReadOnlyTemplate, "Navigation");
      },

      changeTableToEditMode: function () {
        this.rebindTable(this.oEventsEditTemplate, "Edit");
      },

      onChangeTableMode: function (channelId, eventId, object) {
        var viewMode = this.getModel("store").getProperty("/mode");
        if (viewMode === ViewMode.Display) {
          this.changeTableToNavigationMode();
        } else {
          this.changeTableToEditMode();
        }
      },

      selectDefaultProcessType: function () {
        var select = this.byId("processTypeSelect");
        var item = select.getSelectedItem();
        if (item) {
          select.fireChange({ selectedItem: item });
        }
      },

      bindElementOnControl: function (controlName, context) {
        this.byId(controlName).bindElement({
          path: context.getPath(),
          model: "store",
        });
      },

      clearEventsTable: function () {
        this.getModel("view").setProperty("/events", []);
        this.getModel("view").setProperty("/userFields", []);
        this.getModel("view").setProperty("/standardFields", []);
      },

      setItemsIntoTable: function (processType) {
        var events = this.getModel("view").getProperty("/events");

        // ProcessType VPMapping
        var processTypeEvent = {
          _ref: processType,
        };
        events.push(processTypeEvent);

        // EventType VPMapping
        var eventTypes = this.filterEventTypeVP(processType.name);
        eventTypes.forEach(function (item) {
          events.push({
            _ref: item,
          });
        });

        this.getModel("view").refresh();
      },

      filterEventTypeVP: function (context) {
        var eventTypes = this.getView().getModel("store").getProperty("/eventTypes");

        return eventTypes.filter(function (item) {
          if (!item.vpMapping) {
            item.vpMapping = {
              lbnEventType: "",
              fieldMapping: [],
            };
          }
          return item._ref && item._ref.context && item._ref.context.name === context;
        });
      },

      selectDefaultEvent: function () {
        var items = this._eventsTable.getItems();
        var selectedItem = this._eventsTable.getSelectedItem();

        if (!selectedItem) {
          selectedItem = items.find(function (item) {
            return !item.isGroupHeader();
          });
        }

        this._eventsTable.setSelectedItem(selectedItem, true, true);
      },

      setOutboundFields: function () {
        var result = [];
        var vpPresets = this.getModel("store").getProperty("/vpPresets/processType");
        var fields = vpPresets.fields;
        fields.forEach(function (field) {
          var item = {
            _ref: {
              field: null,
            },
            trackingField: field.name,
            label: field.label,
            required: field.required,
          };
          if (field.fields) {
            item._ref.target = null;
            item.composition = field.fields.map(function (element) {
              return {
                _ref: {
                  field: null,
                },
                trackingField: element.name,
                label: element.label,
                required: element.required,
              };
            });
          }
          result.push(item);
        });
        return result;
      },

      handleProcessTypeVPMapping: function (context) {
        var processType = context.getObject();
        if (!processType.vpMapping) {
          if (processType._category === ModelCategory.Standard) {
            // stay empty when Process Type is Standard
            processType.vpMapping = {
              _ref: {
                eventType: processType,
              },
              fieldMapping: [],
            };
          } else {
            processType.vpMapping = {
              _ref: {
                eventType: processType,
                upstreamProcessType: null,
              },
              trackingIndicator: TrackingIndicator.Shipment,
              fieldMapping: this.setOutboundFields(),
            };
          }
        }
        return processType;
      },

      checkIfUsedByContainer: function (context) {
        var processType = context.getObject();
        var processTypes = this.getModel("store").getProperty("/processTypes");
        var index = processTypes.findIndex(function (item) {
          return (
            item.vpMapping &&
            item.vpMapping.trackingIndicator === TrackingIndicator.Resource &&
            item.vpMapping._ref &&
            item.vpMapping._ref.upstreamProcessType &&
            item.vpMapping._ref.upstreamProcessType.name === processType.name
          );
        });
        return index !== -1;
      },

      onChangeProcessType: function (oEvent) {
        this.clearEventsTable();

        var context = oEvent.getParameter("selectedItem").getBindingContext("store");
        // bind items on switch, tracking indicator and upstream process type
        this.bindElementOnControl("switch", context);
        this.bindElementOnControl("trackingIndicatorDisplay", context);
        this.bindElementOnControl("trackingIndicatorEdit", context);
        this.bindElementOnControl("upstreamProcessTypeDisplay", context);
        this.bindElementOnControl("upstreamProcessTypeEdit", context);
        this.bindElementOnControl("DynamicSideContent", context);

        // handle processType vpMapping property
        var processType = this.handleProcessTypeVPMapping(context);

        // set processType and eventType into event table
        this.setItemsIntoTable(processType);

        // trigger tracking indicator on change to update copy from tp select
        var trackingIndicatorSelect = this.byId("trackingIndicatorEdit");
        var trackingIndicatorItem = trackingIndicatorSelect.getSelectedItem();
        trackingIndicatorSelect.fireChange({ selectedItem: trackingIndicatorItem });

        // if this procesType is used in container upstreamProcessType, then we do not allow to change tracking indicator
        var bUsed = this.checkIfUsedByContainer(context);
        var resourceBundle = this.getResourceBundle();
        if (bUsed) {
          trackingIndicatorSelect.setEditable(false);
          trackingIndicatorSelect.setTooltip(
            resourceBundle.getText("trackingIndicatorWarningMessage")
          );
        } else {
          trackingIndicatorSelect.setEditable(true);
          trackingIndicatorSelect.setTooltip("");
        }
      },

      onUpstreamProcessTypeChange: function (oEvent) {
        var oSelect = oEvent.getSource();
        var oSelectObject = oSelect.getBindingContext("store").getObject();
        var oSelectedItem = oEvent.getParameter("selectedItem");
        var oSelectedItemObject = oSelectedItem.getBindingContext("view").getObject();

        if (oSelectObject.vpMapping && oSelectObject.vpMapping._ref) {
          // remove origin upstream process type where used info
          this.deleteHelper.removeVPSimpleAssociationInfo(oSelectObject.vpMapping);

          oSelectObject.vpMapping._ref.upstreamProcessType = oSelectedItemObject;

          if (oSelectedItemObject.name !== "") {
            // add association to where-used list
            this.whereUsedListHelper.addUpstreamProcessTypeAssociation(oSelectObject.vpMapping);
          }
        }
      },

      updateUpstreamProcessTypes: function () {
        var upstreamProcessTypes = [{ name: "", descr: "" }];
        var processTypes = this.getModel("store").getProperty("/processTypes");
        var shipmentProcessTypes = processTypes.filter(function (processType) {
          if (processType.vpMapping) {
            return (
              processType.enableVP === true &&
              processType.vpMapping.trackingIndicator === TrackingIndicator.Shipment
            );
          }
          return false;
        });
        upstreamProcessTypes = upstreamProcessTypes.concat(shipmentProcessTypes);
        this.getModel("view").setProperty("/upstreamProcessTypes", upstreamProcessTypes);
      },

      onTrackingIndicatorChange: function (oEvent) {
        var control = oEvent.getSource();
        var value = control.getSelectedKey();
        if (value === TrackingIndicator.Resource) {
          this.updateUpstreamProcessTypes();
        } else {
          // set related _ref.upstreamProcessTypes to null
          var context = control.getBindingContext("store");
          var object = context.getObject();
          if (object.vpMapping._ref && object.vpMapping._ref.upstreamProcessType) {
            this.whereUsedListHelper.removeUpstreamProcessTypeAssociations(object);
            object.vpMapping._ref.upstreamProcessType = null;
          }
        }
      },

      onSelectionChange: function (oEvent) {
        var item = oEvent.getParameter("listItem");
        var context = item.getBindingContext("view");

        // bind fields to Tree Table
        if (context.getProperty("_ref/_objectType") === ObjectType.ProcessType) {
          // Process Type
          Fragment.byId(
            this.createFragmentId("userProcessTypeFragment"),
            "processTypeTable"
          ).bindElement({
            path: context.getPath(),
            model: "view",
          });
          Fragment.byId(
            this.createFragmentId("standardProcessTypeFragment"),
            "processTypeTable"
          ).bindElement({
            path: context.getPath(),
            model: "view",
          });
        } else {
          // Event Type
          this.processEventTypeFieldMapping(context.getObject());
          Fragment.byId(
            this.createFragmentId("userEventTypeFragment"),
            "eventTypeTable"
          ).bindElement({
            path: context.getPath(),
            model: "view",
          });
          Fragment.byId(
            this.createFragmentId("standardEventTypeFragment"),
            "eventTypeTable"
          ).bindElement({
            path: context.getPath(),
            model: "view",
          });
        }

        this.setDataForFieldMappingTables(context);
      },

      setSideContentVisibility: function (isProcessTypeEvent, isStandardEvent) {
        var viewModel = this.getModel("view");

        viewModel.setProperty("/isProcessTypeEvent", isProcessTypeEvent);
        viewModel.setProperty("/isStandardEvent", isStandardEvent);
      },

      setDataForFieldMappingTables: function (context) {
        var viewModel = this.getModel("view");

        var bIsProcessTypeEvent =
          context.getProperty("_ref/_objectType") === ObjectType.ProcessType;
        var bIsStandardEvent = context.getProperty("_ref/_category") === ModelCategory.Standard;

        this.setSideContentVisibility(bIsProcessTypeEvent, bIsStandardEvent);

        var standardFields = [];
        var userFields = [];
        var aFieldMapping = context.getProperty("_ref/vpMapping/fieldMapping");

        if (bIsStandardEvent) {
          if (bIsProcessTypeEvent) {
            standardFields = aFieldMapping;
            userFields = [];
          } else {
            standardFields = aFieldMapping.filter(function (item) {
              return item._ref && item._ref.field._category === ModelCategory.Standard;
            });
            userFields = aFieldMapping.filter(function (field) {
              return field._ref && field._ref.field._category !== ModelCategory.Standard;
            });
          }
        } else {
          standardFields = [];
          userFields = aFieldMapping;
        }

        viewModel.setProperty("/standardFields", standardFields);
        viewModel.setProperty("/userFields", userFields);
      },

      onUpdateFinished: function (oEvent) {
        this.selectDefaultEvent();
        var sTitle;
        var iTotal = oEvent.getParameter("total");
        var resourceBundle = this.getResourceBundle();
        if (this._eventsTable.getBinding("items").isLengthFinal()) {
          sTitle = resourceBundle.getText("eventsTitle", iTotal);
        }
        this.getModel("view").setProperty("/eventsTitle", sTitle);
      },

      /**
       * process user define field into fieldMapping
       * @param {object} object of event type to process
       */
      processEventTypeFieldMapping: function (object) {
        var refObject = object._ref || {};
        var fields = refObject.elements || [];
        var fieldMapping = refObject.vpMapping.fieldMapping;

        if (!fieldMapping) {
          refObject.vpMapping.fieldMapping = [];
        }

        // jump out when Standard Event Type own empty fieldMapping
        if (refObject._category === ModelCategory.Standard) {
          return;
        }

        if (fieldMapping.length === 0) {
          // Event Type
          fields.forEach(function (item) {
            var newField = {
              _ref: {},
            };
            newField._ref.field = item;
            this.whereUsedListHelper.addMappingItemDependency(newField);

            if (item.type === FieldType.Composition) {
              newField._ref.target = item._ref.target;
              newField.composition = item._ref.target.elements.map(function (element) {
                var newCompositionField = {
                  _ref: {
                    field: element,
                  },
                };
                this.whereUsedListHelper.addMappingItemDependency(newCompositionField);
                return newCompositionField;
              }, this);
            }

            fieldMapping.push(newField);
          }, this);
        }
      },

      handleOutboundCloseWithItem: function (oEvent, context) {
        var item = oEvent.getParameter("selectedItem").getBindingContext("dialog").getObject();
        if (item) {
          var inputObject = context.getObject();

          var bIsNone = item.name === "";
          var bIsChanged = inputObject._ref.field !== item;
          if (bIsNone) {
            inputObject._ref.field = null;

            this.deleteHelper.removeVPSimpleAssociationInfo(inputObject);
          } else {
            inputObject._ref.field = item;
            // delete origin where used info
            this.deleteHelper.removeVPSimpleAssociationInfo(inputObject);
            // add new where used info
            this.whereUsedListHelper.addMappingItemAssociation(inputObject);
          }

          if (this.level === 1 && inputObject.composition) {
            this.handleCompositionItem(inputObject, bIsChanged, item);
          }
        }
      },

      handleCompositionItem: function (inputObject, bIsChanged, item) {
        if (bIsChanged) {
          if (item._ref && item._ref.target) {
            inputObject._ref.target = item._ref.target;
          } else {
            inputObject._ref.target = null;
          }
          inputObject.composition.forEach(
            function (compositionItem) {
              this.deleteHelper.removeVPSimpleAssociationInfo(compositionItem);
            }.bind(this)
          );
          inputObject.composition = inputObject.composition.map(function (field) {
            return {
              trackingField: field.trackingField,
              label: field.label,
              _ref: {},
            };
          });
        }
      },

      filterItemsOnLevel: function (level, rowBindingContext, tableBindingContext) {
        var result = [];
        var elements = tableBindingContext.getObject()._ref.elements;
        if (level === 1) {
          if (rowBindingContext.getProperty("composition")) {
            // filter composition type element
            result = elements.filter(function (element) {
              return element.type === FieldType.Composition;
            });
          } else {
            // filter level 1 simple type
            result = elements.filter(function (element) {
              return (
                element.type !== FieldType.Composition &&
                !FieldType.isItemAssociationToMany(element)
              );
            });
          }
        }
        // level 2, filter parent's composition field for outboundFields
        if (level === 2) {
          var sPath = rowBindingContext.getPath();
          var sParentPath = sPath.split("/composition")[0];
          var parent = this.getModel("view").getProperty(sParentPath);
          var target = parent._ref.target;

          if (target) {
            result = target.elements.filter(function (element) {
              return !FieldType.isItemAssociationToMany(element);
            });
          }
        }

        // add none option
        return [
          {
            name: "",
          },
        ].concat(result);
      },

      handleOutboundValueHelp: function (oEvent) {
        var input = oEvent.getSource();
        var row = input.getParent();
        var rowBindingContext = row.getRowBindingContext();
        var level = row.getLevel();
        var table = row.getParent();
        var tableBindingContext = table.getBindingContext("view");

        //use level and binding context judge current level should input simple type or complex type
        var outboundFields = this.filterItemsOnLevel(level, rowBindingContext, tableBindingContext);

        // Set selection status
        this._input = oEvent.getSource();
        var sInputValue = this._input.getValue();
        outboundFields.forEach(function (oField) {
          oField.selected = oField.name === sInputValue;
        });

        var oModel = new JSONModel({
          outboundFields: outboundFields,
        });

        var options = {
          fragmentId: "outboundValueHelpDialog",
          fragmentName: "OutboundValueHelp",
          controller: merge({}, this, {
            modelName: "dialog",
            level: level,
            handleConfirm: function (oEvent) {
              var context = this._input.getBindingContext("view");

              this.handleOutboundCloseWithItem(oEvent, context);
              this._input.getBinding("value").refresh();

              var dialog = oEvent.getSource();
              dialog.destroy();
            },
            handleClose: function (oEvent) {
              var dialog = oEvent.getSource();
              dialog.destroy();
            },
            handleSearch: function (oEvent) {
              var sValue = oEvent.getParameter("value");
              var oFilter = new Filter({
                filters: [new Filter("name", FilterOperator.Contains, sValue)],
              });
              var oBinding = oEvent.getSource().getBinding("items");
              oBinding.filter([oFilter]);
            },
          }),
          model: oModel,
        };
        this.openDialog(options);
      },

      handleInboundCloseWithItem: function (oEvent, context) {
        var item = oEvent.getParameter("selectedItem");
        if (item) {
          var inputObject = context.getObject();
          var sName = item.getBindingContext("dialog").getProperty("name");
          context.getModel().setProperty("trackingField", sName, context);
          var bIsNone = sName === "";
          if (bIsNone) {
            this._input.resetProperty("value");
          } else {
            this._input.setValue(item.getTitle());
          }
        }

        if (this.level === 1 && inputObject && inputObject.composition) {
          inputObject.composition = inputObject.composition.map(function (compositionField) {
            return {
              trackingField: "",
              _ref: {
                field: compositionField._ref.field,
              },
            };
          });
        }
      },

      filterPresetsOnLevel: function (level, rowBindingContext, presets) {
        var result = [];
        var rowObject = rowBindingContext.getObject();
        if (level === 1) {
          if (rowObject.composition) {
            // filter composition type element
            result = presets.filter(function (element) {
              return element.fields;
            });
          } else {
            // filter level 1 simple type
            result = presets.filter(function (element) {
              return !element.fields;
            });
          }
        }
        // level 2, filter parent's composition field for outboundFields
        if (level === 2) {
          var sPath = rowBindingContext.getPath();
          var sParentPath = sPath.split("/composition")[0];
          var parent = this.getModel("view").getProperty(sParentPath);
          var parentTrackingField = parent.trackingField;
          var parentItem = presets.find(function (item) {
            return item.name === parentTrackingField;
          });
          if (parentItem) {
            result = parentItem.fields;
          }
        }
        return result;
      },

      handleInboundValueHelp: function (oEvent) {
        var inboundFields = [
          {
            label: this.getResourceBundle().getText("none"),
            name: "",
          },
        ];
        var input = oEvent.getSource();
        var row = input.getParent();
        var rowBindingContext = row.getRowBindingContext();
        var level = row.getLevel();

        var vpPresets = this.getModel("store").getProperty("/vpPresets").eventType || {};
        var etPresets = vpPresets.fields || [];
        //use level and binding context judge current level should input simple type or complex type
        inboundFields = inboundFields.concat(
          this.filterPresetsOnLevel(level, rowBindingContext, etPresets)
        );

        // Set selection status
        this._input = oEvent.getSource();
        var sInputValue = this._input.getValue();
        inboundFields.forEach(function (oField) {
          oField.selected =
            (sInputValue === "" && oField.name === sInputValue) || oField.label === sInputValue;
        });

        var oModel = new JSONModel({
          inboundFields: inboundFields,
        });

        var options = {
          fragmentId: "inboundValueHelpDialog",
          fragmentName: "InboundValueHelp",
          controller: merge({}, this, {
            modelName: "dialog",
            level: level,
            handleConfirm: function (oEvent) {
              var context = this._input.getBindingContext("view");

              this.handleInboundCloseWithItem(oEvent, context);
              this._input.getBinding("value").refresh();

              var dialog = oEvent.getSource();
              dialog.destroy();
            },
            handleClose: function (oEvent) {
              var dialog = oEvent.getSource();
              dialog.destroy();
            },
            handleSearch: function (oEvent) {
              var sValue = oEvent.getParameter("value");
              var oFilter = new Filter({
                filters: [
                  new Filter("label", FilterOperator.Contains, sValue),
                  new Filter("name", FilterOperator.Contains, sValue),
                ],
              });
              var oBinding = oEvent.getSource().getBinding("items");
              oBinding.filter([oFilter]);
            },
          }),
          model: oModel,
        };
        this.openDialog(options);
      },

      getUnmappedLBNEventTypes: function (value) {
        var lbnEventTypes = this.getModel("store").getProperty("/lbnEventType");
        var eventTypes = this.getModel("store").getProperty("/eventTypes");

        lbnEventTypes = lbnEventTypes.filter(function (item) {
          return (
            item.eventType === value ||
            !eventTypes.find(function (event) {
              return event.vpMapping && event.vpMapping.lbnEventType === item.eventType;
            })
          );
        });

        return lbnEventTypes;
      },

      handleEventTypeValueHelp: function (oEvent) {
        var aLBNEventTypes = [
          {
            descr: this.getResourceBundle().getText("none"),
            eventType: "",
          },
        ];

        // Set selection status
        this._input = oEvent.getSource();
        var sInputValue = this._input.getValue();

        var lbnEventTypes = this.getUnmappedLBNEventTypes(sInputValue);
        aLBNEventTypes = aLBNEventTypes.concat(lbnEventTypes);

        aLBNEventTypes.forEach(function (oField) {
          oField.selected = oField.eventType === sInputValue;
        });

        var oModel = new JSONModel({
          lbnEventTypes: aLBNEventTypes,
        });
        var options = {
          fragmentId: "lbnEventTypeValueHelpDialog",
          fragmentName: "LbnEventTypeValueHelp",
          controller: merge({}, this, {
            modelName: "dialog",
            handleConfirm: function (oEvent) {
              var item = oEvent.getParameter("selectedItem");
              if (item) {
                var bIsNone = item.getBindingContext("dialog").getProperty("eventType") === "";
                if (bIsNone) {
                  this._input.resetProperty("value");
                } else {
                  this._input.setValue(item.getDescription());
                }
              }
              var dialog = oEvent.getSource();
              dialog.destroy();
            },
            handleClose: function (oEvent) {
              var dialog = oEvent.getSource();
              dialog.destroy();
            },
            handleSearch: function (oEvent) {
              var sValue = oEvent.getParameter("value");
              var oFilter = new Filter({
                filters: [
                  new Filter("descr", FilterOperator.Contains, sValue),
                  new Filter("eventType", FilterOperator.Contains, sValue),
                ],
              });
              var oBinding = oEvent.getSource().getBinding("items");
              oBinding.filter([oFilter]);
            },
          }),
          model: oModel,
        };
        this.openDialog(options);
      },
    });
  }
);
