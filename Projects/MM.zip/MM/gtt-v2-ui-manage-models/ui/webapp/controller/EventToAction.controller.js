sap.ui.define(
  [
    "./BaseController",
    "../util/AsyncUtils",
    "../util/ServiceUtils",
    "../util/RestClient",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/library",
    "sap/m/MessageBox",
    "../constant/ModelCategory",
  ],
  function (
    BaseController,
    AsyncUtils,
    ServiceUtils,
    RestClient,
    JSONModel,
    Library,
    MessageBox,
    ModelCategory
  ) {
    "use strict";

    return BaseController.extend("com.sap.gtt.v2.model.manage.controller.EventToAction", {
      onInit: function () {
        var viewModel = new JSONModel({
          validationMessage: [],
        });

        this.setModel(viewModel, "view");
      },

      onValidateCode: function () {
        this.byId("messageView").navigateBack();
        this._loadValidationMessage();
      },

      onMessageItemSelect: function (oEvent) {
        var oSelectedContext = oEvent.getParameter("item").getBindingContext("view");
        var iSelectedSectionIndex = oSelectedContext.getProperty("sectionIndex");

        this.expandErrorPanelByIndex(iSelectedSectionIndex);
      },

      hideSideContent: function () {
        var oSideContent = this.byId("eventToActionDynamicSideContent");
        oSideContent.setShowSideContent(false);
        this.byId("openValidationDetailsButton").setEnabled(true);
      },

      showSideContent: function () {
        var oSideContent = this.byId("eventToActionDynamicSideContent");
        oSideContent.setShowSideContent(true);
        this.byId("openValidationDetailsButton").setEnabled(false);
      },

      expandErrorPanelByIndex: function (iIndex) {
        var sModelCategory = this.getModel("store").getProperty("/modelCategory");
        // no need to navigate to relative section in User Model
        if (sModelCategory !== ModelCategory.Standard) {
          return;
        }

        var oStandardEditorView = this.byId("standardEditorView");
        if (!oStandardEditorView || !oStandardEditorView.getContent()) {
          return;
        }

        var aEditorViewContent = oStandardEditorView.getContent();
        if (!aEditorViewContent) {
          return;
        }

        aEditorViewContent.forEach(function (panel, index) {
          if (panel && panel.isA("sap.m.Panel")) {
            if (index === iIndex) {
              panel.setExpanded(true);
            } else {
              panel.setExpanded(false);
            }
          }
        });
      },

      // ========================================================
      // HTTP Request
      // ========================================================
      _loadValidationMessage: function () {
        var that = this;

        var oView = that.getView();
        oView.setBusy(true);

        var postPayload = that._getValidationRequestPayload();
        var dataSource = ServiceUtils.getDataSource("mainService");
        var url = ServiceUtils.getUrl(dataSource.uri).concat("/eventToAction/validate");
        var request = RestClient.post(url, postPayload);

        var promise = AsyncUtils.finally(request, function () {
          oView.setBusy(false);
        });

        promise.then(
          function (data) {
            that._processValidationMessage(data);
            that.showSideContent();
          },
          function (error) {
            MessageBox.error(error.responseText);
          }
        );
      },

      _getValidationRequestPayload: function () {
        var oStoreModel = this.getModel("store");
        var aContentPayload = [];

        if (oStoreModel.getProperty("/modelCategory") === ModelCategory.Standard) {
          /* In standard model:
            send following scripts in order:
            Standard Declaration, User Script Before Standard, Standard Script, User Script After Standard */
          var oStandardEventToAction =
            oStoreModel.getProperty("/model/standardModel/eventToAction") || {};
          var sCustomScriptBefore =
            oStoreModel.getProperty("/model/customModel/eventToAction") || "";
          var sCustomScriptAfter =
            oStoreModel.getProperty("/model/customModel/eventToActionEx") || "";

          aContentPayload = [
            oStandardEventToAction.declaration,
            sCustomScriptBefore,
            oStandardEventToAction.script,
            sCustomScriptAfter,
          ];
        } else {
          /* In custom model: send the only eventToAction script under custom model*/
          var sScript = oStoreModel.getProperty("/model/customModel/eventToAction") || "";

          aContentPayload = [sScript];
        }

        return {
          content: aContentPayload,
        };
      },

      _processValidationMessage: function (data) {
        var that = this;

        var aItems = [];
        var sResult = data.result;

        if (sResult === "fail") {
          data.details.forEach(function (element, index) {
            aItems.push({
              type: Library.MessageType.Error,
              msg: element.message,
              description: element.message,
              sectionIndex: element.sectionIndex,
            });
            if (index === 0) {
              var iSelectedSectionIndex = element.sectionIndex;
              that.expandErrorPanelByIndex(iSelectedSectionIndex);
            }
          });
        } else {
          aItems.push({
            type: Library.MessageType.Success,
            msg: this.getResourceBundle().getText("success"),
            description: "",
          });
        }

        that.getModel("view").setProperty("/validationMessage", aItems);
        that.getModel("view").refresh(true);
      },
    });
  }
);
