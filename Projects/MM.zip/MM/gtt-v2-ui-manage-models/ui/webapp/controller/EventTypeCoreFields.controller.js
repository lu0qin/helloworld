sap.ui.define(
  [
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/base/strings/formatMessage",
  ],
  function (BaseController, JSONModel, formatMessage) {
    "use strict";

    return BaseController.extend("com.sap.gtt.v2.model.manage.controller.EventTypeCoreFields", {
      initModel: function () {
        var tableInfo = new JSONModel();
        this.setModel(tableInfo, "tableInfo");
      },
    });
  }
);
