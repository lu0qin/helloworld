sap.ui.define(
  [
    "./BaseController",
    "sap/base/util/merge",
    "sap/m/ColumnListItem",
    "sap/m/Text",
    "sap/m/Input",
    "sap/m/GroupHeaderListItem",
    "sap/ui/core/Fragment",
    "sap/ui/model/Sorter",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "../constant/ErpObjectType",
    "../constant/IDocEventType",
    "../constant/ViewMode",
    "../constant/FieldType",
    "../constant/ModelCategory",
    "../constant/ObjectType",
    "../util/ValidationHelper",
    "./WhereUsedListHelper",
    "./EntityValidator",
  ],
  function (
    BaseController,
    merge,
    ColumnListItem,
    Text,
    Input,
    GroupHeaderListItem,
    Fragment,
    Sorter,
    JSONModel,
    Filter,
    FilterOperator,
    ErpObjectType,
    IDocEventType,
    ViewMode,
    FieldType,
    ModelCategory,
    ObjectType,
    ValidationHelper,
    WhereUsedListHelper,
    EntityValidator
  ) {
    "use strict";

    var IDOC_PRESETS_PATH = "/idocPresets";

    var IDOC = {
      E1EHPAO: "E1EHPAO",
      E1EVMHDR02: "E1EVMHDR02",
    };
    var IDOC_SEGMENT = {
      E1EHPCP: "E1EHPCP",
      E1EHPIP: "E1EHPIP",
      E1EVMPAR: "E1EVMPAR",
    };

    return BaseController.extend("com.sap.gtt.v2.model.manage.controller.IDoc", {
      whereUsedListHelper: WhereUsedListHelper,
      aSelectedEventCodes: [],

      initModel: function () {
        var iDoc = new JSONModel({
          events: [],
          userFields: [],
          standardFields: [],
          showValueHelp: false,
          objectTypeItems: [
            { name: ErpObjectType.Others },
            { name: ErpObjectType.SalesOrderHeader },
            { name: ErpObjectType.SalesOrderItem },
            { name: ErpObjectType.DeliveryHeader },
            { name: ErpObjectType.DeliveryItem },
            { name: ErpObjectType.ShipmentHeader },
            { name: ErpObjectType.PurchaseOrderItem },
          ],
        });
        this.setModel(iDoc, "iDoc");

        var tableInfo = new JSONModel({
          eventsTitle: "",
          userFieldsTitle: this.getResourceBundle().getText("userModelMappingFields"),
          standardFieldsTitle: this.getResourceBundle().getText("standardModelMappingFields"),
          idocEditable: true,
          shouldShowStandardFieldMapping: false,
        });
        this.setModel(tableInfo, "tableInfo");

        var iDocValueHelp = new JSONModel({
          items: [{ name: IDOC.E1EHPAO }, { name: IDOC.E1EVMHDR02 }],
          segment: [],
          fields: [],
        });
        this.setModel(iDocValueHelp, "iDocValueHelp");

        this._eventsTable = Fragment.byId(
          this.createFragmentId("detailFragment"),
          "eventsMappingTable"
        );

        this._erpType = "";
      },

      initControls: function () {
        // transfer this context to where used list helper
        this.whereUsedListHelper.init(this);

        this.oEventsReadOnlyTemplate = new ColumnListItem({
          cells: [
            new Text({
              text:
                "{= ${iDoc>type} === 'processType' ? ${iDoc>_ref/name} + 'Event' : ${iDoc>_ref/name}}",
            }),
            new Text({
              text: "{iDoc>_ref/idocMapping/idoc}",
            }),
            new Text({
              text: "{iDoc>_ref/idocMapping/erpEventCode}",
            }),
          ],
        });
        this.oEventsEditTemplate = new ColumnListItem({
          cells: [
            new Text({
              text:
                "{= ${iDoc>type} === 'processType' ? ${iDoc>_ref/name} + 'Event' : ${iDoc>_ref/name}}",
            }),
            new Input({
              value: "{iDoc>_ref/idocMapping/idoc}",
              change: this.onIDocInputChange.bind(this),
              showValueHelp: true,
              valueHelpOnly: false,
              valueHelpRequest: this.handleValueHelp.bind(this),
              // editable: "{= ${tableInfo>/idocEditable} && ${iDoc>type} !== 'plannedEvent'}",
              editable: "{= ${tableInfo>/idocEditable} && ${iDoc>_ref/_category} !== 'STANDARD' }",
            }),
            new Input({
              value: "{iDoc>_ref/idocMapping/erpEventCode}",
              change: this.onIDocInputChange.bind(this),
              showValueHelp: "{= ${store>/modelCategory} !== 'STANDARD'}",
              valueHelpOnly: false,
              valueHelpRequest: this.handleEventCodeValueHelp.bind(this),
              editable: "{= ${iDoc>_ref/_category} !== 'STANDARD'}",
              visible: "{= ${iDoc>type} !== 'processType'}",
            }),
          ],
        });
      },

      onExit: function () {
        if (this._idocHelpDialog) {
          this._idocHelpDialog.destroy();
        }
        this.unsubscribeEvents();
      },

      subscribeEvents: function () {
        var eventBus = this.getEventBus();
        eventBus.subscribe("modelDetail", "modeChanged", this.onChangeTableMode, this);
        eventBus.subscribe(
          "modelDetail",
          "refreshIDocBinding",
          this.selectDefaultTrackedProcess,
          this
        );
      },

      unsubscribeEvents: function () {
        var eventBus = this.getEventBus();
        eventBus.unsubscribe("modelDetail", "modeChanged", this.onChangeTableMode, this);
        eventBus.unsubscribe(
          "modelDetail",
          "refreshIDocBinding",
          this.selectDefaultTrackedProcess,
          this
        );
      },

      onBeforeRendering: function () {
        this.selectDefaultTrackedProcess();
      },

      storeSelectedEventCodes: function () {
        var that = this;
        var oStoreModel = this.getModel("store");
        var aEventsData = oStoreModel.getProperty("/eventTypes");
        this.aSelectedEventCodes.length = 0;
        if (aEventsData.length > 0) {
          aEventsData.forEach(function (item, index) {
            if (item._ref.context.name !== "CoreModel") {
              that.aSelectedEventCodes.push(item.idocMapping.erpEventCode);
            }
          });
        }
      },

      clearIDocModel: function () {
        var model = this.getModel("iDoc");
        model.setProperty("/events", []);
        model.setProperty("/userFields", []);
        model.setProperty("/standardFields", []);
      },

      selectDefaultTrackedProcess: function () {
        var select = this.byId("processTypeSelect");
        var item = select.getSelectedItem();
        if (item !== null) {
          select.fireChange({ selectedItem: item });
        }
      },

      onChange: function (oEvent) {
        var context = oEvent.getParameter("selectedItem").getBindingContext("store");
        var object = context.getObject();
        if (!object.idocMapping) {
          object.idocMapping = {
            _ref: {
              eventType: object,
            },
            // eventType: object.name + "Event",
            erpObjectType: ErpObjectType.Others,
          };
        }

        // bind items on swith
        this.byId("switch").bindElement({
          path: context.getPath(),
          model: "store",
        });

        // bind items on tracked process mapping and detail mapping for enabled use
        this.bindOnFragment("frag", "vbox", context);
        this.bindOnFragment("detailFragment", "DynamicSideContent", context);

        // bind items on events mapping - processType
        this.clearIDocModel();
        var iDoc = this.getModel("iDoc");
        var events = iDoc.getProperty("/events");

        var processTypeEvent = {
          _ref: object,
          type: IDocEventType.ProcessType,
        };
        events.push(processTypeEvent);

        // // bind items on events mapping - plannedEvents
        // var plannedEvents = object.admissiblePlannedEvents;
        // plannedEvents.forEach(function (item) {
        //   var plannedEventIDoc = {
        //     name: item.eventType.target,
        //     type: IDocEventType.PlannedEvent,
        //     idocMapping: item.idocMapping ||  {
        //       idoc: processTypeIDoc.idocMapping.idoc || "",
        //       erpEventCode: "",
        //     },
        //   };
        //   events.push(plannedEventIDoc);
        // });

        // bind items on events mapping - eventTypes
        var eventTypes = this.getModel("store").getProperty("/eventTypes");
        eventTypes.forEach(function (item) {
          if (
            item._ref &&
            item._ref.context !== "CoreModel" &&
            item._ref.context.name === object.name
          ) {
            if (!item.idocMapping) {
              item.idocMapping = {};
            }
            events.push({
              _ref: item,
              type: IDocEventType.ActualEvent,
            });
          }
        });

        // table.refresh() maybe
        iDoc.refresh();

        this.selectDefaultEvent();

        this.selectDefaultERPType();
      },

      bindOnFragment: function (fragName, control, context) {
        Fragment.byId(this.createFragmentId(fragName), control).bindElement({
          path: context.getPath(),
          model: "store",
        });
      },

      selectDefaultERPType: function () {
        var select = Fragment.byId(this.createFragmentId("frag"), "erpTypeSelect");
        var item = select.getSelectedItem();
        select.fireChange({ selectedItem: item });
      },

      onERPTypeSelectChange: function (oEvent) {
        var item = oEvent.getParameter("selectedItem");
        var selectedKey = item.getKey();
        var mode = this.getModel("store").getProperty("/mode");
        if (mode !== ViewMode.Display) {
          if (selectedKey !== ErpObjectType.Others) {
            this.setIDocInput(false);
            this.setRelatedIDocValue();
            this.getModel("iDoc").setProperty("/showValueHelp", true);
          } else {
            this.setIDocInput(true);
            this.getModel("iDoc").setProperty("/showValueHelp", false);
          }
          this._erpType = selectedKey;
        }
      },

      onChangeApplicationObjectType: function (oEvent) {
        var oInput = oEvent.getSource();
        var oSelectedProcessTypeContext = oInput.getBindingContext("store");
        var sModelCategory = oSelectedProcessTypeContext.getProperty("/modelCategory");
        var sEntityCategory = oSelectedProcessTypeContext.getProperty("_category");

        var sValue = oInput.getValue();
        var aErrors = this.validateApplicationObjectType(sValue, sModelCategory, sEntityCategory);

        if (aErrors && aErrors.length !== 0) {
          ValidationHelper.setControlValidationError(oInput, aErrors[0].message);
        }
      },

      validateApplicationObjectType: function (sValue, sModelCategory, sEntityCategory) {
        var aErrors = [];

        var oResourceBundle = this.getResourceBundle();

        if (
          sModelCategory === ModelCategory.Standard &&
          sEntityCategory !== ModelCategory.Standard
        ) {
          aErrors = aErrors.concat(
            EntityValidator.validateNotStartWithZZ(
              sValue,
              "",
              ObjectType.ProcessType,
              oResourceBundle
            )
          );
        }

        aErrors = aErrors.concat(
          EntityValidator.validateStringConstraint(sValue, true, true, oResourceBundle)
        );

        return aErrors;
      },

      setIDocInput: function (bValue) {
        this.getModel("tableInfo").setProperty("/idocEditable", bValue);
      },

      setRelatedIDocValue: function () {
        var iDoc = this.getModel("iDoc");
        var events = iDoc.getProperty("/events");
        events.forEach(function (event) {
          if (event.type === IDocEventType.ActualEvent) {
            event._ref.idocMapping.idoc = IDOC.E1EVMHDR02;
          } else {
            event._ref.idocMapping.idoc = IDOC.E1EHPAO;
          }
        });
        iDoc.refresh();
        this.selectDefaultEvent();
      },

      selectDefaultEvent: function () {
        var items = this._eventsTable.getItems();
        var selectedItem = this._eventsTable.getSelectedItem();

        if (!selectedItem) {
          selectedItem = items.find(function (item) {
            return !item.isGroupHeader();
          });
        }

        this._eventsTable.setSelectedItem(selectedItem, true, true);
      },

      onEventsSelectionChange: function (oEvent) {
        var item = oEvent.getParameter("listItem");
        var oContext = item.getBindingContext("iDoc");
        var oItemObject = oContext.getObject();

        var bShouldShowStandardFieldMapping =
          oContext.getProperty("_ref/_category") === ModelCategory.Standard;
        this.getModel("iDoc").setProperty(
          "/shouldShowStandardFieldMapping",
          bShouldShowStandardFieldMapping
        );

        this.processFieldMapping(oItemObject);

        // bind fields to treetable
        var objectFieldMapping = oItemObject._ref.idocMapping.fieldMapping;

        var standardFields = [];
        var userFields = [];
        if (bShouldShowStandardFieldMapping) {
          standardFields = objectFieldMapping.filter(function (item) {
            return item._ref.field._category === ModelCategory.Standard;
          });
          userFields = objectFieldMapping.filter(function (item) {
            return item._ref.field._category !== ModelCategory.Standard;
          });
        } else {
          standardFields = [];
          userFields = objectFieldMapping;
        }
        this.getModel("iDoc").setProperty("/userFields", userFields);
        this.getModel("iDoc").setProperty("/standardFields", standardFields);
      },

      onEventsUpdateFinished: function (oEvent) {
        var sTitle;
        var iTotal = oEvent.getParameter("total");
        var resourceBundle = this.getResourceBundle();
        if (this._eventsTable.getBinding("items").isLengthFinal()) {
          sTitle = resourceBundle.getText("eventsTitle", iTotal);
        }
        this.getModel("tableInfo").setProperty("/eventsTitle", sTitle);
      },

      onChangeTableMode: function (channelId, eventId, object) {
        var viewMode = this.getModel("store").getProperty("/mode");
        if (viewMode === ViewMode.Display) {
          this.changeTableToNavigationMode();
        } else {
          this.changeTableToEditMode();

          // get un mapped fields from user fields
          // var fields = this.getModel("idoc").getProperty("/fields");
          // fields = fields.concat(this.getRestFieldsFromEventType());
          // this.getModel("idoc").setProperty("/fields", fields);
          this.selectDefaultEvent();
        }
      },

      changeTableToNavigationMode: function () {
        this.rebindTable(this.oEventsReadOnlyTemplate, "Navigation");
      },

      changeTableToEditMode: function () {
        this.rebindTable(this.oEventsEditTemplate, "Edit");
      },

      rebindTable: function (oTemplate, sKeyboardMode) {
        var that = this;

        var selectedItem = that._eventsTable.getSelectedItem();

        if (selectedItem) {
          var itemPath = selectedItem.getBindingContextPath();
          var index = itemPath.split("/").pop();
        }

        var oSorter = new Sorter({
          path: "type",
          descending: true,
          group: true,
        });

        that._eventsTable
          .bindItems({
            path: "iDoc>/events",
            template: oTemplate,
            sorter: oSorter,
            groupHeaderFactory: that.getGroupHeader.bind(that),
          })
          .setKeyboardMode(sKeyboardMode);

        // select the previous item before rebinding
        if (selectedItem) {
          var isFireEvent = true;

          var items = that._eventsTable.getItems().filter(function (item) {
            return !item.isGroupHeader();
          });

          selectedItem = items[index] || items[0];
          that._eventsTable.setSelectedItem(selectedItem, true, isFireEvent);
        }
      },

      getGroupHeader: function (oGroup) {
        var sId = this.createId(oGroup.key);

        var sHeaderText = "";
        switch (oGroup.key) {
          case IDocEventType.ProcessType:
            sHeaderText = this.getResourceBundle().getText("trackedProcess");
            break;
          // case IDocEventType.PlannedEvent:
          //   return this.getResourceBundle().getText("plannedEvents");
          case IDocEventType.ActualEvent:
            // return this.getResourceBundle().getText("actualEvents");
            sHeaderText = this.getResourceBundle().getText("eventTypes");
            break;
          default:
            break;
        }

        return new GroupHeaderListItem({
          id: sId,
          title: sHeaderText,
        });
      },

      onChangeIDoc: function (oEvent) {
        // var oModel = oEvent.getSource().getBindingContext("iDoc");
        // var sPath = oModel.getPath();
        // var oEvent = oModel.getProperty(sPath);
        // if (oEvent.type === IDocEventType.ProcessType) {
        //   var oEvents = oModel.getProperty("/events");
        //   oEvents.forEach(function (event) {
        //     if (event.type === IDocEventType.PlannedEvent) {
        //       event.idocMapping.idoc = oEvent.idocMapping.idoc;
        //     }
        //   });
        // }
      },

      onIDocInputChange: function (oEvent) {
        var oInput = oEvent.getSource();
        // trim pre and post blank space
        var sValue = oInput.getValue().trim();
        oInput.setValue(sValue);
      },

      _configValueHelpSelection: function (aItems, sInputValue) {
        aItems.forEach(function (oItem) {
          oItem.selected = oItem.name === sInputValue;
        });
      },

      handleValueHelp: function (oEvent) {
        this._input = oEvent.getSource();
        var sInputValue = this._input.getValue();
        var aItems = this.getModel("iDocValueHelp").getProperty("/items");
        this._configValueHelpSelection(aItems, sInputValue);

        var oView = this.getView();
        var oValueHelpID = this.createFragmentId("idocValueHelp");
        if (!Fragment.byId(oValueHelpID, "idocValueHelpDialog")) {
          Fragment.load({
            id: oValueHelpID,
            name: "com.sap.gtt.v2.model.manage.view.fragments.IDocValueHelp",
            controller: this,
          }).then(function (oDialog) {
            oView.addDependent(oDialog);
            oDialog.open();
          });
        } else {
          Fragment.byId(oValueHelpID, "idocValueHelpDialog").open();
        }
      },

      getIDocEventCodes: function (objectType) {
        var model = this.getModel("store");
        var idocPresets = model.getProperty(IDOC_PRESETS_PATH);

        var preset = idocPresets.find(function (item) {
          return item.name === objectType;
        });

        // return empty array if objectType === 'Others'
        if (!preset) {
          return [];
        }

        var docItem =
          preset.docs.find(function (doc) {
            return doc.idoc === IDOC.E1EVMHDR02;
          }) || {};

        return docItem.events || [];
      },

      _filterSelectedEventCodes: function (eventCodes) {
        var that = this;
        var aFilteredEventCodes = [];
        if (eventCodes.length > 0) {
          eventCodes.forEach(function (eventCode) {
            if (eventCode.selected) {
              aFilteredEventCodes.push(eventCode);
            } else {
              if (!that.aSelectedEventCodes.includes(eventCode.type)) {
                aFilteredEventCodes.push(eventCode);
              }
            }
          });
        }
        return aFilteredEventCodes;
      },

      handleEventCodeValueHelp: function (oEvent) {
        var that = this;
        this._input = oEvent.getSource();
        var sInputValue = this._input.getValue();
        // To handle the end user do not press enter to confirm the input value, fireChagne to update the new value.
        this._input.fireChange();
        this.storeSelectedEventCodes();
        var eventCodes = this.getIDocEventCodes(this._erpType);
        eventCodes.forEach(function (eventCode) {
          eventCode.selected = eventCode.type === sInputValue;
          // Memory the selected eventCode type
          if (eventCode.selected) {
            that.aSelectedEventCodes.push(eventCode.type);
          }
        });
        if (this.aSelectedEventCodes && this.aSelectedEventCodes.length > 0) {
          eventCodes = this._filterSelectedEventCodes(eventCodes);
        }
        var oModel = new JSONModel({
          eventCodes: eventCodes,
        });

        var options = {
          fragmentId: "idocEventCodeValueHelpDialog",
          fragmentName: "IDocEventCodeValueHelp",
          controller: merge({}, this, {
            modelName: "dialog",
            handleConfirm: function (oEvent) {
              this.handleConfirm(oEvent);
            }.bind(this),
            handleClose: function (oEvent) {
              var dialog = oEvent.getSource();
              dialog.destroy();
            },
            handleSearch: function (oEvent) {
              this.handleSearch(oEvent);
            }.bind(this),
          }),
          model: oModel,
        };
        this.openDialog(options);
      },

      handleSegmentValueHelp: function (oEvent) {
        var oView = this.getView();
        var oFieldsValueHelpID = this.createFragmentId("idocSegmentValueHelp");
        this._input = oEvent.getSource();

        this.setSegmentValueHelp();
        var sInputValue = this._input.getValue();
        var aSegments = this.getModel("iDocValueHelp").getProperty("/segment");
        this._configValueHelpSelection(aSegments, sInputValue);

        if (!Fragment.byId(oFieldsValueHelpID, "idocSegmentValueHelpDialog")) {
          Fragment.load({
            id: oFieldsValueHelpID,
            name: "com.sap.gtt.v2.model.manage.view.fragments.IDocSegmentValueHelp",
            controller: this,
          }).then(function (oDialog) {
            oView.addDependent(oDialog);
            oDialog.open();
          });
        } else {
          Fragment.byId(oFieldsValueHelpID, "idocSegmentValueHelpDialog").open();
        }
      },

      handleFieldsValueHelp: function (oEvent) {
        var oView = this.getView();
        var oFieldsValueHelpID = this.createFragmentId("idocFieldsValueHelp");
        this._input = oEvent.getSource();

        this.setFieldsValueHelp(oEvent);
        var sInputValue = this._input.getValue();
        var aFields = this.getModel("iDocValueHelp").getProperty("/fields");
        this._configValueHelpSelection(aFields, sInputValue);

        if (!Fragment.byId(oFieldsValueHelpID, "idocFieldsValueHelpDialog")) {
          Fragment.load({
            id: oFieldsValueHelpID,
            name: "com.sap.gtt.v2.model.manage.view.fragments.IDocFieldsValueHelp",
            controller: this,
          }).then(function (oDialog) {
            oView.addDependent(oDialog);
            oDialog.open();
          });
        } else {
          Fragment.byId(oFieldsValueHelpID, "idocFieldsValueHelpDialog").open();
        }
      },

      handleConfirm: function (oEvent) {
        var item = oEvent.getParameter("selectedItem");
        var dialog = oEvent.getSource();

        if (item) {
          this._input.setValue(item.getDescription());
        }

        this._input.fireChange();
        dialog.destroy();
      },

      handleClose: function (oEvent) {
        var item = oEvent.getParameter("selectedItem");
        if (item) {
          this._input.setValue(item.getTitle());
        }

        this._input.fireChange();
        var dialog = oEvent.getSource();
        dialog.destroy();
      },

      handleSearch: function (oEvent) {
        var sValue = oEvent.getParameter("value");
        var oFilter = new Filter({
          filters: [
            new Filter("name", FilterOperator.Contains, sValue),
            new Filter("type", FilterOperator.Contains, sValue),
          ],
        });
        var oBinding = oEvent.getSource().getBinding("items");
        oBinding.filter([oFilter]);
      },

      setSegmentValueHelp: function () {
        // get selected item idoc value
        var selectedItem = this._eventsTable.getSelectedItem();
        if (selectedItem) {
          var idocCell = selectedItem.getCells()[1];
          var idocValue = idocCell.getValue();
          var eventCodeCell = selectedItem.getCells()[2];
          var eventCodeValue = eventCodeCell.getValue();
          this.setSegmentValueHelpItems(this._erpType, idocValue, eventCodeValue);
        } else {
          this.setSegmentValueHelpItems(this._erpType, "");
        }
      },

      setSegmentValueHelpItems: function (objectType, idoc, eventCode) {
        var items = [];
        switch (objectType) {
          case ErpObjectType.PurchaseOrderItem:
          case ErpObjectType.SalesOrderHeader:
          case ErpObjectType.SalesOrderItem:
          case ErpObjectType.DeliveryHeader:
          case ErpObjectType.DeliveryItem:
          case ErpObjectType.ShipmentHeader:
            items = this.getSegmentArray(objectType, idoc, eventCode);
            break;
          case ErpObjectType.Others:
            if (idoc === IDOC.E1EHPAO) {
              items = [{ name: IDOC_SEGMENT.E1EHPCP }, { name: IDOC_SEGMENT.E1EHPIP }];
            } else if (idoc === IDOC.E1EVMHDR02) {
              items = [{ name: IDOC_SEGMENT.E1EVMPAR }];
            } else {
              items = [];
            }
            break;
          default:
            items = [];
            break;
        }
        this.getModel("iDocValueHelp").setProperty("/segment", items);
      },

      getSegmentArray: function (objectType, idoc, eventCode) {
        var result = [];
        var presets = this.getModel("store").getProperty(IDOC_PRESETS_PATH);

        var item = presets.find(function (preset) {
          return preset.name === objectType;
        });

        var docs = item.docs;
        var object = docs.find(function (doc) {
          return doc.idoc === idoc;
        });

        if (!object || !object.fields) {
          return [];
        }

        switch (idoc) {
          case IDOC.E1EHPAO:
            object.fields.forEach(function (field) {
              if (result.indexOf(field.idocSegment) === -1) {
                result.push(field.idocSegment);
              }
            });
            break;
          case IDOC.E1EVMHDR02:
            object.fields.forEach(function (field) {
              if (
                eventCode &&
                eventCode === field.eventType &&
                result.indexOf(field.idocSegment) === -1
              ) {
                result.push(field.idocSegment);
              }
            });
            break;
          default:
            result = [];
            break;
        }

        result.sort();

        result = result.map(function (arrayItem) {
          return { name: arrayItem };
        });

        return result;
      },

      setFieldsValueHelp: function (oEvent) {
        var row = oEvent.getSource().getParent();
        var segmentValue = row.getCells()[1].getValue();
        // get selected item idoc value
        var selectedItem = this._eventsTable.getSelectedItem();
        if (selectedItem) {
          var idocCell = selectedItem.getCells()[1];
          var idocValue = idocCell.getValue();
          var eventCodeCell = selectedItem.getCells()[2];
          var eventCodeValue = eventCodeCell.getValue();
          this.setFieldsValueHelpItems(this._erpType, idocValue, eventCodeValue, segmentValue);
        } else {
          this.setFieldsValueHelpItems(this._erpType, "", eventCodeValue, segmentValue);
        }
      },

      setFieldsValueHelpItems: function (objectType, idoc, eventCode, segment) {
        var items = [];
        if (!idoc || !segment) {
          items = [];
        } else {
          items = this.getFieldArray(objectType, idoc, eventCode, segment);
        }
        this.getModel("iDocValueHelp").setProperty("/fields", items);
      },

      getFieldArray: function (objectType, idoc, eventCode, segment) {
        var result = [];
        var presets = this.getModel("store").getProperty(IDOC_PRESETS_PATH);
        var item = presets.find(function (preset) {
          return preset.name === objectType;
        });
        var docs = item.docs;
        var object = docs.find(function (doc) {
          return doc.idoc === idoc;
        });

        if (!object || !object.fields || !segment) {
          return [];
        }

        switch (idoc) {
          case IDOC.E1EHPAO:
            object.fields.forEach(function (field) {
              if (field.idocSegment === segment) {
                result.push(field.idocField);
              }
            });
            break;
          case IDOC.E1EVMHDR02:
            object.fields.forEach(function (field) {
              if (eventCode && eventCode === field.eventType && field.idocSegment === segment) {
                result.push(field.idocField);
              }
            });
            break;
          default:
            result = [];
            break;
        }

        result.sort();

        result = result.map(function (arrayItem) {
          return { name: arrayItem };
        });

        return result;
      },

      /**
       * process user define field into fieldMapping
       * @param {Object} object need to process
       */
      processFieldMapping: function (object) {
        if (!object._ref.idocMapping.fieldMapping) {
          object._ref.idocMapping.fieldMapping = [];
        }

        if (object._ref._category === ModelCategory.Standard) {
          return;
        }

        // need refine, when in edit and create mode, user define field will change
        if (object._ref.idocMapping.fieldMapping.length === 0) {
          // if (object.type === IDocEventType.PlannedEvent) {
          //   var plannedEventExtensions = oStore.getProperty("/plannedEvent/elements");
          //   plannedEventExtensions.forEach(function (item) {
          //     if (item.writable) {
          //       var newField = {};
          //       newField.field = item.name;
          //       object.idocMapping.fieldMapping.push(newField);
          //     }
          //   });
          // } else {
          var elements = object._ref.elements;
          elements.forEach(function (element) {
            // filter AssociationToMany field
            if (!FieldType.isItemAssociationToMany(element)) {
              var newField = {
                _ref: {
                  field: element,
                },
              };
              this.whereUsedListHelper.addMappingItemDependency(newField);

              if (element.type === FieldType.Composition) {
                newField._ref.target = element._ref.target;
                newField.composition = element._ref.target.elements.map(function (compoElement) {
                  var newCompositionField = {
                    _ref: {
                      field: compoElement,
                    },
                  };
                  this.whereUsedListHelper.addMappingItemDependency(newCompositionField);
                  return newCompositionField;
                }, this);
              }
              object._ref.idocMapping.fieldMapping.push(newField);
            }
          }, this);
          // }
        }
      },

      onSwitchChange: function (oEvent) {
        var oControl = oEvent.getSource();
        var bValue = oControl.getState();
        if (!bValue) {
          var fragmentId = this.getView().createId("frag");
          var aot = Fragment.byId(fragmentId, "aot");
          aot.fireValidationSuccess({
            element: aot,
            property: "value",
            message: "",
          });
        }
      },
    });
  }
);
