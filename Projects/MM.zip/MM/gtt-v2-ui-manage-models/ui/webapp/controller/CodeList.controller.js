sap.ui.define(
  [
    "./BaseEntityList",
    "sap/m/GroupHeaderListItem",
    "sap/base/util/merge",
    "../constant/ObjectType",
    "../constant/ModelCategory",
    "./EditCodeListDialog",
  ],
  function (
    BaseEntityList,
    GroupHeaderListItem,
    merge,
    ObjectType,
    ModelCategory,
    EditCodeListDialog
  ) {
    "use strict";
    return BaseEntityList.extend("com.sap.gtt.v2.model.manage.controller.CodeList", {
      initCreateAndEditDialogController: function () {
        var oDialogController = new EditCodeListDialog();
        this.oDialogController = this.mergeViewFunctionsIntoCreateAndEditDialog(oDialogController);

        this._createAndEditDialogFragmentId = "editCodeListDialog";
        this._createAndEditDialogFragmentName = "EditCodeListDialog";
      },

      getGroupHeader: function (oGroup) {
        var sId = this.createId(oGroup.key);

        var bShouldGroup =
          this.getModel("store").getProperty("/modelCategory") === ModelCategory.Standard;

        var sTitle = this.getResourceBundle().getText("userDefined");
        if (oGroup.key === ModelCategory.Standard) {
          sTitle = this.getResourceBundle().getText("standard");
        }

        return new GroupHeaderListItem({
          id: sId,
          title: sTitle,
          visible: bShouldGroup,
        });
      },

      onItemSelected: function (listItem) {
        if (listItem) {
          var sPath = listItem.getBindingContextPath();
          var oDetailView = this.byId("detailView");
          oDetailView.bindElement({
            path: sPath,
            model: "store",
          });
        }
      },

      setSideContentEditable: function (isEditable) {
        this.byId("detailView")
          .byId("codeListUserCodesView")
          .getModel("view")
          .setProperty("/isCreateEnabled", isEditable);
      },

      getCreateDialogData: function () {
        return {
          name: "",
          _parent: null,
          _objectType: ObjectType.CodeList,
          _category: ModelCategory.User,
        };
      },

      onDialogAccepted: function (type, data, context) {
        if (type === "edit") {
          this.modify(context.getObject(), data);
          this.refreshBinding();
        } else {
          // Create in model
          var items = this.getListItems();
          var newItems = items.slice();
          var newItem = merge(
            {
              values: [
                {
                  name: "",
                  code: "",
                  translation: {
                    name: {
                      textType: "NAME",
                      translation: {},
                    },
                  },
                  _category: ModelCategory.User,
                },
              ],
            },
            data
          );

          newItems.push(newItem);
          this.setListItems(newItems);

          this.refreshBinding();
          this.updateListSelection(newItem.name);
          this.scrollToNewCreatedItem(data.name);
        }
        this.changeToEditMode();
      },
    });
  }
);
