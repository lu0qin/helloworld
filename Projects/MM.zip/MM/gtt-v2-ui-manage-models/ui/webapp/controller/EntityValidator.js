sap.ui.define(
  ["sap/ui/core/MessageType", "../constant/ObjectType", "../constant/FieldType"],
  function (MessageType, ObjectType, FieldType) {
    "use strict";

    var INFO_IS_USED_BY_MAPPING_PATH = "/info/isUsedByMapping";
    var INFO_IS_USED_BY_ASSO_TO_MANY_PATH = "/info/isUsedByAssociationToMany";
    var INFO_IS_USED_BY_MATCH_EXTENSION_FIELD_PATH = "/info/isUsedByMatchExtensionField";

    var EntityValidator = {};

    /**
     * Validate if the sName string is mandatory but empty
     * @param {string} sValue the value of the current input
     * @param {object} oResourceBundle resource bundle to get i18n text
     * @return {array} return error array with i18n error message when the name is empty
     */
    EntityValidator.validateEmpty = function (sValue, oResourceBundle) {
      var aErrors = [];

      if (sValue === "") {
        aErrors.push({
          message: oResourceBundle.getText("mandatoryFieldMissing"),
          type: MessageType.Error,
          additionalText: oResourceBundle.getText("mandatoryFieldMissing"),
          isPositional: false,
        });
      }

      return aErrors;
    };

    /**
     * Validate if the sName string not start with GTT when its parent is Standard
     * @param {string} sValue the value of the current input
     * @param {string} sObjectType enum value of Object Type of item to check
     * @param {string} sParentObjectType enum value of Object Type of the parent of the item to check
     * @param {object} oResourceBundle resource bundle to get i18n text
     * @return {array} return error array with i18n error message when the name is empty
     */
    EntityValidator.validateNotStartWithZZ = function (
      sValue,
      sObjectType,
      sParentObjectType,
      oResourceBundle
    ) {
      function _getValidationErrorI18NText(objectType, parentObjectType, resourceBundle) {
        function _getObjectTypeI18NText(key) {
          return resourceBundle.getText("ObjectType." + key);
        }

        // User Field - Tracked Process/Field Type/Event Type
        if (objectType === ObjectType.UserField) {
          return resourceBundle.getText("fieldMustStartWithZZ", [
            _getObjectTypeI18NText(parentObjectType),
          ]);
        }

        // User Field - Planned Event Extension
        if (objectType === ObjectType.PlannedEventExtension) {
          return resourceBundle.getText("fieldMustStartWithZZ", [
            _getObjectTypeI18NText(objectType),
          ]);
        }

        // Code - Code List
        if (objectType === ObjectType.Code) {
          return resourceBundle.getText("codeMustStartWithZZ");
        }

        // Tracked Process/Field Type/Event Type/Code List
        if (
          objectType === ObjectType.ProcessType ||
          objectType === ObjectType.ItemType ||
          objectType === ObjectType.EventType ||
          objectType === ObjectType.CodeList
        ) {
          return resourceBundle.getText("entityNameMustStartWithZZ", [
            _getObjectTypeI18NText(objectType),
          ]);
        }

        // Application Object Type - IDOC Mapping
        if (objectType === "" && parentObjectType === ObjectType.ProcessType) {
          return resourceBundle.getText("aotMustStartWithZZ");
        }

        return "";
      }

      var aErrors = [];

      var regex = /^[zZ][zZ]/i;
      if (!regex.test(sValue)) {
        var sI18NText = _getValidationErrorI18NText(
          sObjectType,
          sParentObjectType,
          oResourceBundle
        );

        aErrors.push({
          message: sI18NText,
          type: MessageType.Error,
          additionalText: sI18NText,
          isPositional: false,
        });
      }

      return aErrors;
    };

    /**
     * Validate if the sName string starts with 'GTT'(case-insensitive)
     * @param {string} sValue the value of the current input
     * @param {object} oResourceBundle resource bundle to get i18n text
     * @return {array} return error array with i18n error message when the name starts with letters 'GTT'
     */
    EntityValidator.validateStartWithGTT = function (sValue, oResourceBundle) {
      var aErrors = [];

      var regex = /^gtt/i;

      if (regex.test(sValue)) {
        aErrors.push({
          message: oResourceBundle.getText("nameNotStartWithGTT"),
          type: MessageType.Error,
          additionalText: oResourceBundle.getText("nameNotStartWithGTT"),
          isPositional: false,
        });
      }

      return aErrors;
    };

    /**
     * Validate if the sName string violates the constraints
     * @param {string} sValue the value of the current input
     * @param {boolean} isStartWithLetter indicates if the string should start with letter
     * @param {boolean} isHaveUnderscore indicates if the string should have underscore
     * @param {object} oResourceBundle resource bundle to get i18n text
     * @return {array} return error array with i18n error message when the name violates the constraints
     */
    EntityValidator.validateStringConstraint = function (
      sValue,
      isStartWithLetter,
      isHaveUnderscore,
      oResourceBundle
    ) {
      var aErrors = [];

      var regex;
      if (isStartWithLetter) {
        // have underscore: Used in TrackingIdType of Tracked Process, Name of User-Defined Field
        // not have underscore: Used in Entity Name
        regex = isHaveUnderscore ? /^[a-zA-Z]+[a-zA-Z0-9_]*$/ : /^[a-zA-Z]+[a-zA-Z0-9]*$/;
      } else if (isHaveUnderscore) {
        // have underscore: Used in Code of Code List
        regex = /^[a-zA-Z0-9_]*$/;
      }

      if (regex && !regex.test(sValue)) {
        var errorMessage = "";
        if (isStartWithLetter) {
          errorMessage = isHaveUnderscore
            ? oResourceBundle.getText("onlyNumbersLetterUnderscoresAllowedAndStartWithLetters")
            : oResourceBundle.getText("onlyNumbersLettersAllowedAndStartWithLetters");
        } else if (isHaveUnderscore) {
          errorMessage = oResourceBundle.getText("onlyNumbersLettersUnderscoresAllowed");
        }

        aErrors.push({
          message: errorMessage,
          type: MessageType.Error,
          additionalText: errorMessage,
          isPositional: false,
        });
      }

      return aErrors;
    };

    /**
     * Validate if the sName is used by other user-defined entity
     * @param {string} sName the value of the current entity name input
     * @param {string} sPreviousName the value of the original entity name
     * @param {object} oContext the binding context of store model for the entity list
     * @param {object} oResourceBundle resource bundle to get i18n text
     * @return {array} return error array with i18n error message with parameters when the name is duplicate
     */
    EntityValidator.validateDuplicateEntityName = function (
      sName,
      sPreviousName,
      oContext,
      oResourceBundle
    ) {
      var aErrors = [];

      // In edit mode, ignore new name with same letters with the previous name
      if (sPreviousName && sName && sPreviousName.toLowerCase() === sName.toLowerCase()) {
        return aErrors;
      }

      var aEntities = this.getUserDefinedEntities(oContext);
      var duplicateItem = aEntities.find(function (item) {
        return item.name.toLowerCase() === sName.toLowerCase();
      });

      if (duplicateItem) {
        var sUsedByObjectName =
          (duplicateItem.context && duplicateItem.context.concat(".", duplicateItem.name)) ||
          duplicateItem.name;
        var sSectionName = this.getEntitySectionName(duplicateItem, oResourceBundle);

        aErrors.push({
          message: oResourceBundle.getText("entityNameNotUniqueInModel", [
            sUsedByObjectName,
            sSectionName,
          ]),
          type: MessageType.Error,
          additionalText: oResourceBundle.getText("name"),
          isPositional: false,
        });
      }

      return aErrors;
    };

    /**
     * Validate if the sName is used by other user-defined field under the current entity
     * @param {string} sName the value of the current field name input
     * @param {string} sPreviousName the value of the original entity name
     * @param {object} oCurrentElements the children elements of entity which owns the field under creating/editing
     * @param {object} oResourceBundle resource bundle to get i18n text
     * @return {array} return error array with i18n error message when the name is duplicate
     */
    EntityValidator.validateDuplicateEntityFieldName = function (
      sName,
      sPreviousName,
      oCurrentElements,
      oResourceBundle
    ) {
      var aErrors = [];

      // In edit mode, ignore new name with same letters with the previous name
      if (sPreviousName && sName && sPreviousName.toLowerCase() === sName.toLowerCase()) {
        return aErrors; // []
      }

      var oDuplicateItem = oCurrentElements.find(function (element) {
        return element.name.toLowerCase() === sName.toLowerCase();
      });

      if (oDuplicateItem) {
        aErrors.push({
          message: oResourceBundle.getText("fieldNameNotUniqueInEntity"),
          type: MessageType.Error,
          additionalText: oResourceBundle.getText("name"),
          isPositional: false,
        });
      }

      return aErrors;
    };

    /**
     * Validate if the sName is used by other reserved entity defined in CoreModel
     * @param {string} sName the value of the current entity name input
     * @param {object} oContext the binding context of store model for the entity list
     * @param {object} oResourceBundle resource bundle to get i18n text
     * @return {array} return error array with i18n error message when the name is duplicate with reserved entity name
     */
    EntityValidator.validateReservedEntityName = function (sName, oContext, oResourceBundle) {
      var aErrors = [];

      var oModel = oContext.getModel("store");
      var oCoreModel = oModel.getProperty("/model/coreModel");
      var aReservedItems = this.getReservedEntities(oCoreModel);
      var reservedItem = aReservedItems.find(function (item) {
        return item.name.toLowerCase() === sName.toLowerCase();
      });

      if (reservedItem) {
        aErrors.push({
          message: oResourceBundle.getText("nameReserved"),
          type: MessageType.Error,
          additionalText: oResourceBundle.getText("name"),
          isPositional: false,
        });
      }

      return aErrors;
    };

    /**
     * Validate if the sName is used by other reserved entity field defined in CoreModel
     * @param {string} sName the value of the current field name input
     * @param {object} oParentObject the object of entity which owns the field under creating/editing
     * @param {object} oModel store model
     * @param {object} oResourceBundle resource bundle to get i18n text
     * @return {array} return error array with i18n error message when the name is duplicate with reserved field name
     */
    EntityValidator.validateReservedEntityFieldName = function (
      sName,
      oParentObject,
      oModel,
      oResourceBundle
    ) {
      var aErrors = [];

      var oCoreModel = oModel.getProperty("/model/coreModel");
      var aReservedItems = this.getReservedEntityFields(oParentObject, oCoreModel);
      var oDuplicateElement = aReservedItems.find(function (element) {
        return element.name.toLowerCase() === sName.toLowerCase();
      });

      if (oDuplicateElement) {
        aErrors.push({
          message: oResourceBundle.getText("nameReserved"),
          type: MessageType.Error,
          additionalText: oResourceBundle.getText("name"),
          isPositional: false,
        });
      }

      return aErrors;
    };

    /**
     * Validate if the chosen inherit event have reserved fields conflicted with the current user-defined fields in edit mode
     * @param {string} sInheritKey dialog model
     * @param {object} oContext context of event type under edit
     * @param {object} oResourceBundle resource bundle to get i18n text
     * @return {array} return error array with i18n error message when there is conflict
     */
    EntityValidator.validateOverlappedEntityFields = function (
      sInheritKey,
      oContext,
      oResourceBundle
    ) {
      var aErrors = [];

      var oStoreModel = oContext.getModel("store");
      var oOriginItem = oContext.getObject();

      var oCoreModelEventTypes = oStoreModel.getProperty("/model/coreModel/eventTypes");
      var aReservedItems = this.getReservedEventTypeFields(sInheritKey, oCoreModelEventTypes);
      var aReservedNames = aReservedItems.map(function (field) {
        return field.name;
      });

      var aEventTypeFields = oOriginItem.elements || [];
      // Get the user-defined fields overlapped with the reserved fields of the chosen inherited event
      var aOverlappedFields = aEventTypeFields.filter(function (field) {
        return aReservedNames.includes(field.name);
      });

      if (aOverlappedFields && aOverlappedFields.length > 0) {
        var aOverlappedFieldNames = aOverlappedFields.map(function (field) {
          // Add single quote to every name
          return "'".concat(field.name, "'");
        });
        aErrors.push({
          message: oResourceBundle.getText(
            "overlapReservedField",
            aOverlappedFieldNames.toString()
          ),
          type: MessageType.Error,
          additionalText: oResourceBundle.getText("inherit"),
          isPositional: false,
        });
      }

      return aErrors;
    };

    /**
     * Get reserved entity set from core model
     * @param {object} oCoreModel source data of core model
     * @return {array} return reserved entity set
     */
    EntityValidator.getReservedEntities = function (oCoreModel) {
      var processTypes = oCoreModel.processTypes || [];
      var itemTypes = oCoreModel.itemTypes || [];
      var eventTypes = oCoreModel.eventTypes || [];
      var codeLists = oCoreModel.codeLists || [];
      var others = oCoreModel.others || [];

      // merge JSON Model data into array
      return [].concat(processTypes, itemTypes, eventTypes, codeLists, others);
    };

    /**
     * Get reserved entity field set from core model
     * @param {object} oCurrentItem user-defined entity which owns the field under creating/editing
     * @param {object} oCoreModel source data of core model
     * @return {array} return reserved entity fields set
     */
    EntityValidator.getReservedEntityFields = function (oCurrentItem, oCoreModel) {
      var aReservedElements = [];

      // Planned Event Extension
      if (!oCurrentItem._objectType) {
        var oParentPlannedEvent = oCoreModel.itemTypes.find(function (itemType) {
          return itemType.name === "PlannedEvent";
        });
        aReservedElements = (oParentPlannedEvent && oParentPlannedEvent.elements) || [];
      }

      // ProcessType and EventType have inherited reserved elements
      // ProcessType: inherit from 'TrackedProcess'
      if (oCurrentItem._objectType === ObjectType.ProcessType) {
        var oParentProcessType = oCoreModel.processTypes.find(function (processType) {
          return processType.name === "TrackedProcess";
        });
        aReservedElements = (oParentProcessType && oParentProcessType.elements) || [];
      }

      // EventType: inherit from its own property 'parent'
      if (oCurrentItem._objectType === ObjectType.EventType) {
        aReservedElements = this.getReservedEventTypeFields(
          oCurrentItem.parent.target,
          oCoreModel.eventTypes
        );
      }

      return aReservedElements;
    };

    /**
     * Recursive method to get all the reserved event type fields through the inheritance hierarchy
     * @param {string} sInheritKey the CoreModel Event to start from
     * @param {object} oCoreModelEventTypes source data of event types in core model
     * @return {array} return reserved event type fields set
     */
    EntityValidator.getReservedEventTypeFields = function (sInheritKey, oCoreModelEventTypes) {
      var aReservedFields = [];

      if (sInheritKey) {
        var sParentName = sInheritKey.split(".")[1];
        var oParentItem = oCoreModelEventTypes.find(function (eventType) {
          return eventType.name === sParentName;
        });

        aReservedFields = aReservedFields.concat(oParentItem.elements);

        if (oParentItem.parent && oParentItem.parent.target) {
          aReservedFields = aReservedFields.concat(this.getReservedEventTypeFields(oParentItem.parent.target, oCoreModelEventTypes));
        }
      }

      return aReservedFields;
    };

    /**
     * Get user-defined entity set from draft model
     * @param {object} oContext the binding context of store model for the entity list
     * @return {array} return user-defined entity set
     */
    EntityValidator.getUserDefinedEntities = function (oContext) {
      var oModel = oContext.getModel("store");
      // Add entity type information to entity data
      var processTypes = oModel.getProperty("/processTypes");
      var itemTypes = oModel.getProperty("/itemTypes");
      // Filter out core model events
      var eventTypes = oModel.getProperty("/eventTypes").filter(function (eventType) {
        return eventType.context !== "CoreModel";
      });
      var codeLists = oModel.getProperty("/codeLists");

      return [].concat(processTypes, itemTypes, eventTypes, codeLists);
    };

    /**
     * Get i18n name of the section which the target entity item is located
     * @param {object} oItem the target entity item
     * @param {object} oResourceBundle resource bundle to get i18n text
     * @return {string} return i18n text of section name
     */
    EntityValidator.getEntitySectionName = function (oItem, oResourceBundle) {
      var objectTypeText = "";

      switch (oItem._objectType) {
        case ObjectType.ProcessType:
          objectTypeText = oResourceBundle.getText("trackedProcess");
          break;
        case ObjectType.ItemType:
          objectTypeText = oResourceBundle.getText("fieldTypePool");
          break;
        case ObjectType.EventType:
          objectTypeText = oResourceBundle.getText("eventTypePool");
          break;
        case ObjectType.CodeList:
          objectTypeText = oResourceBundle.getText("codeList");
          break;
      }
      return objectTypeText;
    };

    /**
     * Validate if the the change of item name will cause update or delete
     * @param {object} oModel dialog model
     * @param {object} oResourceBundle resource bundle to get i18n text
     * @return {array}  return warning message array, [] if will not cause update or delete
     */
    EntityValidator.validateNameUpdate = function (oModel, oResourceBundle) {
      var aWarnings = [];

      var currentItem = oModel.getProperty("/data");
      var originItem = oModel.getProperty("/context").getObject();

      if (currentItem.name === originItem.name) {
        return aWarnings; // []
      }

      var warningMsg = "";
      if (
        originItem._objectType === ObjectType.UserField ||
        originItem._objectType === ObjectType.PlannedEventExtension
      ) {
        if (
          oModel.getProperty(INFO_IS_USED_BY_MAPPING_PATH) ||
          oModel.getProperty(INFO_IS_USED_BY_MATCH_EXTENSION_FIELD_PATH) ||
          oModel.getProperty(INFO_IS_USED_BY_ASSO_TO_MANY_PATH)
        ) {
          warningMsg = oResourceBundle.getText("usedByOtherObjects");
        }
      } else {
        if (oModel.getProperty("/info/isUsed")) {
          warningMsg = oResourceBundle.getText("usedByOtherObjects");
        }
      }

      if (warningMsg) {
        aWarnings.push({
          message: warningMsg,
          type: MessageType.Warning,
          additionalText: oResourceBundle.getText("name"),
          isPositional: false,
        });
      }

      return aWarnings;
    };

    /**
     * Validate if the the change of item context will cause update or delete
     * @param {object} oModel dialog model
     * @param {object} oResourceBundle resource bundle to get i18n text
     * @return {string} return warning message, "" if will not cause update or delete
     */
    EntityValidator.validateContextUpdate = function (oModel, oResourceBundle) {
      var currentItem = oModel.getProperty("/data");
      var originItem = oModel.getProperty("/context").getObject();

      var type = oModel.getProperty("/type");

      if (
        type === "create" ||
        (originItem._ref &&
          currentItem._ref &&
          currentItem._ref.context === originItem._ref.context)
      ) {
        return "";
      }

      var warningMsg = "";
      if (oModel.getProperty("/info/isUsed")) {
        warningMsg = oResourceBundle.getText("usedByOtherObjects");
      }

      return warningMsg;
    };

    /**
     * Validate if the chosen item type target will cause update or delete to idoc/vp mapping
     * @param {object} oModel dialog model
     * @param {object} oResourceBundle resource bundle to get i18n text
     * @returns {string} return "" if no need to delete mapped idoc/vp item, otherwise return warning message to update field type
     */
    EntityValidator.validateItemTypeTarget = function (oModel, oResourceBundle) {
      var warningMsg = "";

      var currentItem = oModel.getProperty("/data");
      var originItem = oModel.getProperty("/context").getObject();

      var isUsedByMapping = oModel.getProperty(INFO_IS_USED_BY_MAPPING_PATH);

      var resultTextArr = [];
      // If used by idoc/vp mapping, check type change between composition and other types
      // only check UserField of Process Type, Event Type
      if (
        isUsedByMapping &&
        this.checkIfParentNotItemType(originItem) &&
        originItem.type === currentItem.type &&
        originItem._ref.target !== currentItem.itemTypeTarget
      ) {
        resultTextArr.push(oResourceBundle.getText("iDocIntegrationFieldMapping"));
        resultTextArr.push(oResourceBundle.getText("vpIntegrationFieldMapping"));
      }

      if (resultTextArr.length !== 0) {
        var objectsText = resultTextArr.join(",\n");
        warningMsg = oResourceBundle.getText("changeFieldTypeUpdate", objectsText);
      }

      return warningMsg;
    };

    /**
     * Validate if the selected type will cause update or delete to referenced objects
     * @param {object} oModel dialog model
     * @param {object} oResourceBundle resource bundle to get i18n text
     * @returns {string} return "" if no need to delete mapped idoc/vp item, otherwise return warning message to update field type
     */
    EntityValidator.validateFieldType = function (oModel, oResourceBundle) {
      var warningMsg = "";

      var currentItem = oModel.getProperty("/data");
      var originItem = oModel.getProperty("/context").getObject();

      // type not changed, skip
      if (currentItem.type === originItem.type) {
        return "";
      }

      var isUsedByMapping = oModel.getProperty(INFO_IS_USED_BY_MAPPING_PATH);
      var isUsedByMatchExtensionField = oModel.getProperty(
        INFO_IS_USED_BY_MATCH_EXTENSION_FIELD_PATH
      );
      var isUsedByAssociationToMany = oModel.getProperty(INFO_IS_USED_BY_ASSO_TO_MANY_PATH);

      var resultTextArr = [];
      // If used by matchExtensionField, check any type change
      // only check UserField of Event Type or PlannedEventExtension
      if (isUsedByMatchExtensionField) {
        resultTextArr.push(oResourceBundle.getText("actualPlannedMatch"));
        if (originItem._objectType === ObjectType.PlannedEventExtension) {
          resultTextArr.push(oResourceBundle.getText("plannedPlannedMatch"));
        }
      }

      // If used by idoc/vp mapping, check type change between composition and other types
      // only check UserField of Process Type or Event Type
      if (
        isUsedByMapping &&
        this.checkIfParentNotItemType(originItem) &&
        (currentItem.type === FieldType.AssociationToMany ||
          originItem.type === FieldType.Composition ||
          currentItem.type === FieldType.Composition)
      ) {
        resultTextArr.push(oResourceBundle.getText("iDocIntegrationFieldMapping"));
        resultTextArr.push(oResourceBundle.getText("vpIntegrationFieldMapping"));
      }

      // If used by asso-to-many field, check type change between asso-to-one and other types
      // only check UserField of Process Type
      if (isUsedByAssociationToMany) {
        resultTextArr.push(oResourceBundle.getText("associationToManyUserModelField"));
      }

      if (resultTextArr.length !== 0) {
        var objectsText = resultTextArr.join(",\n");
        warningMsg = oResourceBundle.getText("changeTypeUpdate", objectsText);
      }

      return warningMsg;
    };

    EntityValidator.checkIfParentNotItemType = function (item) {
      return item._parent && item._parent._objectType !== ObjectType.ItemType;
    };

    /**
     * Validate if the selected type will cause update or delete to referenced objects
     * @param {object} oDialogModel dialog model
     * @param {object} oResourceBundle resource bundle to get i18n text
     * @returns {string} return "" if no need to delete related AssociationToMany field
     */
    EntityValidator.validateProcessTypeTarget = function (oDialogModel, oResourceBundle) {
      var sWarningMsg = "";

      var oProcessTypeTarget = oDialogModel.getProperty("/data/processTypeTarget");
      var oOriginTarget = oDialogModel.getProperty("/context").getProperty("_ref/target");
      var bIsUsedByAssoToMany = oDialogModel.getProperty(INFO_IS_USED_BY_ASSO_TO_MANY_PATH);
      var sDialogType = oDialogModel.getProperty("/type");
      if (bIsUsedByAssoToMany && sDialogType === "edit" && oOriginTarget !== oProcessTypeTarget) {
        sWarningMsg = oResourceBundle.getText(
          "changeProcessTypeUpdate",
          oResourceBundle.getText("associationToManyUserModelField")
        );
      }

      return sWarningMsg;
    };

    /**
     * Check if User Field:
     * 1. Type is AssociationToOne
     * 2. Used by other AssociationToMany User Field as backlink
     * 3. Type is changed, or type is always AssociationToOne but target is changed
     *
     * @param {object} originItem original item object
     * @param {object} newItem current item object after edit
     * @param {boolean} isUsedByAssociationToMany if the item is used by other AssociationToMany User Field
     *
     * @returns {boolean} true if need to delete reference AssociationToMany User Field
     * */
    EntityValidator.checkIfDeleteAssoToManyUserFields = function (
      originItem,
      newItem,
      isUsedByAssociationToMany
    ) {
      if (!isUsedByAssociationToMany) {
        return false;
      }

      function _isTargetChanged() {
        return (
          FieldType.isItemAssociationToOne(newItem) &&
          originItem._ref &&
          newItem._ref &&
          originItem._ref.target !== newItem._ref.target
        );
      }

      return (
        FieldType.isItemAssociationToOne(originItem) &&
        (_isTargetChanged() || !FieldType.isItemAssociationToOne(newItem))
      );
    };

    /**
     * Check if User Field:
     * 1. Type is always Composition but the target is changed
     * 2. Type is changed from/to Composition
     * 3. Type is changed from/to AssociationToMany
     *
     * @param {object} originItem original item object
     * @param {object} newItem new item object after edit
     *
     * @returns {boolean} true if need to delete IDOC/VP mapping items
     * */
    EntityValidator.checkIfUpdateMappingItems = function (originItem, newItem) {
      var originType = originItem.type;
      var newType = newItem.type;

      // no need to update for Item Type, Planned Event Extension
      if (
        !originItem._parent ||
        (originItem._parent && originItem._parent._objectType === ObjectType.ItemType)
      ) {
        return false;
      }

      /* check if type changed from/to asso-to-many */
      function _ifTypeChangedBetweenAssoToManyAndOthers() {
        var isOriginAssoToMany = FieldType.isItemAssociationToMany(originItem);
        var isNewAssoToMany = FieldType.isItemAssociationToMany(newItem);
        return isOriginAssoToMany !== isNewAssoToMany && (isOriginAssoToMany || isNewAssoToMany);
      }

      /* check if type changed from/to composition */
      function _ifTypeChangedBetweenCompositionAndOthers() {
        return (
          originType !== newType &&
          (originType === FieldType.Composition || newType === FieldType.Composition)
        );
      }

      /* check if originType and newType is composition and the reference target is changed */
      function ifCompositionTargetChanged() {
        function _ifTypeAlwaysComposition() {
          return (
            originType === newType &&
            originType === FieldType.Composition &&
            newType === FieldType.Composition
          );
        }
        return (
          _ifTypeAlwaysComposition() &&
          originItem._ref &&
          newItem._ref &&
          originItem._ref.target !== newItem._ref.target
        );
      }

      return (
        _ifTypeChangedBetweenAssoToManyAndOthers() ||
        _ifTypeChangedBetweenCompositionAndOthers() ||
        ifCompositionTargetChanged()
      );
    };

    /**
     * Check if User Field:
     * 1. Field is used by Match Extension Field
     * 2. Type is changed
     *
     * @param {object} originItem original item object
     * @param {object} newItem new item object after edit
     * @param {boolean} isUsedByMatchExtensionField if the item is used by match extension field
     *
     * @returns {boolean} true if need to delete match extension fields
     * */
    EntityValidator.checkIfDeleteReferenceForMatchExtensionField = function (
      originItem,
      newItem,
      isUsedByMatchExtensionField
    ) {
      return isUsedByMatchExtensionField && originItem.type !== newItem.type;
    };

    EntityValidator.validateAssoToOneFieldDuplicateWithCurrentFieldName = function (
      sValue,
      oDialogModel,
      aElements,
      oResourceBundle
    ) {
      var aErrors = [];

      var sCurrentName = oDialogModel.getProperty("/data/name");
      var oCurrentFieldParent = oDialogModel.getProperty("/data/_parent");
      var oTargetProcessType = oDialogModel.getProperty("/data/processTypeTarget");

      // regular duplicate check for elements in target process type
      var aDuplicateEntityFieldError = EntityValidator.validateDuplicateEntityFieldName(
        sValue,
        "",
        aElements,
        oResourceBundle
      );

      // check if the current name of the field is same as the name of the asso-to-one field to create
      if (
        (oCurrentFieldParent === oTargetProcessType &&
          sCurrentName.toLowerCase() === sValue.toLowerCase()) ||
        aDuplicateEntityFieldError.length > 0
      ) {
        aErrors.push({
          message: oResourceBundle.getText(
            "newAssoToOneFieldNameNotUniqueInTargetEntity",
            oTargetProcessType.name
          ),
          type: MessageType.Error,
          additionalText: oResourceBundle.getText("name"),
          isPositional: false,
        });
      }

      return aErrors;
    };

    return EntityValidator;
  }
);
