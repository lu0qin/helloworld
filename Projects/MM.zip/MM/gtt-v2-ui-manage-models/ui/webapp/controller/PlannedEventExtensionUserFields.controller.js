sap.ui.define(
  [
    "./UserFields",
    "sap/ui/model/json/JSONModel",
    "../constant/FieldType",
    "./DeleteHelper",
    "./IntegrationMappingHelper",
    "./WhereUsedListHelper",
  ],
  function (
    UserFieldsController,
    JSONModel,
    FieldType,
    DeleteHelper,
    IntegrationMappingHelper,
    WhereUsedListHelper
  ) {
    "use strict";
    return UserFieldsController.extend(
      "com.sap.gtt.v2.model.manage.controller.PlannedEventExtensionUserFields",
      {
        initModel: function () {
          // Set relevant info for planned event extension view
          var view = new JSONModel({
            tableTitle: "",
            isCreateEnabled: true,
            isShowDppColumn: false,
            isShowKeyColumn: false,
            isShowAuthScopeColumn: false,
            selectedCount: 0,
            type: [],
          });
          this.setModel(view, "view");

          // bind plannedEvent to view
          this.getView().bindElement({
            path: "/plannedEvent",
            model: "store",
          });
        },

        getFieldTypeArray: function () {
          return [
            { name: FieldType.String },
            { name: FieldType.Uuid },
            { name: FieldType.Boolean },
            { name: FieldType.Integer },
            { name: FieldType.Decimal },
            { name: FieldType.Date },
            { name: FieldType.Timestamp },
            // { name: FieldType.CodeList },
          ];
        },

        handleCreateItem: function (newItem) {},
      }
    );
  }
);
