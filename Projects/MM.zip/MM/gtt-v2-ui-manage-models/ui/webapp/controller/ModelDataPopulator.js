sap.ui.define(
  [
    "sap/base/strings/formatMessage",
    "../constant/ObjectType",
    "../constant/FieldType",
    "../constant/ViewMode",
    "../constant/ModelCategory",
  ],
  function (formatMessage, ObjectType, FieldType, ViewMode, ModelCategory) {
    "use strict";

    var ModelDataPopulator = {
      populateData: function (storeModel) {
        var mode = storeModel.getProperty("/mode");
        var modelData = storeModel.getProperty("/model");

        var result = {
          name: modelData.name,
          descr: modelData.descr,
          customModel: this.populateCustomModelData(storeModel),
        };

        if (modelData.translation && modelData.translation.descr) {
          result.translation = {
            descr: modelData.translation.descr,
          };
        }

        if (mode === ViewMode.Create) {
          result.version = "1.0.0";
          result.namespace = storeModel.getProperty("/namespacePrefix").concat(".", modelData.name);
        } else if (mode === ViewMode.Edit) {
          result.version = modelData.version;
          result.namespace = modelData.namespace;
        }

        return result;
      },

      /**
       * Populate Data in order of PlannedEventExtension, SubModels and CodeLists under GTTCodeList
       * @param {object} storeModel the model of store
       * @returns {object} JSON obejct of /customModel
       */
      populateCustomModelData: function (storeModel) {
        var customModelData = storeModel.getProperty("/model/customModel") || {};
        var bIsStandardModel = storeModel.getProperty("/modelCategory") === ModelCategory.Standard;

        var newCustomModelData = {
          eventToAction: customModelData.eventToAction || "",
          plannedEvent: this.populateDataForPlannedEvent(storeModel),
          subModels: [].concat(
            this.populateDataForUserDefinedSubModels(storeModel),
            this.populateDataForCodeList(storeModel)
          ),
        };

        if (!bIsStandardModel) {
          newCustomModelData.eventCorrelationLevel = customModelData.eventCorrelationLevel;
          newCustomModelData.schemaVersion = customModelData.schemaVersion;
        } else {
          newCustomModelData.eventToActionEx = customModelData.eventToActionEx || "";
        }

        return newCustomModelData;
      },

      /**
       * Populate Data for PlannedEventExtension
       * @param {object} storeModel the model of store
       * @returns {object} JSON object of /plannedEvent
       */
      populateDataForPlannedEvent: function (storeModel) {
        var plannedEvent = storeModel.getProperty("/plannedEvent");

        return {
          elements: this.populateDataForElements(plannedEvent.elements),
        };
      },

      /**
       * Populate Data for Process/Item/EventTypes under SubModels
       * @param {object} storeModel the model of store
       * @returns {object} JSON obejct of User-Defined Submodels Array
       */
      populateDataForUserDefinedSubModels: function (storeModel) {
        // result
        var result = [];

        var processTypes = storeModel.getProperty("/processTypes");

        if (processTypes && processTypes.length !== 0) {
          processTypes.forEach(function (processType) {
            result.push({
              name: processType.name,
              enableIDoc: processType.enableIDoc,
              enableVP: processType.enableVP,
              // push itself as the only element in processTypes array
              processTypes: this.populateDataForProcessType(processType),
              // push children ItemTypes into subModel
              itemTypes: this.populateDataForItemTypes(processType, storeModel),
              // push children EventTypes into subModel
              eventTypes: this.populateDataForEventTypes(processType, storeModel),
            });
          }, this);
        }

        return result;
      },

      /**
       * Populate Data for ProcessType from UI Object to JSON
       * @param {object} processType the object of current ProcessType
       * @returns {object} array of the JSON Object of ProcessType
       */
      populateDataForProcessType: function (processType) {
        var result = [];

        var newProcessType = {
          name: processType.name,
          elements: this.populateDataForElements(processType.elements),
          admissiblePlannedEvents: this.populateDataForAdmissiblePlannedEvents(
            processType.admissiblePlannedEvents
          ),
          admissibleUnplannedEvents: this.populateDataForAdmissibleUnplannedEvents(
            processType.admissibleUnplannedEvents
          ),
          idocMapping: this.populateDataForIDocMapping(processType),
          vpMapping: this.populateDataForVPMapping(processType),
        };

        if (processType._category !== ModelCategory.Standard) {
          newProcessType.descr = processType.descr;
          newProcessType.trackingIdType = processType.trackingIdType;
          newProcessType.parent = { target: "CoreModel.TrackedProcess" };
        }

        if (processType.translation && processType.translation.descr) {
          newProcessType.translation = {
            descr: processType.translation.descr,
          };
        }

        result.push(newProcessType);

        return result;
      },

      /**
       * Populate Data for ItemTypes from UI Object to JSON
       * @param {object} processType the object of current ProcessType
       * @param {object} storeModel the model of store
       * @returns {object} array of the JSON Object of ItemTypes
       */
      populateDataForItemTypes: function (processType, storeModel) {
        var result = [];

        var itemTypes = storeModel.getProperty("/itemTypes");

        if (itemTypes && itemTypes.length !== 0) {
          itemTypes.forEach(function (itemType) {
            // find out the parent-child relation
            if (itemType._ref.context === processType) {
              var newItemType = {
                name: itemType.name,
                elements: this.populateDataForElements(itemType.elements),
              };

              if (
                itemType._category !== ModelCategory.Standard ||
                newItemType.elements.length !== 0
              ) {
                result.push(newItemType);
              }
            }
          }, this);
        }

        return result;
      },

      /**
       * Populate Data for EventTypes from UI Object to JSON
       * @param {object} processType the object of current ProcessType
       * @param {object} storeModel the model of store
       * @returns {object} array of the JSON Object of EventTypes
       */
      populateDataForEventTypes: function (processType, storeModel) {
        var result = [];

        var eventTypes = storeModel.getProperty("/eventTypes");

        if (eventTypes && eventTypes.length !== 0) {
          eventTypes.forEach(function (eventType) {
            if (eventType._ref.context === processType) {
              var newEventType = this.formatEventType(eventType);

              if (
                eventType._category !== ModelCategory.Standard ||
                newEventType.elements.length !== 0 ||
                newEventType.idocMapping ||
                newEventType.vpMapping
              ) {
                result.push(newEventType);
              }
            }
          }, this);
        }

        return result;
      },

      formatEventType: function (eventType) {
        var newEventType = {
          name: eventType.name,
          elements: this.populateDataForElements(eventType.elements),
          idocMapping: this.populateDataForIDocMapping(eventType),
          vpMapping: this.populateDataForVPMapping(eventType),
        };

        if (eventType._category !== ModelCategory.Standard) {
          newEventType.descr = eventType.descr;
          newEventType.parent = eventType.parent;
        }

        if (eventType.translation && eventType.translation.descr) {
          newEventType.translation = {
            descr: eventType.translation.descr,
          };
        }

        return newEventType;
      },

      /**
       * Populate Data for CodeLists under GTTCodeList
       * @param {object} storeModel the model of store
       * @returns {object} JSON object of GTTCodeList Submodel
       */
      populateDataForCodeList: function (storeModel) {
        var newCodeLists = [];

        var codeLists = storeModel.getProperty("/codeLists");
        var elementTemplate = [
          {
            name: "code",
            label: "Code",
            type: "string",
            length: 255,
            key: true,
            required: true,
            readable: true,
            writable: true,
          },
          {
            name: "name",
            label: "Name",
            type: "string",
            length: 255,
            localized: true,
            key: false,
            required: true,
            readable: true,
            writable: true,
          },
        ];

        codeLists.forEach(function (codeList) {
          var newValues = [];

          var values = codeList.values;

          values.forEach(function (value) {
            var isNameNotEmpty = this.isCodeNameNotEmpty(value);
            if (value._category !== ModelCategory.Standard && (isNameNotEmpty || !!value.code)) {
              var newValue = {
                code: value.code,
                name: value.name,
              };

              if (value.translation && value.translation.name) {
                newValue.translation = {
                  name: value.translation.name,
                };
              }

              newValues.push(newValue);
            }
          }, this);

          if (codeList._category !== ModelCategory.Standard || newValues.length !== 0) {
            newCodeLists.push({
              name: codeList.name,
              values: newValues,
              elements: elementTemplate,
            });
          }
        }, this);

        return {
          name: "GTTCodeList",
          codeLists: newCodeLists,
        };
      },

      /**
       * Check if name of the code has any value or translation
       * @param {object} item object of code to check
       * @returns {boolean} true for name is not empty
       * */
      isCodeNameNotEmpty: function (item) {
        var nameValue = item.name;
        if (nameValue) {
          return true; // not empty
        }

        var translationList = item.translation.name.translation;
        var translationListKeys = Object.keys(translationList);
        var keysLength = translationListKeys.length;
        // check if ANY translation of name is not empty
        for (var i = 0; i < keysLength; i++) {
          var key = translationListKeys[i];
          if (translationList[key]) {
            return true; // not empty
          }
        }

        return false;
      },

      /**
       * Populate Data for Elements from UI Object to JSON
       * @param {object} elements array of Entity or PlannedEventExtension elements
       * @returns {object} return result array with elements in JSON format
       */
      populateDataForElements: function (elements) {
        var newElements = [];

        if (elements && elements.length !== 0) {
          elements.forEach(function (element) {
            if (element._category !== ModelCategory.Standard) {
              var newElement = this.formatElement(element);
              newElements.push(newElement);
            }
          }, this);
        }

        return newElements;
      },

      formatElement: function (element) {
        var newElement = [
          "name",
          "label",
          "type",
          "readable",
          "writable",
          "key",
          "dpp",
          "authScopes",
        ].reduce(function (result, key) {
          result[key] = element[key];
          return result;
        }, {});

        if (element.translation && element.translation.label) {
          newElement.translation = {
            label: element.translation.label,
          };
        }

        switch (newElement.type) {
          case FieldType.String:
            newElement.length = element.length;
            break;
          case FieldType.Decimal:
            newElement.precision = element.precision;
            newElement.scale = element.scale;
            break;
          case FieldType.Association:
            newElement.target = formatMessage("{0}.{1}", [
              element._ref.target.name,
              element._ref.target.name,
            ]);
            // to-one: {max: 1}
            // to-many: {max: "*"}
            newElement.cardinality = element.cardinality;
            // add backlink value when asso-to-many
            if (FieldType.isItemAssociationToMany(element)) {
              newElement.backlink = element._ref.backlink.name;
            }
            break;
          case FieldType.Composition:
            newElement.target = this.getTargetNameWithContext(element._ref.target);
            // {max: "*"}
            newElement.cardinality = element.cardinality;
            break;
          case FieldType.CodeList:
            newElement.target = formatMessage("{0}.{1}", ["GTTCodeList", element._ref.target.name]);
            break;
          default:
            break;
        }

        return newElement;
      },

      /**
       * Populate Data for AdmissiblePlannedEvents from UI Object to JSON
       * @param {object} plannedEvents array of AdmissiblePlannedEvents in a ProcessType
       * @returns {object} return result array with AdmissiblePlannedEvents in JSON format, return [] if plannedEvents are null or undefined or empty
       */
      populateDataForAdmissiblePlannedEvents: function (plannedEvents) {
        var result = [];

        if (plannedEvents && plannedEvents.length !== 0) {
          plannedEvents.forEach(function (plannedEvent) {
            if (plannedEvent && plannedEvent._ref) {
              var newPlannedEvent = {
                eventType: {
                  target: this.getTargetNameWithContext(plannedEvent._ref.eventType),
                },
                businessToleranceUnit: plannedEvent.businessToleranceUnit,
                businessToleranceValue: Number(plannedEvent.businessToleranceValue), // Use Number to force type-conversion
                matchLocation: plannedEvent.matchLocation,
                maxOverdueDetection: Number(plannedEvent.maxOverdueDetection),
                periodicOverdueDetectionUnit: plannedEvent.periodicOverdueDetectionUnit,
                periodicOverdueDetection: Number(plannedEvent.periodicOverdueDetection),
                technicalToleranceUnit: plannedEvent.technicalToleranceUnit,
                technicalToleranceValue: Number(plannedEvent.technicalToleranceValue),
                matchExtensionFields: this.populateDataForMatchExtensionFields(
                  plannedEvent.matchExtensionFields
                ),
                matchPlanFieldsForUpdatePlan: this.populateDataForMatchPlanFieldsForUpdatePlan(
                  plannedEvent.matchPlanFieldsForUpdatePlan
                ),
              };

              result.push(newPlannedEvent);
            }
          }, this);
        }

        return result;
      },

      /**
       * Populate Data for MatchExtensionFields from UI Object to JSON
       * @param {object} matchExtensionFields array of MatchExtensionFields in an AdmissiblePlannedEvents
       * @returns {object} return result array in JSON format, return [] if matchExtensionFields are null or undefined or empty
       */
      populateDataForMatchExtensionFields: function (matchExtensionFields) {
        var result = [];

        if (matchExtensionFields && matchExtensionFields.length !== 0) {
          matchExtensionFields.forEach(function (field) {
            if (field._ref && field._ref.plannedEventField && field._ref.actualEventField) {
              var newField = {
                plannedEventField: field._ref.plannedEventField.name,
                actualEventField: field._ref.actualEventField.name,
                operator: field.operator,
              };

              result.push(newField);
            }
          }, this);
        }

        return result;
      },

      /**
       * Populate Data for MatchPlanFieldsForUptePlan from UI Object to JSON
       * @param {object} matchPlanFieldsForUpdatePlan array of MatchPlanFieldsForUptePlan in an AdmissiblePlannedEvents
       * @returns {object} return result array in JSON format, return [] if matchPlanFieldsForUpdatePlan are null or undefined or empty
       */
      populateDataForMatchPlanFieldsForUpdatePlan: function (matchPlanFieldsForUpdatePlan) {
        var result = [];

        if (matchPlanFieldsForUpdatePlan && matchPlanFieldsForUpdatePlan.length !== 0) {
          matchPlanFieldsForUpdatePlan.forEach(function (field) {
            if (field) {
              // differ locationAltKey/eventMatchKey from user-defined planned event fields
              var newField = field._ref ? field._ref.name : field.name;
              result.push(newField);
            }
          });
        }

        return result;
      },

      /**
       * Populate Data for AdmissibleUnplannedEvents from UI Object to JSON
       * @param {object} unplannedEvents array of AdmissibleUnplannedEvents in a ProcessType
       * @returns {object} return result array with AdmissibleUnplannedEvents in JSON format, return [] if unplannedEvents are null or undefined or empty
       */
      populateDataForAdmissibleUnplannedEvents: function (unplannedEvents) {
        var result = [];

        if (unplannedEvents && unplannedEvents.length !== 0) {
          unplannedEvents.forEach(function (unplannedEvent) {
            if (
              unplannedEvent &&
              unplannedEvent._ref &&
              unplannedEvent._category !== ModelCategory.Standard
            ) {
              var newPlannedEvent = {
                eventType: {
                  target: this.getTargetNameWithContext(unplannedEvent._ref.eventType),
                },
              };

              result.push(newPlannedEvent);
            }
          }, this);
        }

        return result;
      },

      /**
       * Populate Data for IDocMapping from UI Object to JSON
       * @param {object} entity entity: ProcessType or EventType
       * @returns {object} return result idocMapping JSON, return undefined if idocMapping is null, undefined or lack of _ref to eventType when _object of entity is ProcessType
       */
      populateDataForIDocMapping: function (entity) {
        var newIDocMapping;
        var newFieldMapping = [];

        var idocMapping = entity.idocMapping;
        if (idocMapping) {
          newFieldMapping = this.populateDataForIDocFieldMapping(idocMapping.fieldMapping);

          if (entity._category !== ModelCategory.Standard || newFieldMapping.length !== 0) {
            newIDocMapping = {
              fieldMapping: newFieldMapping,
            };

            // Add editable properties when NOT Standard entity
            if (entity._category !== ModelCategory.Standard) {
              this.populateDataForIDocEventMapping(entity._objectType, idocMapping, newIDocMapping);
            }
          }
        }

        return newIDocMapping;
      },

      populateDataForIDocEventMapping: function (sObjectType, idocMapping, newIDocMapping) {
        if (
          sObjectType === ObjectType.ProcessType &&
          idocMapping._ref &&
          idocMapping._ref.eventType
        ) {
          newIDocMapping.eventType = formatMessage("{0}Event", idocMapping._ref.eventType.name);
          newIDocMapping.erpObjectType = idocMapping.erpObjectType;
          newIDocMapping.applicationObjectType = idocMapping.applicationObjectType;
          newIDocMapping.idoc = idocMapping.idoc;
        }

        if (sObjectType === ObjectType.EventType) {
          newIDocMapping.erpEventCode = idocMapping.erpEventCode;
          newIDocMapping.idoc = idocMapping.idoc;
        }
      },

      _checkIfMappingItemReferenceExist: function (mappingItem) {
        return mappingItem._ref && mappingItem._ref.field;
      },

      /**
       * Populate Mapped Data for IDocFieldMapping from UI Object to JSON
       * @param {object} fieldMapping fieldMapping of IDoc UI Object
       * @returns {object} return result fieldMapping array in JSON format, return [] if fieldMapping is null, undefined or empty
       */
      populateDataForIDocFieldMapping: function (fieldMapping) {
        if (!fieldMapping) {
          return [];
        }

        var newFieldMapping = [];

        fieldMapping.forEach(function (mappingItem) {
          if (
            this._checkIfMappingItemReferenceExist(mappingItem) &&
            mappingItem._ref.field._category !== ModelCategory.Standard
          ) {
            var newMappingItem = this.formatIDocFieldMappingItem(mappingItem);
            if (newMappingItem) {
              newFieldMapping.push(newMappingItem);
            }
          }
        }, this);

        return newFieldMapping;
      },

      formatIDocFieldMappingItem: function (mappingItem) {
        // init as undefined for later check
        var newMappingItem;

        if (mappingItem.composition) {
          newMappingItem = this.populateDataForIDocFieldMappingForComposition(mappingItem);
        } else {
          // filter unmapped item which lacks any value of _ref.field, idocSegment, idocField
          if (
            !!mappingItem.idocSegment &&
            !!mappingItem.idocField &&
            !FieldType.isItemAssociationToMany(mappingItem._ref.field)
          ) {
            newMappingItem = {
              field: mappingItem._ref.field.name,
              idocSegment: mappingItem.idocSegment,
              idocField: mappingItem.idocField,
            };
          }
        }

        return newMappingItem;
      },

      populateDataForIDocFieldMappingForComposition: function (mappingItem) {
        var newMappingItem;

        // calculate NOT-empty composition items
        var newCompositionMapping = [];
        mappingItem.composition.forEach(function (item) {
          // filter unmapped item which lacks any value of _ref.field, idocSegment, idocField
          if (!!item.idocSegment && !!item.idocField && item._ref) {
            var newCompositionItem = {
              field: item._ref.field.name,
              idocSegment: item.idocSegment,
              idocField: item.idocField,
            };

            newCompositionMapping.push(newCompositionItem);
          }
        }, this);

        if (newCompositionMapping.length !== 0 && mappingItem._ref) {
          newMappingItem = {
            field: mappingItem._ref.field.name,
            target: this.getTargetNameWithContext(mappingItem._ref.target),
            composition: newCompositionMapping,
          };
        }

        return newMappingItem;
      },

      /**
       * Populate Data for VPMapping from UI Object to JSON
       * @param {object} entity entity: ProcessType or EventType
       * @returns {object} return result vpMapping JSON, return undefined if vpMapping is null, undefined or lack of _ref to eventType when _object of entity is ProcessType
       */
      populateDataForVPMapping: function (entity) {
        var newVPMapping;
        var newFieldMapping = [];

        var vpMapping = entity.vpMapping;
        if (vpMapping) {
          newFieldMapping = this.populateDataForVPFieldMapping(vpMapping.fieldMapping);

          if (entity._category !== ModelCategory.Standard || newFieldMapping.length !== 0) {
            newVPMapping = {
              fieldMapping: newFieldMapping,
            };

            if (entity._category !== ModelCategory.Standard) {
              this.populateDataForVPEventMapping(entity._objectType, vpMapping, newVPMapping);
            }
          }
        }

        return newVPMapping;
      },

      populateDataForVPEventMapping: function (sObjectType, vpMapping, newVPMapping) {
        if (sObjectType === ObjectType.ProcessType && vpMapping._ref && vpMapping._ref.eventType) {
          newVPMapping.eventType = formatMessage("{0}Event", vpMapping._ref.eventType.name);
          newVPMapping.trackingIndicator = vpMapping.trackingIndicator;
          newVPMapping.upstreamProcessType = vpMapping._ref.upstreamProcessType
            ? vpMapping._ref.upstreamProcessType.name
            : ""; // _ref.upstreamProcessType could be null
        }

        if (sObjectType === ObjectType.EventType) {
          newVPMapping.lbnEventType = vpMapping.lbnEventType;
        }
      },

      /**
       * Populate Mapped Data for VPFieldMapping from UI Object to JSON
       * Since the JSON format of Outbound(ProcessType) and Inbound(EventType) is same, this function could be shared
       * @param {object} fieldMapping fieldMapping of VP UI Object
       * @returns {object} return result fieldMapping array in JSON format, return [] if fieldMapping is null, undefined or empty
       */
      populateDataForVPFieldMapping: function (fieldMapping) {
        if (!fieldMapping) {
          return [];
        }

        var newFieldMapping = [];

        fieldMapping.forEach(function (mappingItem) {
          // filter unmapped item which lacks any value of _ref.field, trackingField
          if (
            this._checkIfMappingItemReferenceExist(mappingItem) &&
            mappingItem._ref.field._category !== ModelCategory.Standard &&
            !!mappingItem.trackingField &&
            !!mappingItem._ref.field.name
          ) {
            var newMappingItem = {
              trackingField: mappingItem.trackingField,
              field: mappingItem._ref.field.name,
            };

            // map composition
            if (mappingItem.composition) {
              newMappingItem.target = this.getTargetNameWithContext(mappingItem._ref.target);

              var newCompositionMapping = [];
              mappingItem.composition.forEach(function (item) {
                // filter unmapped item which lacks any value of _ref.field, trackingField
                if (
                  !!item.trackingField &&
                  item._ref &&
                  item._ref.field &&
                  !!item._ref.field.name
                ) {
                  newCompositionMapping.push({
                    field: item._ref.field.name,
                    trackingField: item.trackingField,
                  });
                }
              });
              newMappingItem.composition = newCompositionMapping;
            }

            newFieldMapping.push(newMappingItem);
          }
        }, this);

        return newFieldMapping;
      },

      /**
       * Get the formatted text of context from UI-Object Target
       * @param {object} targetObject object of target
       * @returns {string} return formatted text of target
       */
      getTargetNameWithContext: function (targetObject) {
        var context = targetObject._ref.context.name;
        var name = targetObject.name;

        return formatMessage("{0}.{1}", [context, name]);
      },
    };

    return ModelDataPopulator;
  }
);
