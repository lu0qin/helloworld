sap.ui.define(
  [
    "./PlannedEventDetail",
    "sap/ui/model/json/JSONModel",
    "../constant/ModelCategory",
    "../constant/ViewMode",
    "../constant/ObjectType",
  ],
  function (PlannedEventDetail, JSONModel, ModelCategory, ViewMode, ObjectType) {
    "use strict";
    return PlannedEventDetail.extend(
      "com.sap.gtt.v2.model.manage.controller.PlannedEventUserDetail",
      {
        initModel: function () {
          var view = new JSONModel({
            tableTitle: "",
            isCreateEnabled: true,
            selectedCount: 0,
          });
          this.setModel(view, "view");
        },

        onUpdateFinished: function () {
          var oTable = this.byId("table");
          var sTitle;
          var iTotalItems = oTable.getBinding("items").getLength();
          if (oTable.getBinding("items").isLengthFinal()) {
            sTitle = this.getResourceBundle().getText("userPlannedEventTableTitle", [iTotalItems]);
          } else {
            sTitle = this.getResourceBundle().getText("userPlannedEventTableTitle");
          }
          this.getModel("view").setProperty("/tableTitle", sTitle);

          this.setSelectedCount();
        },

        /* Add Planned Event */
        onAddItem: function () {
          var oContext = this.byId("table").getBindingContext("store");
          this.onOpenPlannedEventDialog(
            ViewMode.Create,
            oContext,
            this.getCreateDialogData(oContext)
          );
        },

        getCreateDialogData: function (oContext) {
          return {
            _ref: {
              eventType: null,
            },
            matchLocation: false,
            businessToleranceValue: 0,
            businessToleranceUnit: "M",
            technicalToleranceValue: 0,
            technicalToleranceUnit: "M",
            periodicOverdueDetection: null,
            periodicOverdueDetectionUnit: "M",
            maxOverdueDetection: null,
            matchExtensionFields: [],
            matchPlanFieldsForUpdatePlan: [
              {
                name: "eventMatchKey",
                selected: true,
              },
            ],
            _category: ModelCategory.User,
            _parent: oContext.getObject(),
            _objectType: ObjectType.AdmissiblePlannedEvent,
          };
        },

        /* Delete Planned Event */
        // Overwrite for not show Where Used Dialog
        onDeleteItem: function () {
          var oTable = this.byId("table");
          var oSelectedContexts = oTable.getSelectedContexts();

          // Use for-loop to start deleting from the last item
          // to avoid index change by deleting the starting item
          for (var i = oSelectedContexts.length - 1; i >= 0; i--) {
            var oSelectedContext = oSelectedContexts[i];
            var oSelectedObject = oSelectedContext.getObject();
            this.onItemDeleted(oSelectedObject);
          }

          this.changeToEditMode();
          this.refreshBinding();
        },

        onItemDeleted: function (oItem) {
          this.deleteHelper.deleteObject(oItem);
        },
      }
    );
  }
);
