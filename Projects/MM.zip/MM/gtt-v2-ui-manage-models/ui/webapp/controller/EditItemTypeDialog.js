sap.ui.define(
  ["./EditTypeDialog", "./EntityValidator", "../util/ValidationHelper"],
  function (EditTypeDialog, EntityValidator, ValidationHelper) {
    "use strict";

    return EditTypeDialog.extend("com.sap.gtt.v2.model.manage.controller.EditItemTypeDialog", {
      getMandatoryControls: function () {
        return [this.byId("name"), this.byId("processType")];
      },

      onProcessTypeChange: function (oEvent) {
        var oControl = oEvent.getSource();
        var oDialogModel = oControl.getModel(this.modelName);
        var oSelectedItem = oControl.getSelectedItem();
        var oContext = oSelectedItem.getBindingContext("store");
        oDialogModel.setProperty("/data/_ref/context", oContext.getObject());

        var sWarningMsg = EntityValidator.validateContextUpdate(
          oDialogModel,
          this.getResourceBundle()
        );
        if (sWarningMsg) {
          ValidationHelper.setControlValidationWarning(oControl, sWarningMsg);
        } else {
          ValidationHelper.resetControlValidation(oControl);
        }
      },
    });
  }
);
