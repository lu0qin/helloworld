sap.ui.define(
  ["sap/ui/core/ValueState", "./BaseDialog", "./EntityValidator", "../constant/ModelCategory"],
  function (ValueState, BaseDialog, EntityValidator, ModelCategory) {
    "use strict";

    return BaseDialog.extend("com.sap.gtt.v2.model.manage.controller.EditTypeDialog", {
      getValidationControls: function () {
        return this.getMandatoryControls();
      },

      onChangeName: function (oEvent) {
        var oControl = oEvent.getSource();

        var oModel = oControl.getModel("dialog");

        var oValidationResult = this.validateName(oModel);
        oControl.setValueState(oValidationResult.valueState);
        oControl.setValueStateText(oValidationResult.msg);
      },

      validateName: function (oModel) {
        var oResourceBundle = this.getResourceBundle();

        var result = {
          valueState: ValueState.None,
          msg: "",
        };

        // check empty, constraint, duplicate, reserved, start with GTT
        var aErrors = this.validateNameError(oModel, oResourceBundle);

        if (aErrors.length === 0) {
          // check update warning
          var aWarnings = EntityValidator.validateNameUpdate(oModel, oResourceBundle);
          if (aWarnings.length !== 0) {
            result.valueState = ValueState.Warning;
            result.msg = aWarnings[0].message;
          }
        } else {
          result.valueState = ValueState.Error;
          result.msg = aErrors[0].message;
        }

        return result;
      },

      validateNameError: function (oModel, oResourceBundle) {
        var aErrors = [];

        var sType = oModel.getProperty("/type");
        var oCurrentItem = oModel.getProperty("/data");
        var sCurrentName = oCurrentItem.name;
        var oContext = oModel.getProperty("/context");

        // check empty, constraint, duplicate, reserved, start with GTT
        if (sType === "edit" && oContext.getProperty("name") === sCurrentName) {
          return [];
        }

        var sPreviousName = "";
        if (sType === "edit") {
          sPreviousName = oContext.getProperty("name");
        }

        if (oContext.getProperty("/modelCategory") === ModelCategory.Standard) {
          aErrors = aErrors.concat(
            EntityValidator.validateNotStartWithZZ(
              sCurrentName,
              oCurrentItem._objectType,
              null,
              oResourceBundle
            )
          );
        }

        aErrors = aErrors.concat(
          EntityValidator.validateEmpty(sCurrentName, oResourceBundle),
          EntityValidator.validateStringConstraint(sCurrentName, true, false, oResourceBundle),
          EntityValidator.validateDuplicateEntityName(
            sCurrentName,
            sPreviousName,
            oContext,
            oResourceBundle
          ),
          EntityValidator.validateReservedEntityName(sCurrentName, oContext, oResourceBundle),
          EntityValidator.validateStartWithGTT(sCurrentName, oResourceBundle)
        );

        return aErrors;
      },
    });
  }
);
