sap.ui.define(
  [
    "./BaseDetailController",
    "sap/ui/core/ValueState",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/core/MessageType",
    "sap/base/util/merge",
    "sap/m/Input",
    "sap/m/Text",
    "sap/m/ListMode",
    "sap/m/ColumnListItem",
    "sap/m/ListKeyboardMode",
    "sap/base/strings/formatMessage",
    "../model/formatter",
    "../util/ValidationHelper",
    "../util/TranslationHelper",
    "./EntityValidator",
    "./ImportCodeListDialog",
    "../constant/TextType",
    "../constant/LanguageCode",
    "../constant/ModelCategory",
    "../constant/ObjectType",
    "../constant/ViewMode",
  ],
  function (
    BaseDetailController,
    ValueState,
    JSONModel,
    Filter,
    FilterOperator,
    MessageType,
    merge,
    Input,
    Text,
    ListMode,
    ColumnListItem,
    ListKeyboardMode,
    formatMessage,
    formatter,
    ValidationHelper,
    TranslationHelper,
    EntityValidator,
    ImportCodeListDialog,
    TextType,
    LanguageCode,
    ModelCategory,
    ObjectType,
    ViewMode
  ) {
    "use strict";
    return BaseDetailController.extend("com.sap.gtt.v2.model.manage.controller.CodeListDetail", {
      initModel: function () {
        // Set relevant info for Code List Table view
        var oView = new JSONModel({
          tableTitle: "",
          count: 0,
        });
        this.setModel(oView, "view");
      },

      initControls: function () {
        // Table edit mode template
        var currentLanguageCode = TranslationHelper.getCurrentLanguageCode();
        var isLanguageSupported = TranslationHelper.checkIfLanguageIsSupported(currentLanguageCode);

        var propertyName = "name";
        var sTranslatedTextPath = formatMessage("{0}/{1}/{2}/{3}", [
          "translation",
          propertyName,
          "translation",
          currentLanguageCode,
        ]);

        this.oEditableTemplate = new ColumnListItem({
          cells: [
            new Input({
              value: {
                path: "store>code",
                type: "sap.ui.model.type.String", // Cannot change to use import class for String,
              },
              change: this.onChangeCode.bind(this),
            }),
            new Input({
              value: {
                path:
                  currentLanguageCode === LanguageCode.English || !isLanguageSupported
                    ? propertyName
                    : sTranslatedTextPath,
                model: "store",
              },
              placeholder: {
                path: propertyName,
                model: "store",
              },
            }),
          ],
        });

        // Table read only mode template
        this.oReadOnlyTemplate = new ColumnListItem({
          cells: [
            new Text({
              text: "{store>code}",
            }),
            new Text({
              text: {
                parts: [{ path: "store>translation/name/translation" }, { path: "store>name" }],
                formatter: formatter.getTranslatedText,
              },
            }),
          ],
        });
      },

      subscribeEvents: function () {
        var eventBus = this.getEventBus();
        eventBus.subscribe("modelDetail", "modeChanged", this.onTableModeChange, this);
      },

      unsubscribeEvents: function () {
        var eventBus = this.getEventBus();
        eventBus.unsubscribe("modelDetail", "modeChanged", this.onTableModeChange, this);
      },

      onTableModeChange: function (channelId, eventId, data) {
        var sMode = data.mode;
        if (sMode === ViewMode.Display) {
          this.changeTableToDisplayMode();
        } else {
          this.changeTableToEditMode();
        }
      },

      onUpdateFinished: function (oEvent) {
        var oView = this.getModel("view");
        var count = oEvent.getParameter("total");
        oView.setProperty("/count", count);
        oView.setProperty(
          "/tableTitle",
          this.getResourceBundle().getText("userCodeListValuesTableTitle", [
            this.getModel("view").getProperty("/count"),
          ])
        );
      },

      _rebindTable: function (oTemplate, sKeyboardMode) {
        this.byId("table")
          .bindItems({
            path: "store>values",
            template: oTemplate,
            filters: [
              new Filter({
                path: "_category",
                operator: FilterOperator.NE,
                value1: ModelCategory.Standard,
              }),
            ],
            templateShareable: true,
          })
          .setKeyboardMode(sKeyboardMode);
      },

      changeTableToDisplayMode: function () {
        this.byId("table").setMode(ListMode.None);
        this._rebindTable(this.oReadOnlyTemplate, ListKeyboardMode.Navigation);
      },

      changeTableToEditMode: function () {
        this.byId("table").setMode(ListMode.Delete);
        this._rebindTable(this.oEditableTemplate, ListKeyboardMode.Edit);
      },

      // Overwrite for different delete action
      onDeleteItem: function (oEvent) {
        var oListItem = oEvent.getParameter("listItem").getBindingContext("store").getObject();

        var items = this.getListItems();
        var iSelectedIndex = items.indexOf(oListItem);

        var newItems = items.slice();
        newItems.splice(iSelectedIndex, 1);

        this.setListItems(newItems);
      },

      onDragDropSelectedItem: function (oEvent) {
        var oDraggedItem = oEvent
          .getParameter("draggedControl")
          .getBindingContext("store")
          .getObject();
        var oDroppedItem = oEvent
          .getParameter("droppedControl")
          .getBindingContext("store")
          .getObject();

        var items = this.getListItems();
        var newItems = items.slice();

        var startIndex = items.indexOf(oDraggedItem);
        var endIndex = items.indexOf(oDroppedItem);

        if (startIndex < endIndex) {
          newItems.splice(endIndex + 1, 0, newItems[startIndex]);
          newItems.splice(startIndex, 1);
        } else {
          newItems.splice(endIndex, 0, newItems[startIndex]);
          newItems.splice(startIndex + 1, 1);
        }

        this.setListItems(newItems);
      },

      onImportItems: function (oEvent) {
        var that = this;

        var oImportButton = oEvent.getSource();
        var oTableContext = oImportButton.getBindingContext("store");

        var oImportDialogController = new ImportCodeListDialog();
        oImportDialogController = merge({}, oImportDialogController, {
          onDialogAccepted: function (type, data, context, info) {
            that.onImportCodeListDialogAccepted(type, data, context, info);
          },
          getView: function () {
            return that.getView();
          },
          getResourceBundle: function () {
            return that.getResourceBundle();
          },
        });

        var oModel = new JSONModel({
          type: "import",
          context: oTableContext,
          data: {},
          info: {
            tableTitle: this.getResourceBundle().getText("previewCodes"),
            lists: [],
            state: ValueState.None,
          },
        });

        var options = {
          fragmentId: "importCodeListDialog",
          fragmentName: "ImportCodeListDialog",
          controller: oImportDialogController,
          model: oModel,
        };

        this.openDialog(options);
      },

      onImportCodeListDialogAccepted: function (type, data, oContext, info) {
        if (!data || !data.values || data.values.length <= 0) {
          return;
        }

        this.changeToEditMode();

        var aOriginValues = this.getListItems() || [];
        var aNewValues = [];

        var aSelectedListValues = data.values;
        aSelectedListValues.forEach(function (value) {
          // if import codes duplicate with original code
          // replace the name and translation with the imported one
          var oDuplicateValue = aOriginValues.find(function (originValue) {
            return originValue.code === value.code;
          });
          if (oDuplicateValue) {
            oDuplicateValue.name = value.name;
            oDuplicateValue.translation = value.translation;
          } else {
            var newValue = {
              name: value.name,
              code: value.code,
              translation: value.translation,
              _category: ModelCategory.User,
              _objectType: ObjectType.Code,
              _parent: oContext.getObject(),
            };
            aNewValues.push(newValue);
          }
        });

        aNewValues = aOriginValues.concat(aNewValues);
        this.setListItems(aNewValues);
      },

      // Overwrite for different add action
      onAddItem: function () {
        this.changeToEditMode();

        var oParentObject = this.byId("table").getBindingContext("store").getObject();

        var items = this.getListItems();
        var newItems = items.slice();

        var newItem = {
          name: "",
          code: "",
          translation: {
            name: {
              textType: TextType.Name,
              translation: {},
            },
          },
          _category: ModelCategory.User,
          _objectType: ObjectType.Code,
          _parent: oParentObject,
        };

        newItems.push(newItem);
        this.setListItems(newItems);
      },

      getItemsBinding: function () {
        var oList = this.byId("table");

        return oList.getBinding("items");
      },

      onChangeCode: function (oEvent) {
        var oControl = oEvent.getSource();
        this.handleCodeChange(oControl);
      },

      handleCodeChange: function (oControl) {
        var oBindingContext = oControl.getBindingContext("store");
        var sValue = oControl.getValue();
        var oResourceBundle = this.getResourceBundle();

        var aErrors = [];

        if (oBindingContext.getProperty("_parent/_category") === ModelCategory.Standard) {
          aErrors = aErrors.concat(
            EntityValidator.validateNotStartWithZZ(
              sValue,
              ObjectType.Code,
              ObjectType.CodeList,
              oResourceBundle
            )
          );
        }
        aErrors = aErrors.concat(
          EntityValidator.validateStringConstraint(sValue, false, true, oResourceBundle),
          this.validateDuplicateCode(sValue)
        );

        if (aErrors.length > 0) {
          var errorMessage = aErrors[0].message;
          ValidationHelper.setControlValidationError(oControl, errorMessage);
        }
      },

      validateDuplicateCode: function (sValue) {
        var aErrors = [];
        var oResourceBundle = this.getResourceBundle();

        var aItemNames = this.getListItems().map(function (item) {
          return item.code;
        });

        // check if sValue is null/undefined/""
        // check if there is more than one code with sValue
        if (sValue && aItemNames.indexOf(sValue) !== aItemNames.lastIndexOf(sValue)) {
          aErrors.push({
            message: oResourceBundle.getText("notUniqueInOneCodeList"),
            type: MessageType.Error,
            additionalText: oResourceBundle.getText("code"),
            isPositional: false,
          });
        }

        return aErrors;
      },
    });
  }
);
