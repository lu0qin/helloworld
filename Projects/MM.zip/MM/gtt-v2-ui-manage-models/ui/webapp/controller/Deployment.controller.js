sap.ui.define(
  [
    "./BaseController",
    "sap/base/Log",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "../constant/ModelStatus",
    "../constant/ModelViewType",
    "../util/AsyncUtils",
    "../util/RestClient",
    "../util/ServiceUtils",
  ],
  function (
    BaseController,
    Log,
    JSONModel,
    MessageBox,
    MessageToast,
    ModelStatus,
    ModelViewType,
    AsyncUtils,
    RestClient,
    ServiceUtils
  ) {
    "use strict";

    return BaseController.extend("com.sap.gtt.v2.model.manage.controller.Deployment", {
      initModel: function () {
        var model = new JSONModel({
          model: {},
          modelViewType: ModelViewType.Runtime,
        });
        this.setModel(model, "store");

        var viewModel = new JSONModel({
          busy: false,
        });
        this.setModel(viewModel, "view");
      },

      initRoute: function () {
        // route to model draft
        this.getRouter()
          .getRoute("deployment")
          .attachPatternMatched(
            function (event) {
              this.onRouteMatched(event);
            }.bind(this)
          );
      },

      onRouteMatched: function (oEvent) {
        // reset view state
        this.resetViewState();

        // get arguments
        var args = oEvent.getParameter("arguments");
        this.refresh(args);
      },

      resetViewState: function () {
        var objectPageLayout = this.byId("objectPageLayout");
        objectPageLayout.setSelectedSection(this.byId("writeApiSection"));
      },

      onViewSelected: function (oEvent) {
        var item = oEvent.getParameter("item");
        var key = item.getKey();

        var viewRoute = {};
        viewRoute[ModelViewType.Draft] = "modelDraft";
        viewRoute[ModelViewType.Runtime] = "deployment";
        viewRoute[ModelViewType.Deployed] = "modelDetail";
        viewRoute[ModelViewType.History] = "history";

        var route = viewRoute[key];
        var context = this.getStoreContext();
        var namespace = context.getProperty("namespace");

        this.getRouter().navTo(route, {
          namespace: namespace,
        });
      },

      onActivatePressed: function () {
        MessageBox.confirm(this.getResourceBundle().getText("confirmMessageActivateModel"), {
          onClose: function (action) {
            if (action === MessageBox.Action.OK) {
              this.updateModelStatus(ModelStatus.Active);
            }
          }.bind(this),
        });
      },

      onDeactivatePressed: function () {
        MessageBox.confirm(this.getResourceBundle().getText("confirmMessageDeactivateModel"), {
          onClose: function (action) {
            if (action === MessageBox.Action.OK) {
              this.updateModelStatus(ModelStatus.Inactive);
            }
          }.bind(this),
        });
      },

      refresh: function (options) {
        var promise = this.updateData(options.namespace);

        promise.catch(
          function (error) {
            Log.error(error);
            this.getRouter().getTargets().display("notFound");
          }.bind(this)
        );

        // trigger model data change event
        this.getEventBus().publish("modelDeployment", "modelUpdated", promise);
      },

      getStoreContext: function () {
        var objectPageLayout = this.byId("objectPageLayout");
        return objectPageLayout.getBindingContext("store");
      },

      updateData: function (namespace) {
        this.setBusy(true);

        var dataSource = ServiceUtils.getDataSource("mainService");
        var url = ServiceUtils.getUrl(dataSource.uri).concat(
          "/models/",
          namespace,
          "/deployments/current/info"
        );
        var request = RestClient.get(url);

        var promise = AsyncUtils.finally(
          request,
          function () {
            this.setBusy(false);
          }.bind(this)
        );

        return promise.then(
          function (data) {
            // not deployed
            if (!data.status) {
              throw new Error("Undeployed");
            }

            return this.updateModelData(data);
          }.bind(this)
        );
      },

      updateModelData: function (data) {
        var context = this.getStoreContext();
        var model = context.getModel();
        model.setProperty("", data, context);

        return data;
      },

      updateModelStatus: function (newStatus) {
        var context = this.getStoreContext();
        var namespace = context.getProperty("namespace");

        var dataSource = ServiceUtils.getDataSource("mainService");
        var url = ServiceUtils.getUrl(dataSource.uri).concat(
          "/models/",
          namespace,
          "/deployments/current/status"
        );
        var request = RestClient.put(url, {
          status: newStatus,
        });

        this.setBusy(true);
        var promise = AsyncUtils.finally(
          request,
          function () {
            this.setBusy(false);
          }.bind(this)
        );

        return promise
          .then(
            function (data) {
              if (data.status !== newStatus) {
                throw new Error("model status is not updated");
              }

              // message toast
              var messageTextKey =
                newStatus === ModelStatus.Active
                  ? "messageModelActivated"
                  : "messageModelDeactivated";
              MessageToast.show(this.getResourceBundle().getText(messageTextKey));

              // refresh view
              this.refresh(data);
            }.bind(this)
          )
          .catch(
            function (error) {
              this.handleServerError(error);
            }.bind(this)
          );
      },
    });
  }
);
