sap.ui.define(["./BaseDialog"], function (BaseDialog) {
  "use strict";
  return BaseDialog.extend("com.sap.gtt.v2.model.manage.controller.EditUnplannedEventDialog", {
    onChangeEventType: function (oEvent) {
      var oSelect = oEvent.getSource();
      var oModel = oSelect.getModel(this.modelName);
      var selectedItem = oSelect.getSelectedItem();
      var context = selectedItem.getBindingContext(this.modelName);
      var eventType = context.getObject();
      oModel.setProperty("/data/_ref/eventType", eventType);
    },

    getValidationControls: function () {
      return this.getControls();
    },

    getMandatoryControls: function () {
      return this.getControls();
    },

    handleNameChange: function () {},

    getControls: function () {
      var aControls = [];
      var oNameSelect = this.byId("name");
      aControls.push(oNameSelect);
      return aControls;
    },
  });
});
