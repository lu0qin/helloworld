sap.ui.define(
  [
    "sap/ui/core/Fragment",
    "sap/ui/core/MessageType",
    "../util/ValidationHelper",
    "../constant/ModelCategory",
  ],
  function (Fragment, MessageType, ValidationHelper, ModelCategory) {
    "use strict";

    var GTT_CODE_LIST_NAME = "GTTCodeList";

    var ModelDataValidator = {
      _bModelIsStandard: false,

      _checkIfStandardItem: function (sValue) {
        return this._bModelIsStandard && !this._checkStringStartWithZZIgnoreCases(sValue);
      },

      _checkStringStartWithZZIgnoreCases: function (sValue) {
        return sValue.toLowerCase().startsWith("zz");
      },

      validateData: function (oModelData) {
        var oResult = {};
        var aErrors = [];

        this._bModelIsStandard =
          this.getView().getModel("store").getProperty("/modelCategory") === ModelCategory.Standard;

        if (oModelData.customModel && oModelData.customModel.subModels) {
          var aSubModels = oModelData.customModel.subModels;
          aErrors = aErrors.concat(
            this.validateDataForModelHeader(),
            this.validateDataForProcessType(aSubModels),
            this.validateDataForCodeList(aSubModels),
            this.validateDataForIDoc(aSubModels)
          );
        }

        if (aErrors.length > 0) {
          oResult.error = {
            message: this.getResourceBundle().getText("msgModelValidationError"),
            details: aErrors,
          };
        }

        return oResult;
      },

      // ========================================================
      // Model Header
      // ========================================================
      validateDataForModelHeader: function () {
        var aErrors = [];

        if (this.getView().byId("headerSection").getVisible()) {
          var sFragmentId = this.getView().createId("headerFragment");
          var oName = Fragment.byId(sFragmentId, "inputModelName");
          var oCorrelationLevel = Fragment.byId(sFragmentId, "inputCorrelationLevel");
          var oControls = [oName, oCorrelationLevel];

          aErrors = aErrors.concat(
            ValidationHelper.validateMandatory(oControls),
            ValidationHelper.checkValueState(oControls)
          );
        }

        return aErrors;
      },

      // ========================================================
      // Process Type
      // ========================================================
      validateDataForProcessType: function (aSubModels) {
        var aErrors = [];

        if (this._bModelIsStandard) {
          return [];
        }

        // Check at least one process type exists in submodel.
        var oSubModel = aSubModels.find(function (item) {
          return item && item.processTypes && item.processTypes.length !== 0;
        });

        if (!oSubModel) {
          aErrors.push({
            message: this.getResourceBundle().getText("msgTrackedProcessRequired"),
            type: MessageType.Error,
            additionalText: this.getResourceBundle().getText("trackedProcess"),
            isPositional: false,
          });
        }

        return aErrors;
      },

      // ========================================================
      // Code List
      // ========================================================
      validateDataForCodeList: function (aSubModels) {
        var aErrors = [];

        var oGttCodeList = aSubModels.find(function (oSubmodel) {
          return oSubmodel.name === GTT_CODE_LIST_NAME;
        });

        if (oGttCodeList.codeLists) {
          oGttCodeList.codeLists.forEach(function (codeList) {
            var aValues = codeList.values;

            // Get unique array of code
            var aUniqueValues = [];
            aValues.forEach(function (value) {
              // validate code of each value
              aErrors = aErrors.concat(this.validateDataForCodeListValue(value, codeList, aErrors));

              // only push new item into unique array
              if (!!value.code && aUniqueValues.indexOf(value.code, 0) === -1) {
                aUniqueValues.push(value.code);
              }
            }, this);

            this.validateDataForCodeListDuplicateValues(aUniqueValues, aValues);
          }, this);
        }

        return aErrors;
      },

      validateDataForCodeListValue: function (value, codeList) {
        // check if code starts with 'zz' in standard code list
        var aStandardErrors = this._bModelIsStandard
          ? this.validateDataForValueInStandardCodeList(value, codeList)
          : [];

        // check common constraint: code should only contains numbers, letters and underscores
        var aStringFormatErrors =
          aStandardErrors.length === 0
            ? this.validateDataForCodeListValueStringFormat(value, codeList)
            : [];

        return [].concat(aStandardErrors, aStringFormatErrors);
      },

      validateDataForValueInStandardCodeList: function (value, codeList) {
        var aErrors = [];

        if (
          !this._checkStringStartWithZZIgnoreCases(codeList.name) &&
          !this._checkStringStartWithZZIgnoreCases(value.code)
        ) {
          aErrors.push({
            message: this.getResourceBundle().getText("msgModelValidationCodStartWithZZError", [
              GTT_CODE_LIST_NAME.concat(".", codeList.name),
              value.code,
            ]),
            type: MessageType.Error,
            additionalText: this.getResourceBundle().getText("codeList"),
            isPositional: false,
          });
        }

        return aErrors;
      },

      validateDataForCodeListValueStringFormat: function (value, codeList) {
        var oStringConstraintReg = /^[a-zA-Z0-9_]*$/;
        if (!oStringConstraintReg.test(value.code)) {
          return [
            {
              message: this.getResourceBundle().getText(
                "msgModelValidationCodeStringConstraintError",
                [GTT_CODE_LIST_NAME.concat(".", codeList.name), value.code]
              ),
              type: MessageType.Error,
              additionalText: this.getResourceBundle().getText("codeList"),
              isPositional: false,
            },
          ];
        }

        return [];
      },

      validateDataForCodeListDuplicateValues: function (uniqueValues, values) {
        // validate if duplicate codes exist
        if (uniqueValues.length < values.length) {
          return [
            {
              message: this.getResourceBundle().getText(
                "msgModelValidationCodeDuplicateError",
                GTT_CODE_LIST_NAME.concat(".", values.name)
              ),
              type: MessageType.Error,
              additionalText: this.getResourceBundle().getText("codeList"),
              isPositional: false,
            },
          ];
        }

        return [];
      },

      // ========================================================
      // IDOC Mapping
      // ========================================================
      validateDataForIDoc: function (aSubModels) {
        var aErrors = [];

        aSubModels.forEach(function (item) {
          if (item.enableIDoc) {
            // validate Tracked Process & its Event Types Event IDoc Mapping
            aErrors = aErrors.concat(
              this.validateDataForProcessTypeIDoc(item),
              this.validateDataForEventTypeIDoc(item)
            );
          }
        }, this);

        return aErrors;
      },

      /**
       * Validate Process Type IDocMapping.
       * 1. If Process Type is NOT standard, Validate Application Object Type
       * 2. If Process Type is NOT standard, Validate IDOC Value
       * 3. Validate Detail Field Mapping
       *
       * @param {object} oSubModel object of entity: SubModel
       * @returns {array} return array of error. Return 0 if no idocMapping or no error.
       */
      validateDataForProcessTypeIDoc: function (oSubModel) {
        var aErrors = [];

        var sProcessTypeName = oSubModel.name;

        var oProcessType = oSubModel.processTypes[0];
        if (!oProcessType.idocMapping) {
          return [];
        }

        if (!this._checkIfStandardItem(sProcessTypeName)) {
          aErrors = aErrors.concat(
            this.validateDataForApplicationObjectType(oProcessType),
            this.validateDataForIDocValue(oProcessType, sProcessTypeName)
          );
        }

        aErrors = aErrors.concat(
          this.validateDataForIDocDetailMapping(oProcessType, sProcessTypeName)
        );

        return aErrors;
      },

      /**
       * Validate Event Type IDocMapping.
       * 1. If Event Type is NOT standard, Validate IDOC Value
       * 2. If Event Type is NOT standard, Validate Event Code
       * 3. Validate Detail Field Mapping
       *
       * @param {object} oEventType object of entity: Event Type
       * @returns {array} return array of error. Return 0 if no idocMapping or no error.
       */
      validateDataForEventTypeIDoc: function (oEventType) {
        var aErrors = [];

        var sProcessTypeName = oEventType.name;
        var aEventTypes = oEventType.eventTypes || [];
        aEventTypes.forEach(function (eventType) {
          if (eventType.idocMapping) {
            if (!this._checkIfStandardItem(eventType.name)) {
              aErrors = aErrors.concat(
                this.validateDataForIDocValue(eventType, sProcessTypeName),
                this.validateDataForEventCode(eventType, sProcessTypeName)
              );
            }

            aErrors = aErrors.concat(
              this.validateDataForIDocDetailMapping(eventType, sProcessTypeName)
            );
          }
        }, this);

        return aErrors;
      },

      /**
       * Validate Application Object Type of Process Type IDocMapping.
       * The following validation rules contradict with each other and should execute in order,
       * therefore the returned error array will only contain 0 or 1 item.
       *
       * Validation rules:
       * 1. AOT should not be undefined/empty string
       * 2. If the oProcessType is standard, AOT should start with letters 'zz'
       * 3. AOT should start with a letter and only contain letters, numbers and underscores
       *
       * @param {object} oProcessType object of entity: Process Type
       * @returns {array} return array of error with 0 or 1 item. Return 0 if no idocMapping or no error.
       */
      validateDataForApplicationObjectType: function (oProcessType) {
        var oIDocMapping = oProcessType.idocMapping;
        var sProcessTypeName = oProcessType.name;

        if (!oIDocMapping) {
          return [];
        }

        var sAOT = oIDocMapping.applicationObjectType;

        // missing required field: Application Object Type for Tracked Process IDoc Mapping
        if (!sAOT) {
          return [
            {
              message: this.getResourceBundle().getText(
                "msgModelValidationIDocAOTMissingError",
                sProcessTypeName
              ),
              type: MessageType.Error,
              additionalText: this.getResourceBundle().getText("iDocIntegration"),
              isPositional: false,
            },
          ];
        }

        // AOT of user-defined TP in standard model should start with letters 'ZZ'
        if (
          this._bModelIsStandard &&
          this._checkStringStartWithZZIgnoreCases(sProcessTypeName) &&
          !this._checkStringStartWithZZIgnoreCases(sAOT)
        ) {
          return [
            {
              message: this.getResourceBundle().getText(
                "msgModelValidationIDocAOTValueStartWithZZError",
                sProcessTypeName
              ),
              type: MessageType.Error,
              additionalText: this.getResourceBundle().getText("iDocIntegration"),
              isPositional: false,
            },
          ];
        }

        // wrong input pattern: Application Object Type should start with letters and then letters/numbers
        var formatRegex = /^[a-zA-Z]+[a-zA-Z0-9_]*$/;
        if (!formatRegex.test(sAOT)) {
          return [
            {
              message: this.getResourceBundle().getText(
                "msgModelValidationIDocAOTValueError",
                sProcessTypeName
              ),
              type: MessageType.Error,
              additionalText: this.getResourceBundle().getText("iDocIntegration"),
              isPositional: false,
            },
          ];
        }

        return [];
      },

      /**
       * Validate IDOC of Process/Event Type IDocMapping.
       * The following validation rules contradict with each other and should execute in order,
       * therefore the returned error array will only contain 0 or 1 item.
       *
       * Validation rules:
       * 1. If oItem is Process Type, IDOC should not be undefined/empty string
       * 2. IDOC should not contain blank spaces
       *
       * @param {object} oItem object of entity: Process/Event Type
       * @param {string} sProcessTypeName name of submodel
       * @returns {array} return array of error with 0 or 1 item. Return 0 if no idocMapping or no error.
       */
      validateDataForIDocValue: function (oItem, sProcessTypeName) {
        var sIDocValue = oItem.idocMapping.idoc;
        var bItemIsProcessType = oItem.name === sProcessTypeName;
        var sIDocMappingEventName = bItemIsProcessType
          ? sProcessTypeName.concat("Event")
          : oItem.name;

        // missing required field: IDOC for Tracked Process Event
        if (bItemIsProcessType && !sIDocValue) {
          return [
            {
              message: this.getResourceBundle().getText("msgModelValidationIDocValueMissingError", [
                sProcessTypeName,
                sIDocMappingEventName,
              ]),
              type: MessageType.Error,
              additionalText: this.getResourceBundle().getText("iDocIntegration"),
              isPositional: false,
            },
          ];
        }

        // wrong input pattern: IDoc cannot contains blank space
        if (sIDocValue && sIDocValue.includes(" ")) {
          return [
            {
              message: this.getResourceBundle().getText(
                "msgModelValidationIDocValueBlankSpaceError",
                [sProcessTypeName, sIDocMappingEventName]
              ),
              type: MessageType.Error,
              additionalText: this.getResourceBundle().getText("iDocIntegration"),
              isPositional: false,
            },
          ];
        }

        return [];
      },

      /**
       * Validate Event Code of Event Type IDocMapping.
       * The following validation rules contradict with each other and should execute in order,
       * therefore the returned error array will only contain 0 or 1 item.
       *
       * Validation rules:
       * Event Code should not contain blank spaces
       *
       * @param {object} oEventType object of entity: Event Type
       * @param {string} sProcessTypeName name of submodel
       * @returns {array} return array of error with 0 or 1 item. Return 0 if no idocMapping or no error.
       */
      validateDataForEventCode: function (oEventType, sProcessTypeName) {
        var result = [];
        var oResourceBundle = this.getResourceBundle();

        var oIDocMapping = oEventType.idocMapping;
        var sIDocMappingEventName =
          oEventType.name === sProcessTypeName ? sProcessTypeName.concat("Event") : oEventType.name;

        var sErpEventCode = oIDocMapping.erpEventCode;

        if (!sErpEventCode) {
          return [];
        }

        // wrong input pattern: Event Code cannot contains blank space
        if (sErpEventCode.includes(" ")) {
          result.push({
            message: oResourceBundle.getText("msgModelValidationEventCodeValueBlankSpaceError", [
              sProcessTypeName,
              sIDocMappingEventName,
            ]),
            type: MessageType.Error,
            additionalText: oResourceBundle.getText("iDocIntegration"),
            isPositional: false,
          });
        }

        // For User-Defined Event Types in Standard Model, Event Code must start with letters 'ZZ'
        if (
          this._bModelIsStandard &&
          this._checkStringStartWithZZIgnoreCases(oEventType.name) &&
          !this._checkStringStartWithZZIgnoreCases(sErpEventCode)
        ) {
          result.push({
            message: oResourceBundle.getText(
              "msgModelValidationIDocEventCodeValueStartWithZZError",
              [sProcessTypeName, sIDocMappingEventName]
            ),
            type: MessageType.Error,
            additionalText: oResourceBundle.getText("iDocIntegration"),
            isPositional: false,
          });
        }

        return result;
      },

      /**
       * Validate Detail Field Mapping of Process/Event Type IDocMapping.
       *
       * Validation rules:
       * 1. IDOC Segment should not contain blank spaces
       * 2. IDOC Field should not contain blank spaces
       *
       * @param {object} oItem object of entity: Process/Event Type
       * @param {string} sProcessTypeName name of submodel
       * @returns {array} return array of error. Return 0 if no idocMapping or no error.
       */
      validateDataForIDocDetailMapping: function (oItem, sProcessTypeName) {
        var aErrors = [];

        var oFieldMapping = oItem.idocMapping.fieldMapping;
        if (!oFieldMapping) {
          return [];
        }

        var sIDocMappingEventName =
          oItem.name === sProcessTypeName ? sProcessTypeName.concat("Event") : oItem.name;

        oFieldMapping.forEach(function (mappingField) {
          // wrong input pattern: IDoc Segment cannot contains blank space
          if (mappingField.idocSegment && mappingField.idocSegment.includes(" ")) {
            aErrors.push({
              message: this.getResourceBundle().getText(
                "msgModelValidationIDocSegmentValueBlankSpaceError",
                [sProcessTypeName, sIDocMappingEventName, mappingField.field]
              ),
              type: MessageType.Error,
              additionalText: this.getResourceBundle().getText("iDocIntegration"),
              isPositional: false,
            });
          }

          // wrong input pattern: IDoc Field cannot contains blank space
          if (mappingField.idocField && mappingField.idocField.includes(" ")) {
            aErrors.push({
              message: this.getResourceBundle().getText(
                "msgModelValidationIDocFieldValueBlankSpaceError",
                [sProcessTypeName, sIDocMappingEventName, mappingField.field]
              ),
              type: MessageType.Error,
              additionalText: this.getResourceBundle().getText("iDocIntegration"),
              isPositional: false,
            });
          }
        }, this);

        return aErrors;
      },
    };

    return ModelDataValidator;
  }
);
