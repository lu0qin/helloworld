sap.ui.define(
  [
    "./UserFields",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/ValueState",
    "../constant/FieldType",
    "../constant/ObjectType",
    "../constant/ModelCategory",
    "./EntityValidator",
  ],
  function (
    UserFieldsController,
    JSONModel,
    ValueState,
    FieldType,
    ObjectType,
    ModelCategory,
    EntityValidator
  ) {
    "use strict";

    return UserFieldsController.extend(
      "com.sap.gtt.v2.model.manage.controller.ProcessTypeUserFields",
      {
        initModel: function () {
          // Set relevant info for view
          var view = new JSONModel({
            tableTitle: "",
            isCreateEnabled: true,
            isShowDppColumn: true,
            isShowKeyColumn: false,
            isShowAuthScopeColumn: true,
            selectedCount: 0,
          });
          this.setModel(view, "view");
        },

        getFieldTypeArray: function () {
          return [
            { name: FieldType.String },
            { name: FieldType.Uuid },
            { name: FieldType.Boolean },
            { name: FieldType.Integer },
            { name: FieldType.Decimal },
            { name: FieldType.Date },
            { name: FieldType.Timestamp },
            { name: FieldType.AssociationToOne },
            { name: FieldType.AssociationToMany },
            { name: FieldType.Composition },
            { name: FieldType.CodeList },
          ];
        },

        // Only used in ProcessTypeDetail
        handleAssociationToOneFieldChange: function (oControl) {
          var oDialogModel = oControl.getModel("dialog");
          // set new value for backlink
          // item selected - set item reference
          // no item selected - set input value
          var oSelectedItem = oControl.getSelectedItem();
          var newValue = oSelectedItem
            ? oSelectedItem.getBindingContext("dialog").getObject()
            : oControl.getValue();
          oDialogModel.setProperty("/data/backlink", newValue);

          // validate new value of asso-to-many target field
          var oValidationResult = this.validateAssociationToOneField(oControl, oDialogModel);
          oControl.setValueState(oValidationResult.valueState);
          oControl.setValueStateText(oValidationResult.msg);
        },

        validateAssociationToOneField: function (oControl, oDialogModel) {
          var result = {
            valueState: ValueState.None,
            msg: "",
          };

          var oResourceBundle = this.getResourceBundle();

          var sValue = oControl.getValue();
          var oStoreModel = oControl.getModel("store");

          var aErrors = this.validateAssociationToOneFieldError(sValue, oStoreModel, oDialogModel);

          var bIsFieldNew = this.checkIfAssoToOneFieldIsNew(sValue, oDialogModel);

          if (aErrors.length !== 0) {
            result.valueState = ValueState.Error;
            result.msg = aErrors[0].message;
          } else if (bIsFieldNew) {
            result.valueState = ValueState.Warning;
            result.msg = oResourceBundle.getText("newAssoToOneFieldBeCreated");
          }

          return result;
        },

        validateAssociationToOneFieldError: function (sValue, oStoreModel, oDialogModel) {
          var oResourceBundle = this.getResourceBundle();

          // init with validations independent from the selected process type
          var aErrors = [].concat(
            EntityValidator.validateEmpty(sValue, oResourceBundle),
            EntityValidator.validateStringConstraint(sValue, true, true, oResourceBundle),
            EntityValidator.validateStartWithGTT(sValue, oResourceBundle)
          );

          // get elements from the selected process type to check duplicate and reserved
          var oTargetProcessType = oDialogModel.getProperty("/data/processTypeTarget");
          if (oTargetProcessType) {
            if (oTargetProcessType._category === ModelCategory.Standard) {
              aErrors = aErrors.concat(
                EntityValidator.validateNotStartWithZZ(
                  sValue,
                  ObjectType.UserField,
                  ObjectType.ProcessType,
                  oResourceBundle
                )
              );
            }

            var aElementsToCheckDuplicate = oTargetProcessType.elements.filter(function (element) {
              // basic list: elements in target process type elements, but not in backlink list
              // element should not be same as current field if in edit dialog
              return (
                !this.oDialogController.checkIfItemAssoToTargetProcessType(element) &&
                !this.oDialogController.checkIfItemSameAsCurrentField(element)
              );
            }, this);

            // check reserved and duplicate
            aErrors = aErrors.concat(
              EntityValidator.validateAssoToOneFieldDuplicateWithCurrentFieldName(
                sValue,
                oDialogModel,
                aElementsToCheckDuplicate,
                oResourceBundle
              ),
              EntityValidator.validateReservedEntityFieldName(
                sValue,
                oTargetProcessType,
                oStoreModel,
                oResourceBundle
              )
            );
          }

          return aErrors;
        },

        checkIfAssoToOneFieldIsNew: function (sValue, oDialogModel) {
          var bIsNew = false;

          var sDialogType = oDialogModel.getProperty("/type");
          var oContext = oDialogModel.getProperty("/context");

          var oTargetProcessType = oDialogModel.getProperty("/data/processTypeTarget");
          if (oTargetProcessType) {
            var aElements = oTargetProcessType.elements;
            var aElementsToCheckUpdate = aElements.filter(function (element) {
              return (
                sDialogType === "create" ||
                (sDialogType === "edit" && oContext.getObject() !== element)
              );
            });

            // check if the input value differs from all element name in the target process type
            bIsNew = aElementsToCheckUpdate.every(function (element) {
              return element.name.toLowerCase() !== sValue.toLowerCase();
            }, this);
          }

          return bIsNew;
        },

        handleCreateAssociationToOneItem: function (backlinkItemName, currentItem) {
          var targetProcessType = currentItem._ref.target;

          var backlinkItem = {
            name: backlinkItemName,
            label: backlinkItemName,
            type: FieldType.Association,
            writable: true,
            readable: true,
            _ref: {
              target: currentItem._parent,
            },
            cardinality: {
              max: 1,
            },
            authScopes: [],
            _parent: targetProcessType,
            _objectType: ObjectType.UserField,
            _category: ModelCategory.User,
          };

          // set i18n label & translation property
          // oOriginalListItemData is always 'null' and sDialogType is always 'create'
          // since it will only be created
          this.setTranslationPropertiesForListItem("label", backlinkItem, "", "create");

          var elements = targetProcessType.elements;
          elements.push(backlinkItem);
          this.handleCreateItem(backlinkItem);

          currentItem._ref.backlink = backlinkItem;
        },
      }
    );
  }
);
