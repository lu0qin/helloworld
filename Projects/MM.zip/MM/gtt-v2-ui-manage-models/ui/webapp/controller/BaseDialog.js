sap.ui.define(
  ["sap/ui/base/Object", "sap/ui/core/Fragment", "../model/formatter", "../util/ValidationHelper"],
  function (BaseObject, Fragment, formatter, ValidationHelper) {
    "use strict";

    return BaseObject.extend("com.sap.gtt.v2.model.manage.controller.BaseDialog", {
      modelName: "dialog",
      fragmentId: "",
      formatter: formatter,
      onAcceptPress: function (oEvent) {
        var oDialog = oEvent.getSource().getParent();
        oDialog.setBusy(true);

        var isValid = this.validate();
        if (!isValid) {
          oDialog.setBusy(false);
          return;
        }

        var oModel = oDialog.getModel(this.modelName);
        var sType = oModel.getProperty("/type");
        var oContext = oModel.getProperty("/context");
        var data = oModel.getProperty("/data");
        var info = oModel.getProperty("/info");
        oDialog.close();

        this.onDialogAccepted(sType, data, oContext, info);
      },

      onCancelPress: function (oEvent) {
        var oDialog = oEvent.getSource().getParent();
        oDialog.close();
      },

      onAfterClose: function (oEvent) {
        var oDialog = oEvent.getSource();
        oDialog.destroy();
      },

      byId: function (sId) {
        return Fragment.byId(this.fragmentId, sId);
      },

      validate: function () {
        var aCheckValueStateControls = this.getValidationControls();
        var aMandatoryControls = this.getMandatoryControls();
        var aErrors = [].concat(
          ValidationHelper.validateMandatory(aMandatoryControls),
          ValidationHelper.checkValueState(aCheckValueStateControls)
        );
        return aErrors.length === 0;
      },

      getValidationControls: function () {
        return [];
      },

      getMandatoryControls: function () {
        return [];
      },

      onDialogAccepted: function (type, data, context, info) {},
    });
  }
);
