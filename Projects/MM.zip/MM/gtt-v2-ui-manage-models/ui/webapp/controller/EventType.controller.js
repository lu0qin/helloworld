sap.ui.define(
  [
    "./BaseEntityList",
    "sap/ui/model/json/JSONModel",
    "sap/base/util/deepClone",
    "sap/base/strings/formatMessage",
    "../constant/ErpObjectType",
    "../constant/ObjectType",
    "../constant/InheritEvent",
    "../constant/ModelCategory",
    "./EditEventTypeDialog",
  ],
  function (
    BaseEntityList,
    JSONModel,
    deepClone,
    formatMessage,
    ErpObjectType,
    ObjectType,
    InheritEvent,
    ModelCategory,
    EditEventTypeDialog
  ) {
    "use strict";

    var REF_CONTEXT_NAME_RELATIVE_PATH = "_ref/context/name";
    var IS_CORE_MODEL_PATH = "/isCoreModel";

    return BaseEntityList.extend("com.sap.gtt.v2.model.manage.controller.EventType", {
      initModel: function () {
        var oListViewInfo = new JSONModel({
          busy: false,
          count: 0,
          listTitle: this.getResourceBundle().getText("listTitle"),
          isCoreModel: true,
          isStandardModel: true,
          selectedCount: 0,
        });
        this.setModel(oListViewInfo, "listViewInfo");
      },

      initCreateAndEditDialogController: function () {
        var oDialogController = new EditEventTypeDialog();
        this.oDialogController = this.mergeViewFunctionsIntoCreateAndEditDialog(oDialogController);

        this._createAndEditDialogFragmentId = "editEventTypeDialog";
        this._createAndEditDialogFragmentName = "EditEventTypeDialog";
      },

      updateIsCoreModel: function (contextName) {
        if (contextName === "CoreModel") {
          this.getModel("listViewInfo").setProperty(IS_CORE_MODEL_PATH, true);
        } else {
          this.getModel("listViewInfo").setProperty(IS_CORE_MODEL_PATH, false);
          var oEventUserFieldsView = this.byId("detailView").byId("eventUserFieldsView");
          oEventUserFieldsView.byId("table").removeSelections();
          oEventUserFieldsView.getModel("view").setProperty("/selectedCount", 0);
        }
      },

      getCreateDialogData: function () {
        return {
          _ref: {
            context: null,
          },
          name: "",
          descr: "",
          elements: [],
          parent: { target: InheritEvent.Event.key },
          _parent: null,
          _objectType: ObjectType.EventType,
          _category: ModelCategory.User,
        };
      },

      onDialogAccepted: function (type, data, context) {
        this.setTranslationPropertiesForListItem(
          "descr",
          data,
          type === "edit" ? context.getProperty("descr") : "",
          type
        );

        if (type === "edit") {
          var originData = context.getObject();
          // update reference for context
          this.whereUsedListHelper.updateEntityDependency(originData, data._ref.context);
          // remove reference by admissible planned event when change inherit to GTTDelayed/OnTimeEvent
          this.removeAdmissiblePlannedEvents(originData, data.parent.target);
          this.modify(originData, data);
          this.refreshBinding();
        } else {
          var items = context.getModel().getProperty("/eventTypes");
          data.idocMapping = {
            idoc: "",
            erpEventCode: "",
          };
          data.vpMapping = {
            lbnEventType: "",
            fieldMapping: [],
          };
          // set idoc value for new event type in idoc mapping
          this.setIDocValue(data);
          items.push(data);

          // add dependency to where-used list
          this.whereUsedListHelper.addEntityDependency(data);

          this.refreshBinding();
          this.updateListSelection(data.name);
          this.scrollToNewCreatedItem(data.name);
        }
        this.changeToEditMode();
      },

      removeAdmissiblePlannedEvents: function (originData, newInherit) {
        if (originData.parent.target !== newInherit) {
          var admPlannedEventList = this.whereUsedListHelper.getUsedByAdmissiblePlannedEventList(
            originData
          );
          admPlannedEventList.forEach(function (admPlannedEvent) {
            this.deleteHelper.deleteObject(admPlannedEvent);
          }, this);
        }
      },

      setIDocValue: function (data) {
        var processType = data._ref.context;
        if (processType.idocMapping && processType.idocMapping.erpObjectType) {
          if (processType.idocMapping.erpObjectType !== ErpObjectType.Others) {
            data.idocMapping.idoc = "E1EVMHDR02";
          }
        }
      },

      getGroupKey: function (oContext) {
        return oContext.getProperty(REF_CONTEXT_NAME_RELATIVE_PATH);
      },

      compareContext: function (a, b) {
        // always put CoreModel group to bottom
        if (a === "CoreModel".toUpperCase()) {
          return 1;
        } else if (b === "CoreModel".toUpperCase()) {
          return -1;
        }

        // ascending order
        if (a > b) {
          return 1;
        } else if (a < b) {
          return -1;
        } else {
          return 0;
        }
      },

      onItemSelected: function (listItem) {
        if (!listItem) {
          this.getModel("listViewInfo").setProperty(IS_CORE_MODEL_PATH, false);
          return;
        }

        var context = listItem.getBindingContext("store");
        var contextName = context.getProperty(REF_CONTEXT_NAME_RELATIVE_PATH);
        this.updateIsCoreModel(contextName);

        // set event fields elements
        var sPath = listItem.getBindingContextPath();

        var oCoreModelFieldsBase = deepClone(
          this.getModel("store").getProperty("/coreModel/baseEventType/elements")
        );
        var oContext = listItem.getBindingContext("store");
        var sTarget = oContext.getProperty("parent/target");
        var sContext = oContext.getProperty(REF_CONTEXT_NAME_RELATIVE_PATH);
        var aElements = oContext.getProperty("elements");

        if (sContext === "CoreModel") {
          if (sTarget === InheritEvent.Event.key) {
            oCoreModelFieldsBase = oCoreModelFieldsBase.concat(aElements);
          } else {
            oCoreModelFieldsBase = aElements;
          }
        } else {
          if (sTarget !== InheritEvent.Event.key) {
            var aCoreModelEventTypes = this.getModel("store").getProperty("/coreModel/eventTypes");
            var oInheritEventType = aCoreModelEventTypes.filter(function (item) {
              return sTarget === item.context.concat(".").concat(item.name);
            });
            oCoreModelFieldsBase = oCoreModelFieldsBase.concat(oInheritEventType[0].elements);
          }
        }

        this.getModel("store").setProperty("/eventCoreFields", oCoreModelFieldsBase);

        var oDetailView = this.byId("detailView");
        var oCoreFieldView = oDetailView.byId("eventCoreFieldsView");
        var oTable = oCoreFieldView.byId("table");
        var sTitle,
          iTotalItems = oCoreModelFieldsBase.length,
          sType = oContext.getProperty("type"),
          sName = oContext.getProperty("name");
        if (sType === "CoreModel") {
          sTitle = oTable.getBinding("items").isLengthFinal()
            ? formatMessage("{0}.{1} ({2})", sContext, sName, iTotalItems)
            : formatMessage("{0}.{1}", sContext, sName);
        } else {
          sTitle = oTable.getBinding("items").isLengthFinal()
            ? formatMessage("{0}({1})", sTarget, iTotalItems)
            : formatMessage("{0}", sTarget);
        }

        var oTitle = oTable.getHeaderToolbar().getTitleControl();
        oTitle.setText(sTitle);

        this.byId("detailView").bindElement({
          path: sPath,
          model: "store",
        });
      },

      setSideContentEditable: function (isEditable) {
        this.byId("detailView")
          .byId("eventUserFieldsView")
          .getModel("view")
          .setProperty("/isCreateEnabled", isEditable);
      },
    });
  }
);
