sap.ui.define(
  ["sap/ui/core/ValueState", "./EditTypeDialog", "./EntityValidator", "../constant/InheritEvent", "../util/ValidationHelper"],
  function (ValueState, EditTypeDialog, EntityValidator, InheritEvent, ValidationHelper) {
    "use strict";

    var PARENT_TARGET_RELATIVE_PATH = "parent/target";

    return EditTypeDialog.extend("com.sap.gtt.v2.model.manage.controller.EditEventTypeDialog", {
      getMandatoryControls: function () {
        return [this.byId("name"), this.byId("processType"), this.byId("inherit")];
      },

      onProcessTypeChange: function (oEvent) {
        var oControl = oEvent.getSource();
        var oDialogModel = oControl.getModel(this.modelName);
        var oSelectedItem = oControl.getSelectedItem();
        var oContext = oSelectedItem.getBindingContext("store");
        oDialogModel.setProperty("/data/_ref/context", oContext.getObject());

        var sWarningMsg = EntityValidator.validateContextUpdate(
          oDialogModel,
          this.getResourceBundle()
        );
        if (sWarningMsg) {
          ValidationHelper.setControlValidationWarning(oControl, sWarningMsg);
        } else {
          ValidationHelper.resetControlValidation(oControl);
        }
      },

      onInheritChange: function (oEvent) {
        var oControl = oEvent.getSource();

        var oDialogModel = oControl.getModel("dialog");

        var oValidationResult = this.validateInherit(oDialogModel);
        oControl.setValueState(oValidationResult.valueState);
        oControl.setValueStateText(oValidationResult.msg);
      },

      validateInherit: function (oDialogModel) {
        var result = {
          valueState: ValueState.None,
          msg: "",
        };

        var sType = oDialogModel.getProperty("/type");
        var oContext = oDialogModel.getProperty("/context");
        var sInheritKey = oDialogModel.getProperty("/data/parent/target");

        // stop validating:
        // 1. create mode
        // 2. edit mode but the inherit keeps original value
        if (
          sType === "create" ||
          (sType === "edit" && oContext.getProperty(PARENT_TARGET_RELATIVE_PATH) === sInheritKey)
        ) {
          return result;
        }

        var oResourceBundle = this.getResourceBundle();

        var aErrors = this.validateInheritError(sInheritKey, oContext, oResourceBundle);
        if (aErrors.length !== 0) {
          // check error validation
          result.valueState = ValueState.Error;
          result.msg = aErrors[0].message;
        } else {
          var warningMsg = this.validateInheritWarning(oContext, sInheritKey, oResourceBundle);
          if (warningMsg) {
            result.valueState = ValueState.Warning;
            result.msg = warningMsg;
          }
        }

        return result;
      },

      validateInheritError: function (sInheritKey, oContext, oResourceBundle) {
        return [].concat(
          EntityValidator.validateOverlappedEntityFields(sInheritKey, oContext, oResourceBundle)
        );
      },

      validateInheritWarning: function (oContext, sInheritKey, oResourceBundle) {
        var warningMsg = "";

        // type is always edit
        // origin value of inherit is different from current value
        if (this.checkIfInheritChangeFromEventToOther(oContext, sInheritKey)) {
          var usedByAdmPlannedEventList = this.whereUsedListHelper.getUsedByAdmissiblePlannedEventList(
            oContext.getObject()
          );
          if (usedByAdmPlannedEventList.length > 0) {
            // get parameter for i18n text
            var usedByAdmPlannedEventParentTPNameList = usedByAdmPlannedEventList.map(function (
              admPlannedEvent
            ) {
              return admPlannedEvent._parent.name;
            });
            var usedByAdmPlannedEventParentTPNameString = usedByAdmPlannedEventParentTPNameList.join(
              ", "
            );

            warningMsg = oResourceBundle.getText(
              "usedByAdm",
              usedByAdmPlannedEventParentTPNameString
            );
          }
        }

        return warningMsg;
      },

      checkIfInheritChangeFromEventToOther: function (oContext, sInheritKey) {
        var isOriginalInheritEvent =
          oContext.getProperty(PARENT_TARGET_RELATIVE_PATH) === InheritEvent.Event.key;
        var isCurrentNotInheritEvent =
          sInheritKey === InheritEvent.GTTDelayedEvent.key ||
          sInheritKey === InheritEvent.GTTOnTimeEvent.key;

        return isOriginalInheritEvent && isCurrentNotInheritEvent;
      },
    });
  }
);
