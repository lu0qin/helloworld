sap.ui.define([], function () {
  "use strict";

  /**
   * Enum type for where used list used type
   * @enum {string}
   * @public
   */

  var UsedType = {
    Dependency: "dependency",
    Association: "association",
  };

  return UsedType;
});
