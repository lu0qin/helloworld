sap.ui.define([], function () {
  "use strict";

  /**
   * Enum type for the erp object type
   * @enum {string}
   * @public
   */
  var ErpObjectType = {
    Others: "OTHERS",
    PurchaseOrderItem: "PO_ITEM",
    SalesOrderHeader: "SO_HEADER",
    SalesOrderItem: "SO_ITEM",
    DeliveryHeader: "DLV_HEADER",
    DeliveryItem: "DLV_ITEM",
    ShipmentHeader: "SHIP_HEADER",
  };

  return ErpObjectType;
});
