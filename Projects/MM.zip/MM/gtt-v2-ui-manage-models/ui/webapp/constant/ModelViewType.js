sap.ui.define([], function () {
  "use strict";

  /**
   * Enum type for the view type
   * @enum {string}
   * @public
   */
  var ModelViewType = {
    Draft: "draftView",
    Runtime: "runtimeView",
    Deployed: "deployedView",
    History: "historyView",
  };

  return ModelViewType;
});
