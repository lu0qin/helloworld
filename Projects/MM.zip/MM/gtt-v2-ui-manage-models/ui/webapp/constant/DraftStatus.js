sap.ui.define([], function () {
  "use strict";

  /**
   * Enum type for the draft status
   * @enum {string}
   * @public
   */
  var DraftStatus = {
    Draft: "DRAFT",
    Deployed: "DEPLOYED",
    BeingDeployed: "BEING_DEPLOYED",
    BeingDeleted: "BEING_DELETED",
  };

  return DraftStatus;
});
