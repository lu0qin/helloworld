sap.ui.define([], function () {
  "use strict";

  /**
   * Enum type for the operation status
   * @enum {string}
   * @public
   */
  var OperationStatus = {
    Undeployed: "Undeployed",
    NewDraftAfterDeployed: "NewDraftAfterDeployed",
    Deployed: "Deployed",
    DeployWarning: "DeployWarning",
    DeployError: "DeployError",
    DeployPending: "DeployPending",
    DeletePending: "DeletePending",
    DeleteError: "DeleteError",
    DeleteFailedWithTechnicalError: "DeleteFailedWithTechnicalError",
    DeployFailedWithValidationError: "DeployFailedWithValidationError",
    DeployFailedWithTechnicalError: "DeployFailedWitTechnicalError",
  };

  return OperationStatus;
});
