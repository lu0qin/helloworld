sap.ui.define([], function () {
  "use strict";

  /**
   * Enum type for update action
   * @enum {string}
   * @public
   */

  var ActionType = {
    Create: "Create",
    Update: "Update",
    Delete: "Delete",
  };

  return ActionType;
});
