sap.ui.define([], function () {
  "use strict";

  /**
   * Enum type for idoc event group type
   * @enum {string}
   * @public
   */
  var IDocEventType = {
    ProcessType: "processType",
    PlannedEvent: "plannedEvent",
    ActualEvent: "actualEvent",
  };

  return IDocEventType;
});
