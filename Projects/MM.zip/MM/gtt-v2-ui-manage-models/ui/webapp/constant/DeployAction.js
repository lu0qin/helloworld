sap.ui.define([], function () {
  "use strict";

  /**
   * Enum type for the deploy action
   * @enum {string}
   * @public
   */
  var DeployAction = {
    Deploy: "DEPLOY",
    Redeploy: "REDEPLOY",
    Activate: "ACTIVATE",
    Deactivate: "DEACTIVATE",
    Delete: "DELETE",
  };

  return DeployAction;
});
