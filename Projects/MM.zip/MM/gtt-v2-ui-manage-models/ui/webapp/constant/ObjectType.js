sap.ui.define([], function () {
  "use strict";

  /**
   * Enum type for Object
   * @enum {string}
   * @public
   */
  var ObjectType = {
    ProcessType: "ProcessType",
    ItemType: "ItemType",
    EventType: "EventType",
    CodeList: "CodeList",
    Code: "Code",
    UserField: "UserField",
    AdmissiblePlannedEvent: "AdmissiblePlannedEvent",
    AdmissibleUnplannedEvent: "AdmissibleUnplannedEvent",
    PlannedEventExtension: "PlannedEventExtension",
  };

  return ObjectType;
});
