sap.ui.define([], function () {
  "use strict";

  /**
   * Enum type for the text type
   * @enum {string}
   * @public
   */
  var TextType = {
    Label: "LABEL",
    Name: "NAME",
    Descr: "DESCR",
  };

  return TextType;
});
