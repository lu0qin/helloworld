sap.ui.define([], function () {
  "use strict";

  var InheritEvent = {};
  /**
   * Enum type for the inherit event
   * @readonly
   * @enum {string}
   */
  InheritEvent = {
    Event: {
      key: "CoreModel.Event",
      value: "Event",
    },
    GTTDelayedEvent: {
      key: "CoreModel.GTTDelayedEvent",
      value: "GTTDelayedEvent",
    },
    GTTOnTimeEvent: {
      key: "CoreModel.GTTOnTimeEvent",
      value: "GTTOnTimeEvent",
    },
  };

  return InheritEvent;
});
