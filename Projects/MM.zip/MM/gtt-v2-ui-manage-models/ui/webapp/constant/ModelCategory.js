sap.ui.define([], function () {
  "use strict";

  /**
   * Enum type for model category
   * @readonly
   * @enum {string}
   */
  var ModelCategory = {
    Standard: "STANDARD",
    User: "USER",
  };

  return ModelCategory;
});
