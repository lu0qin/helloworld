sap.ui.define(["sap/ui/core/ValueState"], function (ValueState) {
  "use strict";

  var FieldType = {};
  /**
   * Enum type for the process types
   * @readonly
   * @enum {string}
   */
  FieldType = {
    Uuid: "uuid",
    String: "string",
    Boolean: "boolean",
    Integer: "integer",
    Decimal: "decimal",
    Date: "date",
    Timestamp: "timestamp",
    Composition: "composition",
    CodeList: "codelist",
    Association: "association",
    AssociationToOne: "associationToOne",
    AssociationToMany: "associationToMany",

    isItemAssociationToMany: function (item) {
      return Boolean(
        item.type === FieldType.Association && !FieldType.isItemAssociationToOne(item)
      );
    },

    isItemAssociationToOne: function (item) {
      return Boolean(
        item.type === FieldType.Association && item._ref && item._ref.target && !item._ref.backlink
      );
    },
  };

  return FieldType;
});
