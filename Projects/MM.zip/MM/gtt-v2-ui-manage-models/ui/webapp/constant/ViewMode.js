sap.ui.define([], function () {
  "use strict";

  /**
   * Enum type for the view mode
   * @enum {string}
   * @public
   */
  var ViewMode = {
    Display: "display",
    Create: "create",
    Edit: "edit",
  };

  return ViewMode;
});
