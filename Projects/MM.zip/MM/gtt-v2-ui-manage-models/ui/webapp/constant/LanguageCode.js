sap.ui.define([], function () {
  "use strict";

  var LanguageCode = {};
  /**
   * Enum type for i18n language code
   * @readonly
   * @enum {string}
   */
  LanguageCode = {
    English: "en",
    German: "de",
    Spanish: "es",
    French: "fr",
    Dutch: "nl",
    Polish: "pl",
    Portuguese: "pt_BR",
    Russian: "ru",
    Turkish: "tr",
    Chinese: "zh_CN",
    Italian: "it",
  };

  return LanguageCode;
});
