sap.ui.define([], function () {
  "use strict";

  /**
   * Enum type for the model status
   * @enum {string}
   * @public
   */
  var ModelStatus = {
    Active: "ACTIVE",
    Inactive: "INACTIVE",
  };

  return ModelStatus;
});
