sap.ui.define(["sap/ui/core/ValueState"], function (ValueState) {
  "use strict";

  var DppType = {};
  /**
   * Enum type for the process types
   * @readonly
   * @enum {string}
   */
  DppType = {
    PII: {
      key: "PII",
      name: "dpp_PII",
    },
    DATA_SUBJECT_ID: {
      key: "DATA_SUBJECT_ID",
      name: "dpp_DATA_SUBJECT_ID",
    },
  };

  return DppType;
});
