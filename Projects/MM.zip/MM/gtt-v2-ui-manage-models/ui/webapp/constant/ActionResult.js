sap.ui.define([], function () {
  "use strict";

  /**
   * Enum type for the action result
   * @enum {string}
   * @public
   */
  var ActionResult = {
    Info: "INFO",
    Success: "SUCCESS",
    TechnicalError: "TECHNICAL_ERROR",
    ValidationError: "VALIDATION_ERROR",
    Warning: "WARNING",
  };

  return ActionResult;
});
