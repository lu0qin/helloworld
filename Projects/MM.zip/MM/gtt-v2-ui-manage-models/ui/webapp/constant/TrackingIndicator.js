sap.ui.define([], function () {
  "use strict";

  /**
   * Enum type for tracking indicator
   * @enum {string}
   * @public
   */
  var TrackingIndicator = {
    Shipment: "01",
    Resource: "02",
  };

  return TrackingIndicator;
});
