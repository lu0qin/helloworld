sap.ui.define(
  [
    "../constant/FieldType",
    "sap/ui/core/Fragment",
    "sap/ui/core/MessageType",
    "sap/ui/core/ValueState",
  ],
  function (FieldType, Fragment, MessageType, ValueState) {
    "use strict";

    var INPUT_CONTROL_CLASS_NAME = "sap.m.Input";
    var SELECT_CONTROL_CLASS_NAME = "sap.m.Select";
    var COMBOBOX_CONTROL_CLASS_NAME = "sap.m.ComboBox";
    var MULTI_COMBOBOX_CONTROL_CLASS_NAME = "sap.m.MultiComboBox";
    var CHECKBOX_CONTROL_CLASS_NAME = "sap.m.CheckBox";

    var ValidationHelper = {};

    ValidationHelper.setControlValidationError = function (oControl, sMsg) {
      var sProperty = "value";
      var sType = oControl.getMetadata().getName();
      switch (sType) {
        case INPUT_CONTROL_CLASS_NAME:
          break;
        case SELECT_CONTROL_CLASS_NAME:
          sProperty = "selectedKey";
          break;
        case MULTI_COMBOBOX_CONTROL_CLASS_NAME:
          sProperty = "selectedKeys";
          break;
        case CHECKBOX_CONTROL_CLASS_NAME:
          sProperty = "selected";
          break;
      }

      oControl.fireValidationError(
        {
          element: oControl,
          property: sProperty,
          message: sMsg,
        },
        false,
        true
      );
    };

    ValidationHelper.setControlValidationWarning = function (oControl, sMsg) {
      oControl.setValueState(ValueState.Warning);
      oControl.setValueStateText(sMsg);
    };

    ValidationHelper.resetControlValidation = function (oControl) {
      oControl.setValueState(ValueState.None);
      oControl.setValueStateText("");
    };

    ValidationHelper.setControlValidationState = function (oControl, sValueState, sMsg) {
      oControl.setValueState(sValueState);
      oControl.setValueStateText(sMsg);
    };

    ValidationHelper.setControlValidationSuccess = function (oControl, sMsg) {
      var sProperty = "value";
      var sType = oControl.getMetadata().getName();
      switch (sType) {
        case INPUT_CONTROL_CLASS_NAME:
          break;
        case SELECT_CONTROL_CLASS_NAME:
          sProperty = "selectedKey";
          break;
        case MULTI_COMBOBOX_CONTROL_CLASS_NAME:
          sProperty = "selectedKeys";
          break;
        case CHECKBOX_CONTROL_CLASS_NAME:
          sProperty = "selected";
          break;
      }

      oControl.fireValidationSuccess(
        {
          element: oControl,
          property: sProperty,
          message: sMsg,
        },
        false,
        true
      );
    };

    ValidationHelper.checkValueState = function (oControls) {
      var aErrors = [];

      oControls.forEach(function (oControl) {
        var sFieldExistError = oControl
          .getModel("i18n")
          .getResourceBundle()
          .getText("fieldExistError");
        var sMandatoryFieldMissing = oControl
          .getModel("i18n")
          .getResourceBundle()
          .getText("mandatoryFieldMissing");

        var sType = oControl.getMetadata().getName();
        var sStatus = oControl.getValueState();
        var sAdditionalText = ValidationHelper.getAdditionalText(oControl);

        switch (sType) {
          case INPUT_CONTROL_CLASS_NAME:
          case SELECT_CONTROL_CLASS_NAME:
            var sValueStateText = oControl.getValueStateText();
            var sMessage = sValueStateText || sFieldExistError;
            if (sStatus === ValueState.Error && sValueStateText !== sMandatoryFieldMissing) {
              aErrors.push({
                message: sMessage,
                type: MessageType.Error,
                additionalText: sAdditionalText,
                isPositional: false,
              });
            }
            break;
          case CHECKBOX_CONTROL_CLASS_NAME:
          case MULTI_COMBOBOX_CONTROL_CLASS_NAME:
            if (sStatus === ValueState.Error) {
              aErrors.push({
                message: sMessage,
                type: MessageType.Error,
                additionalTest: sAdditionalText,
                isPositional: false,
              });
            }
            break;
          case COMBOBOX_CONTROL_CLASS_NAME:
            if (sStatus === ValueState.Error) {
              aErrors.push({
                message: sMessage,
                type: MessageType.Error,
                additionalTest: sAdditionalText,
                isPositional: false,
              });
            }
        }
      });

      return aErrors;
    };

    ValidationHelper.validateMandatory = function (oControls) {
      var aErrors = [];

      oControls.forEach(function (oControl) {
        var sType = oControl.getMetadata().getName();
        var sAdditionalText = ValidationHelper.getAdditionalText(oControl);
        var sMandatoryFieldMissing = oControl
          .getModel("i18n")
          .getResourceBundle()
          .getText("mandatoryFieldMissing");

        switch (sType) {
          case INPUT_CONTROL_CLASS_NAME:
            if (oControl.getValue() === "") {
              ValidationHelper.setControlValidationError(oControl, sMandatoryFieldMissing);
              aErrors.push({
                message: sMandatoryFieldMissing,
                type: MessageType.Error,
                additionalText: sAdditionalText,
                isPositional: false,
              });
            }
            break;

          case SELECT_CONTROL_CLASS_NAME:
            if (oControl.getSelectedKey() === "") {
              ValidationHelper.setControlValidationError(oControl, sMandatoryFieldMissing);
              aErrors.push({
                message: sMandatoryFieldMissing,
                type: MessageType.Error,
                additionalText: sAdditionalText,
                isPositional: false,
              });
            }
            break;

          case COMBOBOX_CONTROL_CLASS_NAME:
            if (oControl.getValue() === "") {
              ValidationHelper.setControlValidationError(oControl, sMandatoryFieldMissing);
              aErrors.push({
                message: sMandatoryFieldMissing,
                type: MessageType.Error,
                additionalText: sAdditionalText,
                isPositional: false,
              });
            }
            break;
        }
      });

      return aErrors;
    };

    ValidationHelper.checkMessageModel = function () {
      var aMessages = sap.ui.getCore().getMessageManager().getMessageModel().getData();

      var isErrorExist = aMessages.some(function (oMessage) {
        return oMessage.getType() === MessageType.Error;
      });

      return !isErrorExist;
    };

    ValidationHelper.getAdditionalText = function (oControl) {
      var sControlType = oControl.getMetadata().getName();
      var aSplitType = sControlType.split(".");

      var sAdditionalText = aSplitType[aSplitType.length - 1];
      if (oControl.getLabels() && oControl.getLabels()[0]) {
        sAdditionalText = oControl.getLabels()[0].getText();
      }

      return sAdditionalText;
    };

    return ValidationHelper;
  }
);
