sap.ui.define(["../constant/LanguageCode", "../util/I18NHelper"], function (
  LanguageCode,
  I18NHelper
) {
  "use strict";

  var TranslationHelper = {};

  TranslationHelper.getCurrentLanguageCode = function () {
    var sCurrentLocale = sap.ui.getCore().getConfiguration().getLanguage();
    return I18NHelper.normalizeJavaLocale(sCurrentLocale);
  };

  TranslationHelper.checkIfLanguageIsSupported = function (currentLanguageCode) {
    var supportLanguages = Object.values(LanguageCode);

    return supportLanguages.find(function (item) {
      return currentLanguageCode === item;
    }) !== undefined;
  };

  TranslationHelper.getDefaultLanguageKeys = function () {
    var englishCode = LanguageCode.English;
    var currentLanguageCode = TranslationHelper.getCurrentLanguageCode();

    return currentLanguageCode === englishCode ? [englishCode] : [englishCode, currentLanguageCode];
  };

  return TranslationHelper;
});
