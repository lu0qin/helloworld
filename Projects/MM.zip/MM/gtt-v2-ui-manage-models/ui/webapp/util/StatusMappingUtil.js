sap.ui.define(
  [
    "sap/ui/core/ValueState",
    "../constant/ActionResult",
    "../constant/DraftStatus",
    "../constant/OperationStatus",
  ],
  function (ValueState, ActionResult, DraftStatus, OperationStatus) {
    "use strict";

    var StatusMappingUtil = {
      getOperationStatus: function (draftStatus, lastActionResult) {
        // Undeployed
        if (!lastActionResult) {
          if (draftStatus === DraftStatus.Draft) {
            return OperationStatus.Undeployed;
          } else {
            return "";
          }
        }

        switch (draftStatus) {
          case DraftStatus.Draft:
            return this.getDraftOperationStatus(lastActionResult);
          case DraftStatus.Deployed:
            return this.getDeployedOperationStatus(lastActionResult);
          case DraftStatus.BeingDeployed:
          case DraftStatus.BeingDeleted:
            return this.getPendingOperationStatus(draftStatus, lastActionResult);
          default:
            break;
        }

        return "";
      },

      getDraftOperationStatus: function (lastActionResult) {
        if (
          lastActionResult === ActionResult.Success ||
          lastActionResult === ActionResult.Warning
        ) {
          return OperationStatus.NewDraftAfterDeployed;
        }

        if (lastActionResult === ActionResult.ValidationError) {
          return OperationStatus.DeployFailedWithValidationError;
        }

        return "";
      },

      getDeployedOperationStatus: function (lastActionResult) {
        if (lastActionResult === ActionResult.Success) {
          return OperationStatus.Deployed;
        }

        if (lastActionResult === ActionResult.Warning) {
          return OperationStatus.DeployWarning;
        }

        return "";
      },

      getPendingOperationStatus: function (draftStatus, lastActionResult) {
        if (lastActionResult === ActionResult.Info) {
          if (draftStatus === DraftStatus.BeingDeleted) {
            return OperationStatus.DeletePending;
          }
          if (draftStatus === DraftStatus.BeingDeployed) {
            return OperationStatus.DeployPending;
          }
        }

        if (lastActionResult === ActionResult.TechnicalError) {
          if (draftStatus === DraftStatus.BeingDeleted) {
            return OperationStatus.DeleteFailedWithTechnicalError;
          }
          if (draftStatus === DraftStatus.BeingDeployed) {
            return OperationStatus.DeployFailedWithTechnicalError;
          }
        }

        return "";
      },
    };

    return StatusMappingUtil;
  }
);
