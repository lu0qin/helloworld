sap.ui.define(function () {
  "use strict";

  var I18NHelper = {};

  // copy from sap/base/i18n/ResourceBundle

  /**
   * A regular expression that describes language tags according to BCP-47.
   * @see BCP47 "Tags for Identifying Languages" (http://www.ietf.org/rfc/bcp/bcp47.txt)
   *
   * The matching groups are
   *  0=all
   *  1=language (shortest ISO639 code + ext. language sub tags | 4digits (reserved) | registered language sub tags)
   *  2=script (4 letters)
   *  3=region (2letter language or 3 digits)
   *  4=variants (separated by '-', Note: capturing group contains leading '-' to shorten the regex!)
   *  5=extensions (including leading singleton, multiple extensions separated by '-')
   *  6=private use section (including leading 'x', multiple sections separated by '-')
   *
   *              [-------------------- language ----------------------][--- script ---][------- region --------][------------- variants --------------][----------- extensions ------------][------ private use -------]
   */
  var rLocale = /^((?:[A-Z]{2,3}(?:-[A-Z]{3}){0,3})|[A-Z]{4}|[A-Z]{5,8})(?:-([A-Z]{4}))?(?:-([A-Z]{2}|[0-9]{3}))?((?:-[0-9A-Z]{5,8}|-[0-9][0-9A-Z]{3})*)((?:-[0-9A-WYZ](?:-[0-9A-Z]{2,8})+)*)(?:-(X(?:-[0-9A-Z]{1,8})+))?$/i;

  /**
   * Resource bundles are stored according to the Java Development Kit conventions.
   * JDK uses old language names for a few ISO639 codes ("iw" for "he", "ji" for "yi", "in" for "id" and "sh" for "sr").
   * Make sure to convert newer codes to older ones before creating file names.
   * @const
   * @private
   */
  var M_ISO639_NEW_TO_OLD = {
    he: "iw",
    yi: "ji",
    id: "in",
    sr: "sh",
    nb: "no",
  };

  var rSAPSupportabilityLocales = /(?:^|-)(saptrc|sappsd)(?:-|$)/i;

  /**
   * Helper to normalize the given locale (in BCP-47 syntax) to the java.util.Locale format.
   * @param {string} sLocale locale to normalize
   * @returns {string} Normalized locale or undefined if the locale can't be normalized
   */
  var normalize = function (sLocale) {
    if (typeof sLocale !== "string") {
      return sLocale;
    }

    var m = rLocale.exec(sLocale.replace(/_/g, "-"));
    if (m) {
      var sLanguage = m[1].toLowerCase();
      sLanguage = M_ISO639_NEW_TO_OLD[sLanguage] || sLanguage;
      var sScript = m[2] ? m[2].toLowerCase() : undefined;
      var sRegion = m[3] ? m[3].toUpperCase() : undefined;
      var sVariants = m[4] ? m[4].slice(1) : undefined;
      var sPrivate = m[6];

      // recognize and convert special SAP supportability locales (overwrites m[]!)
      if (
        (sPrivate && (m = rSAPSupportabilityLocales.exec(sPrivate))) ||
        (sVariants && (m = rSAPSupportabilityLocales.exec(sVariants)))
      ) {
        return "en_US_" + m[1].toLowerCase(); // for now enforce en_US (agreed with SAP SLS)
      }

      // Chinese: when no region but a script is specified, use default region for each script
      if (sLanguage === "zh" && !sRegion) {
        if (sScript === "hans") {
          sRegion = "CN";
        } else if (sScript === "hant") {
          sRegion = "TW";
        }
      }

      return (
        sLanguage +
        (sRegion ? "_" + sRegion + (sVariants ? "_" + sVariants.replace("-", "_") : "") : "")
      );
    }

    return sLocale;
  };

  I18NHelper.normalizeJavaLocale = normalize;

  return I18NHelper;
});
