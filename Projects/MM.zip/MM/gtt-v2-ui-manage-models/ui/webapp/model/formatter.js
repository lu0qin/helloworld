sap.ui.define(
  [
    "sap/base/strings/formatMessage",
    "sap/base/util/ObjectPath",
    "sap/ui/core/ValueState",
    "sap/ui/core/MessageType",
    "sap/m/ButtonType",
    "sap/m/ListType",
    "../constant/ActionResult",
    "../constant/DraftStatus",
    "../constant/ErpObjectType",
    "../constant/OperationStatus",
    "../constant/ModelStatus",
    "../constant/ModelViewType",
    "../constant/TextType",
    "../constant/TrackingIndicator",
    "../constant/ViewMode",
    "../util/I18NHelper",
    "../util/StatusMappingUtil",
    "../constant/FieldType",
    "../constant/DppType",
    "../constant/LanguageCode",
    "../constant/ModelCategory",
  ],
  function (
    formatMessage,
    ObjectPath,
    ValueState,
    MessageType,
    ButtonType,
    ListType,
    ActionResult,
    DraftStatus,
    ErpObjectType,
    OperationStatus,
    ModelStatus,
    ModelViewType,
    TextType,
    TrackingIndicator,
    ViewMode,
    I18NHelper,
    StatusMappingUtil,
    FieldType,
    DppType,
    LanguageCode,
    ModelCategory
  ) {
    "use strict";

    var formatter = {
      getFormatterResourceBundle: function () {
        if (!this.getResourceBundle()) {
          // fragment call
          return this.getView().getModel("i18n").getResourceBundle();
        }

        return this.getResourceBundle();
      },

      getI18NText: function (key) {
        var resourceBundle = formatter.getFormatterResourceBundle.apply(this);

        return resourceBundle.getText(key) || key;
      },

      getI18NTextByEnumKey: function (value, prefix, enumObj) {
        var keys = Object.keys(enumObj);
        var enumKey = "";
        for (var i = 0; i < keys.length; i++) {
          if (enumObj[keys[i]] === value) {
            enumKey = keys[i];
            break;
          }
        }

        if (!enumKey) {
          return value;
        }

        return formatter.getI18NText.apply(this, [prefix.concat(enumKey)]);
      },

      getI18NTextByEnumValue: function (value, prefix, enumObj) {
        if (Object.values(enumObj).indexOf(value) === -1) {
          return value;
        }

        return formatter.getI18NText.apply(this, [prefix.concat(value)]);
      },

      // ========================================================
      // Model List
      // ========================================================
      draftStatusText: function (status) {
        var resourceBundle = formatter.getFormatterResourceBundle.apply(this);

        switch (status) {
          case DraftStatus.Draft:
            return resourceBundle.getText("draft");
          case DraftStatus.Deployed:
            return resourceBundle.getText("deployed");
          default:
            return status;
        }
      },

      isLastOperationStatusVisible: function (lastOperationStatus) {
        return !!lastOperationStatus && lastOperationStatus !== OperationStatus.Undeployed;
      },

      lastOperationStatusText: function (lastOperationStatus) {
        var resourceBundle = formatter.getFormatterResourceBundle.apply(this);

        switch (lastOperationStatus) {
          case OperationStatus.NewDraftAfterDeployed:
          case OperationStatus.Deployed:
            return resourceBundle.getText("deploySuccess");
          case OperationStatus.DeployPending:
            return resourceBundle.getText("deployPending");
          case OperationStatus.DeployWarning:
            return resourceBundle.getText("deployWarning");
          case OperationStatus.DeployFailedWithValidationError:
          case OperationStatus.DeployFailedWithTechnicalError:
            return resourceBundle.getText("deployError");
          case OperationStatus.DeletePending:
            return resourceBundle.getText("deletePending");
          case OperationStatus.DeleteFailedWithTechnicalError:
            return resourceBundle.getText("deleteError");
          default:
            return "";
        }
      },

      lastOperationStatusIcon: function (lastOperationStatus) {
        switch (lastOperationStatus) {
          case OperationStatus.DeployPending:
          case OperationStatus.DeletePending:
            return "sap-icon://pending";
          case OperationStatus.NewDraftAfterDeployed:
          case OperationStatus.Deployed:
          case OperationStatus.DeployWarning:
            return "sap-icon://status-positive";
          case OperationStatus.DeployFailedWithValidationError:
          case OperationStatus.DeployFailedWithTechnicalError:
          case OperationStatus.DeleteFailedWithTechnicalError:
            return "sap-icon://status-error";
          default:
            return "";
        }
      },

      lastOperationStatusState: function (lastOperationStatus) {
        switch (lastOperationStatus) {
          case OperationStatus.DeployPending:
          case OperationStatus.DeletePending:
          case OperationStatus.DeployWarning:
            return ValueState.Warning;
          case OperationStatus.NewDraftAfterDeployed:
          case OperationStatus.Deployed:
            return ValueState.Success;
          case OperationStatus.DeployFailedWithValidationError:
          case OperationStatus.DeployFailedWithTechnicalError:
          case OperationStatus.DeleteFailedWithTechnicalError:
            return ValueState.Error;
          // undeployed
          default:
            return ValueState.None;
        }
      },

      // ========================================================
      // Model Detail
      // ========================================================
      isDeployButtonVisible: function (modelVersion, mode, draftStatus) {
        return (
          modelVersion === DraftStatus.Draft &&
          mode === ViewMode.Display &&
          draftStatus === DraftStatus.Draft
        );
      },

      isEditButtonVisible: function (modelVersion, mode, draftStatus) {
        return (
          mode === ViewMode.Display &&
          modelVersion === DraftStatus.Draft &&
          (draftStatus === DraftStatus.Draft || draftStatus === DraftStatus.Deployed)
        );
      },

      isCRUDButtonVisible: function (mode, modelVersion, draftStatus) {
        if (mode === ViewMode.Create) {
          return modelVersion === DraftStatus.Draft;
        } else {
          return (
            modelVersion === DraftStatus.Draft &&
            (draftStatus === DraftStatus.Draft || draftStatus === DraftStatus.Deployed)
          );
        }
      },

      isImportButtonVisible: function (
        mode,
        modelVersion,
        draftStatus,
        modelCategory,
        entityCategory
      ) {
        return (
          formatter.isCRUDButtonVisible(mode, modelVersion, draftStatus) &&
          modelCategory === ModelCategory.Standard &&
          entityCategory !== ModelCategory.Standard
        );
      },

      detailPressType: function (mode, modelVersion, draftStatus) {
        if (formatter.isCRUDButtonVisible(mode, modelVersion, draftStatus)) {
          return ListType.Detail;
        } else {
          return ListType.Inactive;
        }
      },

      modelStatusText: function (status) {
        var resourceBundle = formatter.getFormatterResourceBundle.apply(this);

        switch (status) {
          case ModelStatus.Active:
            return resourceBundle.getText("active");
          case ModelStatus.Inactive:
            return resourceBundle.getText("inactive");
          default:
            return status;
        }
      },

      modelStatusState: function (status) {
        switch (status) {
          case ModelStatus.Active:
            // Semantic color - green for Active model status
            return ValueState.Success;
          case ModelStatus.Inactive:
            // Semantic color - orange for Inactive model status
            return ValueState.Warning;
          default:
            return ValueState.None;
        }
      },

      modelViewText: function (viewType) {
        return formatter.getI18NTextByEnumValue.apply(this, [viewType, "", ModelViewType]);
      },

      detailDraftStatusText: function (lastOperationStatus) {
        var resourceBundle = formatter.getFormatterResourceBundle.apply(this);

        switch (lastOperationStatus) {
          case OperationStatus.Undeployed:
          case OperationStatus.NewDraftAfterDeployed:
            return resourceBundle.getText("draft");
          case OperationStatus.DeployPending:
            return resourceBundle.getText("beingDeployed");
          case OperationStatus.DeployFailedWithValidationError:
            return resourceBundle.getText("draftWithError");
          case OperationStatus.DeployFailedWithTechnicalError:
            return resourceBundle.getText("beingDeployedWithError");
          case OperationStatus.DeletePending:
            return resourceBundle.getText("beingDeleted");
          case OperationStatus.DeleteFailedWithTechnicalError:
            return resourceBundle.getText("beingDeletedWithError");
          // warning or success
          default:
            return "";
        }
      },

      detailDraftStatusState: function (lastOperationStatus) {
        switch (lastOperationStatus) {
          // deploy/delete pending
          case OperationStatus.DeployPending:
          case OperationStatus.DeletePending:
            return ValueState.Warning;
          // deploy/delete error
          case OperationStatus.DeployFailedWithValidationError:
          case OperationStatus.DeployFailedWithTechnicalError:
          case OperationStatus.DeleteFailedWithTechnicalError:
            return ValueState.Error;
          // new draft or deployed
          default:
            return ValueState.Information;
        }
      },

      detailDraftStatusIcon: function (lastOperationStatus) {
        switch (lastOperationStatus) {
          // new draft
          case OperationStatus.Undeployed:
          case OperationStatus.NewDraftAfterDeployed:
            return "sap-icon://user-edit";
          // pending
          case OperationStatus.DeployPending:
          case OperationStatus.DeletePending:
            return "sap-icon://pending";
          // error
          case OperationStatus.DeployFailedWithValidationError:
          case OperationStatus.DeployFailedWithTechnicalError:
          case OperationStatus.DeleteFailedWithTechnicalError:
            return "sap-icon://status-error";
          // success or warning
          default:
            return "";
        }
      },

      formatMessagePopoverButtonType: function (aMessages) {
        var sHighestSeverity;
        aMessages.forEach(function (sMessage) {
          switch (sMessage.type) {
            case MessageType.Error:
              sHighestSeverity = ButtonType.Negative;
              break;
            case MessageType.Warning:
              sHighestSeverity =
                sHighestSeverity !== ButtonType.Negative ? ButtonType.Critical : sHighestSeverity;
              break;
            case MessageType.Success:
              sHighestSeverity =
                sHighestSeverity !== ButtonType.Negative && sHighestSeverity !== ButtonType.Critical
                  ? ButtonType.Success
                  : sHighestSeverity;
              break;
            default:
              sHighestSeverity = !sHighestSeverity ? ButtonType.Neutral : sHighestSeverity;
              break;
          }
        });

        return sHighestSeverity;
      },

      formatMessagePopoverButtonIcon: function (aMessages) {
        var ICON_URL_SET = {
          MESSAGE_ERROR: "sap-icon://message-error",
          MESSAGE_WARNING: "sap-icon://message-warning",
          MESSAGE_SUCCESS: "sap-icon://message-success",
        };

        var sIcon;
        aMessages.forEach(function (sMessage) {
          switch (sMessage.type) {
            case MessageType.Error:
              sIcon = ICON_URL_SET.MESSAGE_ERROR;
              break;
            case MessageType.Warning:
              sIcon = sIcon !== ICON_URL_SET.MESSAGE_ERROR ? ICON_URL_SET.MESSAGE_WARNING : sIcon;
              break;
            case MessageType.Success:
              sIcon =
                ICON_URL_SET.MESSAGE_ERROR && sIcon !== ICON_URL_SET.MESSAGE_WARNING
                  ? ICON_URL_SET.MESSAGE_SUCCESS
                  : sIcon;
              break;
            default:
              sIcon = !sIcon ? "sap-icon://message-information" : sIcon;
              break;
          }
        });

        return sIcon;
      },

      // ========================================================
      // Translation Dialog
      // ========================================================
      languageName: function (languageCode) {
        return formatter.getI18NTextByEnumKey.apply(this, [languageCode, "language", LanguageCode]);
      },

      textTypeName: function (sKey) {
        var resourceBundle = formatter.getFormatterResourceBundle.apply(this);

        switch (sKey) {
          case TextType.Label:
            return resourceBundle.getText("label");
          case TextType.Name:
            return resourceBundle.getText("name");
          case TextType.Descr:
            return resourceBundle.getText("description");
          default:
            return sKey;
        }
      },

      getTranslatedText: function (oTranslation, sDefault) {
        var sCurrentLocale = sap.ui.getCore().getConfiguration().getLanguage();
        var currentLanguageCode = I18NHelper.normalizeJavaLocale(sCurrentLocale);
        var sTranslatedText = ObjectPath.get(currentLanguageCode, oTranslation);

        return sTranslatedText || sDefault;
      },

      // ========================================================
      // User Fields
      // Edit Field Dialog
      // ========================================================
      formatDppText: function (dppArr) {
        var resourceBundle = formatter.getFormatterResourceBundle.apply(this);

        if (dppArr && dppArr.length !== 0) {
          var dppStr = "";
          var getDppValue = function (dpp) {
            switch (dpp) {
              case DppType.PII.key:
                return resourceBundle.getText(DppType.PII.name);
              case DppType.DATA_SUBJECT_ID.key:
                return resourceBundle.getText(DppType.DATA_SUBJECT_ID.name);
              default:
                return "";
            }
          };

          dppArr.forEach(function (dpp, index) {
            dppStr = dppStr + getDppValue(dpp);
            if (index !== dppArr.length - 1) {
              dppStr = dppStr + ",\n";
            }
          });
          return dppStr;
        } else {
          return "";
        }
      },

      isDppColumnVisibleInDialog: function (isShowDppColumn, type) {
        return (
          isShowDppColumn &&
          type !== FieldType.AssociationToOne &&
          type !== FieldType.AssociationToMany &&
          type !== FieldType.Composition &&
          type !== FieldType.CodeList
        );
      },

      formatAuthScopesText: function (authScopesArr) {
        var resourceBundle = formatter.getFormatterResourceBundle.apply(this);

        if (authScopesArr && authScopesArr.length !== 0) {
          var authScopeStr = "";

          var getAuthScopesValue = function (authScope) {
            switch (authScope) {
              case "READ":
                return resourceBundle.getText("authScope_READ");
              case "REPORT":
                return resourceBundle.getText("authScope_REPORT");
              default:
                return "";
            }
          };

          authScopesArr.forEach(function (authScope, index) {
            authScopeStr = authScopeStr + getAuthScopesValue(authScope);
            if (index !== authScopesArr.length - 1) {
              authScopeStr = authScopeStr + ",\n";
            }
          });
          return authScopeStr;
        } else {
          return "";
        }
      },

      formatFieldType: function (type, length, precision, scale, targetName, backlinkName) {
        var resourceBundle = formatter.getFormatterResourceBundle.apply(this);

        switch (type) {
          case FieldType.Uuid:
          case FieldType.Boolean:
          case FieldType.Integer:
          case FieldType.Date:
          case FieldType.Timestamp:
            return formatter.formatTypeText.apply(this, [type]);

          case FieldType.String:
            return length
              ? resourceBundle.getText("fieldTypeStringWithLength", [length])
              : resourceBundle.getText("fieldTypeStringWithoutLength");

          case FieldType.Decimal:
            return resourceBundle.getText("fieldTypeDecimalWithPrecisionAndScale", [
              precision,
              scale,
            ]);

          case FieldType.Association:
            if (targetName) {
              if (backlinkName) {
                return resourceBundle.getText("associationToMany", [targetName, backlinkName]);
              } else {
                return resourceBundle.getText("associationToOne", targetName);
              }
            }
            return resourceBundle.getText("fieldTypeAssociation");

          case FieldType.Composition:
            if (targetName) {
              return resourceBundle.getText("compositionOf", targetName);
            } else {
              return resourceBundle.getText("fieldTypeComposition");
            }

          case FieldType.CodeList:
            if (targetName) {
              return resourceBundle.getText("codeList").concat(" ", targetName);
            } else {
              return resourceBundle.getText("fieldTypeCodeList");
            }

          default:
            return "";
        }
      },

      formatTypeText: function (type) {
        return formatter.getI18NTextByEnumKey.apply(this, [type, "fieldType", FieldType]);
      },

      backlinkValue: function (backlink) {
        if (typeof backlink === "object" && Boolean(backlink)) {
          return backlink.name;
        }
        if (typeof backlink === "string") {
          return backlink;
        }
        return "";
      },

      backlinkSelectedKey: function (backlink) {
        if (typeof backlink === "object" && Boolean(backlink)) {
          return backlink.name;
        }
        return "";
      },

      // ========================================================
      // Admissible Planned Events
      // ========================================================
      formatExtensionMatchKey: function (extensionArr) {
        var str = "";

        if (extensionArr && extensionArr.length !== 0) {
          extensionArr.forEach(function (item, index) {
            if (item._ref && item._ref.plannedEventField && item._ref.actualEventField) {
              str = str.concat(
                item._ref.plannedEventField.name,
                "=",
                item._ref.actualEventField.name
              );
              if (index !== extensionArr.length - 1) {
                str = str.concat(",\n");
              }
            }
          });
        }

        return str;
      },

      // ========================================================
      // IDOC Integration
      // ========================================================
      displayERPObjectType: function (key) {
        return formatter.getI18NTextByEnumValue.apply(this, [key, "erpObjectType_", ErpObjectType]);
      },

      // ========================================================
      // VP Integration
      // ========================================================
      upstreamProcessTypeText: function (name) {
        if (name === "") {
          return formatter.getI18NText.apply(this, ["none"]);
        } else {
          return name;
        }
      },

      formatTrackingIndicator: function (key) {
        var resourceBundle = formatter.getFormatterResourceBundle.apply(this);

        switch (key) {
          case TrackingIndicator.Shipment:
            return formatMessage("{0} ({1})", [
              key,
              resourceBundle.getText("trackingIndicator_SHIPMENT"),
            ]);
          case TrackingIndicator.Resource:
            return formatMessage("{0} ({1})", [
              key,
              resourceBundle.getText("trackingIndicator_RESOURCE"),
            ]);
          default:
            return key;
        }
      },

      // ========================================================
      // Model History
      // ========================================================
      deployHistoryTimelineItemStatus: function (messageType) {
        switch (messageType) {
          case ActionResult.Info:
          case ActionResult.Success:
            return ValueState.Success;
          case ActionResult.TechnicalError:
          case ActionResult.ValidationError:
            return ValueState.Error;
          case ActionResult.Warning:
            return ValueState.Warning;
          default:
            return ValueState.Success;
        }
      },

      deployHistoryTimelineItemIcon: function (messageType) {
        switch (messageType) {
          case ActionResult.Info:
          case ActionResult.Success:
            return "sap-icon://synchronize";
          case ActionResult.TechnicalError:
          case ActionResult.ValidationError:
          case ActionResult.Warning:
            return "sap-icon://message-information";
          default:
            return "sap-icon://synchronize";
        }
      },
    };

    return formatter;
  }
);
