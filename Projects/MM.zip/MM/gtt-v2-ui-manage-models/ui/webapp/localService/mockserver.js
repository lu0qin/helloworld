sap.ui.define(
  [
    "sap/ui/core/util/MockServer",
    "sap/ui/model/json/JSONModel",
    "sap/base/Log",
    "sap/base/util/UriParameters",
  ],
  function (MockServer, JSONModel, Log, UriParameters) {
    "use strict";

    var MODEL_INFO_FILE_PATH = "model_info.json";

    var oMockServerInterface = {
      /**
       * Initializes the mock server asynchronously.
       * You can configure the delay with the URL parameter "serverDelay".
       * The local mock data in this folder is returned instead of the real data for testing.
       * @protected
       * @param {object} [oOptionsParameter] init parameters for the mockserver
       * @returns{Promise} a promise that is resolved when the mock server has been started
       */
      init: function (oOptionsParameter) {
        var oOptions = oOptionsParameter || {};

        return new Promise(
          function (fnResolve, fnReject) {
            var sManifestUrl = "../manifest.json";
            if (oOptions.componentName) {
              sManifestUrl = sap.ui.require.toUrl(
                oOptions.componentName.replace(/\./g, "/").concat("/manifest.json")
              );
            }

            var oManifestModel = new JSONModel(sManifestUrl);

            oManifestModel.attachRequestCompleted(function () {
              // data source
              var componentName = oManifestModel.getProperty("/sap.app/id");

              oOptions.componentName = componentName;
              oOptions.appPath = sap.ui.require
                .toUrl(componentName.replace(/\./g, "/"))
                .concat("/");

              // token service
              var tokenMockServer = this._initTokenMockServer(
                "csrfService",
                oOptions,
                oManifestModel
              );
              Log.info("Running tokenMockServer", tokenMockServer);


              // json service
              var jsonMockServer = this._initJSONMockServer(
                "mainService",
                oOptions,
                oManifestModel
              );

              // metadata service
              var metadataMockServer = this._initMetadataMockServer(
                "metadataService",
                oOptions,
                oManifestModel
              );
              Log.info("Running metadataMockServer", metadataMockServer);

              Log.info("Running the app with mock data");
              fnResolve(jsonMockServer);
            }, this);

            oManifestModel.attachRequestFailed(function () {
              var sError = "Failed to load application manifest";

              Log.error(sError);
              fnReject(new Error(sError));
            });
          }.bind(this)
        );
      },

      _initTokenMockServer: function (dataSourceName, oOptions, oManifestModel) {
        // token service
        var oMockServer = new MockServer({
          rootUri: "/",
          requests: [
            {
              method: "HEAD",
              path: /token.json(?:\?.+)?/, // "token.json?_=1234567"
              response: function (oXhr) {
                oXhr.respond(200, {
                  "X-CSRF-Token": "csrf_token_" + Date.now(),
                });
                return true;
              },
            },
          ],
        });

        oMockServer.start();

        return oMockServer;
      },

      _initJSONMockServer: function (dataSourceName, oOptions, oManifestModel) {
        var sAppPath = oOptions.appPath;
        var dataSources = oManifestModel.getProperty("/sap.app/dataSources");
        var oDataSource = dataSources[dataSourceName];

        var sMockServerUrl = sAppPath.concat(oDataSource.uri);

        var oMockServer = new MockServer({
          rootUri: sMockServerUrl,
          requests: [
            {
              method: "GET",
              path: "/models",
              response: function (oXhr) {
                var mockdataFileUrl = sAppPath + oDataSource.settings.localUri + "models.json";
                oXhr.respondFile(200, {}, mockdataFileUrl);
                return true;
              },
            },
            {
              method: "GET",
              path: "/models/:model",
              response: function (oXhr, id) {
                var mockdataFilePrefix = sAppPath + oDataSource.settings.localUri;
                var mockdataFileUrl = mockdataFilePrefix + "model.json";
                // nav to standard model for specific namespace
                if (id === "com.sap.gtt.standardtfo") {
                  mockdataFileUrl = mockdataFilePrefix + "model_standard.json";
                }
                oXhr.respondFile(200, {}, mockdataFileUrl);
                return true;
              },
            },
            {
              method: "GET",
              path: "/models/:model/draft",
              response: function (oXhr, id) {
                var mockdataFilePrefix = sAppPath + oDataSource.settings.localUri;
                var mockdataFileUrl = mockdataFilePrefix + "model_draft.json";
                // nav to standard draft model for specific namespace
                if (id === "com.sap.gtt.standardtfo") {
                  mockdataFileUrl = mockdataFilePrefix + "model_standard_draft.json";
                }
                oXhr.respondFile(200, {}, mockdataFileUrl);
                return true;
              },
            },
            {
              method: "GET",
              path: "/models/coremodel",
              response: function (oXhr) {
                var mockdataFileUrl = sAppPath + oDataSource.settings.localUri + "coremodel.json";
                oXhr.respondFile(200, {}, mockdataFileUrl);
                return true;
              },
            },
            {
              method: "GET",
              path: "/models/:model/deployments/current/info",
              response: function (oXhr, model) {
                var mockdataFileUrl = sAppPath + oDataSource.settings.localUri + MODEL_INFO_FILE_PATH;
                oXhr.respondFile(200, {}, mockdataFileUrl);
                return true;
              },
            },
            {
              method: "PUT",
              path: "/models/:model/deployments/current/status",
              response: function (oXhr, model) {
                var mockdataFileUrl = sAppPath + oDataSource.settings.localUri + MODEL_INFO_FILE_PATH;
                oXhr.respondFile(200, {}, mockdataFileUrl);
                return true;
              },
            },
            {
              method: "GET",
              path: "/models/:model/history",
              response: function (oXhr, model) {
                var mockdataFileUrl =
                  sAppPath + oDataSource.settings.localUri + "deploy_history.json";
                oXhr.respondFile(200, {}, mockdataFileUrl);
                return true;
              },
            },
            {
              method: "GET",
              path: "/idoc/presets",
              response: function (oXhr, model) {
                var mockdataFileUrl =
                  sAppPath + oDataSource.settings.localUri + "idoc_presets.json";
                oXhr.respondFile(200, {}, mockdataFileUrl);
                return true;
              },
            },
            {
              method: "GET",
              path: "/vp/presets",
              response: function (oXhr, model) {
                var mockdataFileUrl =
                  sAppPath + oDataSource.settings.localUri + "vp_presets.json";
                oXhr.respondFile(200, {}, mockdataFileUrl);
                return true;
              },
            },
            {
              method: "GET",
              path: "/system/namespace",
              response: function (oXhr, model) {
                var mockdataFileUrl =
                  sAppPath + oDataSource.settings.localUri + "namespace.json";
                oXhr.respondFile(200, {}, mockdataFileUrl);
                return true;
              },
            },
            {
              method: "PUT",
              path: "/models/:model",
              response: function (oXhr, model) {
                var mockdataFileUrl =
                  sAppPath + oDataSource.settings.localUri + MODEL_INFO_FILE_PATH;
                oXhr.respondFile(200, {}, mockdataFileUrl);
                return true;
              },
            },
            {
              method: "POST",
              path: "/models",
              response: function (oXhr, model) {
                var mockdataFileUrl =
                  sAppPath + oDataSource.settings.localUri + MODEL_INFO_FILE_PATH;
                oXhr.respondFile(200, {}, mockdataFileUrl);
                return true;
              },
            },
            {
              method: "POST",
              path: "/models/:model/deployments",
              response: function (oXhr, model) {
                var mockdataFileUrl =
                  sAppPath + oDataSource.settings.localUri + MODEL_INFO_FILE_PATH;
                oXhr.respondFile(200, {}, mockdataFileUrl);
                return true;
              },
            },
            {
              method: "GET",
              path: "/lbn/codelists",
              response: function (oXhr, model) {
                var mockdataFileUrl =
                  sAppPath + oDataSource.settings.localUri + "lbn_codelists.json";
                oXhr.respondFile(200, {}, mockdataFileUrl);
                return true;
              },
            },
            {
              method: "GET",
              path: "/lbn/codelists/:codelistName",
              response: function (oXhr, codelistName) {
                var mockdataFileUrl =
                  sAppPath + oDataSource.settings.localUri + "lbn_codelist.json";
                oXhr.respondFile(200, {}, mockdataFileUrl);
                return true;
              },
            },
          ],
        });

        oMockServer.start();

        return oMockServer;
      },

      _initMetadataMockServer: function (dataSourceName, oOptions, oManifestModel) {
        var sAppPath = oOptions.appPath;
        var dataSources = oManifestModel.getProperty("/sap.app/dataSources");
        var oDataSource = dataSources[dataSourceName];

        var sMockServerUrl = sAppPath.concat(oDataSource.uri);

        var oMockServer = new MockServer({
          rootUri: sMockServerUrl,
          requests: [
            {
              method: "GET",
              path: "/model/:model/spec/write",
              response: function (oXhr, model) {
                var mockdataFileUrl =
                  sAppPath + oDataSource.settings.localUri + "openapi-write.json";
                oXhr.respondFile(200, {}, mockdataFileUrl);
                return true;
              },
            },
            {
              method: "GET",
              path: "/model/:model/spec/read",
              response: function (oXhr, model) {
                var mockdataFileUrl =
                  sAppPath + oDataSource.settings.localUri + "openapi-read.json";
                oXhr.respondFile(200, {}, mockdataFileUrl);
                return true;
              },
            },
          ],
        });

        oMockServer.start();

        return oMockServer;
      },
    };

    return oMockServerInterface;
  }
);
