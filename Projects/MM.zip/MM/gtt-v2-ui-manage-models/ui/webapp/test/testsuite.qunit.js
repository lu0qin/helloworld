sap.ui.define(function () {
  "use strict";

  return {
    defaults: {
      coverage: {
        only: ["com/sap/gtt/v2/model/manage"],
      },
      ui5: {
        libs: ["sap.m"],
      },
      loader: {
        paths: {
          "com/sap/gtt/v2/model/manage": "/base/webapp",
        },
      },
    },

    tests: {
      unitTests: {
        module: "./unit/unitTests.qunit",
        title: "Unit Tests",
      },
      opaTests: {
        module: "./integration/opaTests.qunit",
        title: "OPA Tests",
      },
    },
  };
});
