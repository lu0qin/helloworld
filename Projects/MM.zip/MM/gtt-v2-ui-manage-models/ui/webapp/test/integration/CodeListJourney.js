sap.ui.define(
  [
    "sap/ui/test/opaQunit",
    "sap/ui/core/ValueState",
    "./pageObjects/Browser",
    "./pageObjects/ModelList",
    "./pageObjects/ModelDetail",
    "./pageObjects/CodeList",
    "./pageObjects/CodeListDetail",
    "./pageObjects/TranslationDialog",
  ],
  function (opaTest, ValueState) {
    QUnit.module("CodeList");

    opaTest("Should see the object page section", function (Given, When, Then) {
      // Arrangements
      Given.iStartMyApp();

      // Actions
      var name = "tfo";
      When.onTheModelListPage.iPressOnTheItemWithTheName(name);

      var sectionId = "codeListSection";
      When.onTheModelDetailPage.iSelectTheSection(sectionId);

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection(sectionId);
      Then.onTheCodeListSection.iShouldSeeTheListHasItems(2);
      Then.onTheCodeListSection.iShouldSeeTheListItemSelected("OrderStatus");
      Then.onTheCodeListDetailView.iShouldSeeTheTableInReadMode();
    });

    opaTest("Should open the create dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editCodeListDialog");

      // Actions
      When.onTheCodeListSection.iPressTheCreateButton();

      // Assertions
      Then.onTheEditDialog.iShouldSeeTheForm();
    });

    opaTest("Should cancel the create dialog", function (Given, When, Then) {
      // Actions
      When.onTheEditDialog.iPressTheCancelButton();

      // Assertions
      Then.onTheCodeListSection.iShouldSeeTheList();
    });

    opaTest("Should show errors in the create dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editCodeListDialog");

      // Actions
      When.onTheCodeListSection.iPressTheCreateButton();
      When.onTheEditDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheEditDialog.iShouldSeeTheValidationError("name");

      // Cleanup
      Then.onTheEditDialog.iPressTheCancelButton();
    });

    opaTest("Should submit the create dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editCodeListDialog");

      // Actions
      When.onTheCodeListSection.iPressTheCreateButton();
      When.onTheEditDialog.iInputTextInDialog("name", "NewCodeList");
      When.onTheEditDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheCodeListSection.iShouldSeeTheListHasItems(3);
      Then.onTheCodeListSection.iShouldSeeTheListItemSelected("NewCodeList");
      Then.onTheCodeListDetailView.iShouldSeeTheTableInEditMode();
      Then.onTheCodeListDetailView.iShouldSeeTheTableHasItems(1);
    });

    opaTest("Should add a new code value", function (Given, When, Then) {
      // Actions
      When.onTheCodeListDetailView.iPressTheAddButton();
      When.onTheCodeListDetailView.iInputCodeInRow(1, "CODE_1");
      When.onTheCodeListDetailView.iInputNameInRow(1, "Name 1");

      // Assertions
      Then.onTheCodeListDetailView.iShouldSeeTheTableHasItems(2);
      Then.onTheCodeListDetailView.iShouldSeeTheCodeInRow(1, "CODE_1");
    });

    opaTest(
      "Should show errors when input a duplicate value in new code",
      function (Given, When, Then) {
        // Actions
        When.onTheCodeListDetailView.iPressTheAddButton();
        When.onTheCodeListDetailView.iInputCodeInRow(2, "CODE_1");
        When.onTheCodeListDetailView.iInputNameInRow(2, "Name 2");

        // Assertions
        Then.onTheCodeListDetailView.iShouldSeeTheTableHasItems(3);
        Then.onTheCodeListDetailView.iShouldSeeTheCodeInRow(2, "CODE_1");
        Then.onTheCodeListDetailView.iShouldSeeTheValidationStateInRow(2, 0, ValueState.Error);
      }
    );

    opaTest("Should drag and drop table rows", function (Given, When, Then) {
      // Actions
      When.onTheCodeListDetailView.iDragDropTableRow(0, 1);

      // Assertions
      Then.onTheCodeListDetailView.iShouldSeeTheTableHasItems(3);
      Then.onTheCodeListDetailView.iShouldSeeTheCodeInRow(0, "CODE_1");
    });

    opaTest("Should not show errors when delete the duplicate code", function (Given, When, Then) {
      // Actions
      // Delete the first code with value of "CODE_1"
      When.onTheCodeListDetailView.iDeleteTheTableRow(0);

      // Assertions
      Then.onTheCodeListDetailView.iShouldSeeTheTableHasItems(2);
      Then.onTheCodeListDetailView.iShouldSeeTheCodeInRow(1, "CODE_1");
      Then.onTheCodeListDetailView.iShouldSeeTheValidationStateInRow(1, 0, ValueState.None);
    });

    opaTest("Should delete a code value", function (Given, When, Then) {
      // Actions
      When.onTheCodeListDetailView.iDeleteTheTableRow(0);

      // Assertions
      Then.onTheCodeListDetailView.iShouldSeeTheTableHasItems(1);
      Then.onTheCodeListDetailView.iShouldSeeTheCodeInRow(0, "CODE_1");
    });

    opaTest("Should open the edit dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editCodeListDialog");

      // Actions
      When.onTheCodeListSection.iPressTheEditButton();

      // Assertions
      Then.onTheEditDialog.iShouldSeeTheInputValueInDialog("name", "NewCodeList");
    });

    opaTest("Should show errors in the edit dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editCodeListDialog");

      // Actions
      When.onTheEditDialog.iInputTextInDialog("name", "OrderStatus");
      When.onTheEditDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheEditDialog.iShouldSeeTheValidationError("name");
    });

    opaTest("Should close the edit dialog", function (Given, When, Then) {
      // Actions
      When.onTheEditDialog.iPressTheCancelButton();

      // Assertions
      Then.onTheCodeListSection.iShouldSeeTheListItemSelected("NewCodeList");
    });

    opaTest("Should submit the edit dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editCodeListDialog");

      // Actions
      When.onTheCodeListSection.iPressTheEditButton();
      When.onTheEditDialog.iInputTextInDialog("name", "NewCodeList2");
      When.onTheEditDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheCodeListSection.iShouldSeeTheListHasItems(3);
      Then.onTheCodeListSection.iShouldSeeTheListItemSelected("NewCodeList2");
    });

    opaTest("Should delete the item without reference", function (Given, When, Then) {
      // Actions
      When.onTheCodeListSection.iPressTheDeleteButton();

      // Assertions
      Then.onTheCodeListSection.iShouldSeeTheListHasItems(2);
      Then.onTheCodeListSection.iShouldSeeTheListItemSelected("OrderStatus");
    });

    opaTest("Should open the translation dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("translationDialog");

      // Actions
      When.onTheCodeListDetailView.iPressTheTranslateButton();
      When.onTheTranslateDialog.iSelectLanguage("German");
      When.onTheTranslateDialog.iSelectLanguage("Chinese - China");

      // Assertions
      Then.onTheTranslateDialog.iShouldSeeTheTable();
      // Then.onTheTranslateDialog.iShouldSeeTheTableHasItems(2);
    });

    opaTest("Should close the translation dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("translationDialog");

      // Actions
      When.onTheTranslateDialog.iPressTheCancelButton();

      // Assertions
      Then.onTheCodeListDetailView.iShouldSeeTheTableInEditMode();
    });

    opaTest("Should delete the item with reference", function (Given, When, Then) {
      // Actions
      When.onTheCodeListSection.iPressTheDeleteButton();
      When.onTheCodeListSection.iPressTheButtonInDialog("OK");

      // Assertions
      Then.onTheCodeListSection.iShouldSeeTheListHasItems(1);
    });

    opaTest("last test case", function (Given, When, Then) {
      // Assertions
      Then.onTheCodeListSection.iShouldSeeTheList();

      // Cleanup
      Then.iTeardownMyApp();
    });
  }
);
