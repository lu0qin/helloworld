sap.ui.define(
  [
    "sap/ui/test/Opa5",
    "./ObjectPage",
  ],
  function (
    Opa5,
    ObjectPage
  ) {
    "use strict";

    Opa5.createPageObjects({
      onTheModelDeploymentPage: {
        baseClass: ObjectPage,
        viewName: "Deployment",
        actions: {
          iPressTheDeactivateButton: function () {
            return this.iPressTheButton("deactivateButton");
          },
        },
        assertions: {
          iShouldSeeTheDeactivateConfirmBox: function () {
            return this.iShouldSeeTheMessageBox("confirmMessageDeactivateModel");
          },
        },
      },
    });
  }
);
