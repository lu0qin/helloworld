sap.ui.define(
  [
    "sap/ui/test/Opa5",
    "./ObjectPageSection",
    "sap/ui/test/actions/Press",
    "sap/ui/test/matchers/AggregationLengthEquals",
    "sap/ui/test/matchers/I18NText",
    "sap/ui/test/matchers/Properties",
    "sap/base/strings/formatMessage",
  ],
  function (
    Opa5,
    ObjectPageSection,
    Press,
    AggregationLengthEquals,
    I18NText,
    Properties,
    formatMessage
  ) {
    "use strict";

    Opa5.createPageObjects({
      onTheDeploymentHistorySection: {
        baseClass: ObjectPageSection,
        viewName: "deployment.History",
        actions: {},
        assertions: {
          iShouldSeeTheTimeline: function () {
            return this.iShouldSeeTheControlType("sap.suite.ui.commons.Timeline");
          },
        },
      },
    });
  }
);
