sap.ui.define(["sap/ui/test/Opa5", "./ObjectPage"], function (Opa5, ObjectPage) {
  "use strict";

  Opa5.createPageObjects({
    onTheModelDetailPage: {
      baseClass: ObjectPage,
      viewName: "ModelDetail",
      actions: {
        iPressTheEditButton: function () {
          return this.iPressTheButton("editButton");
        },
        iPressTheSaveButton: function () {
          return this.iPressTheButton("saveButton");
        },
      },
      assertions: {},
    },
  });
});
