sap.ui.define(
  [
    "sap/ui/test/opaQunit",
    "./pageObjects/Browser",
    "./pageObjects/ModelList",
    "./pageObjects/ModelDetail",
    "./pageObjects/ProcessType",
    "./pageObjects/ProcessTypeUserFields",
    "./pageObjects/ProcessTypeCoreFields",
    "./pageObjects/UserFields",
    "./pageObjects/PlannedEvent",
    "./pageObjects/UnplannedEvent",
    "./pageObjects/TranslationDialog",
  ],
  function (opaTest) {
    QUnit.module("ProcessTypeDetail");

    opaTest("Should see the object page section", function (Given, When, Then) {
      // Arrangements
      Given.iStartMyApp();

      // Actions
      var name = "tfo";
      When.onTheModelListPage.iPressOnTheItemWithTheName(name);

      var sectionId = "trackedProcessSection";
      When.onTheModelDetailPage.iSelectTheSection(sectionId);

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection(sectionId);
      Then.onTheProcessTypeSection.iShouldSeeTheListHasItems(1);
      Then.onTheProcessTypeSection.iShouldSeeTheListItemSelected("FreightOrder");
      Then.onTheProcessTypeUserFieldsView.iShouldSeeTheTableInReadMode();
      Then.onTheProcessTypeCoreFieldsView.iShouldSeeTheTableInReadMode();
    });

    opaTest("Should create a new Tracked Process", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editProcessTypeDialog");

      // Actions
      When.onTheProcessTypeSection.iPressTheCreateButton();
      When.onTheEditDialog.iInputTextInDialog("name", "ProcessTypeDetailTest");
      When.onTheEditDialog.iInputTextInDialog("trackingIdType", "detail_test");
      When.onTheEditDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheProcessTypeSection.iShouldSeeTheListHasItems(2);
      Then.onTheProcessTypeSection.iShouldSeeTheListItemSelected("ProcessTypeDetailTest");
    });

    /**
     * User Fields
     * */
    opaTest("Should create one user filed with UUID type", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onTheProcessTypeUserFieldsView.iPressTheCreateButton();
      When.onTheUserFieldsDialog.iInputTextInDialog("name", "uuid_field");
      When.onTheUserFieldsDialog.iInputTextInDialog("label", "Label for UUID field");
      When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "uuid");

      When.onTheUserFieldsDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheProcessTypeUserFieldsView.iShouldSeeTheTableHasItems(1);
    });

    opaTest("Should create one user field with Data Subject ID dpp", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onTheProcessTypeUserFieldsView.iPressTheCreateButton();
      When.onTheUserFieldsDialog.iInputTextInDialog("name", "dataSubjectId_field");
      When.onTheUserFieldsDialog.iInputTextInDialog("label", "Label for DataSubjectID Field");
      When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "uuid");
      When.onTheUserFieldsDialog.iSelectComboBoxInDialog("dpp", "Data Subject ID");

      When.onTheUserFieldsDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheProcessTypeUserFieldsView.iShouldSeeTheTableHasItems(2);
    });

    opaTest("Should create one user field with Composition type", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onTheProcessTypeUserFieldsView.iPressTheCreateButton();
      When.onTheUserFieldsDialog.iInputTextInDialog("name", "compo_field");
      When.onTheUserFieldsDialog.iInputTextInDialog("label", "Label for Composition Field");
      When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "composition");
      When.onTheUserFieldsDialog.iSelectFromValueHelpInDialog("itemTypeTarget");
      Then.onTheUserFieldsDialog.iShouldSeeTheInputValueInDialog(
        "itemTypeTarget",
        "FreightOrder.StopItem"
      );

      When.onTheUserFieldsDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheProcessTypeUserFieldsView.iShouldSeeTheTableHasItems(3);
    });

    opaTest(
      "Should show errors in the user field create dialog while select duplicate Data Subject ID in dpp",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editFieldDialog");

        // Actions
        When.onTheProcessTypeUserFieldsView.iPressTheCreateButton();
        When.onTheUserFieldsDialog.iInputTextInDialog("name", "dpptest");
        When.onTheUserFieldsDialog.iSelectComboBoxInDialog("dpp", "Data Subject ID");
        When.onTheUserFieldsDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheUserFieldsDialog.iShouldSeeTheValidationError("dpp");

        // Cleanup
        Then.onTheUserFieldsDialog.iPressTheCancelButton();
      }
    );

    opaTest(
      "Should open the user field edit dialog by pressing edit-line button",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editFieldDialog");

        // Actions
        When.onTheProcessTypeUserFieldsView.iPressLineEditButtonInTable("table", 0);

        // Assertions
        Then.onTheEditDialog.iShouldSeeTheForm();

        // Clean up
        Then.onTheEditDialog.iPressTheCancelButton();
      }
    );

    opaTest(
      "Should show errors in the user field edit dialog while select duplicate Data Subject ID in dpp",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editFieldDialog");

        // Actions
        When.onTheProcessTypeUserFieldsView.iSelectRowInTable("table", 0);
        When.onTheProcessTypeUserFieldsView.iPressTheEditButton();
        When.onTheUserFieldsDialog.iSelectComboBoxInDialog("dpp", "Data Subject ID");
        When.onTheUserFieldsDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheUserFieldsDialog.iShouldSeeTheValidationError("dpp");

        // Cleanup
        Then.onTheUserFieldsDialog.iPressTheCancelButton();
      }
    );

    opaTest("Should delete the user field without reference", function (Given, When, Then) {
      // Actions
      When.onTheProcessTypeUserFieldsView.iSelectRowInTable("table", 0);
      When.onTheProcessTypeUserFieldsView.iPressTheDeleteButton();
      When.onTheProcessTypeUserFieldsView.iPressTheButtonInDialog("OK");

      // Assertions
      Then.onTheProcessTypeUserFieldsView.iShouldSeeTheTableHasItems(2);
    });

    /**
     * Admissible Planned Event
     * */
    opaTest("Should see the Planned Event Types User Detail table", function (Given, When, Then) {
      When.onTheProcessTypeSection.iSelectDropDown("tpSideViewSelect", "admissiblePlannedEvents");
      Then.onThePlannedEventUserDetailView.iShouldSeeTheTable();
    });

    opaTest("Should open the add planned event type dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editPlannedEventDialog");

      When.onThePlannedEventUserDetailView.iPressTheAddButton();
      Then.onTheEditPlannedEventDialog.iShouldSeeTheDetails();
    });

    opaTest(
      "Should show errors in the add planned event type dialog",
      function (Given, When, Then) {
        // Actions
        When.onTheEditPlannedEventDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheEditPlannedEventDialog.iShouldSeeTheValidationErrorInDetailTab("name");
        Then.onTheEditPlannedEventDialog.iShouldSeeTheValidationErrorInDetailTab(
          "periodicOverdueDetection"
        );
        Then.onTheEditPlannedEventDialog.iShouldSeeTheValidationErrorInDetailTab(
          "maxOverdueDetection"
        );
      }
    );

    opaTest(
      "Should see the Match Actual Event Tab in the add planned event type dialog",
      function (Given, When, Then) {
        // Actions
        When.onTheEditPlannedEventDialog.iSelectTheTab("actualEventMatchTab");

        // Assertions
        Then.onTheEditPlannedEventDialog.iShouldSeeTheActualMatchSettings();
      }
    );

    opaTest(
      "Should see the Match Actual Event Tab in the add planned event type dialog",
      function (Given, When, Then) {
        // Actions
        When.onTheEditPlannedEventDialog.iSelectTheTab("plannedEventMatchTab");

        // Assertions
        Then.onTheEditPlannedEventDialog.iShouldSeeThePlannedMatchSettings();
      }
    );

    opaTest("Should close the add planned event type dialog", function (Given, When, Then) {
      // Actions
      When.onTheEditPlannedEventDialog.iPressTheCancelButton();

      // Assertions
      Then.onThePlannedEventUserDetailView.iShouldSeeTheTable();
    });

    opaTest("Should add Actual/Planned Match Field", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editPlannedEventDialog");

      // Actions
      When.onThePlannedEventUserDetailView.iPressTheAddButton();
      When.onTheEditPlannedEventDialog.iSelectEventTypeDropDownInPlannedEventDialog(
        "FreightOrder.DelayedEvent"
      );
      // Config in extension fields
      When.onTheEditPlannedEventDialog.iSelectTheTab("actualEventMatchTab");
      When.onTheEditPlannedEventDialog.iSelectPlannedEventField("uuidField");

      // Assertions
      Then.onTheEditPlannedEventDialog.iShouldSeeTheActualMatchListHasItems(1);
    });

    opaTest(
      "Should see the automatically added Planned/Planned Match item",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editPlannedEventDialog");

        // Actions
        When.onTheEditPlannedEventDialog.iSelectTheTab("plannedEventMatchTab");

        // Assertions
        Then.onTheEditPlannedEventDialog.iShouldSeeThePlannedMatchListHasItems(2); // eventMatchKey, uuidField
      }
    );

    opaTest("Should submit the add planned event type dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editPlannedEventDialog");

      // Actions
      When.onTheEditPlannedEventDialog.iSelectTheTab("detailsTab");
      When.onTheEditPlannedEventDialog.iInputTextInPlannedEventDialog("businessTolerance", "10");
      When.onTheEditPlannedEventDialog.iInputTextInPlannedEventDialog("technicalTolerance", "1");
      When.onTheEditPlannedEventDialog.iInputTextInPlannedEventDialog(
        "periodicOverdueDetection",
        "10"
      );
      When.onTheEditPlannedEventDialog.iInputTextInPlannedEventDialog("maxOverdueDetection", "1");

      When.onTheEditPlannedEventDialog.iPressTheAcceptButton();

      Then.onThePlannedEventUserDetailView.iShouldSeeTheTableHasItems(1);
    });

    opaTest(
      "Should open the edit planned event type dialog by pressing edit-line button",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editPlannedEventDialog");

        // Actions
        When.onThePlannedEventUserDetailView.iPressLineEditButtonInTable("table", 0);

        // Assertions
        Then.onTheEditPlannedEventDialog.iShouldSeeTheDetails();

        // Clean up
        Then.onTheEditPlannedEventDialog.iPressTheCancelButton();
      }
    );

    opaTest(
      "Should submit changes the edit planned event type dialog",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editPlannedEventDialog");

        When.onThePlannedEventUserDetailView.iSelectRowInTable("table", 0);
        When.onThePlannedEventUserDetailView.iPressTheEditButton();
        When.onTheEditPlannedEventDialog.iInputTextInPlannedEventDialog(
          "maxOverdueDetection",
          "11"
        );
        When.onTheEditPlannedEventDialog.iPressTheAcceptButton();

        Then.onThePlannedEventUserDetailView.iShouldSeeTheTableHasItems(1);
      }
    );

    opaTest("Should delete the planned event", function (Given, When, Then) {
      // Actions
      When.onThePlannedEventUserDetailView.iSelectRowInTable("table", 0);
      When.onThePlannedEventUserDetailView.iPressTheDeleteButton();

      // Assertions
      Then.onThePlannedEventUserDetailView.iShouldSeeTheTableHasItems(0);
    });

    opaTest("Should see the Unplanned Event Types table", function (Given, When, Then) {
      When.onTheProcessTypeSection.iSelectDropDown("tpSideViewSelect", "admissibleUnplannedEvents");
      Then.onTheUnplannedEventUserDetail.iShouldSeeTheTable();
    });

    opaTest("Should open the add unplanned event type dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editUnplannedEventDialog");

      When.onTheUnplannedEventUserDetail.iPressTheAddButton();
      Then.onTheEditUnplannedEventDialog.iShouldSeeTheForm();
    });

    opaTest(
      "Should show errors in the add planned event type dialog",
      function (Given, When, Then) {
        // Actions
        When.onTheEditUnplannedEventDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheEditUnplannedEventDialog.iShouldSeeTheValidationError(
          "name",
          "maxOverdueDetection"
        );
      }
    );

    opaTest("Should close the add planned event type dialog", function (Given, When, Then) {
      // Actions
      When.onTheEditUnplannedEventDialog.iPressTheCancelButton();

      // Assertions
      Then.onTheUnplannedEventUserDetail.iShouldSeeTheTable();
    });

    opaTest("Should submit the add planned event type dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editUnplannedEventDialog");

      When.onTheUnplannedEventUserDetail.iPressTheAddButton();
      When.onTheEditUnplannedEventDialog.iSelectDropDownInDialog(
        "name",
        "FreightOrder.DelayedEvent"
      );
      When.onTheEditUnplannedEventDialog.iPressTheAcceptButton();

      Then.onTheUnplannedEventUserDetail.iShouldSeeTheTableHasItems(1);
    });

    opaTest(
      "Should open the edit unplanned event type dialog by pressing edit-line button",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editUnplannedEventDialog");

        // Actions
        When.onTheUnplannedEventUserDetail.iPressLineEditButtonInTable("table", 0);

        // Assertions
        Then.onTheEditUnplannedEventDialog.iShouldSeeTheForm();

        // Clean up
        Then.onTheEditUnplannedEventDialog.iPressTheCancelButton();
      }
    );

    opaTest(
      "Should submit changes the edit planned event type dialog",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editUnplannedEventDialog");

        When.onTheUnplannedEventUserDetail.iSelectRowInTable("table", 0);
        When.onTheUnplannedEventUserDetail.iPressTheEditButton();
        When.onTheEditUnplannedEventDialog.iPressTheAcceptButton();

        Then.onTheUnplannedEventUserDetail.iShouldSeeTheTableHasItems(1);
      }
    );

    opaTest("Should delete the planned event", function (Given, When, Then) {
      // Actions
      When.onTheUnplannedEventUserDetail.iSelectRowInTable("table", 0);
      When.onTheUnplannedEventUserDetail.iPressTheDeleteButton();

      // Assertions
      Then.onTheUnplannedEventUserDetail.iShouldSeeTheTableHasItems(0);
    });

    opaTest(
      "Should delete the ProcessType without external reference",
      function (Given, When, Then) {
        // Actions
        When.onTheProcessTypeSection.iPressTheDeleteButton();
        When.onTheProcessTypeSection.iPressTheButtonInMessageBox("OK");

        // Assertions
        Then.onTheProcessTypeSection.iShouldSeeTheListHasItems(1);
        Then.onTheProcessTypeSection.iShouldSeeTheListItemSelected("FreightOrder");
      }
    );

    opaTest(
      "Should show warning in edit dialog of user field with reference when change type",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editFieldDialog");

        // Actions
        When.onTheProcessTypeSection.iSelectDropDown("tpSideViewSelect", "fieldLists");
        When.onTheProcessTypeUserFieldsView.iSelectRowInTable("table", 0);
        When.onTheProcessTypeUserFieldsView.iPressTheEditButton();
        When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "composition");

        // Assertions
        Then.onTheUserFieldsDialog.iShouldSeeTheValidationWarning("type");
        Then.onTheUserFieldsDialog.iPressTheCancelButton();
      }
    );

    opaTest(
      "Should submit the user field without reference edit dialog with String type",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editFieldDialog");

        // Actions
        When.onTheProcessTypeUserFieldsView.iSelectRowInTable("table", 0);
        When.onTheProcessTypeUserFieldsView.iPressTheEditButton();
        When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "string");
        When.onTheUserFieldsDialog.iInputTextInDialog("length", "10");
        When.onTheUserFieldsDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheProcessTypeUserFieldsView.iShouldSeeTheTableHasItems(10);
      }
    );

    opaTest(
      "Should submit the user field edit dialog with Decimal type",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editFieldDialog");

        // Actions
        When.onTheProcessTypeUserFieldsView.iSelectRowInTable("table", 0);
        When.onTheProcessTypeUserFieldsView.iPressTheEditButton();
        When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "decimal");
        When.onTheUserFieldsDialog.iInputTextInDialog("precision", "10");
        When.onTheUserFieldsDialog.iInputTextInDialog("scale", "1");
        When.onTheUserFieldsDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheProcessTypeUserFieldsView.iShouldSeeTheTableHasItems(10);
      }
    );

    opaTest(
      "Should submit the user field edit dialog with Code List Type",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editFieldDialog");

        // Actions
        When.onTheProcessTypeUserFieldsView.iSelectRowInTable("table", 0);
        When.onTheProcessTypeUserFieldsView.iPressTheEditButton();
        When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "codelist");

        When.onTheUserFieldsDialog.iSelectFromValueHelpInDialog("codeListTarget");
        Then.onTheUserFieldsDialog.iShouldSeeTheInputValueInDialog(
          "codeListTarget",
          "ShipmentStatus"
        );

        When.onTheUserFieldsDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheProcessTypeUserFieldsView.iShouldSeeTheTableHasItems(10);
      }
    );

    opaTest(
      "Should submit the user field edit dialog with Composition type",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editFieldDialog");

        // Actions
        When.onTheProcessTypeUserFieldsView.iSelectRowInTable("table", 0);
        When.onTheProcessTypeUserFieldsView.iPressTheEditButton();
        When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "composition");

        When.onTheUserFieldsDialog.iSelectFromValueHelpInDialog("itemTypeTarget");
        Then.onTheUserFieldsDialog.iShouldSeeTheInputValueInDialog(
          "itemTypeTarget",
          "FreightOrder.StopItem"
        );

        When.onTheUserFieldsDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheProcessTypeUserFieldsView.iShouldSeeTheTableHasItems(10);
      }
    );

    opaTest(
      "Should create one user field with AssociationToOne type",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editFieldDialog");

        // Actions
        When.onTheProcessTypeUserFieldsView.iPressTheCreateButton();
        When.onTheUserFieldsDialog.iInputTextInDialog("name", "assoToOne_field");
        When.onTheUserFieldsDialog.iInputTextInDialog("label", "Label for AssoToOne field");
        When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "associationToOne");
        When.onTheUserFieldsDialog.iSelectFromValueHelpInDialog("processTypeTarget");
        Then.onTheUserFieldsDialog.iShouldSeeTheInputValueInDialog(
          "processTypeTarget",
          "FreightOrder"
        );

        When.onTheUserFieldsDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheProcessTypeUserFieldsView.iShouldSeeTheTableHasItems(11);
      }
    );

    opaTest(
      "Should create one user field with AssociationToMany type with target of existing AssociationToOne user field",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editFieldDialog");

        // Actions
        When.onTheProcessTypeUserFieldsView.iPressTheCreateButton();
        When.onTheUserFieldsDialog.iInputTextInDialog("name", "assoToMany_field");
        When.onTheUserFieldsDialog.iInputTextInDialog("label", "Label for AssoToMany field");
        When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "associationToMany");
        When.onTheUserFieldsDialog.iSelectFromValueHelpInDialog("processTypeTarget");
        Then.onTheUserFieldsDialog.iShouldSeeTheInputValueInDialog(
          "processTypeTarget",
          "FreightOrder"
        );
        When.onTheUserFieldsDialog.iSelectComboBoxInDialog(
          "associationToOneFieldTarget",
          "assoToOne_field"
        );

        When.onTheUserFieldsDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheProcessTypeUserFieldsView.iShouldSeeTheTableHasItems(12);
      }
    );

    opaTest(
      "Should create one user field with AssociationToMany type and a new AssociationToOne User Field",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editFieldDialog");

        // Actions
        When.onTheProcessTypeUserFieldsView.iPressTheCreateButton();
        When.onTheUserFieldsDialog.iInputTextInDialog("name", "assoToMany_field2");
        When.onTheUserFieldsDialog.iInputTextInDialog("label", "Label for AssoToMany field2");
        When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "associationToMany");
        When.onTheUserFieldsDialog.iSelectFromValueHelpInDialog("processTypeTarget");
        Then.onTheUserFieldsDialog.iShouldSeeTheInputValueInDialog(
          "processTypeTarget",
          "FreightOrder"
        );
        When.onTheUserFieldsDialog.iInputTextInDialog(
          "associationToOneFieldTarget",
          "assoToOne_field_new"
        );

        // Assertions
        Then.onTheUserFieldsDialog.iShouldSeeTheValidationWarning("associationToOneFieldTarget");

        // Actions
        When.onTheUserFieldsDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheProcessTypeUserFieldsView.iShouldSeeTheTableHasItems(14);
      }
    );

    opaTest("Should delete the user field with reference", function (Given, When, Then) {
      // Actions
      When.onTheProcessTypeUserFieldsView.iSelectRowInTable("table", 8);
      When.onTheProcessTypeUserFieldsView.iPressTheDeleteButton();
      When.onTheProcessTypeUserFieldsView.iPressTheButtonInDialog("OK");

      // Assertions
      Then.onTheProcessTypeUserFieldsView.iShouldSeeTheTableHasItems(13);
    });

    opaTest("Should delete the ProcessType with external reference", function (Given, When, Then) {
      // Actions
      When.onTheProcessTypeSection.iPressTheDeleteButton();
      When.onTheProcessTypeSection.iPressTheButtonInDialog("OK");

      // Assertions
      Then.onTheProcessTypeSection.iShouldSeeTheListHasItems(0);
    });

    opaTest("last test case", function (Given, When, Then) {
      // Assertions
      Then.onTheProcessTypeSection.iShouldSeeTheList();

      // Cleanup
      Then.iTeardownMyApp();
    });
  }
);
