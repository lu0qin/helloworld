sap.ui.define(
  [
    "sap/ui/test/Opa5",
    "./Common",
    "./Dialog",
    "sap/ui/test/actions/EnterText",
    "sap/ui/test/matchers/Ancestor",
    "sap/ui/test/matchers/PropertyStrictEquals",
    "sap/m/ListMode",
    "sap/base/strings/formatMessage",
  ],
  function (
    Opa5,
    Common,
    Dialog,
    EnterText,
    Ancestor,
    PropertyStrictEquals,
    ListMode,
    formatMessage
  ) {
    "use strict";

    Opa5.createPageObjects({
      onTheCodeListDetailView: {
        baseClass: Common,
        viewName: "CodeListUserCodes",
        actions: {
          iPressTheAddButton: function () {
            return this.iPressTheButton("addButton");
          },
          iPressTheTranslateButton: function () {
            return this.iPressTheButton("translateButton");
          },
          iPressTheImportButton: function () {
            return this.iPressTheButton("importButton");
          },
          iDeleteTheTableRow: function (index) {
            return this.getListInMode("table", ListMode.Delete, function (oTable) {
              oTable.fireDelete({
                listItem: oTable.getItems()[index],
              });
            });
          },
          iInputCodeInRow: function (rowIndex, sText) {
            return this.getListInMode("table", ListMode.Delete, function (oTable) {
              var oRow = oTable.getItems()[rowIndex];

              this.waitFor({
                controlType: "sap.m.Input",
                matchers: [
                  new Ancestor(oRow),
                  function (oInput) {
                    return oInput === oRow.getCells()[0];
                  },
                ],
                actions: [
                  new EnterText({
                    text: sText,
                    clearTextFirst: true,
                    keepFocus: false,
                  }),
                ],
              });
            });
          },
          iInputNameInRow: function (rowIndex, sText) {
            return this.getListInMode("table", ListMode.Delete, function (oTable) {
              var oRow = oTable.getItems()[rowIndex];

              this.waitFor({
                controlType: "sap.m.Input",
                matchers: [
                  new Ancestor(oRow),
                  function (oInput) {
                    return oInput === oRow.getCells()[1];
                  },
                ],
                actions: [
                  new EnterText({
                    text: sText,
                    clearTextFirst: true,
                    keepFocus: false,
                  }),
                ],
              });
            });
          },
          iDragDropTableRow: function (sourceIndex, targetIndex) {
            return this.iDragDropListItem("table", sourceIndex, targetIndex);
          },
        },
        assertions: {
          iShouldSeeTheTable: function () {
            return this.iShouldSeeTheControl("table");
          },
          iShouldSeeTheTableInEditMode: function () {
            return this.getListInMode("table", ListMode.Delete);
          },
          iShouldSeeTheTableInReadMode: function () {
            return this.waitFor({
              id: "table",
              matchers: [
                new PropertyStrictEquals({
                  name: "mode",
                  value: ListMode.None,
                }),
              ],
              success: function (oTable) {
                Opa5.assert.ok(true, "The table is in read mode");
              },
              errorMessage: "Cannot find the table in read mode",
            });
          },
          iShouldSeeTheTableHasItems: function (count) {
            return this.theListShouldHaveItems("table", count);
          },
          iShouldSeeTheCodeInRow: function (rowIndex, code) {
            return this.waitFor({
              id: "table",
              success: function (oTable) {
                var oRow = oTable.getItems()[rowIndex];
                var oCodeInput = oRow.getCells()[0];
                Opa5.assert.strictEqual(oCodeInput.getValue(), code, "The code is correct");
              },
            });
          },
          iShouldSeeTheValidationStateInRow: function (rowIndex, cellIndex, valueState) {
            return this.waitFor({
              id: "table",
              success: function (oTable) {
                var oRow = oTable.getItems()[rowIndex];
                var oCodeInput = oRow.getCells()[cellIndex];
                Opa5.assert.strictEqual(
                  oCodeInput.getValueState(),
                  valueState,
                  formatMessage("The control value state is {0}", valueState)
                );
              },
            });
          },
        },
      },

      onTheImportCodeDialog: {
        baseClass: Dialog,
        actions: {
        },
        assertions: {
          iShouldSeeTheCodeSelect: function () {
            return this.iShouldSeeTheControl(this.getId("codeListSelect"));
          },
          iShouldSeeThePreviewCodesTable: function () {
            return this.iShouldSeeTheControl(this.getId("table"));
          },
        },
      },
    });
  }
);
