sap.ui.define(
  [
    "sap/ui/test/Opa5",
    "sap/ui/test/actions/EnterText",
    "sap/ui/test/actions/Press",
    "sap/ui/test/actions/Drag",
    "sap/ui/test/actions/Drop",
    "sap/ui/test/matchers/AggregationContainsPropertyEqual",
    "sap/ui/test/matchers/AggregationLengthEquals",
    "sap/ui/test/matchers/Ancestor",
    "sap/ui/test/matchers/Descendant",
    "sap/ui/test/matchers/I18NText",
    "sap/ui/test/matchers/LabelFor",
    "sap/ui/test/matchers/Properties",
    "sap/ui/test/matchers/Interactable",
    "sap/ui/test/matchers/PropertyStrictEquals",
    "sap/base/strings/formatMessage",
    "sap/base/util/merge",
    "sap/ui/core/IconPool",
    "sap/m/library",
  ],
  function (
    Opa5,
    EnterText,
    Press,
    Drag,
    Drop,
    AggregationContainsPropertyEqual,
    AggregationLengthEquals,
    Ancestor,
    Descendant,
    I18NText,
    LabelFor,
    Properties,
    Interactable,
    PropertyStrictEquals,
    formatMessage,
    merge,
    IconPool,
    library
  ) {
    "use strict";

    // shortcut for sap.m.DialogType
    var DialogType = library.DialogType;

    // shortcut for sap.m.ButtonType
    var ButtonType = library.ButtonType;

    return Opa5.extend("com.sap.gtt.v2.model.manage.test.integration.pageObjects.Common", {
      // Other page objects that inherit pageObjects.Common can reuse its functionality.
      // Inheritance in this case should be used mainly for commonly used utilities.

      iPressTheButton: function (sId, options) {
        return this.waitFor(
          merge(
            {
              id: sId,
              actions: new Press(),
            },
            options
          )
        );
      },

      iInputText: function (sId, sText, options) {
        return this.waitFor(
          merge(
            {
              id: sId,
              actions: [
                new EnterText({
                  text: sText,
                  clearTextFirst: true,
                  keepFocus: false,
                }),
              ],
            },
            options
          )
        );
      },

      iSelectDropDown: function (sId, sKey, options) {
        return this.waitFor(
          merge(
            {
              id: sId,
              actions: new Press(),
              success: function (oSelect) {
                this.waitFor({
                  controlType: "sap.ui.core.Item",
                  matchers: [
                    new Ancestor(oSelect),
                    new Properties({
                      key: sKey,
                    }),
                  ],
                  actions: new Press(),
                  errorMessage: formatMessage("Cannot select {0} from {1}", sKey, sId),
                });
              },
              errorMessage: formatMessage("Could not find {0}", sId),
            },
            options
          )
        );
      },

      iSelectFromValueHelp: function (sId, options) {
        return this.waitFor(
          merge(
            {
              id: sId,
              success: function (oValueHelpField) {
                this.waitFor({
                  controlType: "sap.ui.core.Icon",
                  matchers: [
                    new Ancestor(oValueHelpField),
                    new Properties({
                      src: "sap-icon://value-help",
                    }),
                  ],
                  actions: new Press(),
                  success: function () {
                    this.waitFor({
                      searchOpenDialogs: true,
                      success: function () {
                        this.waitFor({
                          controlType: "sap.m.ListItemBase",
                          actions: new Press(),
                        });
                      },
                      errorMessage: formatMessage("Could not select in Select Dialog"),
                    });
                  },
                  errorMessage: formatMessage("Could not find value help icon"),
                });
              },
              errorMessage: formatMessage("Could not find {0}", sId),
            },
            options
          )
        );
      },

      iSelectValueHelpItem: function (sKey) {
        return this.waitFor({
          controlType: "sap.m.ListItemBase",
          searchOpenDialogs: true,
          matchers: [
            new PropertyStrictEquals({
              name: "title",
              value: sKey,
            }),
          ],
          actions: new Press(),
          errorMessage: formatMessage("Cannot select {0}", sKey),
        });
      },

      iSelectValueHelpItemByDescription: function (sDescription) {
        return this.waitFor({
          controlType: "sap.m.ListItemBase",
          searchOpenDialogs: true,
          matchers: [
            new PropertyStrictEquals({
              name: "description",
              value: sDescription,
            }),
          ],
          actions: new Press(),
          errorMessage: formatMessage("Cannot select {0}", sDescription),
        });
      },

      iSelectComboBox: function (sId, sText, options) {
        return this.waitFor(
          merge(
            {
              id: sId,
              success: function (oComboBox) {
                this.waitFor({
                  controlType: "sap.ui.core.Icon",
                  matchers: [
                    new Ancestor(oComboBox),
                    new Properties({
                      src: "sap-icon://slim-arrow-down",
                    }),
                  ],
                  actions: new Press(),
                  success: function () {
                    this.waitFor({
                      controlType: "sap.m.StandardListItem",
                      matchers: [
                        new Ancestor(oComboBox),
                        new Properties({
                          title: sText,
                        }),
                      ],
                      actions: new Press(),
                    });
                  },
                  errorMessage: formatMessage("Cannot find arrow down icon in combobox {0}", sId),
                });
              },
              errorMessage: formatMessage("Could not find {0}", sId),
            },
            options
          )
        );
      },

      iSelectMenuButton: function (sId, sKey, options) {
        return this.waitFor(
          merge(
            {
              id: sId,
              actions: new Press(),
              success: function (oMenuButton) {
                var oMenu = oMenuButton.getMenu();

                return this.iSelectMenu(oMenu, sKey);
              }.bind(this),
              errorMessage: formatMessage("Could not find {0}", sId),
            },
            options
          )
        );
      },

      iSelectMenu: function (oMenu, sKey) {
        var oMenuItem = oMenu.getItems().find(function (oItem) {
          return oItem.getKey() === sKey;
        });

        return this.waitFor({
          controlType: "sap.ui.unified.MenuItem",
          matchers: [
            new Ancestor(oMenu),
            new Properties({
              text: oMenuItem.getText(),
            }),
          ],
          actions: new Press(),
          errorMessage: formatMessage("Cannot select {0} from {1}", sKey, oMenu.getId()),
        });
      },

      iSelectCheckBox: function (sId, bSelected, options) {
        return this.waitFor(
          merge(
            {
              id: sId,
              actions: new Press(),
              success: function (oCheckBox) {
                Opa5.assert.strictEqual(
                  oCheckBox.getSelected(),
                  bSelected,
                  formatMessage("The checkbox selected is {0}", bSelected)
                );
              },
              errorMessage: formatMessage("Could not find {0}", sId),
            },
            options
          )
        );
      },

      iSelectSwitch: function (sId, bIsOn, options) {
        return this.waitFor(
          merge(
            {
              id: sId,
              actions: new Press(),
              success: function (oSwitch) {
                Opa5.assert.strictEqual(
                  oSwitch.getState(),
                  bIsOn,
                  formatMessage("The switch state is {0}", bIsOn)
                );
              },
              errorMessage: formatMessage("Could not find {0}", sId),
            },
            options
          )
        );
      },

      iPressLineEditButtonInTable: function (sId, iIndex) {
        return this.waitFor({
          id: sId,
          success: function (oTable) {
            var oItem = oTable.getItems()[iIndex];
            oItem.fireDetailPress();
          },
        });
      },

      iSelectRowInTable: function (sId, iIndex) {
        return this.waitFor({
          id: sId,
          success: function (oTable) {
            var oItem = oTable.getItems()[iIndex];
            oTable.setSelectedItem(oItem, true, true);
          },
        });
      },

      iSelectListItem: function (sId, sTitle) {
        return this.waitFor({
          id: sId,
          actions: new Press(),
          success: function (oList) {
            this.waitFor({
              controlType: "sap.m.ListItemBase",
              matchers: [
                new Ancestor(oList),
                new Properties({
                  title: sTitle,
                }),
              ],
              actions: new Press(),
              errorMessage: formatMessage("Cannot select {0} from {1}", sTitle, sId),
            });
          },
          errorMessage: formatMessage("Could not find {0}", sId),
        });
      },

      iDragDropListItem: function (sId, sourceIndex, targetIndex) {
        this.waitFor({
          id: sId,
          actions: new Press(),
          success: function (oList) {
            this.waitFor({
              controlType: "sap.m.ListItemBase",
              matchers: [
                new Ancestor(oList),
                function (oListItem) {
                  return oList.indexOfItem(oListItem) === sourceIndex;
                },
              ],
              actions: new Drag(),
              errorMessage: formatMessage("Cannot drag item {0}", sourceIndex),
            });
          },
          errorMessage: formatMessage("Could not find {0}", sId),
        });

        return this.waitFor({
          id: sId,
          actions: new Press(),
          success: function (oList) {
            this.waitFor({
              controlType: "sap.m.ListItemBase",
              matchers: [
                new Ancestor(oList),
                function (oListItem) {
                  return oList.indexOfItem(oListItem) === targetIndex;
                },
              ],
              actions: new Drop({
                before: false,
              }),
              errorMessage: formatMessage("Cannot drop item {0}", targetIndex),
            });
          },
          errorMessage: formatMessage("Could not find {0}", sId),
        });
      },

      iPressAcceptButtonInMessageBox: function () {
        return this.getMessageBox(function (oDialog) {
          return this.waitFor({
            searchOpenDialogs: true,
            controlType: "sap.m.Button",
            matchers: [
              // new Ancestor(oDialog),
              new Properties({
                type: ButtonType.Emphasized,
              }),
            ],
            actions: new Press(),
          });
        });
      },

      iPressTheButtonInDialog: function (sText) {
        return this.waitFor({
          controlType: "sap.m.Button",
          searchOpenDialogs: true,
          actions: new Press(),
          matchers: new PropertyStrictEquals({ name: "text", value: sText }),
          success: function () {
            Opa5.assert.ok(true, formatMessage("The {0} button was pressed", sText));
          },
          errorMessage: formatMessage("The {0} button could not be pressed", sText),
        });
      },

      iShouldSeeTheControl: function (sId, options) {
        return this.waitFor(
          merge(
            {
              id: sId,
              success: function () {
                Opa5.assert.ok(true, formatMessage("The control {0} is visible", sId));
              },
              errorMessage: formatMessage("Was not able to see the control {0}.", sId),
            },
            options
          )
        );
      },

      iShouldNotSeeTheControl: function (sId, options) {
        return this.waitFor(
          merge(
            {
              matchers: new Interactable(),
              success: function (aInteractable) {
                Opa5.assert.equal(
                  aInteractable.find(function (oInter) {
                    return oInter.getId() === sId;
                  }),
                  undefined,
                  formatMessage("The control {0} is invisible", sId)
                );
              },
              errorMessage: formatMessage("Was not able to hide the control {0}.", sId),
            },
            options
          )
        );
      },

      iShouldSeeTheControlType: function (controlType) {
        return this.waitFor({
          controlType: controlType,
          success: function () {
            Opa5.assert.ok(true, formatMessage("The control type {0} is available", controlType));
          },
          errorMessage: formatMessage("Was not able to see the control type {0}.", controlType),
        });
      },

      iShouldSeeTheText: function (sId, sText) {
        return this.waitFor({
          id: sId,
          success: function (oText) {
            Opa5.assert.strictEqual(oText.getText(), sText, "The text is correct");
          },
        });
      },

      iShouldSeeTheInputValue: function (sId, sValue, options) {
        return this.waitFor(
          merge(
            {
              id: sId,
              success: function (oText) {
                Opa5.assert.strictEqual(oText.getValue(), sValue, "The value is correct");
              },
            },
            options
          )
        );
      },

      iShouldSeeTheButtonEnabled: function (sId, enabled) {
        return this.waitFor({
          id: sId,
          enabled: enabled,
          success: function (oButton) {
            Opa5.assert.strictEqual(
              oButton.getEnabled(),
              enabled,
              formatMessage("The button.enabled={0}", enabled)
            );
          },
        });
      },

      iShouldSeeTheControlValueState: function (sId, valueState, options) {
        return this.waitFor(
          merge(
            {
              id: sId,
              success: function (oControl) {
                Opa5.assert.strictEqual(
                  oControl.getValueState(),
                  valueState,
                  formatMessage("The control value state is {0}", valueState)
                );
              },
            },
            options
          )
        );
      },

      iShouldSeeTheMultiComboBoxSelection: function (sId, aKeys, options) {
        return this.waitFor(
          merge(
            {
              id: sId,
              success: function (oComboBox) {
                Opa5.assert.deepEqual(
                  oComboBox.getSelectedKeys(),
                  aKeys,
                  "The selection is correct"
                );
              },
            },
            options
          )
        );
      },

      iShouldSeeTheListSelection: function (sListId, sText) {
        return this.waitFor({
          id: sListId,
          success: function (oList) {
            var controlType = "sap.m.ListItemBase";

            this.waitFor({
              controlType: controlType,
              matchers: [
                new Ancestor(oList),
                new Properties({
                  selected: true,
                  title: sText,
                }),
              ],
              success: function (oListItems) {
                Opa5.assert.strictEqual(
                  oListItems.length,
                  1,
                  formatMessage("The item {0} is selected", sText)
                );
              },
              errorMessage: formatMessage("Cannot find selected items in {0}", sListId),
            });
          },
        });
      },

      iShouldSeeTheMessageBox: function () {
        return this.getMessageBox();
      },

      theListShouldHaveItems: function (sId, count) {
        return this.waitFor({
          id: sId,
          success: function (oList) {
            var items = oList.getItems().filter(function (oItem) {
              return !oItem.isGroupHeader();
            });

            Opa5.assert.strictEqual(
              items.length,
              count,
              formatMessage("The list has {0} items", count)
            );
          },
          errorMessage: "Cannot find the list",
        });
      },

      theListShouldBeGrouped: function (sId) {
        return this.waitFor({
          id: sId,
          success: function (oList) {
            this.waitFor({
              controlType: "sap.m.GroupHeaderListItem",
              success: function (oGroupHeaderItems) {
                var iCount = oGroupHeaderItems.length;
                Opa5.assert.ok(iCount !== 0, "The List should be grouped");
              },
            });
          },
        });
      },

      getListInMode: function (sId, mode, callback) {
        return this.waitFor({
          id: sId,
          matchers: [
            new PropertyStrictEquals({
              name: "mode",
              value: mode,
            }),
          ],
          success: function (oList) {
            Opa5.assert.ok(true, formatMessage("The list is in {0} mode", mode));

            if (callback) {
              callback.call(this, oList);
            }
          },
          errorMessage: formatMessage("Cannot find the list in {0} mode", mode),
        });
      },

      getMessageBox: function (callback) {
        return this.waitFor({
          searchOpenDialogs: true,
          controlType: "sap.m.Dialog",
          matchers: new Properties({
            type: DialogType.Message,
            // icon: IconPool.getIconURI("question-mark"),
          }),
          success: function (oDialog) {
            Opa5.assert.ok(true, "The message box is shown");

            if (callback) {
              callback.call(this, oDialog);
            }
          },
          errorMessage: formatMessage("Cannot find message box"),
        });
      },
    });
  }
);
