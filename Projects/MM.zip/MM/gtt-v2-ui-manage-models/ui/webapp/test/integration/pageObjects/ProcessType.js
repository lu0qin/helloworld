sap.ui.define(
  [
    "sap/ui/test/Opa5",
    "sap/ui/test/matchers/PropertyStrictEquals",
    "sap/ui/test/actions/Press",
    "./ObjectPageSection",
    "./Dialog",
  ],
  function (Opa5, PropertyStrictEquals, Press, ObjectPageSection, Dialog) {
    "use strict";

    Opa5.createPageObjects({
      onTheProcessTypeSection: {
        baseClass: ObjectPageSection,
        viewName: "ProcessType",
        actions: {
          iPressTheCreateButton: function () {
            return this.iPressTheButton("createButton");
          },
          iPressTheEditButton: function () {
            return this.iPressTheButton("editButton");
          },
          iPressTheDeleteButton: function () {
            return this.iPressTheButton("deleteButton");
          },
          iPressTheButtonInMessageBox: function (sText) {
            return this.waitFor({
              controlType: "sap.m.Button",
              searchOpenDialogs: true,
              actions: new Press(),
              matchers: new PropertyStrictEquals({ name: "text", value: sText }),
              success: function () {
                Opa5.assert.ok(true, "The Delete button was pressed");
              },
              errorMessage: "The Delete button could not be pressed",
            });
          },
        },
        assertions: {
          iShouldSeeTheList: function () {
            return this.iShouldSeeTheControl("list");
          },
          iShouldSeeTheListHasItems: function (count) {
            return this.theListShouldHaveItems("list", count);
          },
          iShouldSeeTheListItemSelected: function (sText) {
            return this.iShouldSeeTheListSelection("list", sText);
          },
          iShouldSeeTheListGrouped: function () {
            return this.theListShouldBeGrouped("list");
          },
        },
      },
      onTheEditDialog: {
        baseClass: Dialog,
        actions: {},
        assertions: {
          iShouldSeeTheForm: function () {
            var sId = this.getId("form");
            return this.iShouldSeeTheControl(sId);
          },
        },
      },
    });
  }
);
