sap.ui.define(
  [
    "sap/ui/test/opaQunit",
    "./pageObjects/Browser",
    "./pageObjects/History",
    "./pageObjects/ModelList",
    "./pageObjects/ModelDetail",
    "./pageObjects/TranslationDialog",
  ],
  function (opaTest) {
    QUnit.module("ModelDetail");

    opaTest("Should see the detail page when click on the list item", function (Given, When, Then) {
      // Arrangements
      Given.iStartMyApp();

      // Actions
      var name = "tfo";
      When.onTheModelListPage.iPressOnTheItemWithTheName(name);

      // Assertions
      Then.onTheModelDetailPage.theTitleShouldDisplayTheName(name);
      // Should see the detail page initially located at Tracked Process Section and select the first item
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection("trackedProcessSection");
    });

    opaTest("Should go back to the list page from detail page", function (Given, When, Then) {
      // Actions
      When.onTheBrowser.iPressOnTheBackButton();

      // Assertions
      Then.onTheModelListPage.iShouldSeeTheList();
    });

    opaTest("Should be on detail page again when browser forward", function (Given, When, Then) {
      // Actions
      When.onTheBrowser.iPressOnTheForwardButton();

      // Assertions
      var name = "tfo";
      Then.onTheModelDetailPage.theTitleShouldDisplayTheName(name);
    });

    opaTest("Should see the process type section", function (Given, When, Then) {
      // Actions
      var sectionId = "trackedProcessSection";
      When.onTheModelDetailPage.iSelectTheSection(sectionId);

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection(sectionId);
    });

    opaTest("Should see the code list section", function (Given, When, Then) {
      // Actions
      var sectionId = "codeListSection";
      When.onTheModelDetailPage.iSelectTheSection(sectionId);

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection(sectionId);
    });

    opaTest("Should see the deployment history section", function (Given, When, Then) {
      // Actions
      When.onTheModelDetailPage.iSelectTheViewMenu("historyView");

      // Assertions
      Then.onTheHistoryPage.iShouldSeeTheTimeline();
    });

    opaTest("Should stay at model detail page when do save", function (Given, When, Then) {
      // Action
      When.onTheHistoryPage.iSelectTheViewMenu("draftView");

      When.onTheModelDetailPage.iPressTheEditButton();
      When.onTheModelDetailPage.iPressTheSaveButton();

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeThePage();
    });

    opaTest("Should open Model Description translation dialog", function (Given, When, Then) {
      Given.iSetupDialog("translationDialog");

      // Actions
      When.onTheModelDetailPage.iPressTheButton("editButton");
      When.onTheModelDetailPage.iSelectTheSection("headerSection");

      When.onTheModelDetailPage.iPressTheButton("translateButton", {
        fragmentId: "headerFragment",
      });
      When.onTheTranslateDialog.iSelectLanguage("German");
      When.onTheTranslateDialog.iSelectLanguage("Chinese - China");

      // Assertions
      // Assertions
      Then.onTheTranslateDialog.iShouldSeeTheTable();
      Then.onTheTranslateDialog.iPressTheCancelButton();
    });

    opaTest("last test case", function (Given, When, Then) {
      // Assertions
      Then.onTheModelDetailPage.iShouldSeeThePage();

      // Cleanup
      Then.iTeardownMyApp();
    });
  }
);
