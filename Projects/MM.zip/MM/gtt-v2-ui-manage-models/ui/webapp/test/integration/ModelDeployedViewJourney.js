sap.ui.define(
  [
    "sap/ui/test/opaQunit",
    "./pageObjects/Browser",
    "./pageObjects/ModelList",
    "./pageObjects/ModelDetail",
    "./pageObjects/ModelDeployment",
    "./pageObjects/DeploymentHistory",
  ],
  function (opaTest) {
    QUnit.module("ModelDeployedView");

    opaTest("Should see the deployed view page", function (Given, When, Then) {
      // Arrangements
      Given.iStartMyApp();

      // Actions
      var modelName = "tfo";
      When.onTheModelListPage.iPressOnTheItemWithTheName(modelName);
      When.onTheModelDetailPage.iSelectTheViewMenu("deployedView");

      // Assertions
      Then.onTheModelDetailPage.theTitleShouldDisplayTheName(modelName);
    });

    opaTest("Should see the process type section", function (Given, When, Then) {
      // Actions
      var sectionId = "trackedProcessSection";
      When.onTheModelDetailPage.iSelectTheSection(sectionId);

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection(sectionId);
    });

    opaTest("Should see the item type section", function (Given, When, Then) {
      // Actions
      var sectionId = "fieldTypePoolSection";
      When.onTheModelDetailPage.iSelectTheSection(sectionId);

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection(sectionId);
    });

    opaTest("Should see the event type section", function (Given, When, Then) {
      // Actions
      var sectionId = "eventTypePoolSection";
      When.onTheModelDetailPage.iSelectTheSection(sectionId);

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection(sectionId);
    });

    opaTest("Should see the code list section", function (Given, When, Then) {
      // Actions
      var sectionId = "codeListSection";
      When.onTheModelDetailPage.iSelectTheSection(sectionId);

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection(sectionId);
    });

    opaTest("Should see the idoc integration section", function (Given, When, Then) {
      // Actions
      var sectionId = "iDocSection";
      When.onTheModelDetailPage.iSelectTheSection(sectionId);

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection(sectionId);
    });

    opaTest("Should see the vp integration section", function (Given, When, Then) {
      // Actions
      var sectionId = "vpIntegrationSection";
      When.onTheModelDetailPage.iSelectTheSection(sectionId);

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection(sectionId);
    });

    opaTest("Should see the event to action section", function (Given, When, Then) {
      // Actions
      var sectionId = "eventToActionSection";
      When.onTheModelDetailPage.iSelectTheSection(sectionId);

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection(sectionId);
    });

    opaTest("last test case", function (Given, When, Then) {
      // Assertions
      Then.onTheModelDetailPage.iShouldSeeThePage();

      // Cleanup
      Then.iTeardownMyApp();
    });
  }
);
