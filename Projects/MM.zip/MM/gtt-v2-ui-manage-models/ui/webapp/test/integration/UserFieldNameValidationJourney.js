sap.ui.define(
  [
    "sap/ui/test/opaQunit",
    "./pageObjects/Browser",
    "./pageObjects/ModelList",
    "./pageObjects/ModelDetail",
    "./pageObjects/ProcessType",
    "./pageObjects/ProcessTypeUserFields",
    "./pageObjects/UserFields",
  ],
  function (opaTest) {
    QUnit.module("UserFieldNameValidation");

    opaTest("Should see the object page section", function (Given, When, Then) {
      // Arrangements
      Given.iStartMyApp();

      // Actions
      var name = "tfo";
      When.onTheModelListPage.iPressOnTheItemWithTheName(name);

      var sectionId = "trackedProcessSection";
      When.onTheModelDetailPage.iSelectTheSection(sectionId);

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection(sectionId);
      Then.onTheProcessTypeSection.iShouldSeeTheListHasItems(1);
      Then.onTheProcessTypeSection.iShouldSeeTheListItemSelected("FreightOrder");
      Then.onTheProcessTypeUserFieldsView.iShouldSeeTheTableInReadMode();
      Then.onTheProcessTypeCoreFieldsView.iShouldSeeTheTableInReadMode();
    });

    opaTest("Should create a new Tracked Process", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editProcessTypeDialog");

      // Actions
      When.onTheProcessTypeSection.iPressTheCreateButton();
      When.onTheEditDialog.iInputTextInDialog("name", "UserFieldNameValidationTP");
      When.onTheEditDialog.iInputTextInDialog("trackingIdType", "userfield_validation_tp");
      When.onTheEditDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheProcessTypeSection.iShouldSeeTheListHasItems(2);
      Then.onTheProcessTypeSection.iShouldSeeTheListItemSelected("UserFieldNameValidationTP");
    });

    opaTest("Should create a new User Field with type of UUID", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onTheProcessTypeUserFieldsView.iPressTheCreateButton();
      When.onTheUserFieldsDialog.iInputTextInDialog("name", "uuid_field");
      When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "uuid");
      When.onTheUserFieldsDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheProcessTypeUserFieldsView.iShouldSeeTheTableHasItems(1);
    });

    opaTest("Should create a new User Field with type of String", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onTheProcessTypeUserFieldsView.iPressTheCreateButton();
      When.onTheUserFieldsDialog.iInputTextInDialog("name", "string_field");
      When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "string");
      When.onTheUserFieldsDialog.iInputTextInDialog("length", 4000);
      When.onTheUserFieldsDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheProcessTypeUserFieldsView.iShouldSeeTheTableHasItems(2);
    });

    opaTest("Should show error when Name is duplicate in the create dialog", function (
      Given,
      When,
      Then
    ) {
      // Arrangements
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onTheProcessTypeUserFieldsView.iPressTheCreateButton();
      When.onTheUserFieldsDialog.iInputTextInDialog("name", "uuid_field");

      // Assertions
      Then.onTheUserFieldsDialog.iShouldSeeTheValidationError("name");

      // Cleanup
      Then.onTheUserFieldsDialog.iPressTheCancelButton();
    });

    opaTest("Should show error when Name is empty in the create dialog", function (
      Given,
      When,
      Then
    ) {
      // Arrangements
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onTheProcessTypeUserFieldsView.iPressTheCreateButton();
      When.onTheUserFieldsDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheUserFieldsDialog.iShouldSeeTheValidationError("name");

      // Cleanup
      Then.onTheUserFieldsDialog.iPressTheCancelButton();
    });

    opaTest("Should show error when Name is reserved in the create dialog", function (
      Given,
      When,
      Then
    ) {
      // Arrangements
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onTheProcessTypeUserFieldsView.iPressTheCreateButton();
      When.onTheUserFieldsDialog.iInputTextInDialog("name", "trackingid");

      // Assertions
      Then.onTheUserFieldsDialog.iShouldSeeTheValidationError("name");

      // Cleanup
      Then.onTheUserFieldsDialog.iPressTheCancelButton();
    });

    opaTest("Should show error when Name starts with GTT in the create dialog", function (
      Given,
      When,
      Then
    ) {
      // Arrangements
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onTheProcessTypeUserFieldsView.iPressTheCreateButton();
      When.onTheUserFieldsDialog.iInputTextInDialog("name", "GttNameTest");

      // Assertions
      Then.onTheUserFieldsDialog.iShouldSeeTheValidationError("name");

      // Cleanup
      Then.onTheUserFieldsDialog.iPressTheCancelButton();
    });


    /*
     * Check name validation in the edit dialog for rules related to context from the dialog
     * */
    opaTest("Should show error when Name is duplicate in the edit dialog", function (
      Given,
      When,
      Then
    ) {
      // Arrangements
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onTheProcessTypeUserFieldsView.iSelectRowInTable("table", 0);
      When.onTheProcessTypeUserFieldsView.iPressTheEditButton();
      When.onTheUserFieldsDialog.iInputTextInDialog("name", "string_field");

      // Assertions
      Then.onTheUserFieldsDialog.iShouldSeeTheValidationError("name");

      // Cleanup
      Then.onTheUserFieldsDialog.iPressTheCancelButton();
    });

    opaTest("Should show error when Name is reserved in the edit dialog", function (
      Given,
      When,
      Then
    ) {
      // Arrangements
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onTheProcessTypeUserFieldsView.iSelectRowInTable("table", 0);
      When.onTheProcessTypeUserFieldsView.iPressTheEditButton();
      When.onTheUserFieldsDialog.iInputTextInDialog("name", "trackingid");

      // Assertions
      Then.onTheUserFieldsDialog.iShouldSeeTheValidationError("name");

      // Cleanup
      Then.onTheUserFieldsDialog.iPressTheCancelButton();
    });

    opaTest("last test case", function (Given, When, Then) {
      // Assertions
      Then.onTheProcessTypeSection.iShouldSeeTheList();

      // Cleanup
      Then.iTeardownMyApp();
    });
  }
);
