sap.ui.define(
  [
    "./Common",
    "sap/ui/test/actions/Press",
    "sap/ui/test/matchers/AggregationLengthEquals",
    "sap/ui/test/matchers/Ancestor",
    "sap/ui/test/matchers/I18NText",
    "sap/ui/test/matchers/Properties",
    "sap/base/strings/formatMessage",
  ],
  function (Common, Press, AggregationLengthEquals, Ancestor, I18NText, Properties, formatMessage) {
    "use strict";

    return Common.extend("com.sap.gtt.v2.model.manage.test.integration.pageObjects.ObjectPageSection", {
      iShouldSeeThePage: function () {
        return this.iShouldSeeTheControl("objectPageLayout");
      },
    });
  }
);
