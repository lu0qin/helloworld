sap.ui.define(
  [
    "sap/ui/test/Opa5",
    "./ObjectPage",
  ],
  function (
    Opa5,
    ObjectPage
  ) {
    "use strict";

    Opa5.createPageObjects({
      onTheHistoryPage: {
        baseClass: ObjectPage,
        viewName: "History",
        actions: {},
        assertions: {
          iShouldSeeTheTimeline: function () {
            return this.iShouldSeeTheControlType("sap.suite.ui.commons.Timeline");
          },
        },
      },
    });
  }
);
