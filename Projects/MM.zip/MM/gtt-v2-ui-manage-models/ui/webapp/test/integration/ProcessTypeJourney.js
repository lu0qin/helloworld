sap.ui.define(
  [
    "sap/ui/test/opaQunit",
    "./pageObjects/Browser",
    "./pageObjects/ModelList",
    "./pageObjects/ModelDetail",
    "./pageObjects/ProcessType",
    "./pageObjects/ProcessTypeUserFields",
    "./pageObjects/ProcessTypeCoreFields",
    "./pageObjects/PlannedEvent",
    "./pageObjects/UnplannedEvent",
    "./pageObjects/UserFields",
    "./pageObjects/IDoc",
    "./pageObjects/VPIntegration",
    "./pageObjects/TranslationDialog",
  ],
  function (opaTest) {
    QUnit.module("ProcessType");

    opaTest("Should see the object page section", function (Given, When, Then) {
      // Arrangements
      Given.iStartMyApp();

      // Actions
      var name = "tfo";
      When.onTheModelListPage.iPressOnTheItemWithTheName(name);

      var sectionId = "trackedProcessSection";
      When.onTheModelDetailPage.iSelectTheSection(sectionId);

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection(sectionId);
      Then.onTheProcessTypeSection.iShouldSeeTheListHasItems(1);
      Then.onTheProcessTypeSection.iShouldSeeTheListItemSelected("FreightOrder");
      Then.onTheProcessTypeUserFieldsView.iShouldSeeTheTableInReadMode();
      Then.onTheProcessTypeCoreFieldsView.iShouldSeeTheTableInReadMode();
    });

    opaTest("Should open the create dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editProcessTypeDialog");

      // Actions
      When.onTheProcessTypeSection.iPressTheCreateButton();

      // Assertions
      Then.onTheEditDialog.iShouldSeeTheForm();
    });

    opaTest("Should cancel the create dialog", function (Given, When, Then) {
      // Actions
      When.onTheEditDialog.iPressTheCancelButton();

      // Assertions
      Then.onTheProcessTypeSection.iShouldSeeTheList();
    });

    opaTest(
      "Should show errors in the create dialog when input empty name and trackingIdType",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editProcessTypeDialog");

        // Actions
        When.onTheProcessTypeSection.iPressTheCreateButton();
        When.onTheEditDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheEditDialog.iShouldSeeTheValidationError("name");
        Then.onTheEditDialog.iShouldSeeTheValidationError("trackingIdType");

        // Cleanup
        Then.onTheEditDialog.iPressTheCancelButton();
      }
    );

    opaTest(
      "Should show errors in the create dialog when input illegal name and trackingIdType",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editProcessTypeDialog");

        // Actions
        When.onTheProcessTypeSection.iPressTheCreateButton();
        When.onTheEditDialog.iInputTextInDialog("name", "123TrackedProcess");
        When.onTheEditDialog.iInputTextInDialog("trackingIdType", "_shipment");
        When.onTheEditDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheEditDialog.iShouldSeeTheValidationError("name");
        Then.onTheEditDialog.iShouldSeeTheValidationError("trackingIdType");

        // Cleanup
        Then.onTheEditDialog.iPressTheCancelButton();
      }
    );

    opaTest("Should submit the create dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editProcessTypeDialog");

      // Actions
      When.onTheProcessTypeSection.iPressTheCreateButton();
      When.onTheEditDialog.iInputTextInDialog("name", "ShipmentOrder");
      When.onTheEditDialog.iInputTextInDialog("trackingIdType", "shipment");
      When.onTheEditDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheProcessTypeSection.iShouldSeeTheListHasItems(2);
      Then.onTheProcessTypeSection.iShouldSeeTheListItemSelected("ShipmentOrder");
    });

    opaTest("Should open the edit dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editProcessTypeDialog");

      // Actions
      When.onTheProcessTypeSection.iPressTheEditButton();

      // Assertions
      Then.onTheEditDialog.iShouldSeeTheInputValueInDialog("name", "ShipmentOrder");
    });

    opaTest(
      "Should show errors in the edit dialog when input duplicate name",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editProcessTypeDialog");

        // Actions
        When.onTheEditDialog.iInputTextInDialog("name", "FreightOrder");
        When.onTheEditDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheEditDialog.iShouldSeeTheValidationError("name");
      }
    );

    opaTest("Should close the edit dialog", function (Given, When, Then) {
      // Actions
      When.onTheEditDialog.iPressTheCancelButton();

      // Assertions
      Then.onTheProcessTypeSection.iShouldSeeTheListItemSelected("ShipmentOrder");
    });

    opaTest("Should submit the edit dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editProcessTypeDialog");

      // Actions
      When.onTheProcessTypeSection.iPressTheEditButton();
      When.onTheEditDialog.iInputTextInDialog("name", "ShipmentOrder2");
      When.onTheEditDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheProcessTypeSection.iShouldSeeTheListHasItems(2);
      Then.onTheProcessTypeSection.iShouldSeeTheListItemSelected("ShipmentOrder2");
    });

    opaTest("Should open iDoc and VP Enable switch", function (Given, When, Then) {
      When.onTheModelDetailPage.iSelectTheSection("iDocSection");
      When.onTheIDocSection.iSelectDropDown("processTypeSelect", "ShipmentOrder2");
      When.onTheIDocSection.iSelectIntegrationSwitch(true);
      When.onTheModelDetailPage.iSelectTheSection("vpIntegrationSection");
      When.onTheVPIntegrationPage.iSelectDropDown("processTypeSelect", "ShipmentOrder2");
      When.onTheVPIntegrationPage.iSelectIntegrationSwitch(true);
      When.onTheModelDetailPage.iSelectTheSection("trackedProcessSection");

      Then.onTheProcessTypeSection.iShouldSeeTheList();
    });

    opaTest("Should delete the item", function (Given, When, Then) {
      // Actions
      When.onTheProcessTypeSection.iPressTheDeleteButton();
      When.onTheProcessTypeSection.iPressTheButtonInMessageBox("OK");

      // Assertions
      Then.onTheProcessTypeSection.iShouldSeeTheListHasItems(1);
      Then.onTheProcessTypeSection.iShouldSeeTheListItemSelected("FreightOrder");
    });

    opaTest("Should open the translation dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("translationDialog");

      // Actions
      When.onTheProcessTypeSection.iSelectDropDown("tpSideViewSelect", "fieldLists");
      When.onTheProcessTypeUserFieldsView.iPressTheTranslateButton();
      When.onTheTranslateDialog.iSelectLanguage("German");
      When.onTheTranslateDialog.iSelectLanguage("Chinese - China");

      // Assertions
      Then.onTheTranslateDialog.iShouldSeeTheTable();
      // Then.onTheTranslateDialog.iShouldSeeTheTableHasItems(2);
    });

    opaTest("Should close the translation dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("translationDialog");

      // Actions
      When.onTheTranslateDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheProcessTypeUserFieldsView.iShouldSeeTheTableInEditMode();
    });

    opaTest("last test case", function (Given, When, Then) {
      // Assertions
      Then.onTheProcessTypeSection.iShouldSeeTheList();

      // Cleanup
      Then.iTeardownMyApp();
    });
  }
);
