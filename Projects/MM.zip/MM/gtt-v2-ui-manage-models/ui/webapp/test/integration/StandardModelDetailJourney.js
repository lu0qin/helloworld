sap.ui.define(
  [
    "sap/ui/test/opaQunit",
    "./pageObjects/Browser",
    "./pageObjects/History",
    "./pageObjects/ModelList",
    "./pageObjects/ModelDetail",
    "./pageObjects/ProcessType",
    "./pageObjects/CodeList",
    "./pageObjects/CodeListDetail",
  ],
  function (opaTest) {
    QUnit.module("StandardModelDetail");

    opaTest("Standard Model - Should see detail page", function (Given, When, Then) {
      // Arrangements
      Given.iStartMyApp();

      // Actions
      var name = "standardtfo";
      When.onTheModelListPage.iPressOnTheItemWithTheName(name);

      // Assertions
      Then.onTheModelDetailPage.theTitleShouldDisplayTheName(name);
      // Should see the detail page initially located at Tracked Process Section and select the first item
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection("trackedProcessSection");
    });

    opaTest("Tracked Process - Should see list grouped by category", function (Given, When, Then) {
      Then.onTheModelDetailPage.iSelectTheSection("trackedProcessSection");

      Then.onTheProcessTypeSection.iShouldSeeTheListHasItems(2);
      Then.onTheProcessTypeSection.iShouldSeeTheListGrouped();
    });

    opaTest("Code List - Should see List grouped by category", function (Given, When, Then) {
      Then.onTheModelDetailPage.iSelectTheSection("codeListSection");

      Then.onTheCodeListSection.iShouldSeeTheListHasItems(4);
      Then.onTheCodeListSection.iShouldSeeTheListGrouped();
    });

    opaTest("Import Code - Should see the dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("importCodeListDialog");

      // Actions
      When.onTheCodeListSection.iSelectListItem("list", "zzOrderStatus");
      When.onTheCodeListDetailView.iPressTheImportButton();

      // Assertions
      Then.onTheImportCodeDialog.iShouldSeeTheCodeSelect();
      Then.onTheImportCodeDialog.iShouldSeeThePreviewCodesTable();
      Then.onTheImportCodeDialog.iPressTheCancelButton();
    });

    opaTest("Import Code - Should import codes", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("importCodeListDialog");

      // Actions
      When.onTheCodeListDetailView.iPressTheImportButton();
      When.onTheImportCodeDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheCodeListDetailView.iShouldSeeTheTableHasItems(3);
    });

    opaTest("last test case", function (Given, When, Then) {
      // Assertions
      Then.onTheModelDetailPage.iShouldSeeThePage();

      // Cleanup
      Then.iTeardownMyApp();
    });
  }
);
