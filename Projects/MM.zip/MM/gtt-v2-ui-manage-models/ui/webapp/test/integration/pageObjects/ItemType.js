sap.ui.define(
  [
    "sap/ui/test/Opa5",
    "./ObjectPageSection",
    "./Dialog",
  ],
  function (
    Opa5,
    ObjectPageSection,
    Dialog
  ) {
    "use strict";

    Opa5.createPageObjects({
      onTheItemTypeSection: {
        baseClass: ObjectPageSection,
        viewName: "ItemType",
        actions: {
          iPressTheCreateButton: function () {
            return this.iPressTheButton("createButton");
          },
          iPressTheEditButton: function () {
            return this.iPressTheButton("editButton");
          },
          iPressTheDeleteButton: function () {
            return this.iPressTheButton("deleteButton");
          },
        },
        assertions: {
          iShouldSeeTheList: function () {
            return this.iShouldSeeTheControl("list");
          },
          iShouldSeeTheListHasItems: function (count) {
            return this.theListShouldHaveItems("list", count);
          },
          iShouldSeeTheListItemSelected: function (sText) {
            return this.iShouldSeeTheListSelection("list", sText);
          },
        },
      },
      onTheEditDialog: {
        baseClass: Dialog,
        actions: {},
        assertions: {
          iShouldSeeTheForm: function () {
            var sId = this.getId("form");
            return this.iShouldSeeTheControl(sId);
          },
        },
      },
    });
  }
);
