sap.ui.define(
  [
    "sap/ui/test/opaQunit",
    "./pageObjects/Browser",
    "./pageObjects/ModelList",
    "./pageObjects/ModelDetail",
    "./pageObjects/ItemType",
    "./pageObjects/ItemTypeUserFields",
  ],
  function (opaTest) {
    QUnit.module("ItemType");
    opaTest("Should see the object page section", function (Given, When, Then) {
      // Arrangements
      Given.iStartMyApp();

      // Actions
      var name = "tfo";
      When.onTheModelListPage.iPressOnTheItemWithTheName(name);

      var sectionId = "fieldTypePoolSection";
      When.onTheModelDetailPage.iSelectTheSection(sectionId);

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection(sectionId);
      Then.onTheItemTypeSection.iShouldSeeTheListHasItems(1);
      Then.onTheItemTypeSection.iShouldSeeTheListItemSelected("StopItem");
      Then.onTheItemTypeUserFieldsView.iShouldSeeTheTable();
    });

    opaTest("Should open the create dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editItemTypeDialog");

      // Actions
      When.onTheItemTypeSection.iPressTheCreateButton();

      // Assertions
      Then.onTheEditDialog.iShouldSeeTheForm();
    });

    opaTest("Should cancel the create dialog", function (Given, When, Then) {
      // Actions
      When.onTheEditDialog.iPressTheCancelButton();

      // Assertions
      Then.onTheItemTypeSection.iShouldSeeTheList();
    });

    opaTest("Should show errors in the create dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editItemTypeDialog");

      // Actions
      When.onTheItemTypeSection.iPressTheCreateButton();
      When.onTheEditDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheEditDialog.iShouldSeeTheValidationError("processType");
      Then.onTheEditDialog.iShouldSeeTheValidationError("name");

      // Cleanup
      Then.onTheEditDialog.iPressTheCancelButton();
    });

    opaTest("Should submit the create dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editItemTypeDialog");

      // Actions
      When.onTheItemTypeSection.iPressTheCreateButton();
      When.onTheEditDialog.iSelectDropDownInDialog("processType", "FreightOrder");
      When.onTheEditDialog.iInputTextInDialog("name", "NewItemType");
      When.onTheEditDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheItemTypeSection.iShouldSeeTheListHasItems(2);
      Then.onTheItemTypeSection.iShouldSeeTheListItemSelected("NewItemType");

    });

    opaTest("Should open the edit dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editItemTypeDialog");

      // Actions
      When.onTheItemTypeSection.iPressTheEditButton();

      // Assertions
      Then.onTheEditDialog.iShouldSeeTheInputValueInDialog("name", "NewItemType");
    });

    opaTest("Should show errors in the edit dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editItemTypeDialog");

      // Actions
      When.onTheEditDialog.iInputTextInDialog("name", "StopItem");
      When.onTheEditDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheEditDialog.iShouldSeeTheValidationError("name");
    });

    opaTest("Should close the edit dialog", function (Given, When, Then) {
      // Actions
      When.onTheEditDialog.iPressTheCancelButton();

      // Assertions
      Then.onTheItemTypeSection.iShouldSeeTheListItemSelected("NewItemType");
    });

    opaTest("Should submit the edit dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editItemTypeDialog");

      // Actions
      When.onTheItemTypeSection.iPressTheEditButton();
      When.onTheEditDialog.iInputTextInDialog("name", "NewItemType2");
      When.onTheEditDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheItemTypeSection.iShouldSeeTheListHasItems(2);
      Then.onTheItemTypeSection.iShouldSeeTheListItemSelected("NewItemType2");
    });

    opaTest("Should open the create user field dialog", function (Given, When, Then) {
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onTheItemTypeUserFieldsView.iPressTheCreateButton();

      Then.onTheUserFieldsDialog.iShouldSeeTheForm();
    });

    opaTest("Should cancel the create user field dialog", function (Given, When, Then) {
      Given.iSetupDialog("editFieldDialog");

      When.onTheUserFieldsDialog.iPressTheCancelButton();

      Then.onTheItemTypeUserFieldsView.iShouldSeeTheTable();
    });

    opaTest("Should create new user field", function (Given, When, Then) {
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onTheItemTypeUserFieldsView.iPressTheCreateButton();
      When.onTheUserFieldsDialog.iInputTextInDialog("name", "NewSimpleUserField");
      When.onTheUserFieldsDialog.iInputTextInDialog("label", "Label for NewUserField");
      When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "uuid");
      When.onTheUserFieldsDialog.iPressTheAcceptButton();

      Then.onTheItemTypeUserFieldsView.iShouldSeeTheTableHasItems(1);
    });

    opaTest("Should edit user field name", function (Given, When, Then) {
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onTheItemTypeUserFieldsView.iSelectRowInTable("table", 0);
      When.onTheItemTypeUserFieldsView.iPressTheEditButton();
      When.onTheUserFieldsDialog.iInputTextInDialog("name", "NewSimpleUserField222");
      When.onTheUserFieldsDialog.iPressTheAcceptButton();

      Then.onTheItemTypeUserFieldsView.iShouldSeeTheTableHasItems(1);
    });

    opaTest("Should delete user field without reference", function (Given, When, Then) {
      // Actions
      When.onTheItemTypeUserFieldsView.iSelectRowInTable("table", 0);
      When.onTheItemTypeUserFieldsView.iPressTheDeleteButton();
      When.onTheItemTypeSection.iPressTheButtonInDialog("OK");

      Then.onTheItemTypeUserFieldsView.iShouldSeeTheTableHasItems(0);
    });

    opaTest("Should delete the item without reference", function (Given, When, Then) {
      // Actions
      When.onTheItemTypeSection.iPressTheDeleteButton();
      // Assertions
      Then.onTheItemTypeSection.iShouldSeeTheListHasItems(1);
      Then.onTheItemTypeSection.iShouldSeeTheListItemSelected("StopItem");
    });

    opaTest("Should delete user field with reference objects", function (Given, When, Then) {
      // Actions
      When.onTheItemTypeUserFieldsView.iSelectRowInTable("table", 0);
      When.onTheItemTypeUserFieldsView.iPressTheDeleteButton();
      When.onTheItemTypeSection.iPressTheButtonInDialog("OK");

      Then.onTheItemTypeUserFieldsView.iShouldSeeTheTableHasItems(9);
    });

    opaTest("Should delete the item with reference", function (Given, When, Then) {
      // Actions
      When.onTheItemTypeSection.iPressTheDeleteButton();
      When.onTheItemTypeSection.iPressTheButtonInDialog("OK");

      // Assertions
      Then.onTheItemTypeSection.iShouldSeeTheListHasItems(0);
    });

    opaTest("last test case", function (Given, When, Then) {
      // Assertions
      Then.onTheItemTypeSection.iShouldSeeTheList();

      // Cleanup
      Then.iTeardownMyApp();
    });
  }
);
