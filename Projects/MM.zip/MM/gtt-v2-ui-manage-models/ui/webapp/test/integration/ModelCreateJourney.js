sap.ui.define(
  [
    "sap/ui/test/opaQunit",
    "sap/ui/core/ValueState",
    "./pageObjects/ModelList",
    "./pageObjects/ModelDetail",
  ],
  function (opaTest, ValueState) {
    QUnit.module("ModelCreate");

    opaTest("Should see the model create page", function (Given, When, Then) {
      // Arrangements
      Given.iStartMyApp();

      // Actions
      When.onTheModelListPage.iPressOnTheCreateButton();

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeThePage();
      // Should see the header section
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection("headerSection");
    });

    opaTest("Should show errors when doing save without model name", function (Given, When, Then) {
      // Actions
      When.onTheModelDetailPage.iPressTheSaveButton();

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeTheControlValueState("inputModelName", ValueState.Error, {
        fragmentId: "headerFragment",
      });
    });

    opaTest(
      "Should show errors when input model name not safisfied with constraint pattern",
      function (Given, When, Then) {
        // Actions
        When.onTheModelDetailPage.iInputText("inputModelName", "[[N", {
          fragmentId: "headerFragment",
        });
        When.onTheModelDetailPage.iPressTheSaveButton();

        // Assertions
        Then.onTheModelDetailPage.iShouldSeeTheControlValueState(
          "inputModelName",
          ValueState.Error,
          {
            fragmentId: "headerFragment",
          }
        );
      }
    );

    opaTest(
      "Should show error when input value of Correlation Level is not between 1 to 5",
      function (Given, When, Then) {
        // Actions
        When.onTheModelDetailPage.iInputText("inputCorrelationLevel", -1, {
          fragmentId: "headerFragment",
        });
        When.onTheModelDetailPage.iPressTheSaveButton();

        // Assertions
        Then.onTheModelDetailPage.iShouldSeeTheControlValueState(
          "inputCorrelationLevel",
          ValueState.Error,
          {
            fragmentId: "headerFragment",
          }
        );
      }
    );

    opaTest("last test case", function (Given, When, Then) {
      // Assertions
      Then.onTheModelDetailPage.iShouldSeeThePage();

      // Cleanup
      Then.iTeardownMyApp();
    });
  }
);
