sap.ui.define(
  [
    "sap/ui/test/Opa5",
    "sap/ui/test/matchers/Properties",
    "sap/ui/test/actions/Press",
    "./Common",
    "./Dialog",
  ],
  function (Opa5, Properties, Press, Common, Dialog) {
    "use strict";

    Opa5.createPageObjects({
      onTheUnplannedEventUserDetail: {
        baseClass: Common,
        viewName: "UnplannedEventUserDetail",
        actions: {
          iPressTheAddButton: function () {
            return this.iPressTheButton("addButton");
          },
          iPressTheEditButton: function () {
            return this.iPressTheButton("editButton");
          },
          iPressTheDeleteButton: function () {
            return this.iPressTheButton("deleteButton");
          },
        },
        assertions: {
          iShouldSeeTheTable: function () {
            return this.iShouldSeeTheControl("table");
          },
          iShouldSeeTheTableHasItems: function (count) {
            return this.theListShouldHaveItems("table", count);
          },
        },
      },
      onTheEditUnplannedEventDialog: {
        baseClass: Dialog,
        actions: {},
        assertions: {
          iShouldSeeTheForm: function () {
            var sId = this.getId("form");
            return this.iShouldSeeTheControl(sId);
          },
        },
      },
    });
  }
);
