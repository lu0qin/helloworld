sap.ui.define(
  [
    "sap/ui/test/Opa5",
    "./arrangements/Startup",
    "./ModelListJourney",
    "./ModelCreateJourney",
    "./StandardModelDetailJourney",
    "./ModelDetailJourney",
    "./ModelDeployedViewJourney",
    "./ModelDeploymentJourney",
    "./PlannedEventExtensionJourney",
    "./ProcessTypeJourney",
    "./ProcessTypeDetailJourney",
    "./UserFieldNameValidationJourney",
    "./ItemTypeJourney",
    "./EventTypeJourney",
    "./CodeListJourney",
    "./VPIntegrationJourney",
    "./IDocJourney",
  ],
  function (Opa5, Startup) {
    "use strict";

    var componentName = "com.sap.gtt.v2.model.manage";

    Opa5.extendConfig({
      arrangements: new Startup(),
      viewNamespace: componentName.concat(".view."),
      autoWait: true,
    });
  }
);
