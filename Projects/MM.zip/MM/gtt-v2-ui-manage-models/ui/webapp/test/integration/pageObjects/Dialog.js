sap.ui.define(
  [
    "sap/ui/test/Opa5",
    "./Common",
    "sap/ui/test/actions/Press",
    "sap/base/util/merge",
    "sap/ui/core/Fragment",
    "sap/ui/core/ValueState",
  ],
  function (
    Opa5,
    Common,
    Press,
    merge,
    Fragment,
    ValueState
  ) {
    "use strict";

    var publicMethods = Common.prototype.getMetadata().getPublicMethods();
    var dialogDef = publicMethods.reduce(function (result, method) {
      result[method] = function () {
        var args = Array.from(arguments);
        var options = {
          searchOpenDialogs: true,
        };
        args.push(options);
        return Common.prototype[method].apply(this, args);
      };

      return result;
    }, {});

    return Common.extend(
      "com.sap.gtt.v2.model.manage.test.integration.pageObjects.Dialog",
      merge(dialogDef, {
        getId: function (sId) {
          var fragmentId = this.getContext().fragmentId;
          return Fragment.createId(fragmentId, sId);
        },
        iPressTheAcceptButton: function () {
          return this.waitFor({
            controlType: "sap.m.Button",
            searchOpenDialogs: true,
            matchers: [
              function (oButton) {
                var found = false;
                var oParent = oButton.getParent();

                if (oParent && oParent.getMetadata().getName() === "sap.m.Dialog") {
                  var oDialog = oParent;
                  found = oButton === oDialog.getBeginButton();
                }

                return found;
              },
            ],
            actions: new Press(),
            errorMessage: "Did not find the accept button",
          });
        },

        iPressTheCancelButton: function () {
          return this.waitFor({
            controlType: "sap.m.Button",
            searchOpenDialogs: true,
            matchers: [
              function (oButton) {
                var found = false;
                var oParent = oButton.getParent();

                if (oParent && oParent.getMetadata().getName() === "sap.m.Dialog") {
                  var oDialog = oParent;
                  found = oButton === oDialog.getEndButton();
                }

                return found;
              },
            ],
            actions: new Press(),
            errorMessage: "Did not find the cancel button",
          });
        },

        iInputTextInDialog: function (sId, sValue) {
          return this.iInputText(this.getId(sId), sValue);
        },

        iSelectDropDownInDialog: function (sId, sKey) {
          return this.iSelectDropDown(this.getId(sId), sKey);
        },

        iSelectFromValueHelpInDialog: function (sId) {
          return this.iSelectFromValueHelp(this.getId(sId));
        },

        iSelectComboBoxInDialog: function (sId, sText) {
          return this.iSelectComboBox(this.getId(sId), sText);
        },

        iSelectCheckBoxInDialog: function (sId, bSelected) {
          return this.iSelectCheckBox(this.getId(sId), bSelected);
        },

        iShouldSeeTheInputValueInDialog: function (sId, sValue) {
          return this.iShouldSeeTheInputValue(this.getId(sId), sValue);
        },

        iShouldSeeTheListInDialog: function (sId, count) {
          return this.theListShouldHaveItems(this.getId(sId), count);
        },

        iShouldSeeTheValidationError: function (sId) {
          return this.iShouldSeeTheControlValueState(this.getId(sId), ValueState.Error);
        },

        iShouldSeeTheValidationWarning: function (sId) {
          return this.iShouldSeeTheControlValueState(this.getId(sId), ValueState.Warning);
        },

        iShouldSeeTheValidationSuccess: function (sId) {
          return this.iShouldSeeTheControlValueState(this.getId(sId), ValueState.None);
        },
      })
    );
  }
);
