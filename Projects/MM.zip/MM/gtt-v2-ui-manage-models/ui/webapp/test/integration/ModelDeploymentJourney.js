sap.ui.define(
  [
    "sap/ui/test/opaQunit",
    "./pageObjects/Browser",
    "./pageObjects/ModelList",
    "./pageObjects/ModelDetail",
    "./pageObjects/ModelDeployment",
    "./pageObjects/DeploymentHistory",
  ],
  function (opaTest) {
    QUnit.module("ModelDeployment");

    opaTest("Should see the deployment page", function (Given, When, Then) {
      // Arrangements
      Given.iStartMyApp();

      // Actions
      var modelName = "tfo";
      When.onTheModelListPage.iPressOnTheItemWithTheName(modelName);
      When.onTheModelDetailPage.iSelectTheViewMenu("runtimeView");

      // Assertions
      Then.onTheModelDeploymentPage.theTitleShouldDisplayTheName(modelName);
    });

    opaTest("Should see the write api section", function (Given, When, Then) {
      // Actions
      var sectionId = "writeApiSection";
      When.onTheModelDeploymentPage.iSelectTheSection(sectionId);

      // Assertions
      Then.onTheModelDeploymentPage.iShouldSeeTheSelectedSection(sectionId);
    });

    opaSkip("Should see the read api section", function (Given, When, Then) {
      // Actions
      var sectionId = "readApiSection";
      When.onTheModelDeploymentPage.iSelectTheSection(sectionId);

      // Assertions
      Then.onTheModelDeploymentPage.iShouldSeeTheSelectedSection(sectionId);
    });

    opaTest("Should see confirmation box when press deactivate model", function (Given, When, Then) {
      // Actions
      When.onTheModelDeploymentPage.iPressTheDeactivateButton();

      // Assertions
      Then.onTheModelDeploymentPage.iShouldSeeTheDeactivateConfirmBox();
    });

    opaTest("Should deactivate model when confirmed", function (Given, When, Then) {
      // Actions
      When.onTheModelDeploymentPage.iPressAcceptButtonInMessageBox();

      // Assertions
      Then.onTheModelDeploymentPage.iShouldSeeTheControl("modelStatus");
    });

    opaTest("last test case", function (Given, When, Then) {
      // Assertions
      Then.onTheModelDeploymentPage.iShouldSeeThePage();

      // Cleanup
      Then.iTeardownMyApp();
    });
  }
);
