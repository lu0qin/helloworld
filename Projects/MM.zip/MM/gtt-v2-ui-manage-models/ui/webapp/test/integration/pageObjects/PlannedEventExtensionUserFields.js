sap.ui.define(
  [
    "sap/ui/test/Opa5",
    "./Common",
  ],
  function (Opa5, Common) {
    "use strict";

    Opa5.createPageObjects({
      onThePlannedEventExtensionUserFieldsView: {
        baseClass: Common,
        viewName: "PlannedEventExtensionUserFields",
        actions: {
          iPressTheCreateButton: function () {
            return this.iPressTheButton("createButton");
          },
          iPressTheEditButton: function () {
            return this.iPressTheButton("editButton");
          },
          iPressTheDeleteButton: function () {
            return this.iPressTheButton("deleteButton");
          },
          iPressTheTranslateButton: function () {
            return this.iPressTheButton("translateButton");
          },
        },
        assertions: {
          iShouldSeeTheTable: function () {
            return this.iShouldSeeTheControl("table");
          },
          iShouldSeeTheTableHasItems: function (count) {
            return this.theListShouldHaveItems("table", count);
          },
        },
      },
    });
  }
);
