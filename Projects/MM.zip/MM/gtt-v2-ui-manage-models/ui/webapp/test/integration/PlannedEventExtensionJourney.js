sap.ui.define(
  [
    "sap/ui/test/opaQunit",
    "./pageObjects/Browser",
    "./pageObjects/ModelList",
    "./pageObjects/ModelDetail",
    "./pageObjects/PlannedEventExtensionUserFields",
    "./pageObjects/UserFields",
    "./pageObjects/TranslationDialog",
  ],
  function (opaTest) {
    QUnit.module("PlannedEventExtension");

    opaTest("Should see the object page section", function (Given, When, Then) {
      // Arrangements
      Given.iStartMyApp();

      // Actions
      var name = "tfo";
      When.onTheModelListPage.iPressOnTheItemWithTheName(name);

      var sectionId = "plannedEventExtensionSection";
      When.onTheModelDetailPage.iSelectTheSection(sectionId);

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection(sectionId);
      Then.onThePlannedEventExtensionUserFieldsView.iShouldSeeTheTableHasItems(7);
    });

    opaTest("Should Creat one user filed with UUID type", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onThePlannedEventExtensionUserFieldsView.iPressTheCreateButton();
      When.onTheUserFieldsDialog.iInputTextInDialog("name", "NewCRUDUserField");
      When.onTheUserFieldsDialog.iInputTextInDialog("label", "Label for NewUserField");
      When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "uuid");

      When.onTheUserFieldsDialog.iPressTheAcceptButton();

      // Assertions
      Then.onThePlannedEventExtensionUserFieldsView.iShouldSeeTheTableHasItems(8);
    });

    opaTest("Should show error in the planned event extension create dialog while input duplicate name", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onThePlannedEventExtensionUserFieldsView.iPressTheCreateButton();
      When.onTheUserFieldsDialog.iInputTextInDialog("name", "NewCRUDUserField");
      When.onTheUserFieldsDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheUserFieldsDialog.iShouldSeeTheValidationError("name");

      // Clean up
      Then.onTheUserFieldsDialog.iPressTheCancelButton();
    });

    opaTest("Should show error in the planned event extension create dialog while input name starting with GTT", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onThePlannedEventExtensionUserFieldsView.iPressTheCreateButton();
      When.onTheUserFieldsDialog.iInputTextInDialog("name", "gttPlannedEventExtension");
      When.onTheUserFieldsDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheUserFieldsDialog.iShouldSeeTheValidationError("name");

      // Clean up
      Then.onTheUserFieldsDialog.iPressTheCancelButton();
    });

    opaTest("Should open the user field edit dialog by pressing edit-line button", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onThePlannedEventExtensionUserFieldsView.iPressLineEditButtonInTable("table", 0);

      // Assertions
      Then.onTheUserFieldsDialog.iShouldSeeTheForm();

      // Clean up
      Then.onTheUserFieldsDialog.iPressTheCancelButton();
    });

    opaTest("Should submit the user field edit dialog with String type", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onThePlannedEventExtensionUserFieldsView.iSelectRowInTable("table", 7);
      When.onThePlannedEventExtensionUserFieldsView.iPressTheEditButton();
      When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "string");
      When.onTheUserFieldsDialog.iInputTextInDialog("length", "10");
      When.onTheUserFieldsDialog.iPressTheAcceptButton();

      // Assertions
      Then.onThePlannedEventExtensionUserFieldsView.iShouldSeeTheTableHasItems(8);
    });

    // opaTest("Should submit the user field edit dialog with Code List type", function (Given, When, Then) {
    //   // Arrangements
    //   Given.iSetupDialog("editFieldDialog");
    //
    //   // Actions
    //   When.onThePlannedEventExtensionUserFieldsView.iSelectRowInTable(8);
    //   When.onThePlannedEventExtensionUserFieldsView.iPressTheEditButton();
    //   When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "codelist");
    //
    //   When.onTheUserFieldsDialog.iSelectFromValueHelpInDialog("codeListTarget");
    //   Then.onTheUserFieldsDialog.iShouldSeeTheInputValueInDialog("codeListTarget", "FreightOrder.OrderStatus");
    //
    //   When.onTheUserFieldsDialog.iPressTheAcceptButton();
    //
    //   // Assertions
    //   Then.onThePlannedEventExtensionUserFieldsView.iShouldSeeTheTableHasItems(9);
    // });

    opaTest("Should delete the user field without reference", function (Given, When, Then) {
      // Actions
      When.onThePlannedEventExtensionUserFieldsView.iSelectRowInTable("table", 7);
      When.onThePlannedEventExtensionUserFieldsView.iPressTheDeleteButton();
      When.onThePlannedEventExtensionUserFieldsView.iPressTheButtonInDialog("OK");

      // Assertions
      Then.onThePlannedEventExtensionUserFieldsView.iShouldSeeTheTableHasItems(7);
    });

    opaTest("Should show warning in edit dialog of user field with reference when change type", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onThePlannedEventExtensionUserFieldsView.iSelectRowInTable("table", 0);
      When.onThePlannedEventExtensionUserFieldsView.iPressTheEditButton();
      When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "boolean");

      // Assertions
      Then.onTheUserFieldsDialog.iShouldSeeTheValidationWarning("type");
      Then.onTheUserFieldsDialog.iPressTheCancelButton();
    });

    opaTest("Should delete the user field with reference", function (Given, When, Then) {
      // Actions
      When.onThePlannedEventExtensionUserFieldsView.iSelectRowInTable("table", 0);
      When.onThePlannedEventExtensionUserFieldsView.iPressTheDeleteButton();
      When.onThePlannedEventExtensionUserFieldsView.iPressTheButtonInDialog("OK");

      // Assertions
      Then.onThePlannedEventExtensionUserFieldsView.iShouldSeeTheTableHasItems(6);
    });

    opaTest("Should open the translation dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("translationDialog");

      // Actions
      When.onThePlannedEventExtensionUserFieldsView.iPressTheTranslateButton();
      When.onTheTranslateDialog.iSelectLanguage("German");
      When.onTheTranslateDialog.iSelectLanguage("Chinese - China");

      // Assertions
      Then.onTheTranslateDialog.iShouldSeeTheTable();
      // Then.onTheTranslateDialog.iShouldSeeTheTableHasItems(2);
    });

    opaTest("Should close the translation dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("translationDialog");

      // Actions
      When.onTheTranslateDialog.iPressTheCancelButton();

      // Assertions
      Then.onThePlannedEventExtensionUserFieldsView.iShouldSeeTheTable();
    });


    opaTest("last test case", function (Given, When, Then) {
      // Assertions
      Then.onThePlannedEventExtensionUserFieldsView.iShouldSeeTheTable();

      // Cleanup
      Then.iTeardownMyApp();
    });
  }
);
