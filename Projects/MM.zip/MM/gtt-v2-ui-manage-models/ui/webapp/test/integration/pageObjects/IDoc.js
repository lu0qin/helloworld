sap.ui.define(
  [
    "sap/ui/test/Opa5",
    "sap/ui/test/matchers/Properties",
    "sap/ui/test/matchers/PropertyStrictEquals",
    "sap/ui/test/actions/Press",
    "sap/base/strings/formatMessage",
    "./Common",
    "./Dialog",
    "./ObjectPageSection",
  ],
  function (
    Opa5,
    Properties,
    PropertyStrictEquals,
    Press,
    formatMessage,
    Common,
    Dialog,
    ObjectPageSection
  ) {
    "use strict";

    Opa5.createPageObjects({
      onTheIDocSection: {
        baseClass: ObjectPageSection,
        viewName: "IDoc",
        actions: {
          iPressTheCancelButton: function () {
            return this.iPressTheButton(/(.*)cancel/, {
              searchOpenDialogs: true,
            });
          },

          iSelectIntegrationSwitch: function (bState) {
            return this.iSelectSwitch("switch", bState);
          },

          iSelectEventInTable: function (eventName) {
            return this.waitFor({
              id: "eventsMappingTable",
              fragmentId: "detailFragment",
              success: function (oTable) {
                var oItem = oTable.getItems().find(function (item) {
                  return (
                    !item.isGroupHeader() &&
                    item.getBindingContext("iDoc").getProperty("_ref/name") === eventName
                  );
                });
                oTable.setSelectedItem(oItem, true, true);
              },
              errorMessage: formatMessage("Was not able to see the {0} Event.", eventName),
            });
          },

          iSelectERPObjectType: function (erpObjectTypeKey) {
            return this.waitFor({
              id: "erpTypeSelect",
              fragmentId: "frag",
              success: function (oSelect) {
                var oItem = oSelect.getItemByKey(erpObjectTypeKey);
                oSelect.fireChange({ selectedItem: oItem });
              },
              errorMessage: "Was not able to see the ERP Object Type.",
            });
          },

          iInputTheTextInTable: function (text, itemName, cellIndex) {
            return this.waitFor({
              fragmentId: "detailFragment",
              id: "eventsMappingTable",
              success: function (oTable) {
                var aItems = oTable.getItems().filter(function (item) {
                  return !item.isGroupHeader();
                });
                var oItem = aItems.find(function (item) {
                  return item.getBindingContext("iDoc").getProperty("_ref/name") === itemName;
                });
                var oCell = oItem.getCells()[cellIndex];
                if (oCell.getVisible()) {
                  oCell.setValue(text);
                }
              },
              errorMessage: formatMessage(
                "Was not able to input the text: {0} for item: {1} tree table.",
                text,
                itemName
              ),
            });
          },

          iInputTheTextInTreeTable: function (text, itemName, cellIndex, isCompositionElement) {
            return this.waitFor({
              fragmentId: "detailFragment",
              id: "userFieldMappingFragment--fieldsMappingTable",
              success: function (oTable) {
                var aRows = oTable.getRows();
                var oRow = aRows.find(function (row) {
                  if (isCompositionElement) {
                    return (
                      row.getLevel() === 2 &&
                      row.getBindingContext("iDoc").getProperty("_ref/field/name") === itemName
                    );
                  } else {
                    return (
                      row.getLevel() === 1 &&
                      row.getBindingContext("iDoc").getProperty("_ref/field/name") === itemName
                    );
                  }
                });
                var oCell = oRow.getCells()[cellIndex];
                if (oCell.getVisible()) {
                  oCell.setValue(text);
                }
              },
              errorMessage: formatMessage(
                "Was not able to input the text: {0} for item: {1} tree table.",
                text,
                itemName
              ),
            });
          },

          iPressTheValueHelpButtonInTreeTable: function (
            itemName,
            cellIndex,
            isCompositionElement
          ) {
            return this.waitFor({
              fragmentId: "detailFragment",
              id: "userFieldMappingFragment--fieldsMappingTable",
              success: function (oTreeTable) {
                oTreeTable.expandToLevel(2);
                var aRows = oTreeTable.getRows();
                var oItem = aRows.find(function (row) {
                  if (isCompositionElement) {
                    return (
                      row.getLevel() === 2 &&
                      row.getBindingContext("iDoc").getProperty("_ref/field/name") === itemName
                    );
                  } else {
                    return (
                      row.getLevel() === 1 &&
                      row.getBindingContext("iDoc").getProperty("_ref/field/name") === itemName
                    );
                  }
                });
                var oCell = oItem.getCells()[cellIndex];
                if (oCell.getVisible()) {
                  oCell.fireValueHelpRequest();
                }
              },
              errorMessage: formatMessage(
                "Was not able to open value help dialog of {0}.",
                itemName
              ),
            });
          },

          iPressTheValueHelpButtonInTable: function (itemName, cellIndex) {
            return this.waitFor({
              fragmentId: "detailFragment",
              id: "eventsMappingTable",
              success: function (oTable) {
                var aItems = oTable.getItems().filter(function (item) {
                  return !item.isGroupHeader();
                });
                var oItem = aItems.find(function (item) {
                  return item.getBindingContext("iDoc").getProperty("_ref/name") === itemName;
                });
                var oCell = oItem.getCells()[cellIndex];
                if (oCell.getVisible()) {
                  oCell.fireValueHelpRequest();
                }
              },
              errorMessage: formatMessage(
                "Was not able to open value help dialog of {0}.",
                itemName
              ),
            });
          },
        },
        assertions: {
          iShouldSeeTheTrackedProcessSelect: function () {
            return this.iShouldSeeTheControl("processTypeSelect");
          },

          iShouldSeeTheIDocSwitch: function () {
            return this.iShouldSeeTheControl("switch");
          },

          iShouldSeeTheErpObjectType: function () {
            return this.iShouldSeeTheControl("erpObjectType", {
              fragmentId: "frag",
            });
          },

          iShouldSeeTheApplicationObjectType: function () {
            return this.iShouldSeeTheControl("applicationObjectType", {
              fragmentId: "frag",
            });
          },

          iShouldNotSeeTheTrackedProcessMapping: function () {
            return this.iShouldNotSeeTheControl("trackedProcessEdit", {
              fragmentId: "frag",
            });
          },

          iShouldNotSeeTheDetailMapping: function () {
            return this.iShouldNotSeeTheControl("DynamicSideContent", {
              fragmentId: "detailFragment",
            });
          },

          theEventTableShouldHaveItems: function (count) {
            return this.waitFor({
              fragmentId: "detailFragment",
              id: "eventsMappingTable",
              success: function (oTable) {
                var aItems = oTable.getItems().filter(function (item) {
                  return !item.isGroupHeader();
                });
                Opa5.assert.equal(
                  aItems.length,
                  count,
                  formatMessage("Event Table have {0} items.", count)
                );
              },
              errorMessage: "Was not able to see the Event table.",
            });
          },

          theFieldTableShouldHaveItems: function (count) {
            return this.waitFor({
              fragmentId: "detailFragment",
              id: "userFieldMappingFragment--fieldsMappingTable",
              success: function (oTable) {
                oTable.expandToLevel(2);
                var length = oTable.getBinding().getLength();
                Opa5.assert.equal(
                  length,
                  count,
                  formatMessage("Field Table have {0} items.", count)
                );
              },
              errorMessage: "Was not able to see the Field table.",
            });
          },

          theEventTableShouldSelectItem: function (eventName) {
            return this.waitFor({
              id: "eventsMappingTable",
              fragmentId: "detailFragment",
              success: function (oTable) {
                var sSelectedItemName = oTable
                  .getSelectedItem()
                  .getBindingContext("iDoc")
                  .getProperty("_ref/name");
                Opa5.assert.equal(
                  sSelectedItemName,
                  eventName,
                  formatMessage("Event Table select the {0}.", eventName)
                );
              },
              errorMessage: formatMessage("Was not able to see the selected item: {0}.", eventName),
            });
          },

          iShouldSeeTheIDocInput: function () {
            return this.waitFor({
              id: "eventsMappingTable",
              fragmentId: "detailFragment",
              success: function (oTable) {
                var sItems = oTable.getItems().filter(function (item) {
                  return !item.isGroupHeader();
                });
                sItems.forEach(function (item) {
                  Opa5.assert.equal(item.getCells()[1].getEnabled(), true, "The input is enabled.");
                });
              },
              errorMessage: formatMessage("Was not able to see the idoc input."),
            });
          },

          iShouldSeeTheInputValueInTable: function (text, itemName, cellIndex) {
            return this.waitFor({
              fragmentId: "detailFragment",
              id: "eventsMappingTable",
              success: function (oTable) {
                var oItem = oTable.getItems().find(function (item) {
                  return (
                    !item.isGroupHeader() &&
                    item.getBindingContext("iDoc").getProperty("_ref/name") === itemName
                  );
                });
                var oCell = oItem.getCells()[cellIndex];
                Opa5.assert.equal(
                  oCell.getValue(),
                  text,
                  formatMessage("The input has value: {0}", text)
                );
              },
              errorMessage: formatMessage("The text {0} doesn't match with the input value.", text),
            });
          },

          iShouldSeeTheInputValueInTreeTable: function (
            text,
            itemName,
            cellIndex,
            isCompositionElement
          ) {
            return this.waitFor({
              fragmentId: "detailFragment",
              id: "userFieldMappingFragment--fieldsMappingTable",
              success: function (oTable) {
                oTable.expandToLevel(2);
                var oItem = oTable.getRows().find(function (row) {
                  if (isCompositionElement) {
                    return (
                      row.getLevel() === 2 &&
                      row.getBindingContext("iDoc").getProperty("_ref/field/name") === itemName
                    );
                  } else {
                    return (
                      row.getLevel() === 1 &&
                      row.getBindingContext("iDoc").getProperty("_ref/field/name") === itemName
                    );
                  }
                });
                var oCell = oItem.getCells()[cellIndex];
                Opa5.assert.equal(
                  oCell.getValue(),
                  text,
                  formatMessage("The input has value: {0}", text)
                );
              },
              errorMessage: formatMessage("The text {0} doesn't match with the input value.", text),
            });
          },

          iShouldSeeTheValueHelp: function (valueHelpId) {
            return this.iShouldSeeTheControl(valueHelpId);
          },

          iShouldSeeTheValueHelpHasItems: function (listId, count) {
            return this.waitFor({
              id: listId,
              success: function (oList) {
                Opa5.assert.equal(
                  oList[0].getItems().length,
                  count,
                  formatMessage("The control {0} has {1} items", listId, count)
                );
              },
              errorMessage: formatMessage("Was not able to see the control {0}.", listId),
            });
          },
        },
      },
    });
  }
);
