sap.ui.define(
  [
    "sap/ui/test/opaQunit",
    "./pageObjects/Browser",
    "./pageObjects/ModelList",
    "./pageObjects/ModelDetail",
    "./pageObjects/IDoc",
    "./pageObjects/ProcessType",
    "./pageObjects/ProcessTypeUserFields",
    "./pageObjects/ItemType",
    "./pageObjects/ItemTypeUserFields",
  ],
  function (opaTest) {
    QUnit.module("IDoc");

    var sFreightOrderEvent = "FreightOrder";
    var sDelayedEvent = "DelayedEvent";

    opaTest("Should see the object page section", function (Given, When, Then) {
      // Arrangements
      Given.iStartMyApp();

      // Actions
      var name = "tfo";
      When.onTheModelListPage.iPressOnTheItemWithTheName(name);

      var sectionId = "iDocSection";
      When.onTheModelDetailPage.iSelectTheSection(sectionId);

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection(sectionId);
      Then.onTheIDocSection.iShouldSeeTheTrackedProcessSelect();
      Then.onTheIDocSection.iShouldSeeTheErpObjectType();
      Then.onTheIDocSection.iShouldSeeTheApplicationObjectType();
      Then.onTheIDocSection.theEventTableShouldHaveItems(2);
      Then.onTheIDocSection.theEventTableShouldSelectItem(sFreightOrderEvent);
      Then.onTheIDocSection.theFieldTableShouldHaveItems(20);
    });

    opaTest("Should switch off the integration switch", function (Given, When, Then) {
      When.onTheModelDetailPage.iPressTheEditButton();

      When.onTheIDocSection.iSelectIntegrationSwitch(false);

      // When switch off to disable idoc
      Then.onTheIDocSection.iShouldSeeTheTrackedProcessSelect();
      Then.onTheIDocSection.iShouldSeeTheIDocSwitch();
      Then.onTheIDocSection.iShouldNotSeeTheTrackedProcessMapping();
      Then.onTheIDocSection.iShouldNotSeeTheDetailMapping();
    });

    opaTest("Should select an event type mapping", function (Given, When, Then) {
      When.onTheIDocSection.iSelectIntegrationSwitch(true);
      When.onTheIDocSection.iSelectEventInTable(sDelayedEvent);

      Then.onTheIDocSection.theEventTableShouldSelectItem(sDelayedEvent);
      Then.onTheIDocSection.theFieldTableShouldHaveItems(20);
    });

    /*
     * ERP Object Type is Others
     */
    opaTest("Should select the Others ERP Object Type", function (Given, When, Then) {
      When.onTheIDocSection.iSelectERPObjectType("OTHERS");

      Then.onTheIDocSection.iShouldSeeTheIDocInput(true);
    });

    opaTest("Should free input IDoc and Event Code Value", function (Given, When, Then) {
      var sIDocValue01 = "testIDoc01";
      var sIDocValue02 = "testIDoc02";
      var sEventCodeValue = "testEventCode";
      When.onTheIDocSection.iInputTheTextInTable(sIDocValue01, sFreightOrderEvent, 1);
      When.onTheIDocSection.iInputTheTextInTable(sIDocValue02, sDelayedEvent, 1);
      When.onTheIDocSection.iInputTheTextInTable(sEventCodeValue, sDelayedEvent, 2);

      Then.onTheIDocSection.iShouldSeeTheInputValueInTable(sIDocValue01, sFreightOrderEvent, 1);
      Then.onTheIDocSection.iShouldSeeTheInputValueInTable(sIDocValue02, sDelayedEvent, 1);
      Then.onTheIDocSection.iShouldSeeTheInputValueInTable(sEventCodeValue, sDelayedEvent, 2);
    });

    // When the IDoc is free input
    opaTest("Should see 0 items in IDoc Segment value help when IDOC is free input", function (
      Given,
      When,
      Then
    ) {
      When.onTheIDocSection.iSelectEventInTable(sFreightOrderEvent);
      When.onTheIDocSection.iPressTheValueHelpButtonInTreeTable("uuidField", 1, false);

      Then.onTheIDocSection.iShouldSeeTheValueHelp(/(.*)idocSegmentValueHelpDialog-dialog/);
      Then.onTheIDocSection.iShouldSeeTheValueHelpHasItems(
        /(.*)idocSegmentValueHelpDialog-list/,
        0
      );
    });

    opaTest("Should cancel the IDoc Segment value help", function (Given, When, Then) {
      When.onTheIDocSection.iPressTheCancelButton();

      Then.onTheIDocSection.iShouldSeeTheTrackedProcessSelect();
      Then.onTheIDocSection.iShouldSeeTheInputValueInTreeTable("", "uuidField", 1, false);
    });

    opaTest("Should free input IDoc Segment value", function (Given, When, Then) {
      When.onTheIDocSection.iInputTheTextInTreeTable("testIDocSegment", "uuidField", 1, false);

      Then.onTheIDocSection.iShouldSeeTheInputValueInTreeTable(
        "testIDocSegment",
        "uuidField",
        1,
        false
      );
    });

    // When the IDoc is E1EHPAO
    opaTest("Should see 2 items in IDoc Segment value help when IDOC is E1EHPAO", function (
      Given,
      When,
      Then
    ) {
      When.onTheIDocSection.iPressTheValueHelpButtonInTable(sFreightOrderEvent, 1);
      When.onTheIDocSection.iSelectValueHelpItem("E1EHPAO");
      When.onTheIDocSection.iPressTheValueHelpButtonInTreeTable("uuidField", 1, false);

      Then.onTheIDocSection.iShouldSeeTheValueHelpHasItems(
        /(.*)idocSegmentValueHelpDialog-list/,
        2
      );
    });

    opaTest("Should select E1EHPCP in the IDoc Segment input value help", function (
      Given,
      When,
      Then
    ) {
      When.onTheIDocSection.iSelectValueHelpItem("E1EHPCP");

      Then.onTheIDocSection.iShouldSeeTheInputValueInTreeTable("E1EHPCP", "uuidField", 1, false);
    });

    opaTest("Should free input the IDoc Fields value help", function (Given, When, Then) {
      When.onTheIDocSection.iInputTheTextInTreeTable("testIDocFields", "uuidField", 2, false);

      Then.onTheIDocSection.iShouldSeeTheInputValueInTreeTable(
        "testIDocFields",
        "uuidField",
        2,
        false
      );
    });

    /*
     * ERP Object Type is Purchase Order Item
     */
    opaTest("Should select the Purchase Order ERP Object Type", function (Given, When, Then) {
      When.onTheIDocSection.iSelectERPObjectType("PO_ITEM");

      Then.onTheIDocSection.iShouldSeeTheInputValueInTable("E1EHPAO", sFreightOrderEvent, 1);
      Then.onTheIDocSection.iShouldSeeTheInputValueInTable("E1EVMHDR02", sDelayedEvent, 1);
    });

    // When the IDoc is E1EHPAO
    opaTest("Should see 2 items in IDoc Segment value help when IDOC is E1EHPAO", function (
      Given,
      When,
      Then
    ) {
      When.onTheIDocSection.iSelectEventInTable(sFreightOrderEvent);
      When.onTheIDocSection.iPressTheValueHelpButtonInTreeTable("stringField", 1, false);

      Then.onTheIDocSection.iShouldSeeTheValueHelp(/(.*)idocSegmentValueHelpDialog-dialog/);
      Then.onTheIDocSection.iShouldSeeTheValueHelpHasItems(
        /(.*)idocSegmentValueHelpDialog-list/,
        2
      );
    });

    opaTest("Should select E1EHPCP in the IDoc Segment input value help", function (
      Given,
      When,
      Then
    ) {
      When.onTheIDocSection.iSelectValueHelpItem("E1EHPCP");

      Then.onTheIDocSection.iShouldSeeTheInputValueInTreeTable("E1EHPCP", "stringField", 1, false);
    });

    opaTest(
      "Should see preset items in IDoc Fields input value help when IDOC is E1EHPAO and IDOC Segment is E1EHPCP",
      function (Given, When, Then) {
        When.onTheIDocSection.iPressTheValueHelpButtonInTreeTable("stringField", 2, false);

        Then.onTheIDocSection.iShouldSeeTheValueHelp(/(.*)idocFieldsValueHelpDialog-dialog/);
        Then.onTheIDocSection.iShouldSeeTheValueHelpHasItems(
          /(.*)idocFieldsValueHelpDialog-list/,
          20
        );
      }
    );

    opaTest("Should select PO_NO in the IDoc Fields input value help", function (
      Given,
      When,
      Then
    ) {
      When.onTheIDocSection.iSelectValueHelpItem("PO_NO");

      Then.onTheIDocSection.iShouldSeeTheInputValueInTreeTable("PO_NO", "stringField", 2, false);
    });

    // When the IDoc is E1EVMHDR02
    opaTest("Should see 0 item in IDoc Segment value help when IDOC is E1EVMHDR02", function (
      Given,
      When,
      Then
    ) {
      When.onTheIDocSection.iSelectEventInTable(sDelayedEvent);
      When.onTheIDocSection.iPressTheValueHelpButtonInTreeTable("stringField", 1, false);

      Then.onTheIDocSection.iShouldSeeTheValueHelp(/(.*)idocSegmentValueHelpDialog-dialog/);
      Then.onTheIDocSection.iShouldSeeTheValueHelpHasItems(
        /(.*)idocSegmentValueHelpDialog-list/,
        0
      );
    });

    opaTest("Should free input the IDoc Segment input value help", function (Given, When, Then) {
      When.onTheIDocSection.iPressTheCancelButton();
      When.onTheIDocSection.iInputTheTextInTreeTable("testIDocSegment", "stringField", 1, false);

      Then.onTheIDocSection.iShouldSeeTheInputValueInTreeTable(
        "testIDocSegment",
        "stringField",
        1,
        false
      );
    });

    opaTest(
      "Should see 0 items in IDoc Fields input value help when IDOC is E1EVMHDR02 and IDOC Segment is free input",
      function (Given, When, Then) {
        When.onTheIDocSection.iPressTheValueHelpButtonInTreeTable("stringField", 2, false);

        Then.onTheIDocSection.iShouldSeeTheValueHelp(/(.*)idocFieldsValueHelpDialog-dialog/);
        Then.onTheIDocSection.iShouldSeeTheValueHelpHasItems(
          /(.*)idocFieldsValueHelpDialog-list/,
          0
        );
      }
    );

    opaTest("Should cancel the IDoc Fields input value help", function (Given, When, Then) {
      When.onTheIDocSection.iPressTheCancelButton();

      Then.onTheIDocSection.iShouldSeeTheInputValueInTreeTable("SHIP_NO", "stringField", 2, false);
    });

    /*
     * ERP Object Type is Purchase Order Item, IDoc is E1EHPAO
     * Composition item test
     */
    opaTest("Should open the composition item IDoc Segment input value help", function (
      Given,
      When,
      Then
    ) {
      When.onTheIDocSection.iSelectEventInTable(sFreightOrderEvent);
      When.onTheIDocSection.iPressTheValueHelpButtonInTreeTable("stringField", 1, true);

      Then.onTheIDocSection.iShouldSeeTheValueHelp(/(.*)idocSegmentValueHelpDialog-dialog/);
      Then.onTheIDocSection.iShouldSeeTheValueHelpHasItems(
        /(.*)idocSegmentValueHelpDialog-list/,
        2
      );
    });

    opaTest(
      "Should select E1EHPTID in the IDoc Segment input value help of composition item",
      function (Given, When, Then) {
        When.onTheIDocSection.iSelectValueHelpItem("E1EHPTID");

        Then.onTheIDocSection.iShouldSeeTheTrackedProcessSelect();
        Then.onTheIDocSection.iShouldSeeTheInputValueInTreeTable(
          "E1EHPTID",
          "stringField",
          1,
          true
        );
      }
    );

    /**
     * When ERP Object Type is Delivery Item
     */
    opaTest("Should select an erp object type with delivery item", function (Given, When, Then) {
      When.onTheIDocSection.iSelectERPObjectType("DLV_ITEM");

      Then.onTheIDocSection.iShouldSeeTheInputValueInTable("E1EHPAO", sFreightOrderEvent, 1);
      Then.onTheIDocSection.iShouldSeeTheInputValueInTable("E1EVMHDR02", sDelayedEvent, 1);
    });

    opaTest("Should open the event code dialog", function (Given, When, Then) {
      When.onTheIDocSection.iSelectEventInTable(sDelayedEvent);
      When.onTheIDocSection.iPressTheValueHelpButtonInTable(sDelayedEvent, 2);

      Then.onTheIDocSection.iShouldSeeTheValueHelp(/(.*)idocEventCodeValueHelpDialog--dialog-dialog/);
      Then.onTheIDocSection.iShouldSeeTheValueHelpHasItems(
        /(.*)idocEventCodeValueHelpDialog--dialog-list/,
        6
      );
    });

    opaTest("Should select an event code - picking", function (Given, When, Then) {
      When.onTheIDocSection.iSelectValueHelpItem("Picking");

      Then.onTheIDocSection.iShouldSeeTheTrackedProcessSelect();
    });

    opaTest("Should open a segment value help for picking event code", function (
      Given,
      When,
      Then
    ) {
      When.onTheIDocSection.iPressTheValueHelpButtonInTreeTable("uuidField", 1, false);

      Then.onTheIDocSection.iShouldSeeTheValueHelp(/(.*)idocSegmentValueHelpDialog-dialog/);
      Then.onTheIDocSection.iShouldSeeTheValueHelpHasItems(
        /(.*)idocSegmentValueHelpDialog-list/,
        1
      );
    });

    opaTest("Should select E1EVMPAR segment for picking event code", function (Given, When, Then) {
      When.onTheIDocSection.iSelectValueHelpItem("E1EVMPAR");

      Then.onTheIDocSection.iShouldSeeTheTrackedProcessSelect();
    });

    opaTest("Should open a field value help for picking event code", function (Given, When, Then) {
      When.onTheIDocSection.iPressTheValueHelpButtonInTreeTable("uuidField", 2, false);

      Then.onTheIDocSection.iShouldSeeTheValueHelp(/(.*)idocFieldsValueHelpDialog-dialog/);
      Then.onTheIDocSection.iShouldSeeTheValueHelpHasItems(
        /(.*)idocFieldsValueHelpDialog-list/,
        1
      );
    });

    opaTest("Should select QUANTITY idoc field for picking event code", function (Given, When, Then) {
      When.onTheIDocSection.iSelectValueHelpItem("QUANTITY");

      Then.onTheIDocSection.iShouldSeeTheTrackedProcessSelect();
    });

    opaTest("Should create a new tracked process and select in iDoc Integration", function (
      Given,
      When,
      Then
    ) {
      Given.iSetupDialog("editProcessTypeDialog");
      When.onTheModelDetailPage.iSelectTheSection("trackedProcessSection");
      When.onTheProcessTypeSection.iPressTheCreateButton("createButton");
      When.onTheEditDialog.iInputTextInDialog("name", "ShipmentOrder");
      When.onTheEditDialog.iInputTextInDialog("trackingIdType", "shipment");
      When.onTheEditDialog.iPressTheAcceptButton();
      When.onTheModelDetailPage.iSelectTheSection("iDocSection");
      When.onTheIDocSection.iSelectDropDown("processTypeSelect", "ShipmentOrder");
      When.onTheIDocSection.iSelectIntegrationSwitch(true);

      Then.onTheIDocSection.theEventTableShouldHaveItems(1);
      Then.onTheIDocSection.theFieldTableShouldHaveItems(0);
    });

    opaTest("last test case", function (Given, When, Then) {
      // Assertions
      Then.onTheIDocSection.iShouldSeeTheTrackedProcessSelect();

      // Cleanup
      Then.iTeardownMyApp();
    });
  }
);
