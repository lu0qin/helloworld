sap.ui.define(
  [
    "sap/ui/test/Opa5",
    "./ObjectPageSection",
    "./Dialog",
    "sap/ui/test/actions/Press",
    "sap/ui/test/matchers/AggregationContainsPropertyEqual",
    "sap/ui/test/matchers/AggregationLengthEquals",
    "sap/ui/test/matchers/Ancestor",
    "sap/ui/test/matchers/Descendant",
    "sap/ui/test/matchers/I18NText",
    "sap/ui/test/matchers/LabelFor",
    "sap/ui/test/matchers/Properties",
    "sap/ui/test/matchers/PropertyStrictEquals",
    "sap/base/strings/formatMessage",
    "sap/base/util/merge",
  ],
  function (
    Opa5,
    ObjectPageSection,
    Dialog,
    Press,
    AggregationContainsPropertyEqual,
    AggregationLengthEquals,
    Ancestor,
    Descendant,
    I18NText,
    LabelFor,
    Properties,
    PropertyStrictEquals,
    formatMessage,
    merge
  ) {
    "use strict";

    Opa5.createPageObjects({
      onTheVPIntegrationPage: {
        baseClass: ObjectPageSection,
        viewName: "VPIntegration",
        actions: {
          iSelectIntegrationSwitch: function (bState) {
            return this.iSelectSwitch("switch", bState);
          },
          iSelectTrackingIndicator: function (sId, sKey) {
            return this.iSelectDropDown(sId, sKey);
          },
          iSelectFromValueHelpInTreeTable: function (
            sId,
            sFragmentId,
            sItemName,
            bIsCompositionElement
          ) {
            return this.waitFor({
              fragmentId: sFragmentId,
              id: sId,
              success: function (oTreeTable) {
                oTreeTable.expandToLevel(2);

                var aRows = oTreeTable.getRows();
                var sPropertyName = oTreeTable.getModel("view").getProperty("/isProcessTypeEvent") ? "trackingField" : "_ref/field/name";

                var oItem = aRows.find(function (row) {
                  if (bIsCompositionElement) {
                    return (
                      row.getLevel() === 2 &&
                      row.getBindingContext("view").getProperty(sPropertyName) === sItemName
                    );
                  } else {
                    return (
                      row.getLevel() === 1 &&
                      row.getBindingContext("view").getProperty(sPropertyName) === sItemName
                    );
                  }
                });
                var oCell = oItem.getCells()[1];
                if (oCell.getVisible()) {
                  oCell.fireValueHelpRequest();
                }
              },
              errorMessage: formatMessage(
                "Was not able to open value help dialog of {0}.",
                sItemName
              ),
            });
          },
          iPressCancelButton: function () {
            return this.waitFor({
              controlType: "sap.m.Button",
              searchOpenDialogs: true,
              matchers: [
                new PropertyStrictEquals({
                  name: "text",
                  value: "Cancel",
                }),
              ],
              actions: new Press(),
              errorMessage: "Cannot press Cancel button",
            });
          },
        },
        assertions: {
          iShouldSeeTheTrackedProcessSelect: function () {
            return this.iShouldSeeTheControl("processTypeSelect");
          },
          iShouldSeeTheTrackingIndicatorText: function () {
            return this.iShouldSeeTheControl("trackingIndicatorDisplay");
          },
          iShouldSeeTheTrackingIndicatorSelect: function () {
            return this.iShouldSeeTheControl("trackingIndicatorEdit");
          },
          iShouldSeeTheDynamicSideContent: function () {
            return this.iShouldSeeTheControl("DynamicSideContent");
          },
          iShouldSeeTheEventTable: function () {
            return this.iShouldSeeTheControl("eventTable--table");
          },
          iShouldSeeTheEventTableHasItems: function (count) {
            return this.theListShouldHaveItems("eventTable--table", count);
          },
          iShouldSeeTheProcessTypeTable: function () {
            return this.iShouldSeeTheControl("userProcessTypeFragment--processTypeTable");
          },
          iShouldSeeUpstreamProcessType: function () {
            return this.iShouldSeeTheControl("upstreamProcessTypeEdit");
          },
          iShouldSeeTheOutboundValueHelp: function () {
            var valueHelpId = /(.*)outboundValueHelpDialog--dialog-list/;
            return this.iShouldSeeTheControl(valueHelpId);
          },
          iShouldSeeTheInboundValueHelp: function () {
            var valueHelpId = /(.*)vpInboundFieldValueHelpDialog-list/;
            return this.iShouldSeeTheControl(valueHelpId);
          },
          iShouldSeeTheInputValueInTreeTable: function (
            sId,
            sFragmentId,
            sValue,
            sItemName,
            iCellIndex,
            bIsCompositionElement
          ) {
            return this.waitFor({
              id: sId,
              fragmentId: sFragmentId,
              success: function (oTable) {
                oTable.expandToLevel(2);

                var bIsProcessType = oTable.getModel("view").getProperty("/isProcessTypeEvent");
                var sPropertyName = bIsProcessType ? "trackingField" : "_ref/field/name";

                var oItem = oTable.getRows().find(function (row) {
                  if (bIsCompositionElement) {
                    return (
                      row.getLevel() === 2 &&
                      row.getBindingContext("view").getProperty(sPropertyName) === sItemName
                    );
                  } else {
                    return (
                      row.getLevel() === 1 &&
                      row.getBindingContext("view").getProperty(sPropertyName) === sItemName
                    );
                  }
                });

                var oCell = oItem.getCells()[iCellIndex];

                Opa5.assert.equal(
                  oCell.getValue(),
                  sValue,
                  formatMessage("The input has value: {0}", sValue)
                );
              },
              errorMessage: formatMessage("The text {0} doesn't match with the input value.", sValue),
            });
          },
        },
      },
    });
  }
);
