sap.ui.define(
  [
    "sap/ui/test/Opa5",
    "./Common",
    "./Dialog",
    "sap/ui/test/actions/EnterText",
    "sap/ui/test/matchers/Ancestor",
    "sap/ui/test/matchers/PropertyStrictEquals",
    "sap/m/ListMode",
  ],
  function (Opa5, Common, Dialog, EnterText, Ancestor, PropertyStrictEquals, ListMode) {
    "use strict";

    Opa5.createPageObjects({
      onTheProcessTypeCoreFieldsView: {
        baseClass: Common,
        viewName: "ProcessTypeCoreFields",
        actions: {

        },
        assertions: {
          iShouldSeeTheTable: function () {
            return this.iShouldSeeTheControl("table");
          },
          iShouldSeeTheTableInReadMode: function () {
            return this.waitFor({
              id: "table",
              matchers: [
                new PropertyStrictEquals({
                  name: "mode",
                  value: ListMode.None,
                }),
              ],
              success: function (oTable) {
                Opa5.assert.ok(true, "The Process Type Core Model Fields View is in read mode");
              },
              errorMessage: "Cannot find the Process Type Core Model Fields View in read mode",
            });
          },
          iShouldSeeTheTableHasItems: function (count) {
            return this.theListShouldHaveItems("table", count);
          },
        },
      },
    });
  }
);
