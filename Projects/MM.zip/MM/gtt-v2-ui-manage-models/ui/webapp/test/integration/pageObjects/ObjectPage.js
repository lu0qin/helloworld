sap.ui.define(
  [
    "sap/ui/test/Opa5",
    "./Common",
    "sap/ui/test/actions/Press",
    "sap/ui/test/matchers/AggregationLengthEquals",
    "sap/ui/test/matchers/Ancestor",
    "sap/ui/test/matchers/I18NText",
    "sap/ui/test/matchers/Properties",
    "sap/base/strings/formatMessage",
  ],
  function (
    Opa5,
    Common,
    Press,
    AggregationLengthEquals,
    Ancestor,
    I18NText,
    Properties,
    formatMessage
  ) {
    "use strict";

    return Common.extend("com.sap.gtt.v2.model.manage.test.integration.pageObjects.ObjectPage", {
      iSelectTheSection: function (sSectionId) {
        return this.waitFor({
          id: "objectPageLayout",
          success: function (objectPage) {
            var view = objectPage.getParent();
            var section = view.byId(sSectionId);
            var sectionTitle = section.getTitle();

            return this.iPressTheAnchor(sectionTitle);
          },
        });
      },

      iPressTheAnchor: function (sText) {
        return this.waitFor({
          controlType: "sap.uxap.AnchorBar",
          success: function (oAnchorBar) {
            return this.waitFor({
              controlType: "sap.m.Button",
              matchers: [new Ancestor(oAnchorBar[0], true), new Properties({ text: sText })],
              actions: new Press(),
              errorMessage: formatMessage("Cannot press the anchor {0}", sText),
            });
          },
          errorMessage: "cannot find AnchorBar",
        });
      },

      iSelectTheViewMenu: function (sKey) {
        return this.iSelectMenuButton("viewButton", sKey);
      },

      iShouldSeeThePage: function () {
        return this.iShouldSeeTheControl("objectPageLayout");
      },

      theTitleShouldDisplayTheName: function (sName) {
        return this.iShouldSeeTheText("headingTitle", sName);
      },

      iShouldSeeTheSelectedSection: function (sSectionId) {
        return this.waitFor({
          id: "objectPageLayout",
          success: function (objectPage) {
            var view = objectPage.getParent();
            Opa5.assert.strictEqual(
              objectPage.getSelectedSection(),
              view.createId(sSectionId),
              formatMessage("The section {0} is selected", sSectionId)
            );
          },
        });
      },
    });
  }
);
