sap.ui.define(
  [
    "sap/ui/test/Opa5",
    "sap/ui/test/actions/Press",
    "sap/ui/test/matchers/AggregationLengthEquals",
    "sap/ui/test/matchers/BindingPath",
    "sap/ui/test/matchers/I18NText",
    "sap/ui/test/matchers/Properties",
    "sap/base/strings/formatMessage",
    "./Common",
    "./Dialog",
  ],
  function (
    Opa5,
    Press,
    AggregationLengthEquals,
    BindingPath,
    I18NText,
    Properties,
    formatMessage,
    Common,
    Dialog
  ) {
    "use strict";

    Opa5.createPageObjects({
      onTheModelListPage: {
        baseClass: Common,
        viewName: "ModelList",
        actions: {
          iPressOnTheImportButton: function () {
            return this.iPressTheButton("importButton");
          },
          iPressOnTheExportButton: function () {
            return this.iPressTheButton("exportButton");
          },
          iPressOnTheCreateButton: function () {
            return this.iPressTheButton("createButton");
          },
          iPressOnTheItemWithTheName: function (name) {
            return this.waitFor({
              controlType: "sap.f.GridListItem",
              matchers: [
                function (oCandidateListItem) {
                  var modelName = "view";
                  var item = oCandidateListItem.getBindingContext(modelName).getObject();

                  // Iterate through the list items until the specified cell is found
                  return item.name === name;
                },
              ],
              actions: new Press(),
              errorMessage: formatMessage("No list item with the name {0} was found.", name),
            });
          },
          iSelectItem: function () {
            return this.waitFor({
              controlType: "sap.m.RadioButton",
              actions: new Press(),
            });
          },
        },
        assertions: {
          theButtonShouldHaveADifferentText: function () {
            return this.iShouldSeeTheText("pressMeButton", "clicked");
          },

          iShouldSeeThePage: function () {
            return this.iShouldSeeTheControl("page");
          },

          iShouldSeeTheList: function () {
            return this.iShouldSeeTheControl("gridList");
          },

          theTitleShouldDisplayTheTotalAmountOfItems: function () {
            return this.waitFor({
              id: "tableHeader",
              matchers: new I18NText({
                key: "worklistTableTitleCount",
                propertyName: "text",
                parameters: [23],
              }),
              success: function () {
                Opa5.assert.ok(true, "The table header has 23 items");
              },
              errorMessage: "The table header does not contain the number of items: 23",
            });
          },
        },
      },

      onTheImportExportModelDialog: {
        baseClass: Dialog,
        actions: {},
        assertions: {
          iShouldSeeTheDialog: function () {
            var sId = this.getId("dialog");
            return this.iShouldSeeTheControl(sId);
          },
        },
      },
    });
  }
);
