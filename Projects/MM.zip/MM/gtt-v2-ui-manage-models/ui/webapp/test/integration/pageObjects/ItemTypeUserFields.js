sap.ui.define(["sap/ui/test/Opa5", "./Common", "./Dialog"], function (Opa5, Common, Dialog) {
  "use strict";

  Opa5.createPageObjects({
    onTheItemTypeUserFieldsView: {
      baseClass: Common,
      viewName: "ItemTypeUserFields",
      actions: {
        iPressTheCreateButton: function () {
          return this.iPressTheButton("createButton");
        },
        iPressTheEditButton: function () {
          return this.iPressTheButton("editButton");
        },
        iPressTheDeleteButton: function () {
          return this.iPressTheButton("deleteButton");
        },
      },
      assertions: {
        iShouldSeeTheTable: function () {
          return this.iShouldSeeTheControl("table");
        },
        iShouldSeeTheTableHasItems: function (count) {
          return this.theListShouldHaveItems("table", count);
        },
      },
    },

    onTheUserFieldsDialog: {
      baseClass: Dialog,
      actions: {},
      assertions: {
        iShouldSeeTheForm: function () {
          var sId = this.getId("form");
          return this.iShouldSeeTheControl(sId);
        },
      },
    },
  });
});
