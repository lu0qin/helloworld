sap.ui.define(
  ["sap/ui/test/Opa5", "com/sap/gtt/v2/model/manage/localService/mockserver"],
  function (Opa5, mockserver) {
    "use strict";

    return Opa5.extend("com.sap.gtt.v2.model.manage.test.integration.arrangements.Startup", {
      /**
       * Initializes mock server, then starts the app component
       * @param {object} oOptionsParameter An object that contains the configuration for starting up the app
       * @param {int} oOptionsParameter.delay A custom delay to start the app with
       * @param {string} [oOptionsParameter.hash] The in app hash can also be passed separately for better readability in tests
       * @param {boolean} [oOptionsParameter.autoWait=true] Automatically wait for pending requests while the application is starting up.
       * @returns {Opa5} The Opa5 instance
       */
      iStartMyApp: function (oOptionsParameter) {
        var oOptions = oOptionsParameter || {};
        oOptions.componentName = "com.sap.gtt.v2.model.manage";

        this._clearSharedData();

        // start the app with a minimal delay to make tests fast but still async to discover basic timing issues
        oOptions.delay = oOptions.delay || 1;

        // configure mock server with the current options
        var oMockserverInitialized = mockserver.init(oOptions);

        this.iWaitForPromise(oMockserverInitialized);

        // start the app UI component
        return this.iStartMyUIComponent({
          componentConfig: {
            name: oOptions.componentName,
            async: true,
          },
          hash: oOptions.hash,
          autoWait: true,
        });
      },

      iSetupDialog: function (sFragmentId) {
        this.getContext().fragmentId = sFragmentId;
      },

      iTeardownDialog: function () {
        var context = this.getContext();
        delete context.fragmentId;
      },

      _clearSharedData: function () {
        // clear shared metadata in ODataModel to allow tests for loading the metadata
        // ODataModel.mSharedData = { server: {}, service: {}, meta: {} };
      },
    });
  }
);
