sap.ui.define(
  [
    "sap/ui/test/opaQunit",
    "./pageObjects/Browser",
    "./pageObjects/ModelList",
    "./pageObjects/ModelDetail",
    "./pageObjects/ProcessType",
    "./pageObjects/VPIntegration",
  ],
  function (opaTest) {
    QUnit.module("VPIntegration");
    opaTest("Should see the VP Integration section", function (Given, When, Then) {
      // Arrangements
      Given.iStartMyApp();

      // Actions
      var name = "tfo";
      When.onTheModelListPage.iPressOnTheItemWithTheName(name);

      var sectionId = "vpIntegrationSection";
      When.onTheModelDetailPage.iSelectTheSection(sectionId);

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection(sectionId);
      Then.onTheVPIntegrationPage.iShouldSeeTheTrackedProcessSelect();
      Then.onTheVPIntegrationPage.iShouldSeeTheTrackingIndicatorText();
      Then.onTheVPIntegrationPage.iShouldSeeTheDynamicSideContent();
      Then.onTheVPIntegrationPage.iShouldSeeTheEventTable();
      Then.onTheVPIntegrationPage.iShouldSeeTheProcessTypeTable();
      Then.onTheVPIntegrationPage.iShouldSeeTheEventTableHasItems(2);
    });

    opaTest("Should see the process type table", function (Given, When, Then) {
      // Actions
      When.onTheVPIntegrationPage.iSelectRowInTable("eventTable--table", 0);

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheProcessTypeTable();
    });

    opaTest("Should switch the integration switch", function (Given, When, Then) {
      // Actions
      When.onTheModelDetailPage.iPressTheButton("editButton");
      When.onTheVPIntegrationPage.iSelectIntegrationSwitch(false);

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheTrackedProcessSelect();
    });

    opaTest("Should see the trackingIndicator select", function (Given, When, Then) {
      // Actions
      When.onTheVPIntegrationPage.iSelectIntegrationSwitch(true);

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheTrackingIndicatorSelect();
    });

    opaTest("Should select trackingIndicator to 02 - Resource Tracking", function (
      Given,
      When,
      Then
    ) {
      // Actions
      When.onTheVPIntegrationPage.iSelectTrackingIndicator("trackingIndicatorEdit", "02");

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeUpstreamProcessType();
    });

    opaTest("Should select trackingIndicator to 01 - Shipment Tracking", function (
      Given,
      When,
      Then
    ) {
      // Actions
      When.onTheVPIntegrationPage.iSelectTrackingIndicator("trackingIndicatorEdit", "01");

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheTrackedProcessSelect();
    });

    /* process type*/
    opaTest("Should open process type simple type value help", function (Given, When, Then) {
      // Actions
      When.onTheVPIntegrationPage.iSelectFromValueHelpInTreeTable(
        "processTypeTable",
        "userProcessTypeFragment",
        "carrierLBNID",
        false
      );

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheOutboundValueHelp();
    });

    opaTest("Should select item in process type simple type value help", function (
      Given,
      When,
      Then
    ) {
      // Actions
      When.onTheVPIntegrationPage.iSelectValueHelpItem("stringField");

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheInputValueInTreeTable(
        "processTypeTable",
        "userProcessTypeFragment",
        "stringField",
        "carrierLBNID",
        1,
        false
      );
    });

    opaTest("Should cancel process type simple type value help", function (Given, When, Then) {
      // Actions
      When.onTheVPIntegrationPage.iSelectFromValueHelpInTreeTable(
        "processTypeTable",
        "userProcessTypeFragment",
        "carrierLBNID",
        false
      );
      When.onTheVPIntegrationPage.iPressCancelButton();

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheInputValueInTreeTable(
        "processTypeTable",
        "userProcessTypeFragment",
        "stringField",
        "carrierLBNID",
        1,
        false
      );
    });

    opaTest("Should open process type composition type value help", function (Given, When, Then) {
      // Actions
      When.onTheVPIntegrationPage.iSelectFromValueHelpInTreeTable(
        "processTypeTable",
        "userProcessTypeFragment",
        "shippingType",
        false
      );

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheOutboundValueHelp();
    });

    opaTest("Should select item in process type composition type value help", function (
      Given,
      When,
      Then
    ) {
      // Actions
      When.onTheVPIntegrationPage.iSelectValueHelpItem("compositionField");

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheInputValueInTreeTable(
        "processTypeTable",
        "userProcessTypeFragment",
        "compositionField",
        "shippingType",
        1,
        false
      );
    });

    opaTest("Should cancel process type composition type value help", function (Given, When, Then) {
      // Actions
      When.onTheVPIntegrationPage.iSelectFromValueHelpInTreeTable(
        "processTypeTable",
        "userProcessTypeFragment",
        "shippingType",
        false
      );
      When.onTheVPIntegrationPage.iPressCancelButton();

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheInputValueInTreeTable(
        "processTypeTable",
        "userProcessTypeFragment",
        "compositionField",
        "shippingType",
        1,
        false
      );
    });

    opaTest("Should open process type child of composition type value help", function (
      Given,
      When,
      Then
    ) {
      // Actions
      When.onTheVPIntegrationPage.iSelectFromValueHelpInTreeTable(
        "processTypeTable",
        "userProcessTypeFragment",
        "stopID",
        true
      );

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheOutboundValueHelp();
    });

    opaTest("Should select item in process type child of composition type value help", function (
      Given,
      When,
      Then
    ) {
      // Actions
      When.onTheVPIntegrationPage.iSelectValueHelpItem("stringField");

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheInputValueInTreeTable(
        "processTypeTable",
        "userProcessTypeFragment",
        "stringField",
        "stopID",
        1,
        true
      );
    });

    opaTest("Should cancel process type child of composition type value help", function (
      Given,
      When,
      Then
    ) {
      // Actions
      When.onTheVPIntegrationPage.iSelectFromValueHelpInTreeTable(
        "processTypeTable",
        "userProcessTypeFragment",
        "stopID",
        true
      );
      When.onTheVPIntegrationPage.iPressCancelButton();

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheInputValueInTreeTable(
        "processTypeTable",
        "userProcessTypeFragment",
        "stringField",
        "stopID",
        1,
        true
      );
    });

    opaTest("Should open lbn event type value help", function (Given, When, Then) {
      var lbnId = /(.*)eventTable--table-1-vhi/;
      When.onTheVPIntegrationPage.iPressTheButton(lbnId);
      When.onTheVPIntegrationPage.iPressCancelButton();

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheTrackedProcessSelect();
    });

    /* event type*/
    opaTest("Should open event type simple type value help", function (Given, When, Then) {
      // Actions
      When.onTheVPIntegrationPage.iSelectRowInTable("eventTable--table", 1);
      When.onTheVPIntegrationPage.iSelectFromValueHelpInTreeTable(
        "eventTypeTable",
        "userEventTypeFragment",
        "stringField",
        false
      );

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheInboundValueHelp();
    });

    opaTest("Should select item in event type simple type value help", function (
      Given,
      When,
      Then
    ) {
      // Actions
      When.onTheVPIntegrationPage.iSelectValueHelpItemByDescription("orderId");

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheInputValueInTreeTable(
        "eventTypeTable",
        "userEventTypeFragment",
        "Order Id-label",
        "stringField",
        1,
        false
      );
    });

    opaTest("Should cancel event type simple type value help", function (Given, When, Then) {
      // Actions
      When.onTheVPIntegrationPage.iSelectFromValueHelpInTreeTable(
        "eventTypeTable",
        "userEventTypeFragment",
        "stringField",
        false
      );
      When.onTheVPIntegrationPage.iPressCancelButton();

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheInputValueInTreeTable(
        "eventTypeTable",
        "userEventTypeFragment",
        "Order Id-label",
        "stringField",
        1,
        false
      );
    });

    opaTest("Should open event type composition type value help", function (Given, When, Then) {
      // Actions
      When.onTheVPIntegrationPage.iSelectFromValueHelpInTreeTable(
        "eventTypeTable",
        "userEventTypeFragment",
        "compositionField",
        false
      );

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheInboundValueHelp();
    });

    opaTest("Should select item in event type composition type value help", function (
      Given,
      When,
      Then
    ) {
      // Actions
      When.onTheVPIntegrationPage.iSelectValueHelpItemByDescription("shippingType");

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheInputValueInTreeTable(
        "eventTypeTable",
        "userEventTypeFragment",
        "Shipping Type-label",
        "compositionField",
        1,
        false
      );
    });

    opaTest("Should cancel event type composition type value help", function (Given, When, Then) {
      // Actions
      When.onTheVPIntegrationPage.iSelectFromValueHelpInTreeTable(
        "eventTypeTable",
        "userEventTypeFragment",
        "compositionField",
        false
      );
      When.onTheVPIntegrationPage.iPressCancelButton();

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheInputValueInTreeTable(
        "eventTypeTable",
        "userEventTypeFragment",
        "Shipping Type-label",
        "compositionField",
        1,
        false
      );
    });

    opaTest("Should open event type child of composition type value help", function (
      Given,
      When,
      Then
    ) {
      // Actions
      When.onTheVPIntegrationPage.iSelectFromValueHelpInTreeTable(
        "eventTypeTable",
        "userEventTypeFragment",
        "stringField",
        true
      );

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheInboundValueHelp();
    });

    opaTest("Should select item in event type child of composition type value help", function (
      Given,
      When,
      Then
    ) {
      // Actions
      When.onTheVPIntegrationPage.iSelectValueHelpItemByDescription("stopID");

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheInputValueInTreeTable(
        "eventTypeTable",
        "userEventTypeFragment",
        "stop id-label",
        "stringField",
        1,
        true
      );
    });

    opaTest("Should cancel event type child of composition type value help", function (
      Given,
      When,
      Then
    ) {
      // Actions
      When.onTheVPIntegrationPage.iSelectFromValueHelpInTreeTable(
        "eventTypeTable",
        "userEventTypeFragment",
        "stringField",
        true
      );
      When.onTheVPIntegrationPage.iPressCancelButton();

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheInputValueInTreeTable(
        "eventTypeTable",
        "userEventTypeFragment",
        "stop id-label",
        "stringField",
        1,
        true
      );
    });

    opaTest("Should create a new tracked process and go to vp page", function (Given, When, Then) {
      Given.iSetupDialog("editProcessTypeDialog");
      // Actions
      var sectionId = "trackedProcessSection";
      When.onTheModelDetailPage.iSelectTheSection(sectionId);
      When.onTheProcessTypeSection.iPressTheCreateButton("createButton");
      When.onTheEditDialog.iInputTextInDialog("name", "ShipmentOrder");
      When.onTheEditDialog.iInputTextInDialog("trackingIdType", "shipment");
      When.onTheEditDialog.iPressTheAcceptButton();
      When.onTheModelDetailPage.iSelectTheSection("vpIntegrationSection");
      When.onTheVPIntegrationPage.iSelectDropDown("processTypeSelect", "ShipmentOrder");

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheTrackedProcessSelect();
    });

    opaTest("Should switch on the shipment switch", function (Given, When, Then) {
      // Actions
      When.onTheVPIntegrationPage.iSelectIntegrationSwitch(true);

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheTrackedProcessSelect();
    });

    opaTest("Should select trackingIndicator to 02 - Resource Tracking", function (
      Given,
      When,
      Then
    ) {
      // Actions
      When.onTheVPIntegrationPage.iSelectTrackingIndicator("trackingIndicatorEdit", "02");

      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeUpstreamProcessType();
    });

    opaTest("last test case", function (Given, When, Then) {
      // Assertions
      Then.onTheVPIntegrationPage.iShouldSeeTheTrackedProcessSelect();

      // Cleanup
      Then.iTeardownMyApp();
    });
  }
);
