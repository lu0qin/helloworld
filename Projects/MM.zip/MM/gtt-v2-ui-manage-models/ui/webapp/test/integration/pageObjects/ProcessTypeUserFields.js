sap.ui.define(
  [
    "sap/ui/test/Opa5",
    "./Common",
    "./Dialog",
    "sap/ui/test/actions/Press",
    "sap/ui/test/matchers/Ancestor",
    "sap/ui/test/matchers/PropertyStrictEquals",
    "sap/m/ListMode",
  ],
  function (Opa5, Common, Dialog, Press, Ancestor, PropertyStrictEquals, ListMode) {
    "use strict";

    Opa5.createPageObjects({
      onTheProcessTypeUserFieldsView: {
        baseClass: Common,
        viewName: "ProcessTypeUserFields",
        actions: {
          iPressTheCreateButton: function () {
            return this.iPressTheButton("createButton");
          },
          iPressTheEditButton: function () {
            return this.iPressTheButton("editButton");
          },
          iPressTheDeleteButton: function () {
            return this.iPressTheButton("deleteButton");
          },
          iPressTheTranslateButton: function () {
            return this.iPressTheButton("translateButton");
          },
        },
        assertions: {
          iShouldSeeTheTable: function () {
            return this.iShouldSeeTheControl("table");
          },
          iShouldSeeTheTableInEditMode: function () {
            return this.getListInMode("table", ListMode.MultiSelect);
          },
          iShouldSeeTheTableInReadMode: function () {
            return this.waitFor({
              id: "table",
              matchers: [
                new PropertyStrictEquals({
                  name: "mode",
                  value: ListMode.MultiSelect,
                }),
              ],
              success: function (oTable) {
                Opa5.assert.ok(true, "The Process User Fields View is in read mode");
              },
              errorMessage: "Cannot find the Process User Fields View in read mode",
            });
          },
          iShouldSeeTheTableHasItems: function (count) {
            return this.theListShouldHaveItems("table", count);
          },
        },
      },
    });
  }
);
