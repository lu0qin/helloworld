sap.ui.define(
  [
    "sap/ui/test/Opa5",
    "sap/ui/test/matchers/Properties",
    "sap/ui/test/actions/Press",
    "sap/ui/core/Fragment",
    "./Common",
    "./Dialog",
  ],
  function (Opa5, Properties, Press, Fragment, Common, Dialog) {
    "use strict";

    var DETAIL_FRAG_ID = "detailFragment";
    var PLANNED_EVENT_MATCH_FRAG_ID = "plannedEventMatchFragment";
    var ACTUAL_EVENT_MATCH_FRAG_ID = "actualEventMatchFragment";

    Opa5.createPageObjects({
      onThePlannedEventUserDetailView: {
        baseClass: Common,
        viewName: "PlannedEventUserDetail",
        actions: {
          iPressTheAddButton: function () {
            return this.iPressTheButton("addButton");
          },
          iPressTheEditButton: function () {
            return this.iPressTheButton("editButton");
          },
          iPressTheDeleteButton: function () {
            return this.iPressTheButton("deleteButton");
          },
        },
        assertions: {
          iShouldSeeTheTable: function () {
            return this.iShouldSeeTheControl("table");
          },
          iShouldSeeTheTableHasItems: function (count) {
            return this.theListShouldHaveItems("table", count);
          },
        },
      },
      onTheEditPlannedEventDialog: {
        baseClass: Dialog,
        actions: {
          iSelectTheTab: function (sTabKey) {
            return this.waitFor({
              controlType: "sap.m.IconTabFilter",
              matchers: [new Properties({ key: sTabKey })],
              actions: new Press(),
            });
          },
          iPressTheAddExtensionButton: function () {
            return this.waitFor({
              controlType: "sap.ui.layout.HorizontalLayout",
              searchOpenDialogs: true,
              success: function (oLayouts) {
                var firstLayout = oLayouts[0];
                var addButton = firstLayout.getContent()[1];
                addButton.firePress();
              },
              errorMessage: "Did not find the add button",
            });
          },
          iSelectPlannedEventField: function (sField) {
            return this.waitFor({
              controlType: "sap.m.CustomListItem",
              searchOpenDialogs: true,
              success: function (aCustomListItems) {
                var extensionHBox = aCustomListItems[0];
                var plannedEventSelect = extensionHBox.getContent()[0];
                plannedEventSelect.setSelectedKey(sField);
                var selectedItem = plannedEventSelect.getSelectedItem();
                plannedEventSelect.fireChange({ selectedItem: selectedItem });

                var actualEventSelect = extensionHBox.getContent()[2];
                actualEventSelect.setSelectedKey(sField);
                selectedItem = actualEventSelect.getSelectedItem();
                actualEventSelect.fireChange({ selectedItem: selectedItem });
              },
            });
          },
          iPressTheRemoveExtensionButton: function () {
            return this.waitFor({
              controlType: "sap.ui.layout.HorizontalLayout",
              searchOpenDialogs: true,
              success: function (oLayouts) {
                var lastLayout = oLayouts[1];
                var removeButton = lastLayout.getContent()[0];
                removeButton.firePress();
              },
              errorMessage: "Did not find the remove button",
            });
          },
          iInputTextInPlannedEventDialog: function (sId, sValue) {
            var sControlId = Fragment.createId(DETAIL_FRAG_ID, sId);
            return this.iInputTextInDialog(sControlId, sValue);
          },
          iSelectEventTypeDropDownInPlannedEventDialog: function (sValue) {
            var sControlId = Fragment.createId(DETAIL_FRAG_ID, "name");
            return this.iSelectDropDownInDialog(sControlId, sValue);
          },
        },
        assertions: {
          // general functions to generate control Ids for frags in EditPlannedEventDialog
          iShouldSeeTheControlInPlannedEventDialog: function (sFragmentId, sId) {
            var sControlId = this.getId(Fragment.createId(sFragmentId, sId));
            return this.iShouldSeeTheControl(sControlId);
          },
          theListShouldHaveItemsInPlannedEventDialog: function (sFragmentId, sId, count) {
            var sControlId = this.getId(Fragment.createId(sFragmentId, sId));
            return this.theListShouldHaveItems(sControlId, count);
          },
          iShouldSeeTheValidationErrorInPlannedEventDialog: function (sFragmentId, sId) {
            var sControlId = Fragment.createId(sFragmentId, sId);
            return this.iShouldSeeTheValidationError(sControlId);
          },


          // Specific assertions for see control
          iShouldSeeTheDetails: function () {
            return this.iShouldSeeTheControlInPlannedEventDialog(DETAIL_FRAG_ID, "detailScrollContainer");
          },
          iShouldSeeTheActualMatchSettings: function () {
            return this.iShouldSeeTheControlInPlannedEventDialog(ACTUAL_EVENT_MATCH_FRAG_ID, "actualEventMatchSettingsScrollContainer");
          },
          iShouldSeeThePlannedMatchSettings: function () {
            return this.iShouldSeeTheControlInPlannedEventDialog(PLANNED_EVENT_MATCH_FRAG_ID, "plannedEventMatchSettingsScrollContainer");
          },
          iShouldSeeTheActualMatchListHasItems: function (count) {
            return this.theListShouldHaveItemsInPlannedEventDialog(ACTUAL_EVENT_MATCH_FRAG_ID, "actualMatchList", count);
          },
          iShouldSeeThePlannedMatchListHasItems: function (count) {
            return this.theListShouldHaveItemsInPlannedEventDialog(PLANNED_EVENT_MATCH_FRAG_ID, "plannedMatchList", count);
          },
          iShouldSeeTheValidationErrorInDetailTab: function (sId) {
            return this.iShouldSeeTheValidationErrorInPlannedEventDialog(DETAIL_FRAG_ID, sId);
          },
          iShouldSeeTheValidationErrorInActualEventMatchTab: function (sId) {
            return this.iShouldSeeTheValidationErrorInPlannedEventDialog(ACTUAL_EVENT_MATCH_FRAG_ID, sId);
          },
        },
      },
    });
  }
);
