sap.ui.define(
  [
    "sap/ui/test/Opa5",
    "./Common",
    "./Dialog",
    "sap/base/strings/formatMessage",
    "sap/base/util/merge",
    "sap/ui/test/actions/Press",
    "sap/ui/test/actions/EnterText",
    "sap/ui/test/matchers/Ancestor",
    "sap/ui/test/matchers/PropertyStrictEquals",
    "sap/m/ListMode",
  ],
  function (
    Opa5,
    Common,
    Dialog,
    formatMessage,
    merge,
    Press,
    EnterText,
    Ancestor,
    PropertyStrictEquals,
    ListMode
  ) {
    "use strict";

    Opa5.createPageObjects({
      onTheUserFieldsDialog: {
        baseClass: Dialog,
        actions: {
        },
        assertions: {
          iShouldSeeTheForm: function () {
            var sId = this.getId("form");
            return this.iShouldSeeTheControl(sId);
          },
        },
      },
    });
  }
);
