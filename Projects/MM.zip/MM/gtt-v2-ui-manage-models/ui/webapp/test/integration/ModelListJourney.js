sap.ui.define(["sap/ui/test/opaQunit", "./pageObjects/ModelList"], function (opaTest) {
  QUnit.module("ModelList");

  opaTest("Should see the list", function (Given, When, Then) {
    // Arrangements
    Given.iStartMyApp();

    // Assertions
    Then.onTheModelListPage.iShouldSeeTheList();
    Then.onTheModelListPage.theListShouldHaveItems("gridList", 8);
  });

  opaTest("Should see the import dialog", function (Given, When, Then) {
    // Arrangements
    Given.iSetupDialog("importDialog");
    // Assertions
    When.onTheModelListPage.iPressOnTheImportButton();
    Then.onTheImportExportModelDialog.iShouldSeeTheDialog();
  });

  opaTest("Should close the import dialog", function (Given, When, Then) {
    // Arrangements
    Given.iSetupDialog("importDialog");
    // Assertions
    When.onTheImportExportModelDialog.iPressTheCancelButton();
    Then.onTheModelListPage.theListShouldHaveItems("gridList", 8);
  });

  opaTest("Should see the export dialog", function (Given, When, Then) {
    // Arrangements
    Given.iSetupDialog("exportDialog");
    // Assertions
    When.onTheModelListPage.iSelectItem();
    When.onTheModelListPage.iPressOnTheExportButton();
    Then.onTheImportExportModelDialog.iShouldSeeTheDialog();
  });

  opaTest("Should close the export dialog", function (Given, When, Then) {
    // Arrangements
    Given.iSetupDialog("exportDialog");
    // Assertions
    When.onTheImportExportModelDialog.iPressTheCancelButton();
    Then.onTheModelListPage.theListShouldHaveItems("gridList", 8);
  });

  opaSkip("Should be able to search for items", function (Given, When, Then) {

    // Actions
    When.onTheModelListPage.iSearchFor("Bear");

    // Assertions
    Then.onTheModelListPage.theListShouldHaveItems("gridList", 1);
  });

  opaTest("Should select an item from the list", function (Given, When, Then) {
    // Arrangements
    Then.onTheModelListPage.iShouldSeeTheButtonEnabled("deleteButton", true);

    // Actions
    // Then.onTheModelListPage.iSelectItem();

    // Cleanup
    Then.iTeardownMyApp();
  });
});
