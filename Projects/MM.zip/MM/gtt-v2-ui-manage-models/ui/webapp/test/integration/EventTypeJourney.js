sap.ui.define(
  [
    "sap/ui/test/opaQunit",
    "./pageObjects/Browser",
    "./pageObjects/ModelList",
    "./pageObjects/ModelDetail",
    "./pageObjects/EventType",
    "./pageObjects/EventTypeUserFields",
    "./pageObjects/EventTypeCoreFields",
    "./pageObjects/TranslationDialog",
  ],
  function (opaTest) {
    QUnit.module("EventType");

    opaTest("Should see the object page section", function (Given, When, Then) {
      // Arrangements
      Given.iStartMyApp();

      // Actions
      var name = "tfo";
      When.onTheModelListPage.iPressOnTheItemWithTheName(name);

      var sectionId = "eventTypePoolSection";
      When.onTheModelDetailPage.iSelectTheSection(sectionId);

      // Assertions
      Then.onTheModelDetailPage.iShouldSeeTheSelectedSection(sectionId);
      Then.onTheEventTypeSection.iShouldSeeTheListHasItems(5);
      Then.onTheEventTypeSection.iShouldSeeTheListItemSelected("DelayedEvent");
      Then.onTheEventTypeUserFieldsView.iShouldSeeTheTableInReadMode();
      Then.onTheEventTypeCoreFieldsView.iShouldSeeTheTableInReadMode();
    });

    opaTest("Should open the create dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editEventTypeDialog");

      // Actions
      When.onTheEventTypeSection.iPressTheCreateButton();

      // Assertions
      Then.onTheEditDialog.iShouldSeeTheForm();
    });

    opaTest("Should cancel the create dialog", function (Given, When, Then) {
      // Actions
      When.onTheEditDialog.iPressTheCancelButton();

      // Assertions
      Then.onTheEventTypeSection.iShouldSeeTheList();
    });

    opaTest("Should show errors in the create dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editEventTypeDialog");

      // Actions
      When.onTheEventTypeSection.iPressTheCreateButton();
      When.onTheEditDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheEditDialog.iShouldSeeTheValidationError("processType");
      Then.onTheEditDialog.iShouldSeeTheValidationError("name");

      // Cleanup
      Then.onTheEditDialog.iPressTheCancelButton();
    });

    opaTest(
      "Should show errors in the create event type dialog while input duplicate name",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editEventTypeDialog");

        // Actions
        When.onTheEventTypeSection.iPressTheCreateButton();
        When.onTheEditDialog.iInputTextInDialog("name", "delayedEvent");
        When.onTheEditDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheEditDialog.iShouldSeeTheValidationError("name");

        // Cleanup
        Then.onTheEditDialog.iPressTheCancelButton();
      }
    );

    opaTest(
      "Should show errors in the create event type dialog while input reserved name",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editEventTypeDialog");

        // Actions
        When.onTheEventTypeSection.iPressTheCreateButton();
        When.onTheEditDialog.iInputTextInDialog("name", "processEvent");
        When.onTheEditDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheEditDialog.iShouldSeeTheValidationError("name");

        // Cleanup
        Then.onTheEditDialog.iPressTheCancelButton();
      }
    );

    opaTest(
      "Should show errors in the create event type dialog while input name starting with GTT",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editEventTypeDialog");

        // Actions
        When.onTheEventTypeSection.iPressTheCreateButton();
        When.onTheEditDialog.iInputTextInDialog("name", "gTtTest");
        When.onTheEditDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheEditDialog.iShouldSeeTheValidationError("name");

        // Cleanup
        Then.onTheEditDialog.iPressTheCancelButton();
      }
    );

    opaTest("Should submit the create dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editEventTypeDialog");

      // Actions
      When.onTheEventTypeSection.iPressTheCreateButton();
      When.onTheEditDialog.iSelectDropDownInDialog("processType", "FreightOrder");
      When.onTheEditDialog.iInputTextInDialog("name", "NewEventType");
      When.onTheEditDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheEventTypeSection.iShouldSeeTheListHasItems(6);
      Then.onTheEventTypeSection.iShouldSeeTheListItemSelected("NewEventType");
    });

    opaTest("Should open the edit dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editEventTypeDialog");

      // Actions
      When.onTheEventTypeSection.iPressTheEditButton();

      // Assertions
      Then.onTheEditDialog.iShouldSeeTheInputValueInDialog("name", "NewEventType");
    });

    opaTest(
      "Should show errors in the edit event type dialog when input duplicate name",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editEventTypeDialog");

        // Actions
        When.onTheEditDialog.iInputTextInDialog("name", "DelayedEvent");
        When.onTheEditDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheEditDialog.iShouldSeeTheValidationError("name");

        // Clean up
        Then.onTheEditDialog.iPressTheCancelButton();
      }
    );

    opaTest(
      "Should create field with name duplicate with reserved field name in GTTDelayedEvent",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editFieldDialog");

        // Actions
        // Add field with name overlapped with reserved fields other than those of Event
        When.onTheEventTypeUserFieldsView.iPressTheCreateButton();
        When.onTheUserFieldsDialog.iInputTextInDialog("name", "refPlannedEventMatchKey");
        When.onTheUserFieldsDialog.iInputTextInDialog("label", "Reserved Name in GTTDelayedEvent");
        When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "uuid");
        When.onTheUserFieldsDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheEventTypeUserFieldsView.iShouldSeeTheTableHasItems(1);
      }
    );

    opaTest(
      "Should show errors in the edit event type dialog when select GTTDelayedEvent",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editEventTypeDialog");

        // Actions
        When.onTheEventTypeSection.iPressTheEditButton();
        When.onTheEditDialog.iSelectDropDownInDialog("inherit", "CoreModel.GTTDelayedEvent");
        When.onTheEditDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheEditDialog.iShouldSeeTheValidationError("inherit");
      }
    );

    opaTest("Should close the edit dialog", function (Given, When, Then) {
      // Actions
      When.onTheEditDialog.iPressTheCancelButton();

      // Assertions
      Then.onTheEventTypeSection.iShouldSeeTheListItemSelected("NewEventType");
    });

    opaTest("Should submit the edit dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editEventTypeDialog");

      // Actions
      When.onTheEventTypeSection.iPressTheEditButton();
      When.onTheEditDialog.iInputTextInDialog("name", "NewEventType2");
      When.onTheEditDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheEventTypeSection.iShouldSeeTheListHasItems(6);
      Then.onTheEventTypeSection.iShouldSeeTheListItemSelected("NewEventType2");
    });

    opaTest("Should delete the item without reference", function (Given, When, Then) {
      // Actions
      When.onTheEventTypeSection.iPressTheDeleteButton();

      // Assertions
      Then.onTheEventTypeSection.iShouldSeeTheListHasItems(5);
      Then.onTheEventTypeSection.iShouldSeeTheListItemSelected("DelayedEvent");
    });

    opaTest("Should create Event Type inherit GTTOnTimeEvent", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editEventTypeDialog");

      // Actions
      When.onTheEventTypeSection.iPressTheCreateButton();
      When.onTheEditDialog.iSelectDropDownInDialog("processType", "FreightOrder");
      When.onTheEditDialog.iInputTextInDialog("name", "EventTypeInheritGTTOnTimeEvent");
      When.onTheEditDialog.iSelectDropDownInDialog("inherit", "CoreModel.GTTOnTimeEvent");
      When.onTheEditDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheEventTypeSection.iShouldSeeTheListHasItems(6);
      Then.onTheEventTypeSection.iShouldSeeTheListItemSelected("EventTypeInheritGTTOnTimeEvent");
    });

    opaTest(
      "Should show errors in the user field create dialog while input reserved field name",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editFieldDialog");

        // Actions
        When.onTheEventTypeUserFieldsView.iPressTheCreateButton();
        When.onTheUserFieldsDialog.iInputTextInDialog("name", "refPlannedEventType");

        // Assertions
        Then.onTheUserFieldsDialog.iShouldSeeTheValidationError("name");

        // Cleanup
        Then.onTheUserFieldsDialog.iPressTheCancelButton();
      }
    );

    opaTest("Should delete the EventTypeInheritGTTOnTimeEvent", function (Given, When, Then) {
      // Actions
      When.onTheEventTypeSection.iPressTheDeleteButton();

      // Assertions
      Then.onTheEventTypeSection.iShouldSeeTheListHasItems(5);
      Then.onTheEventTypeSection.iShouldSeeTheListItemSelected("DelayedEvent");
    });

    opaTest("Should open the translation dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("translationDialog");

      // Actions
      When.onTheEventTypeSection.iSelectListItem("list", "DelayedEvent");
      When.onTheEventTypeUserFieldsView.iPressTheTranslateButton();
      When.onTheTranslateDialog.iSelectLanguage("German");
      When.onTheTranslateDialog.iSelectLanguage("Chinese - China");

      // Assertions
      Then.onTheTranslateDialog.iShouldSeeTheTable();
      // Then.onTheTranslateDialog.iShouldSeeTheTableHasItems(2);
    });

    opaTest("Should close the translation dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("translationDialog");

      // Actions
      When.onTheTranslateDialog.iPressTheCancelButton();

      // Assertions
      Then.onTheEventTypeUserFieldsView.iShouldSeeTheTableInEditMode();
    });

    opaTest("Should open the user field create dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onTheEventTypeUserFieldsView.iPressTheCreateButton();

      // Assertions
      Then.onTheUserFieldsDialog.iShouldSeeTheForm();
    });

    opaTest("Should cancel the user field create dialog", function (Given, When, Then) {
      // Actions
      When.onTheUserFieldsDialog.iPressTheCancelButton();

      // Assertions
      Then.onTheEventTypeSection.iShouldSeeTheList();
    });

    opaTest("Should show errors in the user field create dialog", function (Given, When, Then) {
      // Arrangements
      Given.iSetupDialog("editFieldDialog");

      // Actions
      When.onTheEventTypeUserFieldsView.iPressTheCreateButton();
      When.onTheUserFieldsDialog.iPressTheAcceptButton();

      // Assertions
      Then.onTheUserFieldsDialog.iShouldSeeTheValidationError("name");

      // Cleanup
      Then.onTheUserFieldsDialog.iPressTheCancelButton();
    });

    opaTest(
      "Should submit the user field create dialog with uuid type",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editFieldDialog");

        // Actions
        When.onTheEventTypeUserFieldsView.iPressTheCreateButton();
        When.onTheUserFieldsDialog.iInputTextInDialog("name", "NewUserField");
        When.onTheUserFieldsDialog.iInputTextInDialog("label", "Label for NewUserField");
        When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "uuid");
        When.onTheUserFieldsDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheEventTypeUserFieldsView.iShouldSeeTheTableHasItems(11);
      }
    );

    opaTest(
      "Should submit the user field create dialog with String type",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editFieldDialog");

        // Actions
        When.onTheEventTypeUserFieldsView.iPressTheCreateButton();
        When.onTheUserFieldsDialog.iInputTextInDialog("name", "NewStringUserField");
        When.onTheUserFieldsDialog.iInputTextInDialog("label", "Label for NewUserField");
        When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "string");
        When.onTheUserFieldsDialog.iInputTextInDialog("length", "10");
        When.onTheUserFieldsDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheEventTypeUserFieldsView.iShouldSeeTheTableHasItems(12);
      }
    );

    opaTest(
      "Should submit the user field create dialog with Decimal type",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editFieldDialog");

        // Actions
        When.onTheEventTypeUserFieldsView.iPressTheCreateButton();
        When.onTheUserFieldsDialog.iInputTextInDialog("name", "NewDecimalUserField");
        When.onTheUserFieldsDialog.iInputTextInDialog("label", "Label for NewUserField");
        When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "decimal");
        When.onTheUserFieldsDialog.iInputTextInDialog("precision", "10");
        When.onTheUserFieldsDialog.iInputTextInDialog("scale", "1");
        When.onTheUserFieldsDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheEventTypeUserFieldsView.iShouldSeeTheTableHasItems(13);
      }
    );

    opaTest(
      "Should submit the user field create dialog with Association type",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editFieldDialog");

        // Actions
        When.onTheEventTypeUserFieldsView.iPressTheCreateButton();
        When.onTheUserFieldsDialog.iInputTextInDialog("name", "NewAssociationUserField");
        When.onTheUserFieldsDialog.iInputTextInDialog("label", "Label for NewUserField");
        When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "associationToOne");

        When.onTheUserFieldsDialog.iSelectFromValueHelpInDialog("processTypeTarget");
        Then.onTheUserFieldsDialog.iShouldSeeTheInputValueInDialog(
          "processTypeTarget",
          "FreightOrder"
        );

        When.onTheUserFieldsDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheEventTypeUserFieldsView.iShouldSeeTheTableHasItems(14);
      }
    );

    opaTest(
      "Should submit the user field create dialog with Composition type",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editFieldDialog");

        // Actions
        When.onTheEventTypeUserFieldsView.iPressTheCreateButton();
        When.onTheUserFieldsDialog.iInputTextInDialog("name", "NewCompositionUserField");
        When.onTheUserFieldsDialog.iInputTextInDialog("label", "Label for NewUserField");
        When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "composition");

        When.onTheUserFieldsDialog.iSelectFromValueHelpInDialog("itemTypeTarget");
        Then.onTheUserFieldsDialog.iShouldSeeTheInputValueInDialog(
          "itemTypeTarget",
          "FreightOrder.StopItem"
        );

        When.onTheUserFieldsDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheEventTypeUserFieldsView.iShouldSeeTheTableHasItems(15);
      }
    );

    opaTest(
      "Should submit the user field create dialog with Code List type",
      function (Given, When, Then) {
        // Arrangements
        Given.iSetupDialog("editFieldDialog");

        // Actions
        When.onTheEventTypeUserFieldsView.iPressTheCreateButton();
        When.onTheUserFieldsDialog.iInputTextInDialog("name", "NewCodeListUserField");
        When.onTheUserFieldsDialog.iInputTextInDialog("label", "Label for NewUserField");
        When.onTheUserFieldsDialog.iSelectDropDownInDialog("type", "codelist");

        When.onTheUserFieldsDialog.iSelectFromValueHelpInDialog("codeListTarget");
        Then.onTheUserFieldsDialog.iShouldSeeTheInputValueInDialog(
          "codeListTarget",
          "ShipmentStatus"
        );

        When.onTheUserFieldsDialog.iPressTheAcceptButton();

        // Assertions
        Then.onTheEventTypeUserFieldsView.iShouldSeeTheTableHasItems(16);
      }
    );

    opaTest("Should delete the item with reference", function (Given, When, Then) {
      // Actions
      When.onTheEventTypeSection.iPressTheDeleteButton();
      When.onTheEventTypeSection.iPressTheButtonInDialog("OK");

      // Assertions
      Then.onTheEventTypeSection.iShouldSeeTheListHasItems(4);
    });

    opaTest("last test case", function (Given, When, Then) {
      // Assertions
      Then.onTheEventTypeSection.iShouldSeeTheList();

      // Cleanup
      Then.iTeardownMyApp();
    });
  }
);
