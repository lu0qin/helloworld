sap.ui.define(
  [
    "./Component",
    "./util/test",
    "./controller/BaseController",
    "./controller/ModelList",
    "./controller/ModelDetail",
    "./controller/ProcessType",
    "./controller/EventToAction",
    "./controller/ModelDataValidator",
  ],
  function () {
    "use strict";
  }
);
