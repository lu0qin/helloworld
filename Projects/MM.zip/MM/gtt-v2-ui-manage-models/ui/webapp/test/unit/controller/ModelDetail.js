sap.ui.define(
  [
    "com/sap/gtt/v2/model/manage/util/AsyncUtils",
    "com/sap/gtt/v2/model/manage/util/RestClient",
    "com/sap/gtt/v2/model/manage/util/ServiceUtils",
    "sap/ui/model/resource/ResourceModel",
    "sap/ui/core/Fragment",
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "com/sap/gtt/v2/model/manage/util/ValidationHelper",
  ],
  function (
    AsyncUtils,
    RestClient,
    ServiceUtils,
    ResourceModel,
    Fragment,
    MessageBox,
    MessageToast,
    ValidationHelper
  ) {
    "use strict";

    var namespace = "com.sap.gtt.v2.model.manage";
    var controllerName = namespace.concat(".controller.ModelDetail");

    var sandbox = sinon.createSandbox();

    function stub(object, method, func) {
      if (!(method in object)) {
        object[method] = function () {};
      }

      var stubbed = sandbox.stub(object, method);

      if (typeof func === "function") {
        return stubbed.callsFake(func);
      }

      return stubbed;
    }

    QUnit.module(controllerName, {
      beforeEach: function () {
        this.controller = sap.ui.controller(controllerName);

        var fakeView = {};
        stub(fakeView, "byId");
        stub(this.controller, "getView").returns(fakeView);
      },
      afterEach: function () {
        sandbox.restore();
        this.controller.destroy();
      },
    });

    QUnit.test("onInit", function (assert) {
      var controller = this.controller;

      // Arrange
      stub(controller, "initModel");
      stub(controller, "initControls");
      stub(controller, "initRoute");
      stub(controller, "subscribeEvents");
      stub(controller, "createMessagePopover");
      // Act
      controller.onInit();

      // Assert
      assert.ok(controller.initModel.called, "initModel is called");
    });

    QUnit.test("initModel", function (assert) {
      var controller = this.controller;

      // Arrange
      var model = {};
      var fakeModel = {};
      stub(controller, "setModel");
      stub(model, "setProperty");
      stub(fakeModel, "setProperty");
      stub(controller, "getModel").returns(fakeModel);
      var fakeRoute = {};
      stub(fakeRoute, "attachRoutePatternMatched");
      stub(controller, "getRouter").returns(fakeRoute);
      var fakeEvent = {};
      stub(fakeEvent, "getParameter");
      stub(controller, "showDisplayMode");
      stub(controller, "showCreateMode");

      // Act
      controller.initModel();

      // Assert
      assert.ok(controller.setModel.called, "setProperty is called");
    });

    QUnit.test("initRoute", function (assert) {
      var controller = this.controller;

      var fakeRouter = {};
      var fakeRoute = {};
      stub(fakeRoute, "attachPatternMatched");
      stub(fakeRouter, "getRoute").returns(fakeRoute);
      stub(controller, "getRouter").returns(fakeRouter);
      stub(controller, "showDisplayMode");
      stub(controller, "showCreateMode");
      var fakeEvent = {};
      var fakeArgs = { namespace: "" };
      stub(fakeEvent, "getParameter").returns(fakeArgs);

      // Act
      controller.initRoute();

      // Assert
      assert.ok(fakeRoute.attachPatternMatched.called, "function is called");
    });

    QUnit.test("onCancelPress", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeEvent = {};
      stub(controller, "openDiscardPopover");

      // Act
      controller.onCancelPress(fakeEvent);

      // Assert
      assert.ok(controller.openDiscardPopover.called, "function is called");
    });

    QUnit.test("openDiscardPopover", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeEvent = {};
      stub(fakeEvent, "getSource");
      var fakeLoad = {};
      stub(fakeLoad, "then");
      stub(Fragment, "load").returns(fakeLoad);
      var fakeView = controller.getView();
      stub(fakeView, "addDependent");
      stub(fakeView, "getId");

      var fakePopover = {};
      stub(fakePopover, "openBy");

      // Act
      controller.openDiscardPopover(fakeEvent);

      // Assert
      var resolveFn = fakeLoad.then.firstCall.args[0];
      resolveFn(fakePopover);
      assert.ok(fakePopover.openBy.calledOnce, "The popover will open");
    });

    QUnit.test("navToModelList", function (assert) {
      var controller = this.controller;

      // Arrange
      stub(controller, "clearModel");
      var fakeRouter = {};
      stub(fakeRouter, "navTo");
      stub(controller, "getRouter").returns(fakeRouter);

      // Act
      controller.navToModelList();

      // Assert
      assert.ok(fakeRouter.navTo.called, "navTo is called");
    });

    QUnit.test("clearModel", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeModel = {};
      stub(fakeModel, "setProperty");
      stub(controller, "getModel").returns(fakeModel);
      stub(controller, "clearValidationMessage");
      stub(controller, "clearModelHeaderValidation");
      stub(controller, "clearEventToActionValidationMessage");
      stub(fakeModel, "refresh");

      // Act
      controller.clearModel();

      // Assert
      assert.ok(fakeModel.setProperty.called, "function is called");
    });

    QUnit.skip("showCreateMode", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeView = controller.getView();
      stub(controller, "getView").returns(fakeView);
      stub(fakeView, "setBusy");

      stub(controller, "clearModel");
      stub(controller, "resetViewState");

      var fakeModel = {};
      stub(controller, "getModel").returns(fakeModel);
      stub(fakeModel, "setProperty");

      var fakeSectionView = {};
      stub(controller, "byId").returns(fakeSectionView);
      stub(fakeSectionView, "setSelectedSection");

      stub(controller, "_loadCoreModel");
      stub(controller, "_loadNamespace");
      stub(controller, "_loadIDocPresets");
      stub(controller, "_loadVPPresets");

      stub(controller, "handleModelDetailRestRequest");
      stub(controller, "handleDescriptionBindingChange");

      // Act
      controller.showCreateMode();

      // Assert
      assert.ok(controller.clearModel.called, "controller.clearModel is called");
      assert.ok(controller.resetViewState.called, "controller.resetViewState is called");
      assert.ok(controller.getModel.called, "controller.getModel is called");
      assert.ok(controller.handleModelDetailRestRequest.called, "controller.handleModelDetailRestRequest is called");
      assert.ok(controller.handleDescriptionBindingChange.called, "controller.handleDescriptionBindingChange is called");
    });

    QUnit.skip("showDisplayMode", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeView = controller.getView();
      stub(fakeView, "setBusy");

      stub(controller, "clearModel");
      stub(controller, "resetViewState");

      var fakeModel = {};
      stub(controller, "getModel").returns(fakeModel);
      stub(fakeModel, "setProperty");

      stub(controller, "_loadModelDetail");
      stub(controller, "_loadIDocPresets");
      stub(controller, "_loadVPPresets");

      stub(controller, "handleModelDetailRestRequest");
      stub(controller, "handleDescriptionBindingChange");

      // Act
      controller.showDisplayMode("");

      // Assert
      assert.ok(controller.clearModel.called, "controller.clearModel is called");
      assert.ok(controller.resetViewState.called, "controller.resetViewState is called");
      assert.ok(controller.getModel.called, "controller.getModel is called");
      assert.ok(controller.handleModelDetailRestRequest.called, "controller.handleModelDetailRestRequest is called");
    });

    QUnit.test("doDeploy", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeView = controller.getView();
      stub(fakeView, "setBusy");
      var fakeContext = {};
      stub(controller, "getStoreContext").returns(fakeContext);
      stub(fakeContext, "getProperty");
      stub(controller, "_getMainServiceRequest");
      stub(controller, "handleModelDetailRestRequest");

      // Act
      controller.doDeploy();

      // Assert
      assert.ok(controller.handleModelDetailRestRequest.called, "controller.handleModelDetailRestRequest function is called");
    });

    QUnit.test("onDeployPress", function (assert) {
      var controller = this.controller;

      // Arrange
      stub(MessageBox, "confirm");
      var fakeResourceModel = {};
      stub(fakeResourceModel, "getText").returns("Deploy");
      stub(controller, "getResourceBundle").returns(fakeResourceModel);
      stub(controller, "doDeploy");
      var fakeButtonId = {};
      stub(fakeButtonId, "setVisible");
      stub(controller, "byId").returns(fakeButtonId);

      // Act
      controller.onDeployPress();

      // Assert
      var secondeArgs = MessageBox.confirm.firstCall.args[1];
      secondeArgs.onClose(MessageBox.Action.OK);
      assert.ok(controller.doDeploy.called, "function is called");
    });
  }
);
