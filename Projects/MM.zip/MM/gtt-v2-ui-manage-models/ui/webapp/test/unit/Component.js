sap.ui.define(["com/sap/gtt/v2/model/manage/Component"], function (Component) {
  "use strict";

  var sandbox = sinon.sandbox.create();

  QUnit.module("Component", {
    beforeEach: function () {},
    afterEach: function () {
      sandbox.restore();
    },
  });

  QUnit.test("Test case", function (assert) {
    // Arrange
    sandbox.stub(Component.prototype, "createContent");

    // Act
    var COMPONENT_NAME = "com.sap.gtt.v2.model.manage";
    var component = new Component();
    var componentName = component.getComponentName();

    // Assert
    assert.strictEqual(componentName, COMPONENT_NAME, "component name is correct");
  });
});
