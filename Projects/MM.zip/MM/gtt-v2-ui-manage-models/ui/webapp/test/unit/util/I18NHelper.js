sap.ui.define(
  ["com/sap/gtt/v2/model/manage/util/I18NHelper", "sap/base/strings/formatMessage"],
  function (I18NHelper, formatMessage) {
    "use strict";

    var sandbox = sinon.sandbox.create();

    function stub(object, method, func) {
      if (!(method in object)) {
        object[method] = function () {};
      }

      var stubbed = sandbox.stub(object, method);

      if (typeof func === "function") {
        return stubbed.callsFake(func);
      }

      return stubbed;
    }

    function assertLocale(assert, language, expectLocale, actualLocale) {
      assert.strictEqual(
        actualLocale,
        expectLocale,
        formatMessage("{0} -> {1}", language, actualLocale)
      );
    }

    QUnit.module("util/I18NHelper", {
      beforeEach: function () {},
      afterEach: function () {
        sandbox.restore();
      },
    });

    QUnit.test("normalizeJavaLocale: en -> en", function (assert) {
      // Arrange

      // Act
      var language = "en";
      var locale = I18NHelper.normalizeJavaLocale(language);

      // Assert
      assertLocale(assert, language, "en", locale);
    });

    QUnit.test("normalizeJavaLocale: en-US -> en_US", function (assert) {
      // Arrange

      // Act
      var language = "en-US";
      var locale = I18NHelper.normalizeJavaLocale(language);

      // Assert
      assertLocale(assert, language, "en_US", locale);
    });

    QUnit.test("normalizeJavaLocale: zh-CN -> zh_CN", function (assert) {
      // Arrange

      // Act
      var language = "zh-CN";
      var locale = I18NHelper.normalizeJavaLocale(language);

      // Assert
      assertLocale(assert, language, "zh_CN", locale);
    });

    QUnit.test("normalizeJavaLocale: zh-TW -> zh_TW", function (assert) {
      // Arrange

      // Act
      var language = "zh-TW";
      var locale = I18NHelper.normalizeJavaLocale(language);

      // Assert
      assertLocale(assert, language, "zh_TW", locale);
    });

    QUnit.test("normalizeJavaLocale: zh-HK -> zh_HK", function (assert) {
      // Arrange

      // Act
      var language = "zh-HK";
      var locale = I18NHelper.normalizeJavaLocale(language);

      // Assert
      assertLocale(assert, language, "zh_HK", locale);
    });

    QUnit.test("normalizeJavaLocale: zh-Hans -> zh_CN", function (assert) {
      // Arrange

      // Act
      var language = "zh-Hans";
      var locale = I18NHelper.normalizeJavaLocale(language);

      // Assert
      assertLocale(assert, language, "zh_CN", locale);
    });

    QUnit.test("normalizeJavaLocale: zh-Hans-CN -> zh_CN", function (assert) {
      // Arrange

      // Act
      var language = "zh-Hans-CN";
      var locale = I18NHelper.normalizeJavaLocale(language);

      // Assert
      assertLocale(assert, language, "zh_CN", locale);
    });

    QUnit.test("normalizeJavaLocale: zh-Hant -> zh_TW", function (assert) {
      // Arrange

      // Act
      var language = "zh-Hant";
      var locale = I18NHelper.normalizeJavaLocale(language);

      // Assert
      assertLocale(assert, language, "zh_TW", locale);
    });

    QUnit.test("normalizeJavaLocale: zh-Hant-TW -> zh_TW", function (assert) {
      // Arrange

      // Act
      var language = "zh-Hant-TW";
      var locale = I18NHelper.normalizeJavaLocale(language);

      // Assert
      assertLocale(assert, language, "zh_TW", locale);
    });
  }
);
