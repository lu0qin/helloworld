sap.ui.define(
  [
    "com/sap/gtt/v2/model/manage/util/ServiceUtils",
    "com/sap/gtt/v2/model/manage/util/RestClient",
    "com/sap/gtt/v2/model/manage/util/AsyncUtils",
    "sap/ui/model/resource/ResourceModel",
  ],
  function (ServiceUtils, RestClient, AsyncUtils, ResourceModel) {
    "use strict";

    var namespace = "com.sap.gtt.v2.model.manage";
    var controllerName = namespace.concat(".controller.EventToAction");

    var sandbox = sinon.createSandbox();

    function stub(object, method, func) {
      if (!(method in object)) {
        object[method] = function () {};
      }

      var stubbed = sandbox.stub(object, method);

      if (typeof func === "function") {
        return stubbed.callsFake(func);
      }

      return stubbed;
    }

    QUnit.module(controllerName, {
      beforeEach: function () {
        this.controller = sap.ui.controller(controllerName);

        var fakeView = {};
        stub(fakeView, "byId");
        stub(this.controller, "getView").returns(fakeView);
      },
      afterEach: function () {
        sandbox.restore();
        this.controller.destroy();
      },
    });

    QUnit.test("_loadValidationMessage", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeView = controller.getView();
      stub(fakeView, "setBusy");
      stub(controller, "_getValidationRequestPayload");
      var fakeRequest = {};
      var fakePromise = {};
      stub(RestClient, "post").returns(fakeRequest);
      stub(AsyncUtils, "finally").returns(fakePromise);
      stub(fakePromise, "then");
      stub(controller, "_processValidationMessage");
      stub(controller, "showSideContent");

      // Act
      controller._loadValidationMessage();

      // Assert
      var resolveFn = fakePromise.then.firstCall.args[0];
      resolveFn({});
      assert.ok(controller._processValidationMessage.called, "function is called");
    });

    QUnit.test("_processValidationMessage", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeResourceModel = {};
      stub(fakeResourceModel, "getText");
      stub(controller, "getResourceBundle").returns(fakeResourceModel);
      var fakeData = {
        result: "fail",
        details: [
          {
            message: "",
          },
        ],
      };
      var fakeData2 = {
        result: "success",
      };
      var fakeModel = {};
      stub(controller, "getModel").returns(fakeModel);
      stub(fakeModel, "getProperty");
      stub(fakeModel, "setProperty");
      stub(fakeModel, "refresh");

      // Act
      controller._processValidationMessage(fakeData);
      controller._processValidationMessage(fakeData2);

      // Assert
      assert.ok(fakeModel.setProperty.called, "function is called");
    });

    QUnit.test("onValidateCode", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeView = {};
      stub(controller, "byId").returns(fakeView);
      stub(fakeView, "navigateBack");
      stub(controller, "_loadValidationMessage");

      // Act
      controller.onValidateCode();

      // Assert
      assert.ok(controller._loadValidationMessage.called, "function is called");
    });

    QUnit.test("hideSideContent", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeView = {};
      stub(controller, "byId").returns(fakeView);
      stub(fakeView, "setShowSideContent");
      stub(fakeView, "setEnabled");

      // Act
      controller.hideSideContent();

      // Assert
      assert.ok(fakeView.setShowSideContent.called, "function is called");
    });

    QUnit.test("showSideContent", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeView = {};
      stub(controller, "byId").returns(fakeView);
      stub(fakeView, "setShowSideContent");
      stub(fakeView, "setEnabled");

      // Act
      controller.showSideContent();

      // Assert
      assert.ok(fakeView.setShowSideContent.called, "function is called");
    });
  }
);
