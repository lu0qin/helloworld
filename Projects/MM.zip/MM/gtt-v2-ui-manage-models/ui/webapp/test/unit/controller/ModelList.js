sap.ui.define(
  [
    "com/sap/gtt/v2/model/manage/util/AsyncUtils",
    "com/sap/gtt/v2/model/manage/util/RestClient",
    "com/sap/gtt/v2/model/manage/util/ServiceUtils",
    "sap/m/MessageBox",
    "sap/m/MessageToast",
  ],
  function (AsyncUtils, RestClient, ServiceUtils, MessageBox, MessageToast) {
    "use strict";

    var namespace = "com.sap.gtt.v2.model.manage";
    var controllerName = namespace.concat(".controller.ModelList");

    var sandbox = sinon.createSandbox();

    function stub(object, method, func) {
      if (!(method in object)) {
        object[method] = function () {};
      }

      var stubbed = sandbox.stub(object, method);

      if (typeof func === "function") {
        return stubbed.callsFake(func);
      }

      return stubbed;
    }

    QUnit.module(controllerName, {
      beforeEach: function () {
        this.controller = sap.ui.controller(controllerName);

        var fakeView = {};
        stub(fakeView, "byId");
        stub(this.controller, "getView").returns(fakeView);
      },
      afterEach: function () {
        sandbox.restore();
        this.controller.destroy();
      },
    });

    QUnit.test("onInit", function (assert) {
      var controller = this.controller;

      // Arrange
      stub(controller, "initModel");
      var fakeRouter = {};
      var fakeRoute = {};
      stub(fakeRoute, "attachPatternMatched");
      stub(fakeRouter, "getRoute").returns(fakeRoute);
      stub(controller, "getRouter").returns(fakeRouter);
      var fakeEvent = {};
      stub(fakeEvent, "getParameter");
      stub(controller, "updateData");

      // Act
      controller.onInit();

      // Assert
      assert.ok(controller.initModel.called, "initModel is called");
    });

    QUnit.test("initModel", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeModel = {};
      stub(controller, "setModel");
      stub(controller, "getModel").returns(fakeModel);
      stub(fakeModel, "setProperty");

      // Act
      controller.initModel();

      // Assert
      assert.ok(controller.setModel.called, "setProperty is called");
    });

    QUnit.test("updateData", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeUri = "";
      var fakeDataSource = {
        uri: fakeUri,
      };
      var fakeModel = {};
      var fakeData = {
        value: [
          {
            namespace: "com.sap.gtt.tfo",
            description: "Track Freight Orders",
            version: "1.0.0",
            status: "DRAFT",
            draftStatus: "DEPLOYED",
            lastActionResult: "SUCCESS",
            modifiedAt: "2020-05-03T00:00:00.000Z",
            modifiedBy: "somebody2@example.com",
          },
        ],
      };
      var fakeView = controller.getView();
      stub(fakeView, "setBusy");
      var fakeList = {};
      stub(controller, "byId").returns(fakeList);
      stub(fakeList, "removeSelections");
      stub(controller, "onSelectionChange");
      stub(ServiceUtils, "getDataSource").returns(fakeDataSource);
      stub(controller, "getModel").returns(fakeModel);
      stub(fakeModel, "setProperty");
      stub(fakeModel, "refresh");
      stub(ServiceUtils, "getUrl").withArgs(fakeDataSource.uri).returns(fakeUri);
      stub(RestClient, "get");
      var fakePromise = {};
      stub(AsyncUtils, "finally").returns(fakePromise);
      stub(fakePromise, "then");

      // Action
      controller.updateData();

      // Assert
      var resolveFn = fakePromise.then.firstCall.args[0];
      resolveFn(fakeData);
      assert.ok(fakeModel.setProperty.called, "The function is called");
    });

    QUnit.test("onSelectionChange", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeList = {};
      var fakeSelectedItem = null;
      var fakeModel = {};
      stub(controller, "byId").returns(fakeList);
      stub(fakeList, "getSelectedItem").returns(fakeSelectedItem);
      stub(fakeModel, "setProperty");
      stub(controller, "getModel").withArgs("view").returns(fakeModel);

      // Act
      controller.onSelectionChange();

      // Assert
      assert.ok(controller.getModel.called, "getModel is called");
    });

    QUnit.test("onUpdateFinished", function (assert) {
      var controller = this.controller;
      var fakeLength = 1;
      var fakeResourceModel = {};
      var fakeModel = {};
      // Arrange
      stub(controller, "byId")
        .withArgs("gridList")
        .returns({
          getBinding: sinon
            .stub()
            .withArgs("items")
            .returns({
              getLength: sinon.stub().returns(fakeLength),
              isLengthFinal: sinon.stub().returns(false),
            }),
        });
      stub(controller, "getResourceBundle").returns(fakeResourceModel);
      stub(fakeResourceModel, "getText").withArgs("overviewListTitleCount");
      stub(controller, "getModel").returns(fakeModel);
      stub(fakeModel, "setProperty");

      // Act
      controller.onUpdateFinished();

      // Assert
      assert.ok(fakeResourceModel.getText.called, "getText is called");
    });

    QUnit.test("onSearch", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeBinding = {};
      var fakeList = {};
      stub(controller, "byId").returns(fakeList);
      stub(fakeList, "getBinding").withArgs("items").returns(fakeBinding);
      stub(fakeBinding, "filter");
      var event = {
        getSource: sinon.stub().returns({
          getValue: sinon.stub().returns("q"),
        }),
      };

      // Act
      controller.onSearch(event);

      // Assert
      var fakeFilter = fakeBinding.filter.firstCall.args[0];
      assert.ok(fakeFilter.sPath === "name", "The path is correct");
    });

    QUnit.test("onCreatePress", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeRouter = {};
      stub(fakeRouter, "navTo");
      stub(controller, "getRouter").returns(fakeRouter);

      // Act
      controller.onCreatePress();

      // Assert
      assert.ok(fakeRouter.navTo.called, "navTo is called");
    });

    QUnit.test("onItemPress", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeModel = {};
      var fakeItem = {
        namespace: "namespace",
      };
      var fakeListItem = {};
      var fakeRouter = {};
      var fakeEvent = {};
      stub(fakeListItem, "getBindingContext").returns(fakeItem);
      stub(fakeEvent, "getParameter").returns(fakeListItem);

      stub(fakeItem, "getProperty");
      stub(controller, "getModel").returns(fakeModel);
      stub(fakeRouter, "navTo");
      stub(controller, "getRouter").returns(fakeRouter);

      // Act
      controller.onItemPress(fakeEvent);

      // Assert
      assert.ok(fakeItem.getProperty.called, "function is called");
    });

    QUnit.test("onDeleteItem", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeList = {};
      var fakeSelectedContexts = [{ namespace: "" }];
      var fakeModel = { namespace: "", name: "" };
      stub(controller, "byId").returns(fakeList);
      stub(fakeList, "getSelectedContexts").returns(fakeSelectedContexts);
      var fakeContext = fakeSelectedContexts[0];
      stub(fakeContext, "getProperty");
      stub(fakeContext, "getObject").returns(fakeModel);
      var fakeResourceModel = {};
      stub(fakeResourceModel, "getText");
      stub(controller, "getResourceBundle").returns(fakeResourceModel);
      var fakeView = controller.getView();
      stub(fakeView, "setBusy");
      var fakeUri = "";
      var fakeDataSource = {
        uri: fakeUri,
      };
      stub(MessageBox, "warning");
      var fakeService = {};
      var fakeGetCSRFToken = {};
      stub(ServiceUtils, "getDataSource").returns(fakeDataSource);
      stub(ServiceUtils, "getUrl").withArgs(fakeDataSource.uri).returns(fakeUri);
      var fakeAlways = {};
      stub(fakeService, "then").returns(fakeAlways);
      stub(fakeAlways, "always");
      stub(ServiceUtils, "deleteJSON").returns(fakeService);
      var fakeFinally = {};
      stub(fakeGetCSRFToken, "then").returns(fakeFinally);
      stub(fakeFinally, "finally");
      stub(ServiceUtils, "getCSRFToken").returns(fakeGetCSRFToken);
      stub(controller, "updateData");
      stub(controller, "deleteModel");
      stub(fakeList, "removeSelections");
      stub(controller, "onSelectionChange");
      stub(MessageToast, "show");

      // Act
      controller.onDeleteItem();

      // Assert
      var secondeArgs = MessageBox.warning.firstCall.args[1];
      secondeArgs.onClose("DELETE");
      assert.ok(controller.deleteModel.called, "function is called");
    });
  }
);
