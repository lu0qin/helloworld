sap.ui.define(
  ["com/sap/gtt/v2/model/manage/controller/ModelDataValidator"],
  function (ModelDataValidator) {
    "use strict";

    var namespace = "com.sap.gtt.v2.model.manage";
    var controllerName = namespace.concat(".controller.ModelDataValidator");

    var sandbox = sinon.createSandbox();

    function stub(object, method, func) {
      if (!(method in object)) {
        object[method] = function () {};
      }

      var stubbed = sandbox.stub(object, method);

      if (typeof func === "function") {
        return stubbed.callsFake(func);
      }

      return stubbed;
    }

    QUnit.module(controllerName, {
      beforeEach: function () {
        var fakeResourceBundle = {};
        stub(ModelDataValidator, "getResourceBundle").returns(fakeResourceBundle);
        stub(fakeResourceBundle, "getText");

        // clear standard model flag
        ModelDataValidator._bModelIsStandard = false;
      },
      afterEach: function () {
        sandbox.restore();
      },
    });

    // ========================================================
    // Validate Data for Process Type
    // ========================================================
    QUnit.test("validateDataForProcessType: At least 1 TP", function (assert) {
      // Arrange
      var fakeSubmodels = [
        {
          name: "GTTCodeList",
          codeLists: [],
        },
      ];

      // Act
      var aErrors = ModelDataValidator.validateDataForProcessType(fakeSubmodels);

      // Assert
      assert.strictEqual(aErrors.length, 1);
    });

    // ========================================================
    // Validate Data for Code List
    // ========================================================
    QUnit.test("validateDataForValueInStandardCodeList", function (assert) {
      // Arrange
      var fakeUserDefinedValue = {
        code: "fakeCode",
        name: "fakeName",
      };
      var fakeStandardCodeList = {
        name: "standardCodeList",
        values: [fakeUserDefinedValue],
      };

      // Act
      var aErrors = ModelDataValidator.validateDataForValueInStandardCodeList(
        fakeUserDefinedValue,
        fakeStandardCodeList
      );

      // Assert
      assert.strictEqual(aErrors.length, 1);
    });

    QUnit.test("validateDataForCodeListValueStringFormat", function (assert) {
      // Arrange
      var fakeUserDefinedValue = {
        code: ";fakeCode",
        name: "fakeName",
      };
      var fakeUserDefinedCodeList = {
        name: "userDefinedCodeList",
        values: [fakeUserDefinedValue],
      };

      // Act
      var aErrors = ModelDataValidator.validateDataForValueInStandardCodeList(
        fakeUserDefinedValue,
        fakeUserDefinedCodeList
      );

      // Assert
      assert.strictEqual(aErrors.length, 1);
    });

    // ========================================================
    // Validate data for IDOC Mapping: Application Object Type
    // ========================================================
    QUnit.test("validateDataForApplicationObjectType: AOT missing or empty", function (assert) {
      // Arrange
      var fakeUserDefinedProcessType = {
        name: "userDefinedTP",
        elements: [],
        idocMapping: {
          applicationObjectType: "",
          idoc: "idoc",
          fieldMapping: [],
        },
      };

      // Act
      var aErrors = ModelDataValidator.validateDataForApplicationObjectType(
        fakeUserDefinedProcessType
      );

      // Assert
      assert.strictEqual(aErrors.length, 1);
    });

    QUnit.test(
      "validateDataForApplicationObjectType: AOT not start with letters 'zz' in Standard Model",
      function (assert) {
        // Arrange
        ModelDataValidator._bModelIsStandard = true;
        var fakeUserDefinedProcessType = {
          name: "zzUserDefinedTP",
          elements: [],
          idocMapping: {
            applicationObjectType: "notStartWithZZ",
            idoc: "idoc",
            fieldMapping: [],
          },
        };

        // Act
        var aErrors = ModelDataValidator.validateDataForApplicationObjectType(
          fakeUserDefinedProcessType
        );

        // Assert
        assert.strictEqual(aErrors.length, 1);
      }
    );

    QUnit.test("validateDataForApplicationObjectType: AOT wrong string format", function (assert) {
      // Arrange
      var fakeUserDefinedProcessType = {
        name: "userDefinedTP",
        elements: [],
        idocMapping: {
          applicationObjectType: ";aot",
          idoc: "idoc",
          fieldMapping: [],
        },
      };

      // Act
      var aErrors = ModelDataValidator.validateDataForApplicationObjectType(
        fakeUserDefinedProcessType
      );

      // Assert
      assert.strictEqual(aErrors.length, 1);
    });

    // ========================================================
    // Validate data for IDOC Mapping: IDOC
    // ========================================================
    QUnit.test("validateDataForIDocValue: Process Type: IDOC missing", function (assert) {
      // Arrange
      var fakeUserDefinedProcessType = {
        name: "userDefinedTP",
        elements: [],
        idocMapping: {
          applicationObjectType: "aot",
          idoc: "",
          fieldMapping: [],
        },
      };

      // Act
      var aErrors = ModelDataValidator.validateDataForIDocValue(
        fakeUserDefinedProcessType,
        fakeUserDefinedProcessType.name
      );

      // Assert
      assert.strictEqual(aErrors.length, 1);
    });

    QUnit.test("validateDataForIDocValue: IDOC contains blank space", function (assert) {
      // Arrange
      var fakeUserDefinedProcessType = {
        name: "userDefinedTP",
        elements: [],
        idocMapping: {
          applicationObjectType: "aot",
          idoc: "idoc  blank",
          fieldMapping: [],
        },
      };

      // Act
      var aErrors = ModelDataValidator.validateDataForIDocValue(
        fakeUserDefinedProcessType,
        fakeUserDefinedProcessType.name
      );

      // Assert
      assert.strictEqual(aErrors.length, 1);
    });

    // ========================================================
    // Validate data for IDOC Mapping: Event Code
    // ========================================================
    QUnit.test("validateDataForEventCode: Event Code contains blank space", function (assert) {
      // Arrange
      var fakeUserDefinedEventType = {
        name: "userDefinedET",
        elements: [],
        idocMapping: {
          idoc: "idoc",
          erpEventCode: "erpEventCode  blank",
          fieldMapping: [],
        },
      };
      var fakeProcessTypeName = "userDefinedTP";

      // Act
      var aErrors = ModelDataValidator.validateDataForEventCode(
        fakeUserDefinedEventType,
        fakeProcessTypeName
      );

      // Assert
      assert.strictEqual(aErrors.length, 1);
    });

    // ========================================================
    // Validate data for IDOC Mapping: Detail Mapping
    // ========================================================
    QUnit.test(
      "validateDataForIDocDetailMapping: IDOC Field contains blank space",
      function (assert) {
        // Arrange
        var fakeUserDefinedTP = {
          name: "userDefinedTP",
          elements: [
            {
              name: "uuidField",
              label: "descr - uuidField",
              type: "uuid",
              context: "CoreModel",
              key: true,
              required: true,
              localized: false,
              readable: true,
              writable: false,
            },
          ],
          idocMapping: {
            applicationObjectType: "aot",
            fieldMapping: [
              {
                field: "uuidField",
                idocSegment: "idocseg",
                idocField: "idocfield blank", // error checkpoint
              },
            ],
          },
        };

        // Act
        var aErrors = ModelDataValidator.validateDataForIDocDetailMapping(
          fakeUserDefinedTP,
          fakeUserDefinedTP.name
        );

        // Assert
        assert.strictEqual(aErrors.length, 1);
      }
    );

    QUnit.test(
      "validateDataForIDocDetailMapping: IDOC Segment contains blank space",
      function (assert) {
        // Arrange
        var fakeUserDefinedTP = {
          name: "userDefinedTP",
          elements: [
            {
              name: "uuidField",
              label: "descr - uuidField",
              type: "uuid",
              context: "CoreModel",
              key: true,
              required: true,
              localized: false,
              readable: true,
              writable: false,
            },
          ],
          idocMapping: {
            applicationObjectType: "aot",
            fieldMapping: [
              {
                field: "uuidField",
                idocSegment: "idocseg blank", // error checkpoint
                idocField: "idocfield",
              },
            ],
          },
        };

        // Act
        var aErrors = ModelDataValidator.validateDataForIDocDetailMapping(
          fakeUserDefinedTP,
          fakeUserDefinedTP.name
        );

        // Assert
        assert.strictEqual(aErrors.length, 1);
      }
    );
  }
);
