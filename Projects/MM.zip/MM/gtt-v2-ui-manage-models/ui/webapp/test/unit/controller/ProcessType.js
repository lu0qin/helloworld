sap.ui.define(
  [
    "com/sap/gtt/v2/model/manage/util/ServiceUtils",
    "sap/base/util/deepClone",
    "com/sap/gtt/v2/model/manage/constant/FieldType",
    "sap/ui/model/resource/ResourceModel",
  ],
  function (ServiceUtils, deepClone, FieldType, ResourceModel) {
    "use strict";

    var namespace = "com.sap.gtt.v2.model.manage";
    var controllerName = namespace.concat(".controller.ProcessType");

    var sandbox = sinon.createSandbox();

    function stub(object, method, func) {
      if (!(method in object)) {
        object[method] = function () {};
      }

      var stubbed = sandbox.stub(object, method);

      if (typeof func === "function") {
        return stubbed.callsFake(func);
      }

      return stubbed;
    }

    QUnit.module(controllerName, {
      beforeEach: function () {
        this.controller = sap.ui.controller(controllerName);

        var fakeView = {};
        stub(fakeView, "byId");
        stub(this.controller, "getView").returns(fakeView);
        stub(fakeView, "getId");
      },
      afterEach: function () {
        sandbox.restore();
        this.controller.destroy();
      },
    });

    QUnit.test("onInit", function (assert) {
      var controller = this.controller;

      // Arrange
      stub(controller, "initModel");
      stub(controller, "subscribeEvents");
      stub(controller, "initRoute");
      stub(controller, "initPromises");
      stub(controller, "initControls");

      // Act
      controller.onInit();

      // Assert
      assert.ok(controller.initModel.called, "initModel is called");
    });

  }
);
