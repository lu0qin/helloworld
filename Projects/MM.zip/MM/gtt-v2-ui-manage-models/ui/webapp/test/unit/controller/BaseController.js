sap.ui.define(
  [
    "com/sap/gtt/v2/model/manage/controller/BaseController",
    "sap/ui/core/UIComponent",
    "sap/ui/model/resource/ResourceModel",
  ],
  function (BaseController, UIComponent, ResourceModel) {
    "use strict";

    var namespace = "com.sap.gtt.v2.model.manage";
    var controllerName = namespace.concat(".controller.BaseController");

    var sandbox = sinon.createSandbox();

    function stub(object, method, func) {
      if (!(method in object)) {
        object[method] = function () {};
      }

      var stubbed = sandbox.stub(object, method);

      if (typeof func === "function") {
        return stubbed.callsFake(func);
      }

      return stubbed;
    }

    QUnit.module(controllerName, {
      beforeEach: function () {
        this.controller = sap.ui.controller(controllerName);

        var fakeView = {};
        stub(fakeView, "byId");
        stub(this.controller, "getView").returns(fakeView);
      },
      afterEach: function () {
        sandbox.restore();
        this.controller.destroy();
      },
    });

    QUnit.test("getStartupParameters", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeData = {};
      var fakeComponent = {};
      stub(fakeComponent, "getComponentData").returns(fakeData);
      stub(controller, "getOwnerComponent").returns(fakeComponent);

      // Act
      controller.getStartupParameters();

      // Assert
      assert.ok(fakeComponent.getComponentData.called, "function is called");
    });

    QUnit.test("setModel", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeView = controller.getView();
      stub(fakeView, "setModel");

      // Act
      controller.setModel("model object", "model name");

      // Assert
      assert.ok(fakeView.setModel.calledWith("model object", "model name"), "The model is set");
    });

    QUnit.test("getModel", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeView = controller.getView();
      stub(fakeView, "getModel");

      // Act
      controller.getModel("model name");

      // Assert
      assert.ok(fakeView.getModel.calledWith("model name"), "The model is got");
    });

    QUnit.test("getResourceBundle", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeModel = {};
      stub(fakeModel, "getResourceBundle");
      var fakeComponent = {};
      stub(fakeComponent, "getModel").returns(fakeModel);
      stub(controller, "getOwnerComponent").returns(fakeComponent);

      // Act
      controller.getResourceBundle();

      // Assert
      assert.ok(fakeModel.getResourceBundle.called, "function is called");
    });

    QUnit.test("getComponentConfig", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeComponent = {};
      stub(fakeComponent, "getManifestEntry");
      stub(controller, "getOwnerComponent").returns(fakeComponent);

      // Act
      controller.getComponentConfig();

      // Assert
      assert.ok(fakeComponent.getManifestEntry.called, "function is called");
    });

    QUnit.test("validateInput", function (assert) {
      var controller = this.controller;

      // Arrange
      var fakeEvent = {};
      var fakeBinding = {};
      var fakeValue = {};
      var fakeType = {};
      stub(fakeEvent, "getBinding").returns(fakeBinding);
      stub(fakeEvent, "getValue").returns(fakeValue);
      stub(fakeType, "validateValue").withArgs(fakeValue);
      stub(fakeBinding, "getType").returns(fakeType);
      stub(fakeEvent, "setValueState");

      // Act
      controller.validateInput(fakeEvent);

      // Assert
      assert.ok(fakeEvent.setValueState.called, "function is called");
    });
  }
);
