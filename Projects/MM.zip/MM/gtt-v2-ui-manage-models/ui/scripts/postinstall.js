const { emptyDir, copy } = require('./fsext');

const dir = {
  webapp: 'webapp',
  node_modules: 'node_modules',
  dist: 'dist',
  vendor: 'webapp/vendor',
};

function getLibFilePaths() {
  const libs = {
    'swagger-ui-dist': ['swagger-ui-bundle.js', 'swagger-ui.css'],
  };

  const filePaths = Object.entries(libs).reduce((paths, [lib, files]) => {
    const newPaths = files.reduce((results, file) => {
      const group = [`${lib}/${file}`, `${lib}/${file}.map`];

      Array.prototype.push.apply(results, group);

      return results;
    }, []);

    Array.prototype.push.apply(paths, newPaths);

    return paths;
  }, []);

  return filePaths;
}

(async function () {
  await emptyDir(dir.vendor);

  const filePaths = getLibFilePaths();

  for (const filePath of filePaths) {
    const srcPath = `${dir.node_modules}/${filePath}`;
    const destPath = `${dir.vendor}/${filePath}`;
    await copy(srcPath, destPath);
    console.log('File copied:', destPath);
  }
})();
