const path = require('path');
const fsPromises = require('fs').promises;

async function copy(src, dest) {
  await ensureDir(path.dirname(dest));

  return fsPromises.copyFile(src, dest);
}

async function emptyDir(dir) {
  await ensureDir(dir);
  const files = await fsPromises.readdir(dir);

  for (const file of files) {
    const filePath = path.join(dir, file);
    await rimraf(filePath);
  }
}

async function ensureDir(dir) {
  const exist = await pathExists(dir);
  if (exist) {
    return;
  }

  return fsPromises.mkdir(dir);
}

async function pathExists(file) {
  var promise = fsPromises
    .access(file)
    .then(() => true)
    .catch((error) => {
      // console.warn(error);
      return false;
    });

  return promise;
}

async function rimraf(file) {
  const stats = await fsPromises.lstat(file);

  if (stats.isDirectory()) {
    return rmdir(file);
  } else {
    return fsPromises.unlink(file);
  }
}

async function rmdir(dir) {
  const files = await fsPromises.readdir(dir);

  for (const file of files) {
    const filePath = path.join(dir, file);
    await rimraf(filePath);
  }

  return fsPromises.rmdir(dir);
}

module.exports = {
  copy,
  emptyDir,
  ensureDir,
  pathExists,
  rimraf,
};
