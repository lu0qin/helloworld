# gtt v2 manage modes UI repository

GTT V2 Manage Models UI

## Pre-requisites

- Node.js - https://nodejs.org/

### Node.js

```sh
$ node -v
v12.18.2

$ npm -v
6.4.1
```

Set registry to internal site

```sh
$ npm config set registry http://nexus.wdf.sap.corp:8081/nexus/content/groups/build.milestones.npm/
```

```sh
npm install
```

## Run

### SAPUI5 Application

Run web application in a local web server.

```sh
cd ui
npm start
```

You can visit http://localhost:5000/test/localhost.html in the browser.

Run opa test and unit test in a local browser

```sh
cd ui
npm run test:debug
```
